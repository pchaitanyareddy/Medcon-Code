import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialService } from '../../services/trial.service';
import { Trial } from '../../models/trial';
import { Pagination } from '../../models/pagination';

@Injectable()
export class TrialsResolve implements Resolve<(Pagination<Trial>)> {
	constructor(private trialService: TrialService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(Pagination<Trial>)>
		| Promise<(Pagination<Trial>)>
		| (Pagination<Trial>) {
		return this.trialService
			.getTrials(route.params['customer_id'], route.queryParams['page'], route.queryParams['perPage']);
	}
}
