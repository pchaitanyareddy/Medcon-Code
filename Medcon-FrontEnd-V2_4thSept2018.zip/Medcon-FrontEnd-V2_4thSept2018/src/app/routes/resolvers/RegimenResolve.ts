import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RegimenService } from '../../services/regimen.service';
import { Regimen } from '../../models/regimen';

@Injectable()
export class RegimenResolve implements Resolve<Regimen> {
	constructor(private regimenService: RegimenService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Regimen> | Promise<Regimen> | Regimen {
		return this.regimenService.getRegimen(route.params['id']);
	}
}
