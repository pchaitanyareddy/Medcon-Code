﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { ExportService } from '../../services/export.service';
import { Export } from '../../models/export';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { saveAs } from 'file-saver';
import { ReportService } from '../../services/report.service';
import { UserService } from '../../services/user.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './export-list.component.html?v=${new Date().getTime()}'
})

export class ExportListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public exports: Pagination<Export>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public user: any;
    public selectedCompanyId: any = 'all';
    public selectedCompany: string;
    public maxSize: number = 5;
    public currentPage: number = 1;
    exportList: any;
    privilegesByModule: any;
    privilegesList: any;
    companyList: any;
    public privileges: Privileges;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private exportService: ExportService,
        private cognitoUtil: CognitoUtil,
        private reportService: ReportService,
        private userService: UserService,
        private url: LocationStrategy) {

          }

    public ngOnInit(): void {
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.exports = this.route.snapshot.data['trialGroups'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        //if (this.currentUserRole === UserRole.MedConAdmin) {
        //    this.exportService.getExportList(this.selectedCustomerId)
        //        .subscribe((companyexport) => {
        //            this.exports = companyexport;
        //        }
        //        );
        //}

        //this.exportList = [
        //    { exportId: 1, companyName: 'Company1', CompanyID: 'comp001', trailName: 'Test Trail1', trialID: 'Trail001', drugRegimenName: 'Drug1/Once a Day', drugRegimenPairID:'Drug001_Reg001' },
        //    { exportId: 2, companyName: 'Company2', CompanyID: 'comp002', trailName: 'Test Trail2', trialID: 'Trail002', drugRegimenName: 'Drug2/Once a Day', drugRegimenPairID: 'Drug001_Reg002' },
        //    { exportId: 3, companyName: 'Company3', CompanyID: 'comp003', trailName: 'Test Trail3', trialID: 'Trail003', drugRegimenName: 'Drug3/Once a Day', drugRegimenPairID: 'Drug001_Reg003' },
        //    { exportId: 4, companyName: 'Company1', CompanyID: 'comp001', trailName: 'Test Trail1', trialID: 'Trail001', drugRegimenName: 'Drug4/Once a Day', drugRegimenPairID: 'Drug001_Reg004' },
        //    { exportId: 5, companyName: 'Company2', CompanyID: 'comp002', trailName: 'Test Trail2', trialID: 'Trail002', drugRegimenName: 'Drug5/Once a Day', drugRegimenPairID: 'Drug001_Reg005' },
        //    { exportId: 6, companyName: 'Company3', CompanyID: 'comp003', trailName: 'Test Trail3', trialID: 'Trail003', drugRegimenName: 'Drug6/Once a Day', drugRegimenPairID: 'Drug001_Reg006' },
        //    { exportId: 7, companyName: 'Company1', CompanyID: 'comp001', trailName: 'Test Trail1', trialID: 'Trail001', drugRegimenName: 'Drug7/Once a Day', drugRegimenPairID: 'Drug001_Reg007' },
        //    { exportId: 8, companyName: 'Company2', CompanyID: 'comp002', trailName: 'Test Trail2', trialID: 'Trail002', drugRegimenName: 'Drug8/Once a Day', drugRegimenPairID: 'Drug001_Reg008' },
        //    { exportId: 9, companyName: 'Company3', CompanyID: 'comp003', trailName: 'Test Trail3', trialID: 'Trail003', drugRegimenName: 'Drug9/Once a Day', drugRegimenPairID: 'Drug001_Reg009' },
        //    { exportId: 10, companyName: 'Company1', CompanyID: 'comp001', trailName: 'Test Trail1', trialID: 'Trail001', drugRegimenName: 'Drug10/Once a Day', drugRegimenPairID: 'Drug001_Reg0010' },
        //    { exportId: 11, companyName: 'Company2', CompanyID: 'comp002', trailName: 'Test Trail2', trialID: 'Trail002', drugRegimenName: 'Drug11/Once a Day', drugRegimenPairID: 'Drug001_Reg0011' },
        //    { exportId: 12, companyName: 'Company3', CompanyID: 'comp003', trailName: 'Test Trail3', trialID: 'Trail003', drugRegimenName: 'Drug12/Once a Day', drugRegimenPairID: 'Drug001_Reg0012' },
        //    { exportId: 13, companyName: 'Company1', CompanyID: 'comp001', trailName: 'Test Trail1', trialID: 'Trail001', drugRegimenName: 'Drug13/Once a Day', drugRegimenPairID: 'Drug001_Reg0013' },
        //    { exportId: 14, companyName: 'Company2', CompanyID: 'comp002', trailName: 'Test Trail2', trialID: 'Trail002', drugRegimenName: 'Drug14/Once a Day', drugRegimenPairID: 'Drug001_Reg0014' },

        //]

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Export')

        this.userService.getAllCompanies().subscribe(
            (response) => {
                this.companyList = response;
                //this.allCompanyList.filter(company => company.companyId === this.selectedCompanyId);
            },
            (err) => {
                this.errorMessage = err;

            });
    }

    public ngAfterViewInit(): void {


        this.loadExportLabelsData(Number(localStorage.getItem('GLOBAL_COMPANY_ID')));


    }

    public exportNow(companyId, trialId, drugRegimenId): void {
        
        try {
            let isFileSaverSupported = !!new Blob();
        } catch (e) {
            alert('Browser not supported');
            return;
        }

        //let params: URLSearchParams = new URLSearchParams();
        //params.set('trial_id', String(trialId || ''));
        //params.set('customer_id', String(customerId || ''));
        //if (filters) {
        //    filters.forEach((filter) => {
        //        params.set(filter.key, String(filter.value || ''));
        //    });
        //}

        //this.http.get(API_PATH + '/report/adherence/export', { search: params })
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'))
        //    .subscribe((response) => {
        //        let blob = new Blob([decodeURIComponent(encodeURI(response.text()))], {
        //            type: 'text/csv;charset=utf-8;'
        //        });

        //        let filename = 'medcon dose export.csv';
        //        saveAs(blob, filename);
        //    });

        var response = "Company Id, Trial Id, Drug Regimen Id"+"\n"+companyId + "," +trialId +"," + drugRegimenId;

        let blob = new Blob([decodeURIComponent(encodeURI(response))], {
            type: 'text/csv;charset=utf-8;'
        });

        let filename = 'medcon dose export.csv';
        saveAs(blob, filename);
    }


    //public customerChanged(): void {
    //    this.exportService.getExportList(this.selectedCustomerId).subscribe((companyexport) => {
    //        this.exports = companyexport;
    //        this.url.pushState(null, null, '/' + this.selectedCustomerId + '/export', '');
    //    });
    //}

    //public pageChanged(event: any): void {
    //    let queryParams = new URLSearchParams();
    //    queryParams.set('page', event.page);
    //    queryParams.set('per_page', event.itemsPerPage);

    //    this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
    //    this.exportService.getExportList(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((companyexport) => {
    //        this.exports = companyexport;
    //    });
    //}

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    onChange(selectedValue) {
        $("#datatable").dataTable().fnDestroy();
        this.selectedCompanyId = this.getCompanyIdCompanyName(selectedValue);
        this.loadExportLabelsData(this.selectedCompanyId);
    }

    getCompanyIdCompanyName(companyName): number {
        let companyId = 0;
        if (this.companyList != null) {
            for (var i = 0; i < this.companyList.length; i++) {
                if (this.companyList[i].companyName == companyName) {
                    companyId = this.companyList[i].companyId;
                }
            }

        }
        return companyId;
    }

    loadExportLabelsData(companyId)
    {

        //$('#datatable').DataTable();
        //$('#datatable').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});
        var self = this;

        this.cognitoUtil.getIdToken({
            callback() {
                / tslint:disable:no-empty /
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {

                        //'url': 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/exportdata?companyId=' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')),
                        'url': CommonService.API_PATH_V2_EXPORT_LABEL_DATA + 'label/exportdata?companyId=' + companyId,


                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export',
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_EXPORT_LABEL_DATA + 'label/exportdata?companyId=' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '&draw=1&columns%5B0%5D%5Bdata%5D=companyName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=companyId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=trialName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=trialId&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=drugRegimenName&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=drugRegimenId&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() + '&search%5Bregex%5D=false&_=1535546403868'
                                self.reportService.ExportAll(apiUrl, 'Export Label');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "companyName" },
                        { "data": "companyId" },
                        { "data": "trialName" },
                        { "data": "trialId" },
                        { "data": "drugRegimenName" },

                        { "data": "drugRegimenId" }

                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                //return "<div class=\"btn-action\"><a href=\"#/" + 52 + "/trialgroup/" + full.id + "/Export\" class=\"btn btn-primary btn-xs\"><i class=\"glyphicon glyphicon-export\" > </i> Export</a> </div>";
                                return "<div class=\"btn-action\"><button  id=\"" + full.companyId + "_" + full.trialId + "_" + full.drugRegimenId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-upload\" > </i> Export</button> </div>";
                            }
                        }


                    ],
                    "columnDefs": [

                        //{
                        //    "targets": [3],
                        //    "visible": false
                        //}
                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                });
            }
        });


        $('#datatable tbody').on('click', 'td button', function () {
            //alert('hello');
            //alert($(this).attr('id'));
            //alert($('button').text());
            var attId = $(this).attr('id');
            var companyId = attId.split("_")[0];
            var trialId = attId.split("_")[1];
            var drugRegimenId = attId.split("_")[2];

            self.exportNow(companyId, trialId, drugRegimenId);



        });

    }

}
