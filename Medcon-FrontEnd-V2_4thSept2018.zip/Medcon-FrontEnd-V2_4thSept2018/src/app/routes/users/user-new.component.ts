import { UserCreateRequest } from '../../requests/user-create-request';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { UserService } from '../../services/user.service';
import { Observable } from 'rxjs/Observable';
import { UserRole } from '../../models/userrole';
import { CurrentUserService } from '../../services/currentuser.service';
import { CognitoUser } from '../../models/cognito-user';
//import { CompanyService } from '../../services/company.service';
enum Roles {
    'MedconAdmin',
    'CustomerAdmin',
    'LabelUser',
    'CustomerUser',
    'Patient'
}

enum Companies {

    'ABC Pharmaticual',
    'Test1',
    'Test2'
}

@Component({
    templateUrl: './user-new.component.html?v=${new Date().getTime()}'
})

export class UserNewComponent implements OnInit {
	public user: FormGroup;
	public showErrors: boolean;
    public errorMessage: string;
    public successMessage: string;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    companyOptions: string[];
    Companies: typeof Companies = Companies;
    defaultRole;
    defaultCompany;
    loggedInCompany; 
    public UserRole: typeof UserRole = UserRole;
    public loggedInUserRole: string;
    public currentUserRole: UserRole;
    //public loggedInUser: CognitoUser = new CognitoUser(-1, '', '', -1);
    public allRoleList: any;
    public allCompanyList: any;
    selectedRoleId: number;
    selectedRoleName: string;
    selectedCompany: string;
    selectedCompanyId: number;
    isLoading: boolean;
	constructor(public templateService: TemplateService,
		public router: Router,
        public userService: UserService,
        public currentUserService: CurrentUserService,
        //public companyService: CompanyService,
		private fb: FormBuilder,
        private route: ActivatedRoute) {

        this.currentUserService.getRole().subscribe((role) => {
            if (role === UserRole.MedConAdmin) {
                
                this.loggedInUserRole = "MedConAdmin";
            }
            
        }, (err) => {
            //if (err.message === 'Token is null') {
            //    this.userService.logout();
            //}
            });

        
	}

    public ngOnInit() {
        this.isLoading = false;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        
		this.user = this.fb.group({
            firstName: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            lastName: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            emailAddress: [
				'', [Validators.required,
					Validators.pattern('^[a-zA-Z0-9]+(\.[_a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,15})$')]
            ],
            phoneNumber: ['', Validators.required],
            role: [''],
            password: [''],
            company:  ['']
        });

        //alert(this.currentUserRole);
        var x = Roles;
        var options = Object.keys(Roles);
        this.options = options.slice(options.length / 2);
        this.defaultRole = this.options[1];
        var z = Companies;
        var companyOptions = Object.keys(Companies);
        this.companyOptions = companyOptions.slice(companyOptions.length / 2);
        this.defaultCompany = this.companyOptions[0];
        //this.loggedInCompany = this.companyOptions[0];
        //this.loggedInUserRole = this.loggedInUser.role;
        //this.loggedInCompany = this.loggedInUser.name;
        //alert(this.loggedInUserRole);

       // this.allRoleList = this.userService.getAllRoles();
        //this.allCompanyList = this.userService.getAllCompanies();
        //alert(this.defaultRole);
        this.selectedRoleId = 1;
        this.selectedRoleName = 'MedCon Admin';
        this.userService.getAllRoles().subscribe(
            (response) => {
                this.allRoleList = response;
                
            },
            (err) => {
                this.errorMessage = err;
                
            });
        //if (this.loggedInUserRole == "MedConAdmin") {
            this.userService.getAllCompanies().subscribe(
                (response) => {
                    this.allCompanyList = response;
                    //this.allCompanyList.filter(company => company.companyId === this.selectedCompanyId);
                },
                (err) => {
                    this.errorMessage = err;

                });

            //this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');

        //}
        //else
        //{
            //this.allCompanyList = [
            //    { companyId: 1, companyName: 'ABC Pharmaticual' },
            //]

            

        //}
        //alert(this.userService.getAllRoles()[0].roleName);
        //this.allRoleList = this.userService.getAllRoles();
        //alert(this.allRoleList.length);
    }

    public ngAfterViewInit() {
        //this.loggedInCompany = (<HTMLInputElement>document.getElementById("companyName")).value;
        //alert(this.loggedInCompany);
    }

    public onSubmit() {
        this.showErrors = false;
        this.errorMessage = "";
        let selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        //alert(this.selectedRoleName);
        //alert(this.user.invalid)
		if (this.user.invalid) {
			this.showErrors = true;
			return;
        }
        this.isLoading = true;
        //this.selectedRoleId = 2;
		this.route.params.subscribe((params) => {
            let request = new UserCreateRequest(
                +params['customer_id'],
                this.user.value.firstName,
                this.user.value.lastName,
                this.user.value.emailAddress,
                this.user.value.phoneNumber,
                //this.user.value.password,
                //this.user.value.dateOfBirth,
                //this.user.value.gender,
                //this.user.value.raceName,
                this.selectedRoleName,
                this.selectedRoleId,
                selectedCompanyId,
                //this.user.value.createdBy,
                //this.user.value.createdDate,
                //this.user.value.lastUpdatedBy,
                //this.user.value.lastUpdatedDate,
                this.user.value.active
			);

            //alert(this.selectedRoleId);
			this.userService.createUser(request).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.user.markAsPristine();
                    this.successMessage = "Successfully Created User";
                    $(window).scrollTop(5);
					this.goBack();
				},
				(err) => {
				        this.isLoading = false;
					this.errorMessage = err;
				});
		});
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

    public goBack(): void {
        //alert(this.selectedCompanyId);
		this.user.markAsPristine();
        //this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'users']);
        this.router.navigate(['/', this.selectedCompanyId, 'users']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.user.dirty;
    }
    //Code added by ramesh on 21st Nov 2017
    public sendPassword(): void {
        alert('send');
        this.isLoading = true;
        this.userService.sendPassword(this.user.value.sub, this.route.snapshot.params['customer_id'])
            .subscribe(
            (response) => {
                this.isLoading = false;
                this.successMessage = 'Password has been emailed to the user';
            },
            (err) => {
                this.errorMessage = err;
            }
            );
    }

    onChange(selectedValue) {
        this.selectedRoleId = Number(selectedValue);
        //this.selectedRoleName = null;
        //To get selected role name
        if (this.allRoleList != null)
            {
              for (var i = 0; i < this.allRoleList.length; i++) {
                if (this.allRoleList[i].roleId == this.selectedRoleId) {
                    this.selectedRoleName = this.allRoleList[i].roleName;
                }
            }

        }

    }
}
