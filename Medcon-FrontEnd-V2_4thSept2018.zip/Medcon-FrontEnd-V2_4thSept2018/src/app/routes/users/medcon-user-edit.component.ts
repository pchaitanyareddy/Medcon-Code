import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { UserService } from '../../services/user.service';
import 'rxjs/add/operator/switchMap';
import { UserMedConCreateRequest } from '../../requests/user-medcon-create-request';
import { User } from '../../models/user';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './medcon-user-edit.component.html'
})

export class MedConUserEditComponent implements OnInit {
	public successMessage: string;
	public errorMessage: string;
	public form: FormGroup;
	public showErrors: boolean;
	public user: User;

	constructor(public templateService: TemplateService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		private userService: UserService) {
	}

	public ngOnInit(): void {
		this.user = this.route.snapshot.data['user'];

		this.form = this.fb.group({
			givenName: [this.user.givenName, Validators.required],
			familyName: [this.user.familyName, Validators.required],
			email: [this.user.email]
		});
	}

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
			return;
		}

		let request = new UserMedConCreateRequest(
			this.form.value.givenName,
			this.form.value.familyName
		);

		this.userService.updateMedConUser(this.user.sub, request)
			.subscribe(
				(response) => {
					this.form.markAsPristine();
					this.successMessage = 'User successfully updated';
				},
				(err) => {
					this.errorMessage = err;
				}
			);

	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public resetPassword(): void {
		this.userService.resetMedConUser(this.user.sub)
			.subscribe(
				(response) => {
					this.successMessage = 'Password reset instructions have been emailed to the user';
				},
				(err) => {
					this.errorMessage = err;
				}
			);
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate(['/medcon-users']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}
}
