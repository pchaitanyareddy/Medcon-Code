export * from './drugs-list.component';
export * from './drug-new.component';
export * from './drug-edit.component';
