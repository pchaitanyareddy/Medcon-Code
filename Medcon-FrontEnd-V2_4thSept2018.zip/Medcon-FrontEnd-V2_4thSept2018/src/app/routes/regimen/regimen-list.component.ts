import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { RegimenService } from '../../services/regimen.service';
import { Regimen } from '../../models/regimen';
import { UserRole } from '../../models/userrole';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './regimen-list.component.html?v=${new Date().getTime()}'
})

export class RegimenListComponent implements OnInit {
	@ViewChild('deleteModal') public deleteModal: ModalDirective;
	public regimenToDelete: any;
	public regimens: Pagination<Regimen>;
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public successMessage: string;
	public errorMessage: string;
    public deleteContainers: string;
    isLoading: boolean
	public maxSize: number = 5;
	public currentPage: number = 1;
    privilegesByModule: any;
    privilegesList: any;
    selectedRegimenId: number;
    public privileges: Privileges;
    duration: any;
    days: any;
    hours: any;
    minutes: any;
	constructor(public templateService: TemplateService,
		private route: ActivatedRoute,
        private url: LocationStrategy,
        private cognitoUtil: CognitoUtil,
        private reportService: ReportService,
		private regimenService: RegimenService) {
	}

    public ngOnInit(): void {
    this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
		this.currentUserRole = this.route.snapshot.data['role'];
		this.regimens = this.route.snapshot.data['regimens'];

		if (this.route.queryParams['page']) {
			this.currentPage = this.route.queryParams['page'];
        }


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Regimen')

        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
    }

    public ngAfterViewInit(): void {

        //$('#datatable').DataTable();
        this.loadRegimenList();
    }

    public deleteDuplicateItem(regimenId): void {

        //this.selectedRegimenId=id
		this.regimenService.getRegimen(regimenId).subscribe((regimen) => {
			this.regimenToDelete = regimen;
			this.deleteContainers = (regimen.containersTotal > 0) ?
				regimen.containersTotal + ' unused container(s) assigned to this ' +
				'regimen will also be removed if you proceed.' :
				null;
			
		});
    }
    public deleteItem(id): void {
        this.selectedRegimenId = id;
        this.deleteModal.show();
    }


	public hideDeleteModal(): void {
		this.regimenToDelete = null;
		this.deleteModal.hide();
	}

	public confirmDelete(): void {
		let regimen = this.regimenToDelete;
		this.regimenService
            .deleteRegimen(this.selectedRegimenId)
			.subscribe(
				(response) => {
					//this.regimenService
					//	.getRegimens(this.route.snapshot.params['customer_id'])
					//	.subscribe((regimens) => {
					//		this.regimens = regimens;
					//		this.successMessage = 'regimen has been successfully deleted';
     //                       //this.hideDeleteModal();
     //                       location.reload();
     //                   });
                    this.successMessage = 'regimen has been successfully deleted';
                
                    this.hideDeleteModal();
                    location.reload();
				},
				(err) => {
					this.errorMessage = err;
					this.hideDeleteModal();
				}
			);
	}

	public pageChanged(event: any): void {
		let queryParams = new URLSearchParams();
		queryParams.set('page', event.page);
		queryParams.set('per_page', event.itemsPerPage);

		this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
		this.regimenService
			.getRegimens(this.route.snapshot.params['customer_id'], event.page, event.itemsPerPage)
			.subscribe((regimens) => this.regimens = regimens);
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public convertMinutes(totalMinutes: number): string {
		return this.regimenService.convertMinutesToString(totalMinutes);
    }

    public loadRegimenList(): void {
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/regimen/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_LIST_ALL_REGIMENS+'regimen/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export',
                            exportOptions: {
                                columns: [0, 1, 2,3, 4,5]
                            },
                           
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_LIST_ALL_REGIMENS + 'regimen/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=4&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=trialName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=TrialGroups&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Company&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=startDate&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=endDate&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=15'
                                self.reportService.ExportAll(apiUrl, 'Regimen List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            } }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "regimenName" },
                        { "data": "unitsPerDose" },
                        { "data": "totalDoses" },
                        { "data": "extraDoses" },
                        { "data": "durationBetweenDoses" },
                        { "data": "scheduleType" },
                        { "data": "id" },
                        { "data":"status"}
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.numPairs > 0) {
                                        localStorage.setItem(full.id, full.numPairs);
                                        return "<div class=\"btn-action\"><a  id=\"btnEdit\" title=\"Cannot edit this Regimen as this Regimen already associated with trial\" href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.id + "/view\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a><button disabled title=\"Cannot delete this Regimen as this Regimen already associated with trial\" id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a  disabled title=\"Cannot Edit this Regimen as this Regimen is already Deleted\" id=\"btnEdit\" " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button disabled title=\"Cannot delete this Regimen as this Regimen is already Deleted\" id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a  id=\"btnEdit\" href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {

                                    if (full.numPairs > 0) {
                                        localStorage.setItem(full.id, full.numPairs);
                                        return "<div class=\"btn-action\"><a  id=\"btnEdit\" title=\"Cannot edit this Regimen as this Regimen already associated with trial\" href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.id + "/view\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a></div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a  disabled title=\"Cannot Edit this Regimen as this Regimen is already Deleted\" id=\"btnEdit\" " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a  id=\"btnEdit\" href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {

                                    if (full.numPairs > 0) {
                                        localStorage.setItem(full.id, full.numPairs);
                                        return "<div class=\"btn-action\"><button disabled title=\"Cannot delete this Regimen as this Regimen already associated with trial\" id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button disabled title=\"Cannot delete this Regimen as this Regimen is already Deleted\" id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }

                                }
                                else {
                                    return "";
                                }
                               
                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</a> </div>";
                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/regimens/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(sub){  localStorage.setItem('ID', String(sub)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script> </div>";
                                
                            }
                        }

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [6],
                            "visible": false
                        },
                    {
                        "targets": [7],
                        "visible": false,
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                        ,
                        {
                            "targets": [4],
                            render: function (data, type, row) {
                                //alert(self.convertMinutes(data));
                                //this.duration = self.convertMinutes(data);
                                //this.days = this.duration.days;
                                //this.hours = this.duration.hours;
                                //this.minutes = this.duration.minutes;
                                return self.convertMinutes(data);
                            }
                        }
                        //,

                        //{
                        //    "render": (data, type, full) => {
                        //        return $.map(full['medicationAmount'].concat(full['medicationUnit']), function (d, i) {
                        //            return d.given + ' ' + d.family;
                        //        }).join(',<br />');
                        //    },
                        //    "targets": [3],
                        //    'searchable': false, 
                        //},

                        //{
                        //    "targets": [4],
                        //    "searchable": false
                        //}
                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                    "drawCallback": function (settings, json) {
                        //alert('DataTables has finished its initialisation.');
                        //alert(json.data[0].PatientID);
                        $("#datatable td").each(function () {
                            var id = $(this).text();

                            if ($.isNumeric(id)) {
                                var num = id;

                                var commaNum = numberWithCommas(num);
                                $(this).text(commaNum);
                            }
                        });
                        function numberWithCommas(number) {
                            var parts = number.toString().split(".");
                            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            return parts.join(".");
                        }
                    }
                });
            }
        });


        $('#datatable').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            this.selectedRegimenId = buttonId;
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });
        $('#datatable tbody').on("click", 'tr', function (evt) {


            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });


        //if (this.privilegesByModule[0].edit == 1)
        //{
        //    alert('display edit');
        //   // $("#btnEdit").css("display", "block");
        //    $('#btnEdit').show();
        //}
        //else
        //{
        //    alert('not display edit');
        //    //alert('do not display edit');
        //    //$("#btnEdit").css("display", "none");
        //    $('#btnEdit').hide();
        //}

        //if (this.privilegesByModule[0].delete == 1) {
        //    //alert('display delete button');
        //   // $("#btnDelete").css("display", "block");
        //    $('#btnDelete').show();
        //}
        //else {
        //    //alert('do not display delete button');
        //    //$("#btnDelete").css("display", "none");
        //    $('#btnDelete').hide();
        //}



    }
}
