import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialService } from '../../services/trial.service';
import { SettingsService } from '../../services/settings.service';
import { Customer } from '../../models/customer';
import { TrialRequest } from '../../requests/trial-request';
import { Site } from '../../models/site';
import { Observable } from 'rxjs/Observable';

@Component({
    templateUrl: './trial-new.component.html?v=${new Date().getTime()}'
})

export class TrialNewComponent implements OnInit {
	public form: FormGroup;
	public showErrors: boolean;
	public customer: Customer;
	public sites: Site[];
    public errorMessage: string;
    public trialGroupList: any;
	public startDateOptions: IMyOptions = {
		dateFormat: 'mm/dd/yyyy',
	};
	public endDateOptions: IMyOptions = {
		dateFormat: 'mm/dd/yyyy',
	};
    selectedTrialGroupId: number;
    selectedTrialGroupName: string;
    isLoading: boolean;
    successMessage: string;
	constructor(public templateService: TemplateService,
		private route: ActivatedRoute,
		public router: Router,
		private fb: FormBuilder,
		private trialService: TrialService,
        private settingsService: SettingsService) {

        this.trialGroupList = [
            { id: 1, trialGroupName: 'Test group name1' },
            { id: 2, trialGroupName: 'Test group name2' },
            { id: 4, trialGroupName: 'Test group name3' },
            { id: 5, trialGroupName: 'Test group name4' },
            { id: 6, trialGroupName: 'Test group name5' },
        ]
	}

    public ngOnInit(): void {
        this.isLoading = false;
		this.customer = this.route.snapshot.data['customer'];
		//this.sites = this.route.snapshot.data['sites'];
       		
			this.form = this.fb.group({
				
				name: ['', Validators.required],
				startDate: ['', Validators.required],
                endDate: ['', Validators.required],
                trialGroup: [''],
			});
          

            this.trialService.getAllTrialGroupsDropDown(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
                (response) => {
                    this.trialGroupList = response.trailgroups;

                },
                (err) => {
                    this.errorMessage = err;

                });

            this.disablePastDates();
            
            this.selectedTrialGroupId = 1;
    }

   

    public disablePastDates()
    {
        var todayDate = new Date();
        var month = todayDate.getMonth();
        month = Number(month) + 1;
        var day = todayDate.getDate();
        day = Number(day) - 1;
        let date = this.dateForView(todayDate.getFullYear() + '-' + month + '-' + day);
        //alert(todayDate.getFullYear() + '-' + month + '-' + todayDate.getDate());
        //alert(todayDate.getFullYear() + '-' + month + '-' + day);
        this.setStartDateDisableUntil(date.date);
        this.setEndDateDisableUntil(date.date);

    }

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
        }
        //else if (String(this.selectedTrialGroupId) == 'NaN' || this.selectedTrialGroupId == undefined) {

        //    this.showErrors = true;
        //    this.errorMessage = "Please Select TrialGroup Name"
        //}
        else if (this.trialService.IsStartDateGreaterThanEndDate(this.convertDate(this.form.value.startDate.date), this.convertDate(this.form.value.endDate.date))) {

            this.showErrors = true;
            this.errorMessage = "Start Date should be Less than End Date"
        }
        else {
            
            this.isLoading = true;
            let request = new TrialRequest(
                this.form.value.name,
                this.convertDate(this.form.value.startDate.date),
                this.convertDate(this.form.value.endDate.date),
                Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID')),
                (String(this.selectedTrialGroupId) == 'NaN') ? 0 : this.selectedTrialGroupId
			);

            this.trialService.createTrial(request, Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.successMessage = 'Trial has been successfully created';
					this.form.markAsPristine();
					this.goBack();
				},
                (err) => {
                    this.isLoading = false;
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'trials']);
	}

	public onDateChange(event: IMyInputFieldChanged, field): void {
		let d = event.value.split('/');
		let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

		if (event.valid) {
			if (field === 'start') {
				this.setEndDateDisableUntil(date.date);
			} else if (field === 'end') {
				this.setStartDateDisableSince(date.date);
			}
		}
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

	private setStartDateDisableSince(date) {
		let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
		copy.disableSince = date;
		this.startDateOptions = copy;
	}

	private setEndDateDisableUntil(date) {
		let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
		copy.disableUntil = date;
		this.endDateOptions = copy;
    }

    private setStartDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableUntil = date;
        this.startDateOptions = copy;
    }

	private convertDate(date: any): string {
		return (date) ? date.year + '-' + date.month + '-' + date.day : '';
	}

	private dateForView(date: string): any {
		if (date) {
			let d = date.split('-');
			return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2] } };
		} else {
			return '';
		}
	}

	private getCopyOfDateOptions(date): IMyOptions {
		return JSON.parse(JSON.stringify(date));
    }

    onChangeTrialGroip(selectedValue) {
        this.selectedTrialGroupId = Number(selectedValue);
        this.selectedTrialGroupName = null;
        //To get selected role name
        if (this.trialGroupList != null) {
            for (var i = 0; i < this.trialGroupList.length; i++) {
                if (this.trialGroupList[i].id == this.selectedTrialGroupId) {
                    this.selectedTrialGroupName = this.trialGroupList[i].name;
                }
            }

        }

    }


}
