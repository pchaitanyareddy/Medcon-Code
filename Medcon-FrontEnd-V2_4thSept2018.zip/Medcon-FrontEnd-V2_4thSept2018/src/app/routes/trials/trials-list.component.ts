import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LocationStrategy } from '@angular/common';
import { URLSearchParams } from '@angular/http';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { Trial } from '../../models/trial';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { TrialService } from '../../services/trial.service';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './trials-list.component.html?v=${new Date().getTime()}'
})

export class TrialsListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public trials: Pagination<Trial>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customer: Customer;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public deleteContainers: string;
    public deletePatients: string;
    public trialToDelete: Trial;

    public maxSize: number = 5;
    public currentPage: number = 1;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    selectedCompanyId: number;
    isLoading: boolean;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private router: Router,
        private customerService: CustomerService,
        private reportService: ReportService,
        private privilegesService: PrivilegesService,
        private url: LocationStrategy,
        private cognitoUtil: CognitoUtil,
        private trialService: TrialService) {
    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        this.privileges = this.route.snapshot.data['privileges'];
        this.currentUserRole = this.route.snapshot.data['role'];
        this.customer = this.route.snapshot.data['customer'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.privilegesList = this.privileges;
        // Trials list and pagination setup
        //this.trials = this.route.snapshot.data['trials'];
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Trials')

        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        //alert('list length' +this.privilegesByModule.length);
        //alert(this.privilegesByModule[0].add);
    }

    public ngAfterViewInit(): void {

        //$('#datatable').DataTable(); 
        //$('#datatable').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        this.loadTrialsList();
    }

    public viewTrial(trial): void {
        this.router.navigate(['/', this.selectedCustomerId, 'trials', trial.id, 'view']);
    }

    public customerChanged(): void {
        this.trialService.getTrials(this.selectedCustomerId, null, null).subscribe((trials) => {
            this.trials = trials;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/trials', '');
        });
    }

    public deleteItem(trial: Trial): void {
        this.trialToDelete = trial;
        this.trialService.getPatients(trial.id, this.customer.id).subscribe((patients) => {
            this.deleteContainers = (trial.containers.count > 0) ?
                trial.containers.count + ' unused container(s) that are assigned to this trial ' +
                'will also be removed if you proceed.' :
                null;
            this.deletePatients = (patients.length > 0) ?
                patients.length + ' patients that are assigned to this trial ' +
                'will also be removed if you proceed.' :
                null;
            this.deleteModal.show();
        });
    }

    public hideDeleteModal(): void {
        this.trialToDelete = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        let trial = this.trialToDelete;
        this.trialService
            .deleteTrial(Number(localStorage.getItem('ID')))
            .subscribe(
            (response) => {
                //this.trialService
                //	.getTrials(this.selectedCustomerId)
                //	.subscribe((trials) => {
                //		this.trials = trials;
                //		//this.successMessage = trial.name + ' has been successfully deleted';
                //                       this.successMessage = 'trial has been successfully deleted';
                //		//this.hideDeleteModal();
                //                       location.reload();
                //	});

                this.successMessage = 'trial has been successfully deleted';
                //this.hideDeleteModal();
                location.reload();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.trialService.getTrials(event.page, event.itemsPerPage).subscribe((trials) => this.trials = trials);
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public formatDate(date: string): string {
        return this.trialService.formatDate(date);
    }

    public loadTrialsList(): void {
      /*

        var oldExportAction = function (self, e, dt, button, config) {
            if (button[0].className.indexOf('buttons-excel') >= 0) {
                if ($.fn.dataTable.ext.buttons.excelHtml5.available(dt, config)) {
                    $.fn.dataTable.ext.buttons.excelHtml5.action.call(self, e, dt, button, config);
                }
                else {
                    $.fn.dataTable.ext.buttons.excelFlash.action.call(self, e, dt, button, config);
                }
            } else if (button[0].className.indexOf('buttons-print') >= 0) {
                $.fn.dataTable.ext.buttons.print.action(e, dt, button, config);
            }
        };

        var newExportAction = function (e, dt, button, config) {
            var self = this;
            var oldStart = dt.settings()[0]._iDisplayStart;

            dt.one('preXhr', function (e, s, data) {
                // Just this once, load all data from the server...
                data.start = 0;
                data.length = 2147483647;
                //alert(JSON.stringify(data));
                var jsonData = JSON.stringify(data);
                //alert(jsonData);
                dt.one('preDraw', function (e, settings) {
                    // Call the original action function 
                    oldExportAction(self, e, dt, button, config);

                    dt.one('preXhr', function (e, s, data) {
                        // DataTables thinks the first item displayed is index 0, but we're not drawing that.
                        // Set the property to what it was before exporting.
                        settings._iDisplayStart = oldStart;
                        data.start = oldStart;
                        //alert(JSON.stringify(data));
                    });

                    // Reload the grid with the original page. Otherwise, API functions like table.cell(this) don't work properly.
                    setTimeout(dt.ajax.reload, 0);

                    // Prevent rendering of the full data to the DOM
                    return false;
                });
            });
            alert(dt.data);
            // Requery the server with the new one-time export settings
            dt.ajax.reload();
            
        };

        */
       


        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable').DataTable({
                    //"scrollY": 500,
                    //"scrollX": true,
                    "processing": true,
                    "serverSide": true,
                    "rowId": "Id",
                    'ajax': {
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_TRIAL_LIST+'trial/list/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_LIST + 'trial/list/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=1&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=startDate&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=endDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=labelsUsed&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=males&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=females&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=containers&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=false&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=Id&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() + '&search%5Bregex%5D=false&_=1535094371654'
                                self.reportService.ExportAll(apiUrl, 'Trial List');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0,1,2,3,4,5,6,7]
                            }
                        }

                    ],
                    
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "trialName" },
                        { "data": "startDate" },
                        { "data": "endDate" },
                        { "data": "labelsUsed" },
                        { "data": "males" },
                        { "data": "females" },
                        { "data": "containers" },
                        { "data": "status" },
                        { "data": "Id" }
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                var endDate = new Date(full.endDate);
                                var todayDate = new Date();
                                var trailStatus = todayDate < endDate


                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0 && trailStatus == false) {
                                        return "<div class=\"btn-action\"><a disabled title=\"Cannot Edit this Trial as it is already completed\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it has already deleted\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it has already deleted\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                    else if (full.containers > 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already containers associated with it \"  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                    else if (full.containers == 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                  
                                    else {
                                        return "<div  class=\"btn-action\"><a disabled title=\"Cannot Edit this Trial as it is already completed\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already completed\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }



                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {

                                    if (full.containers > 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                    }
                                    else if (full.containers == 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                    }
                                   
                                    else {
                                        return "<div  class=\"btn-action\"><a disabled title=\"Cannot Edit this Trial as it is already completed\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it has already deleted\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script></div> ";
                                    }
                                    else if (full.containers > 0 && trailStatus == true) {
                                        return "<div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already containers associated with it\"  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                    }
                                    else if (full.containers == 0 && trailStatus == true) {
                                        return "<div id=\"disableDelete\"><button  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                   
                                    else {
                                        return "<div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already completed\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                    //return "<div class=\"btn-action\"><button onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                }
                                else
                                {

                                    return "";
                                }
                            }
                        }

                    ],
                    "columnDefs": [

                        {
                            "targets": [8],
                            "visible": false
                        },
                        {
                            "targets": [7],
                            "orderable": false,
                            render: function (data, type, row) {

                                var startDate = new Date(row.startDate);
                                var endDate = new Date(row.endDate);
                                var todayDate = new Date();
                                //alert(startDate);
                                //alert(endDate);
                                //alert(todayDate)
                                if (startDate <= todayDate && todayDate <= endDate) {
                                    return "<span class=\"btn-xs trial-status complete\" >A</span>";

                                }
                                if (todayDate > endDate) {
                                    return "<span class=\"btn-xs trial-status active\" >C</span>";

                                }
                                if (todayDate < startDate) {
                                    return "<span class=\"btn-xs trial-status pending\" >P</span>";

                                }
                                //return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                });
            }
        });


        $('#datatable tbody').on("click", 'tr', function (evt) {
            //var data = $('#datatable').row(this).data();
            //alert(data.firstName);
            //alert($(this).index());
            //alert(evt.target);
            if (!$(evt.target).is("button") && !$(evt.target).is("a")) {
                var attId = $(this).attr('id');
                //alert(attId);
                
                self.viewTrial_V2(attId);

            }

            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });


    }

    public viewTrial_V2(id): void {
        //alert(id);
        if (id != undefined) {
            this.isLoading = true;
            this.router.navigate(['/', this.selectedCompanyId, 'trials', id, 'view']);
        }
    }

    public ExportAll(): void {

        this.trialService.ExportAll();
    }
}
