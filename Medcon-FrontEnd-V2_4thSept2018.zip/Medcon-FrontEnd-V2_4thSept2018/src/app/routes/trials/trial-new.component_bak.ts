import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialService } from '../../services/trial.service';
import { SettingsService } from '../../services/settings.service';
import { Customer } from '../../models/customer';
import { TrialRequest } from '../../requests/trial-request';
import { Site } from '../../models/site';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './trial-new.component.html'
})

export class TrialNewComponent implements OnInit {
	public form: FormGroup;
	public showErrors: boolean;
	public customer: Customer;
	public sites: Site[];
	public errorMessage: string;
	public durationError: boolean;
	public earlyDosingThreshholdError: boolean;
	public days = [];
	public hours = [];
	public minutes = [];
	public thresholdDays: number;
	public thresholdHours: number;
	public thresholdMinutes:number;
	public startDateOptions: IMyOptions = {
		dateFormat: 'mm/dd/yyyy',
	};
	public endDateOptions: IMyOptions = {
		dateFormat: 'mm/dd/yyyy',
	};
	constructor(public templateService: TemplateService,
		private route: ActivatedRoute,
		public router: Router,
		private fb: FormBuilder,
		private trialService: TrialService,
		private settingsService: SettingsService) {
		//ramesh added by 13th oct 2017
		// Days 
		for (let i = 0; i < 31; i++) {
			this.days.push(i);
		}
		// Hours
		for (let i = 0; i < 24; i++) {
			this.hours.push(i);
		}
		// Minutes
		for (let i = 0; i < 60; i++) {
			this.minutes.push(i);
		}
	}

	public ngOnInit(): void {
	this.form = this.fb.group({
			thresholdDays: [0],
			thresholdHours: [0],
			thresholdMinutes: [0]
			});
		this.customer = this.route.snapshot.data['customer'];
		this.sites = this.route.snapshot.data['sites'];
		if (this.customer.dosageAdherenceBenchmark == null) {
			this.settingsService.getSetting('industry_adherence_target')
				.subscribe((setting) => {
					this.form.controls['adherenceTarget'].setValue(setting.value);
				});
		}

		if (this.sites.length > 0) {
			this.form = this.fb.group({
				site: [this.sites[0].id, Validators.required],
				name: ['', Validators.required],
				startDate: ['', Validators.required],
				endDate: ['', Validators.required],
				adherenceTarget: [this.customer.dosageAdherenceBenchmark,
					Validators.pattern(/^(\d{0,2}(\.\d{1,2})?|100(\.00?)?)$/)],
				enrolmentTarget: [''],
				type: ['schedule', Validators.required]
			});
		}
	}

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
		} else {
			let request = new TrialRequest(
				this.form.value.site,
				this.form.value.name,
				this.form.value.adherenceTarget,
				this.form.value.enrolmentTarget,
				this.form.value.type,
				this.convertDate(this.form.value.startDate.date),
				this.convertDate(this.form.value.endDate.date)
				/*this.form.value.thresholdDays
				this.form.value.thresholdHours,
				this.form.value.thresholdMinutes */
			);

			this.trialService.createTrial(request).subscribe(
				(response) => {
					this.form.markAsPristine();
					this.goBack();
				},
				(err) => {
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate([this.customer.id, 'trials']);
	}

	public onDateChange(event: IMyInputFieldChanged, field): void {
		let d = event.value.split('/');
		let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

		if (event.valid) {
			if (field === 'start') {
				this.setEndDateDisableUntil(date.date);
			} else if (field === 'end') {
				this.setStartDateDisableSince(date.date);
			}
		}
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

	private setStartDateDisableSince(date) {
		let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
		copy.disableSince = date;
		this.startDateOptions = copy;
	}

	private setEndDateDisableUntil(date) {
		let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
		copy.disableUntil = date;
		this.endDateOptions = copy;
	}

	private convertDate(date: any): string {
		return (date) ? date.year + '-' + date.month + '-' + date.day : '';
	}

	private dateForView(date: string): any {
		if (date) {
			let d = date.split('-');
			return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2].replace('0', '') } };
		} else {
			return '';
		}
	}

	private getCopyOfDateOptions(date): IMyOptions {
		return JSON.parse(JSON.stringify(date));
	}
}
