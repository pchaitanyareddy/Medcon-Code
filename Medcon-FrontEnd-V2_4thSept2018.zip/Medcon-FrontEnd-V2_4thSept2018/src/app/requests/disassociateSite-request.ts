﻿export class DisassociateSiteRequest {
    constructor(
        public siteTrailId: number,
        public userId: number
    ) {
    }
}
