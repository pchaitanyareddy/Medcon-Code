﻿export class CompanyRequest {
    constructor(
        public userId: number,
        public companyName: string,
        public companyAdherenceTarget: number,
        public companyType: string,
        public address: string,
        public countryId: number,
        public stateId: number,
        public cityName: string,
        public zipcode: number,
        public phoneNumber: number,
        //public countryName?: string,
        //public stateName?: string
        //public createdBy: string,
        //public createdDate: string,
        //public lastUpdatedBy: string,
        //public lastUpdatedDate: string,
        //public active: string,
        //public allowToEdit: number,
        //public allowToDelete: number
    ) {
    }
}
