export class PatientRequest {
	constructor(public patientNumber: string,
		public trial: number,
		public sex: string,
		public race: number,
		public dob: string) {
	}
}
