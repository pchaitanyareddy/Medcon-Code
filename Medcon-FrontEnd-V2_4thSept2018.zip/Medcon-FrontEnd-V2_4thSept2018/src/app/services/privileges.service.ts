﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Pagination } from '../models/pagination';
import { Privileges } from '../models/privileges';
import { MedConUser } from '../models/medconuser';
import { UserMedConCreateRequest } from '../requests/user-medcon-create-request';
import { UserPreferenceRequest } from '../requests/user-preference-request';
import { PrivilegesRequest } from '../requests/privileges-request';
import {CommonService} from '../services/commonService';
@Injectable()
export class PrivilegesService {
    constructor(private http: Http) {
    }

    //public getPrivileges(customerId: number, roleId: number,page?: number, perPage?: number): Observable<(Pagination<Privileges>)> {
    //    //let params: URLSearchParams = new URLSearchParams();
    //    //if (page) {
    //    //    params.set('page', String(page));
    //    //}
    //    //if (perPage) {
    //    //    params.set('per_page', String(perPage));
    //    //}

    //    //return { "moduleName": "Patient", "type": "Pharmaceutical", "id": 52, "dosageAdherenceBenchmark": 80.0, "name": "ABC Pharma Global" };

    //    //return this.http.get("http://localhost/Test/privilegesData.json", { search: params })
    //    //    .map((res: Response) => res.json())
    //    //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    //    let params: URLSearchParams = new URLSearchParams();
    //    if (page) {
    //        params.set('page', String(page));
    //    }
    //    if (perPage) {
    //        params.set('per_page', String(perPage));
    //    }

    //    return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
    //        .map((res: Response) => res.json())
    //        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //}

    //To get the all privileges list
    //public getPrivileges(roleId: number,
    //    page?: number, perPage?: number,
    //    sortField?: string,
    //    sortOrder?: string): Observable<(Pagination<Privileges>)> {
    //    let params: URLSearchParams = new URLSearchParams();
    //    params.set('sortField', sortField);
    //    params.set('sortOrder', sortOrder);
    //    if (page) {
    //        params.set('page', String(page));
    //    }
    //    if (perPage) {
    //        params.set('per_page', String(perPage));
    //    }
    //    //To fix the runtime errors, commented this code, once service is available then uncomment it
    //    //return this.http.get(API_PATH + '/privileges/lists', { search: params })
    //    //    .map((res: Response) => {
    //    //        let response = res.json();
    //    //        response.items = [];
    //    //        res.json().items.forEach((item) => {
    //    //            response.items.push(item);
    //    //        });

    //    //        return response;
    //    //    })
    //    //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    //        return this.http.get(API_PATH + '/user/list/' + 1, { search: params })
    //        .map((res: Response) => res.json())
    //        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //}

    public updatePrivileges(finalJsonString: string, roleId: number): Observable<(any)> {
        
        //return this.http.put('https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/roles/privileges/' + roleId, finalJsonString)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_PRIVILEGES+'roles/privileges/' + roleId, finalJsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getPrivileges(roleId:number)
    {
        
        //return this.http.get('https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/roles/privileges/' + roleId)
        return this.http.get(CommonService.API_PATH_V2_GET_PRIVILEGES+'roles/privileges/' + roleId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
       
    }

    public getPrivilegesByModule(roleId: number, moduleName: string)
    {

     return   [
            //{
            //    "status": true,
            //    "moduleName": "Patient",
            //    "edit": 0,
            //    "add": 1,
            //    "view": 1,
            //    "id": 1,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Data Reports",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 2,
            //    "delete": 1
            //},
            {
                "status": true,
                "moduleName": "Trials",
                "edit": 0,
                "add": 0,
                "view": 1,
                "id": 3,
                "delete": 0
            }
            //,
            //{
            //    "status": true,
            //    "moduleName": "Trial Group",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 4,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Pharmaceutical Company",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 5,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Label Manufacturer",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 6,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Drugs",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 7,
            //    "delete": 112
            //},
            //{
            //    "status": true,
            //    "moduleName": "Regimen",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 8,
            //    "delete": 111
            //},
            //{
            //    "status": true,
            //    "moduleName": "Alerts",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 9,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Schedules",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 10,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Import",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 11,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Notifications",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 12,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Users",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 13,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Customers",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 14,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "Manage Customer Users",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 15,
            //    "delete": 1
            //},
            //{
            //    "status": true,
            //    "moduleName": "MCC Settings",
            //    "edit": 1,
            //    "add": 1,
            //    "view": 1,
            //    "id": 16,
            //    "delete": 1
            //}
        ]


    }

    
}
