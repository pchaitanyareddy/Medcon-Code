﻿import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { LabelService } from './label.service';
import { Company } from '../models/company';
import { CompanyRequest } from '../requests/companyrequest';
import { Pagination } from '../models/pagination';
import { CompanyType } from '../models/companytype';
import { Country } from '../models/country';
import { State } from '../models/state';
import { CompanyEditRequest } from '../requests/companyEdit-request';
import {CommonService} from '../services/commonService';

@Injectable()
export class CompanyService {
    constructor(private http: Http) {
    }

    public createCompany(request: CompanyRequest): Observable<(any)> {
        
        //return this.http.post('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company', request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_COMPANY+'company', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getCompaniesAll(): Observable<(Company[])> {
        return this.http.get(API_PATH + '/company/lists/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getCompany(id: number): Observable<(Company)> {
        return this.http.get(API_PATH + '/company/' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getCompanyTypesAll(): Observable<(CompanyType[])> {
        return this.http.get(API_PATH + '/company/type/lists/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    

    public updateCompany(id: number, request: CompanyEditRequest): Observable<(any)> {
        
        //return this.http.put('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/update/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_COMPANY+'company/update/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        //return this.http.put(API_PATH + '/company/' + id, request)
        //    .map((res: Response) => res.status === 200)
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //public updateMyCompany(id: number, request: any): Observable<(any)> {
    //    return this.http.put(API_PATH + '/customer/my-company/' + id, request)
    //        .map((res: Response) => res.status === 200)
    //        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //}

    public deleteCompany(id: number): Observable<(any)> {
        
        //return this.http.delete('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_COMPANY+'company/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getCountries(): Observable<(Country[])> {
        
        //return this.http.get('https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/masterdata/list/countries')
        return this.http.get(CommonService.API_PATH_V2_LIST_OF_COUNTRIES+'masterdata/list/countries')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getStatesByCountry(countryId: number): Observable<(State[])> {
        //if (countryId == 1) {
        //    return  [{ id: 1, name: 'New york' },]
        //}
        //else if (countryId == 2) {
        //    return [
        //        { id: 1, name: 'Telangana' },
        //        { id: 2, name: 'AndhraPradesh' },

        //    ]
        //}
        
        //return this.http.get('https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/masterdata/list/countries/' + countryId + '/states')
        return this.http.get(CommonService.API_PATH_V2_LIST_OF_STATES+'masterdata/list/countries/' + countryId + '/states')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getCompanyOverviewInformation(companyId: number): any {
        {
            return [
                {
                    companyId: 1, companyName: '', companyType: '', phoneNumber: '', addressLine1: '', city: '', state: '', zipCode: ''
                    , country: '', totalPatients: 0, totalMalePatients: 0, totalFemalePatients: 0, totalDosesManaged: 0, totalDoseUnitsManaged: 0, totalContainersManaged: 0, totalDrugs: 0, totalRegimens: 0, customerUsers: 0, companyAdmin: 0, trialAdmin: 0, companyAdherenceTarget: 0, actualCompanyAdherence: 0, companyTargetDelta: 0,
                    totalActiveTrails: 0, totalPendingTrials: 0, totalCompletedTrials: 1, lablesCommitted: 0, labelsPurchased: 0, lablesUsed: 0, labelsRemaining: 0

                },
            ]

        }
    }

    public getAllCompanies(): any {
        //return [
        //    { companyId: 1, companyName: 'ABC Pharmaticual' },
        //    { companyId: 2, companyName: 'Test1' },
        //    { companyId: 3, companyName: 'Test2' },

        //]
        
        //return this.http.get('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/list/all')
        //return this.http.get('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/list/all')
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_COMPANIES+'company/list/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getSelectedCompany(companyId: number): any {
        
        //return this.http.get('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/' + companyId)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_COMPANY+'company/' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }


    public getCompanyOverview(companyId: number): any {
        
        //return this.http.get('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/overview?companyId=' + companyId)
        return this.http.get(CommonService.API_PATH_V2_COMPANY_OVERVIEW+'company/overview?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }

    public getCompanyOverview_LabelDetails(companyId: number, year: number): any {
        
        //return this.http.get('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/details/' + companyId + '?year=' + year)
        return this.http.get(CommonService.API_PATH_V2_GET_LABEL_DETAILS+'label/details/' + companyId + '?year=' + year)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }



    
}

