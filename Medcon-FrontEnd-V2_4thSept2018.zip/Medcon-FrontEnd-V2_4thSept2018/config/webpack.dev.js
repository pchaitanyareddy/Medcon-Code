/**
 * @author: @AngularClass
 */

const helpers = require('./helpers');
const webpackMerge = require('webpack-merge'); // used to merge webpack configs
const webpackMergeDll = webpackMerge.strategy({plugins: 'replace'});
const commonConfig = require('./webpack.common.js'); // the settings that are common to prod and dev

/**
 * Webpack Plugins
 */
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin');
const DefinePlugin = require('webpack/lib/DefinePlugin');
const NamedModulesPlugin = require('webpack/lib/NamedModulesPlugin');
const LoaderOptionsPlugin = require('webpack/lib/LoaderOptionsPlugin');

/**
 * Webpack Constants
 */
const ENV = process.env.ENV = process.env.NODE_ENV = 'development';
const HOST = process.env.HOST || 'localhost';
const PORT = process.env.PORT || 3000;
const HMR = helpers.hasProcessFlag('hot');
const API_PATH = process.env.API_PATH || 'https://dev-api.med-conllc.com';
const API_PATH_V2 = process.env.API_PATH || 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev';
const GLOBAL_COMPANY_ID = 2;
const API_PATH_V2_CREATE_MEDCON_USER= 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V1_UPDATE_MEDCON_USER= 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_MEDCON_USER_LIST= 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_MEDCON_USER_LIST_ALL='https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_SELECTED_MEDCON_USER='https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_MEDCON_USER_STATUS='https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_MEDCON_USER_LOGIN_TIME='https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_MEDCON_USER='https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_COMPANY='https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_COMPANY='https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_COMPANIES='https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_ALL_COMPANIES= 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_ROLES= 'https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_PRIVILEGES= 'https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_PRIVILEGES='https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_REGIMEN='https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_REGIMEN='https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_REGIMEN= 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_ALL_REGIMENS= 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_TRIAL_GROUP= 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_TRIAL_GROUP='https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_TRIAL_GROUP= 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_ALL_TRIAL_GROUPS='https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_SITE='https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_SITE='https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_SITES= 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_ALL_SITES='https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_MEASUREMENT='https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_MEASUREMENT='https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_MEASUREMENTS='https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_ALL_MEASUREMENTS='https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_DRUG='https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_DRUG='https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_DRUGS= 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_ALL_DRUGS='https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_OF_COUNTRIES= 'https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_OF_STATES= 'https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_OF_RACES='https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_TRIAL='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_LIST='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_LIST_ALL='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_TRIAL_UPDATE='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_DRUG_REGIMEN_PAIR='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_TRIAL_OPTION='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_PATIENT_ALERTS='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_IMPORT_PATIENTS='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_VALIDATE_CONTAINER='https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev';
const API_PATH_V2_GET_SELECTED_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_PATIENT_USER = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_MEDCON_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_PATIENT_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_PROFILE = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_USER_PROFILE = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_PREFERENCES = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_PREFERENCES = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_PATIENT_DETAILS = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_SUMMARY = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_LIST = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_PATIENT_OVERVIEW_DASHBOARD = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_PATIENT_LIST = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_COMPANY='https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_COMPANY='https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_COMPANY_OVERVIEW = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_REGIMEN='https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_REGIMEN='https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_GROUP_NOTIN_TRAIL= 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_TRIAL_GROUP= 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_TRIAL_GROUP = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_SITE='https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SITE_NOTIN_TRAIL = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_SITE = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_MEASUREMENT_STATUS='https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_DRUGS = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_DRUGS = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_OVERVIEW = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_DRUG_REGIMEN_VIEW='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_TRITRATE_DRUG_REGIMEN_PAIR='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_DRUG_REGIMEN_PAIR='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_PATIENTS='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_PATIENTS_CONTAINER='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_PATIENTS_TRITRATE='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIAL_CONTAINER='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_TRIAL_OPTIONS='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_PATIENT_ALERTS='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_PATIENT_ALERTS='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ASSOCIATE_TRAILGROUP = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ADD_ASSOCIATE_TRAILGROUP='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DISASSOCIATE_TRAILGROUP='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ASSOCIATE_SITE='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DISSOCIATE_SITE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TRIALGROUP_UNDER_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ADD_ASSOCIATE_SITE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LIST_SITES_UNDER_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER_MOBILE = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev';
const API_PATH_V2_GET_CONTAINER_INFO_FOR_ATTACH_PATIENT_HISTORY = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev';
const API_PATH_V2_UPLOAD_DOSE = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DOSE_OVERVIEW = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DOSE_HISTORY = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DOSE_TRACK = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_ADHERENCE_INFO = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_COMPALIANCE_INFO = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_COMMITTED_DOSE = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DATA_REPORT = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_DOSAGE_WINDOW = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_DOSAGE_WINDOW = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_ALERT_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_ALERT_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_NOTIFICATION_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_NOTIFICATION_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_TIME_ZONE = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_ALL_TIME_ZONE = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_SELECTED_TIME_ZONE = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_LIST_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_COMMIT_LABEL_PURCHASE = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_PURCHASE_LABEL = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_LIST_LABEL_PURCHASE = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_UPDATE_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_DELETE_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_LIST_LABEL_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_SELECTED_LABEL_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_EXPORT_LABEL_DATA = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_CREATE_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_EDIT_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_GET_LIST_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_TITRATE_REPORT = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/';
const API_PATH_V2_LABEL_REPORT = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/';
const METADATA = webpackMerge(commonConfig({env: ENV}).metadata, {
	host: HOST,
	port: PORT,
	ENV: ENV,
	HMR: HMR,
	API_PATH: API_PATH,
	GLOBAL_COMPANY_ID: GLOBAL_COMPANY_ID,
	API_PATH_V2_CREATE_MEDCON_USER: API_PATH_V2_CREATE_MEDCON_USER
});


const DllBundlesPlugin = require('webpack-dll-bundles-plugin').DllBundlesPlugin;

/**
 * Webpack configuration
 *
 * See: http://webpack.github.io/docs/configuration.html#cli
 */
module.exports = function (options) {
	return webpackMerge(commonConfig({env: ENV}), {

		/**
		 * Developer tool to enhance debugging
		 *
		 * See: http://webpack.github.io/docs/configuration.html#devtool
		 * See: https://github.com/webpack/docs/wiki/build-performance#sourcemaps
		 */
		devtool: 'cheap-module-source-map',

		/**
		 * Options affecting the output of the compilation.
		 *
		 * See: http://webpack.github.io/docs/configuration.html#output
		 */
		output: {

			/**
			 * The output directory as absolute path (required).
			 *
			 * See: http://webpack.github.io/docs/configuration.html#output-path
			 */
			path: helpers.root('dist'),

			/**
			 * Specifies the name of each output file on disk.
			 * IMPORTANT: You must not specify an absolute path here!
			 *
			 * See: http://webpack.github.io/docs/configuration.html#output-filename
			 */
			filename: '[name].bundle.js',

			/**
			 * The filename of the SourceMaps for the JavaScript files.
			 * They are inside the output.path directory.
			 *
			 * See: http://webpack.github.io/docs/configuration.html#output-sourcemapfilename
			 */
			sourceMapFilename: '[file].map',

			/** The filename of non-entry chunks as relative path
			 * inside the output.path directory.
			 *
			 * See: http://webpack.github.io/docs/configuration.html#output-chunkfilename
			 */
			chunkFilename: '[id].chunk.js',

			library: 'ac_[name]',
			libraryTarget: 'var',
		},

		module: {

			rules: [
				{
					test: /\.ts$/,
					use: [
						{
							loader: 'tslint-loader',
							options: {
								configFile: 'tslint.json'
							}
						}
					],
					exclude: [/\.(spec|e2e)\.ts$/]
				},

				/*
				 * css loader support for *.css files (styles directory only)
				 * Loads external css styles into the DOM, supports HMR
				 *
				 */
				{
					test: /\.css$/,
					use: ['style-loader', 'css-loader'],
					include: [helpers.root('src', 'styles')]
				},

				/*
				 * sass loader support for *.scss files (styles directory only)
				 * Loads external sass styles into the DOM, supports HMR
				 *
				 */
				{
					test: /\.scss$/,
					use: ['style-loader', 'css-loader', 'sass-loader'],
					include: [helpers.root('src', 'styles')]
				},


			]

		},

		plugins: [

			/**
			 * Plugin: DefinePlugin
			 * Description: Define free variables.
			 * Useful for having development builds with debug logging or adding global constants.
			 *
			 * Environment helpers
			 *
			 * See: https://webpack.github.io/docs/list-of-plugins.html#defineplugin
			 */
			// NOTE: when adding more properties, make sure you include them in custom-typings.d.ts
			new DefinePlugin({
				'ENV': JSON.stringify(METADATA.ENV),
				'HMR': METADATA.HMR,
				'process.env': {
					'ENV': JSON.stringify(METADATA.ENV),
					'NODE_ENV': JSON.stringify(METADATA.ENV),
					'HMR': METADATA.HMR,
				},
				'API_PATH': JSON.stringify(METADATA.API_PATH),
				'GLOBAL_COMPANY_ID': JSON.stringify(METADATA.GLOBAL_COMPANY_ID),
				'API_PATH_V2_CREATE_MEDCON_USER': JSON.stringify(METADATA.API_PATH_V2_CREATE_MEDCON_USER),
				'API_PATH_V2_UPDATE_MEDCON_USER': JSON.stringify(METADATA.API_PATH_V2_UPDATE_MEDCON_USER),
				'API_PATH_V2_GET_MEDCON_USER_LIST': JSON.stringify(METADATA.API_PATH_V2_GET_MEDCON_USER_LIST),
				'API_PATH_V2_GET_MEDCON_USER_LIST_ALL': JSON.stringify(METADATA.API_PATH_V2_GET_MEDCON_USER_LIST_ALL),
				'API_PATH_V2_DELETE_SELECTED_MEDCON_USER': JSON.stringify(METADATA.API_PATH_V2_DELETE_SELECTED_MEDCON_USER),
				'API_PATH_V2_UPDATE_MEDCON_USER_STATUS': JSON.stringify(METADATA.API_PATH_V2_UPDATE_MEDCON_USER_STATUS),
				'API_PATH_V2_UPDATE_MEDCON_USER_LOGIN_TIME': JSON.stringify(METADATA.API_PATH_V2_UPDATE_MEDCON_USER_LOGIN_TIME),
				'API_PATH_V2_GET_SELECTED_MEDCON_USER': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_MEDCON_USER),
				'API_PATH_V2_CREATE_COMPANY': JSON.stringify(METADATA.API_PATH_V2_CREATE_COMPANY),
				'API_PATH_V2_UPDATE_COMPANY': JSON.stringify(METADATA.API_PATH_V2_UPDATE_COMPANY),
				'API_PATH_V2_LIST_COMPANIES': JSON.stringify(METADATA.API_PATH_V2_LIST_COMPANIES),
				'API_PATH_V2_LIST_ALL_COMPANIES': JSON.stringify(METADATA.API_PATH_V2_LIST_ALL_COMPANIES),
				'API_PATH_V2_GET_ROLES': JSON.stringify(METADATA.API_PATH_V2_GET_ROLES),
				'API_PATH_V2_GET_PRIVILEGES': JSON.stringify(METADATA.API_PATH_V2_GET_PRIVILEGES),
				'API_PATH_V2_UPDATE_PRIVILEGES': JSON.stringify(METADATA.API_PATH_V2_UPDATE_PRIVILEGES),
				'API_PATH_V2_CREATE_REGIMEN': JSON.stringify(METADATA.API_PATH_V2_CREATE_REGIMEN),
				'API_PATH_V2_UPDATE_REGIMEN': JSON.stringify(METADATA.API_PATH_V2_UPDATE_REGIMEN),
				'API_PATH_V2_LIST_REGIMEN': JSON.stringify(METADATA.API_PATH_V2_LIST_REGIMEN),
				'API_PATH_V2_LIST_ALL_REGIMENS': JSON.stringify(METADATA.API_PATH_V2_LIST_ALL_REGIMENS),
				'API_PATH_V2_CREATE_TRIAL_GROUP': JSON.stringify(METADATA.API_PATH_V2_CREATE_TRIAL_GROUP),
				'API_PATH_V2_UPDATE_TRIAL_GROUP': JSON.stringify(METADATA.API_PATH_V2_UPDATE_TRIAL_GROUP),
				'API_PATH_V2_LIST_TRIAL_GROUP': JSON.stringify(METADATA.API_PATH_V2_LIST_TRIAL_GROUP),
				'API_PATH_V2_LIST_ALL_TRIAL_GROUPS': JSON.stringify(METADATA.API_PATH_V2_LIST_ALL_TRIAL_GROUPS),
				'API_PATH_V2_CREATE_SITE': JSON.stringify(METADATA.API_PATH_V2_CREATE_SITE),
				'API_PATH_V2_UPDATE_SITE': JSON.stringify(METADATA.API_PATH_V2_UPDATE_SITE),
				'API_PATH_V2_LIST_SITES': JSON.stringify(METADATA.API_PATH_V2_LIST_SITES),
				'API_PATH_V2_LIST_ALL_SITES': JSON.stringify(METADATA.API_PATH_V2_LIST_ALL_SITES),
				'API_PATH_V2_CREATE_MEASUREMENT': JSON.stringify(METADATA.API_PATH_V2_CREATE_MEASUREMENT),
				'API_PATH_V2_UPDATE_MEASUREMENT': JSON.stringify(METADATA.API_PATH_V2_UPDATE_MEASUREMENT),
				'API_PATH_V2_LIST_MEASUREMENTS': JSON.stringify(METADATA.API_PATH_V2_LIST_MEASUREMENTS),
				'API_PATH_V2_LIST_ALL_MEASUREMENTS': JSON.stringify(METADATA.API_PATH_V2_LIST_ALL_MEASUREMENTS),
				'API_PATH_V2_CREATE_DRUG': JSON.stringify(METADATA.API_PATH_V2_CREATE_DRUG),
				'API_PATH_V2_UPDATE_DRUG': JSON.stringify(METADATA.API_PATH_V2_UPDATE_DRUG),
				'API_PATH_V2_LIST_DRUGS': JSON.stringify(METADATA.API_PATH_V2_LIST_DRUGS),
				'API_PATH_V2_LIST_ALL_DRUGS': JSON.stringify(METADATA.API_PATH_V2_LIST_ALL_DRUGS),
				'API_PATH_V2_LIST_OF_COUNTRIES': JSON.stringify(METADATA.API_PATH_V2_LIST_OF_COUNTRIES),
				'API_PATH_V2_LIST_OF_STATES': JSON.stringify(METADATA.API_PATH_V2_LIST_OF_STATES),
				'API_PATH_V2_LIST_OF_RACES': JSON.stringify(METADATA.API_PATH_V2_LIST_OF_RACES),
				'API_PATH_V2_CREATE_TRIAL': JSON.stringify(METADATA.API_PATH_V2_CREATE_TRIAL),
				'API_PATH_V2_GET_TRIAL_LIST': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_LIST),
				'API_PATH_V2_GET_TRIAL_LIST_ALL': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_LIST_ALL),
				'API_PATH_V2_TRIAL_UPDATE': JSON.stringify(METADATA.API_PATH_V2_TRIAL_UPDATE),
				'API_PATH_V2_CREATE_DRUG_REGIMEN_PAIR': JSON.stringify(METADATA.API_PATH_V2_CREATE_DRUG_REGIMEN_PAIR),
				'API_PATH_V2_CREATE_TRIAL_OPTION': JSON.stringify(METADATA.API_PATH_V2_CREATE_TRIAL_OPTION),
				'API_PATH_V2_CREATE_PATIENT_ALERTS': JSON.stringify(METADATA.API_PATH_V2_CREATE_PATIENT_ALERTS),
				'API_PATH_V2_IMPORT_PATIENTS': JSON.stringify(METADATA.API_PATH_V2_IMPORT_PATIENTS),
				'API_PATH_V2_VALIDATE_CONTAINER': JSON.stringify(METADATA.API_PATH_V2_VALIDATE_CONTAINER),
				'API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER': JSON.stringify(METADATA.API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER),
				'API_PATH_V2_GET_SELECTED_TRIAL': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_TRIAL),
				'API_PATH_V2_CREATE_PATIENT_USER': JSON.stringify(METADATA.API_PATH_V2_CREATE_PATIENT_USER),
				'API_PATH_V2_UPDATE_MEDCON_USER': JSON.stringify(METADATA.API_PATH_V2_UPDATE_MEDCON_USER),
				'API_PATH_V2_UPDATE_PATIENT_USER': JSON.stringify(METADATA.API_PATH_V2_UPDATE_PATIENT_USER),
				'API_PATH_V2_GET_PROFILE': JSON.stringify(METADATA.API_PATH_V2_GET_PROFILE),
				'API_PATH_V2_GET_USER_PROFILE': JSON.stringify(METADATA.API_PATH_V2_GET_USER_PROFILE),
				'API_PATH_V2_GET_PREFERENCES': JSON.stringify(METADATA.API_PATH_V2_GET_PREFERENCES),
				'API_PATH_V2_UPDATE_PREFERENCES': JSON.stringify(METADATA.API_PATH_V2_UPDATE_PREFERENCES),
				'API_PATH_V2_GET_SELECTED_PATIENT_DETAILS': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_PATIENT_DETAILS),
				'API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_SUMMARY': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_SUMMARY),
				'API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_LIST': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_LIST),
				'API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST),
				'API_PATH_V2_GET_PATIENT_OVERVIEW_DASHBOARD': JSON.stringify(METADATA.API_PATH_V2_GET_PATIENT_OVERVIEW_DASHBOARD),
				'API_PATH_V2_GET_PATIENT_LIST': JSON.stringify(METADATA.API_PATH_V2_GET_PATIENT_LIST),
				'API_PATH_V2_DELETE_COMPANY': JSON.stringify(METADATA.API_PATH_V2_DELETE_COMPANY),
				'API_PATH_V2_GET_SELECTED_COMPANY': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_COMPANY),
				'API_PATH_V2_COMPANY_OVERVIEW': JSON.stringify(METADATA.API_PATH_V2_COMPANY_OVERVIEW),
				'API_PATH_V2_DELETE_REGIMEN': JSON.stringify(METADATA.API_PATH_V2_DELETE_REGIMEN),
				'API_PATH_V2_GET_REGIMEN': JSON.stringify(METADATA.API_PATH_V2_GET_REGIMEN),
				'API_PATH_V2_GET_TRIAL_GROUP_NOTIN_TRAIL': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_GROUP_NOTIN_TRAIL),
				'API_PATH_V2_DELETE_TRIAL_GROUP': JSON.stringify(METADATA.API_PATH_V2_DELETE_TRIAL_GROUP),
				'API_PATH_V2_GET_SELECTED_TRIAL_GROUP': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_TRIAL_GROUP),
				'API_PATH_V2_DELETE_SITE': JSON.stringify(METADATA.API_PATH_V2_DELETE_SITE),
				'API_PATH_V2_GET_SITE_NOTIN_TRAIL': JSON.stringify(METADATA.API_PATH_V2_GET_SITE_NOTIN_TRAIL),
				'API_PATH_V2_GET_SELECTED_SITE': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_SITE),
				'API_PATH_V2_UPDATE_MEASUREMENT_STATUS': JSON.stringify(METADATA.API_PATH_V2_UPDATE_MEASUREMENT_STATUS),
				'API_PATH_V2_GET_SELECTED_DRUGS': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_DRUGS),
				'API_PATH_V2_DELETE_DRUGS': JSON.stringify(METADATA.API_PATH_V2_DELETE_DRUGS),
				'API_PATH_V2_DELETE_TRIAL': JSON.stringify(METADATA.API_PATH_V2_DELETE_TRIAL),
				'API_PATH_V2_GET_TRIAL_OVERVIEW': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_OVERVIEW),
				'API_PATH_V2_GET_SELECTED_DRUG_REGIMEN_VIEW': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_DRUG_REGIMEN_VIEW),
				'API_PATH_V2_TRITRATE_DRUG_REGIMEN_PAIR': JSON.stringify(METADATA.API_PATH_V2_TRITRATE_DRUG_REGIMEN_PAIR),
				'API_PATH_V2_DELETE_DRUG_REGIMEN_PAIR': JSON.stringify(METADATA.API_PATH_V2_DELETE_DRUG_REGIMEN_PAIR),
				'API_PATH_V2_GET_DRUG_REGIMEN_PAIR': JSON.stringify(METADATA.API_PATH_V2_GET_DRUG_REGIMEN_PAIR),
				'API_PATH_V2_UPDATE_DRUG_REGIMEN_PAIR': JSON.stringify(METADATA.API_PATH_V2_UPDATE_DRUG_REGIMEN_PAIR),
				'API_PATH_V2_LIST_DRUG_REGIMEN_PAIR': JSON.stringify(METADATA.API_PATH_V2_LIST_DRUG_REGIMEN_PAIR),
				'API_PATH_V2_GET_TRIAL_PATIENTS': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_PATIENTS),
				'API_PATH_V2_GET_TRIAL_PATIENTS_CONTAINER': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_PATIENTS_CONTAINER),
				'API_PATH_V2_GET_TRIAL_CONTAINER': JSON.stringify(METADATA.API_PATH_V2_GET_TRIAL_CONTAINER),
				'API_PATH_V2_GET_PATIENT_ALERTS': JSON.stringify(METADATA.API_PATH_V2_GET_PATIENT_ALERTS),
				'API_PATH_V2_UPDATE_PATIENT_ALERTS': JSON.stringify(METADATA.API_PATH_V2_UPDATE_PATIENT_ALERTS),
				'API_PATH_V2_ASSOCIATE_TRAILGROUP': JSON.stringify(METADATA.API_PATH_V2_ASSOCIATE_TRAILGROUP),
				'API_PATH_V2_ADD_ASSOCIATE_TRAILGROUP': JSON.stringify(METADATA.API_PATH_V2_ADD_ASSOCIATE_TRAILGROUP),
				'API_PATH_V2_DISASSOCIATE_TRAILGROUP': JSON.stringify(METADATA.API_PATH_V2_DISASSOCIATE_TRAILGROUP),
				'API_PATH_V2_ASSOCIATE_SITE': JSON.stringify(METADATA.API_PATH_V2_ASSOCIATE_SITE),
				'API_PATH_V2_DISSOCIATE_SITE': JSON.stringify(METADATA.API_PATH_V2_DISSOCIATE_SITE),
				'API_PATH_V2_GET_TRIALGROUP_UNDER_TRIAL': JSON.stringify(METADATA.API_PATH_V2_GET_TRIALGROUP_UNDER_TRIAL),
				'API_PATH_V2_ADD_ASSOCIATE_SITE': JSON.stringify(METADATA.API_PATH_V2_ADD_ASSOCIATE_SITE),
				'API_PATH_V2_LIST_SITES_UNDER_TRIAL': JSON.stringify(METADATA.API_PATH_V2_LIST_SITES_UNDER_TRIAL),
				'API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER_MOBILE': JSON.stringify(METADATA.API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER_MOBILE),
				'API_PATH_V2_GET_CONTAINER_INFO_FOR_ATTACH_PATIENT_HISTORY': JSON.stringify(METADATA.API_PATH_V2_GET_CONTAINER_INFO_FOR_ATTACH_PATIENT_HISTORY),
				'API_PATH_V2_UPLOAD_DOSE': JSON.stringify(METADATA.API_PATH_V2_UPLOAD_DOSE),
				'API_PATH_V2_DOSE_OVERVIEW': JSON.stringify(METADATA.API_PATH_V2_DOSE_OVERVIEW),
				'API_PATH_V2_DOSE_HISTORY': JSON.stringify(METADATA.API_PATH_V2_DOSE_HISTORY),
				'API_PATH_V2_DOSE_TRACK': JSON.stringify(METADATA.API_PATH_V2_DOSE_TRACK),
				'API_PATH_V2_ADHERENCE_INFO': JSON.stringify(METADATA.API_PATH_V2_ADHERENCE_INFO),
				'API_PATH_V2_COMPALIANCE_INFO': JSON.stringify(METADATA.API_PATH_V2_COMPALIANCE_INFO),
				'API_PATH_V2_GET_COMMITTED_DOSE': JSON.stringify(METADATA.API_PATH_V2_GET_COMMITTED_DOSE),
				'API_PATH_V2_DATA_REPORT': JSON.stringify(METADATA.API_PATH_V2_DATA_REPORT),
				'API_PATH_V2_GET_DOSAGE_WINDOW': JSON.stringify(METADATA.API_PATH_V2_GET_DOSAGE_WINDOW),
				'API_PATH_V2_UPDATE_DOSAGE_WINDOW': JSON.stringify(METADATA.API_PATH_V2_UPDATE_DOSAGE_WINDOW),
				'API_PATH_V2_GET_ALERT_MESSAGES': JSON.stringify(METADATA.API_PATH_V2_GET_ALERT_MESSAGES),
				'API_PATH_V2_UPDATE_ALERT_MESSAGES': JSON.stringify(METADATA.API_PATH_V2_UPDATE_ALERT_MESSAGES),
				'API_PATH_V2_GET_NOTIFICATION_MESSAGES': JSON.stringify(METADATA.API_PATH_V2_GET_NOTIFICATION_MESSAGES),
				'API_PATH_V2_UPDATE_NOTIFICATION_MESSAGES': JSON.stringify(METADATA.API_PATH_V2_UPDATE_NOTIFICATION_MESSAGES),
				'API_PATH_V2_GET_TIME_ZONE': JSON.stringify(METADATA.API_PATH_V2_GET_TIME_ZONE),
				'API_PATH_V2_GET_ALL_TIME_ZONE': JSON.stringify(METADATA.API_PATH_V2_GET_ALL_TIME_ZONE),
				'API_PATH_V2_UPDATE_SELECTED_TIME_ZONE': JSON.stringify(METADATA.API_PATH_V2_UPDATE_SELECTED_TIME_ZONE),
				'API_PATH_V2_CREATE_NOTIFICATION': JSON.stringify(METADATA.API_PATH_V2_CREATE_NOTIFICATION),
				'API_PATH_V2_UPDATE_NOTIFICATION': JSON.stringify(METADATA.API_PATH_V2_UPDATE_NOTIFICATION),
				'API_PATH_V2_GET_NOTIFICATION': JSON.stringify(METADATA.API_PATH_V2_GET_NOTIFICATION),
				'API_PATH_V2_DELETE_NOTIFICATION': JSON.stringify(METADATA.API_PATH_V2_DELETE_NOTIFICATION),
				'API_PATH_V2_GET_LIST_NOTIFICATION': JSON.stringify(METADATA.API_PATH_V2_GET_LIST_NOTIFICATION),
				'API_PATH_V2_COMMIT_LABEL_PURCHASE': JSON.stringify(METADATA.API_PATH_V2_COMMIT_LABEL_PURCHASE),
				'API_PATH_V2_PURCHASE_LABEL': JSON.stringify(METADATA.API_PATH_V2_PURCHASE_LABEL),
				'API_PATH_V2_GET_LIST_LABEL_PURCHASE': JSON.stringify(METADATA.API_PATH_V2_GET_LIST_LABEL_PURCHASE),
				'API_PATH_V2_UPDATE_COMMITMENT': JSON.stringify(METADATA.API_PATH_V2_UPDATE_COMMITMENT),
				'API_PATH_V2_DELETE_COMMITMENT': JSON.stringify(METADATA.API_PATH_V2_DELETE_COMMITMENT),
				'API_PATH_V2_GET_SELECTED_LABEL_COMMITMENT': JSON.stringify(METADATA.API_PATH_V2_GET_SELECTED_LABEL_COMMITMENT),
				'API_PATH_V2_EXPORT_LABEL_DATA': JSON.stringify(METADATA.API_PATH_V2_EXPORT_LABEL_DATA),
				'API_PATH_V2_CREATE_BROADCAST_MESSAGE': JSON.stringify(METADATA.API_PATH_V2_CREATE_BROADCAST_MESSAGE),
				'API_PATH_V2_GET_BROADCAST_MESSAGE': JSON.stringify(METADATA.API_PATH_V2_GET_BROADCAST_MESSAGE),
				'API_PATH_V2_EDIT_BROADCAST_MESSAGE': JSON.stringify(METADATA.API_PATH_V2_EDIT_BROADCAST_MESSAGE),
				'API_PATH_V2_GET_LIST_BROADCAST_MESSAGE': JSON.stringify(METADATA.API_PATH_V2_GET_LIST_BROADCAST_MESSAGE),
				'API_PATH_V2_TITRATE_REPORT': JSON.stringify(METADATA.API_PATH_V2_TITRATE_REPORT),
				'API_PATH_V2_LABEL_REPORT': JSON.stringify(METADATA.API_PATH_V2_LABEL_REPORT),
			}),

			new DllBundlesPlugin({
				bundles: {
					polyfills: [
						'core-js',
						{
							name: 'zone.js',
							path: 'zone.js/dist/zone.js'
						},
						{
							name: 'zone.js',
							path: 'zone.js/dist/long-stack-trace-zone.js'
						},
					],
					vendor: [
						'@angular/platform-browser',
						'@angular/platform-browser-dynamic',
						'@angular/core',
						'@angular/common',
						'@angular/forms',
						'@angular/http',
						'@angular/router',
						'@angularclass/hmr',
						'rxjs',
					]
				},
				dllDir: helpers.root('dll'),
				webpackConfig: webpackMergeDll(commonConfig({env: ENV}), {
					devtool: 'cheap-module-source-map',
					plugins: []
				})
			}),

			/**
			 * Plugin: AddAssetHtmlPlugin
			 * Description: Adds the given JS or CSS file to the files
			 * Webpack knows about, and put it into the list of assets
			 * html-webpack-plugin injects into the generated html.
			 *
			 * See: https://github.com/SimenB/add-asset-html-webpack-plugin
			 */
			new AddAssetHtmlPlugin([
				{filepath: helpers.root(`dll/${DllBundlesPlugin.resolveFile('polyfills')}`)},
				{filepath: helpers.root(`dll/${DllBundlesPlugin.resolveFile('vendor')}`)}
			]),

			/**
			 * Plugin: NamedModulesPlugin (experimental)
			 * Description: Uses file names as module name.
			 *
			 * See: https://github.com/webpack/webpack/commit/a04ffb928365b19feb75087c63f13cadfc08e1eb
			 */
			// new NamedModulesPlugin(),

			/**
			 * Plugin LoaderOptionsPlugin (experimental)
			 *
			 * See: https://gist.github.com/sokra/27b24881210b56bbaff7
			 */
			new LoaderOptionsPlugin({
				debug: true,
				options: {}
			}),

		],

		/**
		 * Webpack Development Server configuration
		 * Description: The webpack-dev-server is a little node.js Express server.
		 * The server emits information about the compilation state to the client,
		 * which reacts to those events.
		 *
		 * See: https://webpack.github.io/docs/webpack-dev-server.html
		 */
		devServer: {
			port: METADATA.port,
			host: METADATA.host,
			historyApiFallback: true,
			watchOptions: {
				aggregateTimeout: 300,
				poll: 1000
			}
		},

		/*
		 * Include polyfills or mocks for various node stuff
		 * Description: Node configuration
		 *
		 * See: https://webpack.github.io/docs/configuration.html#node
		 */
		node: {
			global: true,
			crypto: 'empty',
			process: true,
			module: false,
			clearImmediate: false,
			setImmediate: false
		}

	});
}
