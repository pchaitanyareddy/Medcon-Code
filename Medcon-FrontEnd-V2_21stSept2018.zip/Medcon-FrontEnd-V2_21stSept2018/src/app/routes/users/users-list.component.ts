import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
//import { HttpService } from '../../services/http.service';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './users-list.component.html?v=${new Date().getTime()}',
    styleUrls: ['../patient-report/custom.css?v=${new Date().getTime()}']
    //styleUrls: ['../../../styles/custom.css']
})

export class UsersListComponent implements OnInit {
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('changeStatusModal') public changeStatusModal: ModalDirective;
    public users: Pagination<User>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public userToDelete: User;
    isLoading: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    public usersList: any;
    public selectedCompanyId: number;
    public authorizationToken: any;
    constructor(private route: ActivatedRoute,
        private router: Router,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private userService: UserService,
        private reportService: ReportService,
        //private httpService: HttpService,
        private cognitoUtil: CognitoUtil,
        private url: LocationStrategy
    ) {
    }


    public deleteItem(user): void {

        this.userToDelete = user;
        this.deleteModal.show();
    }

    public redirect(): void {
        alert('jjjjj');
    }

    public Test(): void {
        alert('Delete');
    }
    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        //alert('hello');
        this.currentUserRole = this.route.snapshot.data['role'];
        this.users = this.route.snapshot.data['users'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Users')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
    }

    public loadUsers(): void {

        //alert(this.selectedCustomerId);
        //$('#datatable').DataTable();
        //$('#datatable').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        //this.userService.getAllUsersByCompany(1).subscribe(
        //    (response) => {
        //        this.usersList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });

        //API url "https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/list/medcon/1"
        //$('#datatable').DataTable({
        //    "processing": true,
        //    "serverSide": true,
        //    "ajax": "https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/list/medcon/1",
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'

        //    ]
        //});


        //'eyJraWQiOiJDR2lMcE5lY2tGbERuNHZHamNaYnlpczNHTWRoXC9QXC9Gd0srcnY1dXhFOXM9IiwiYWxnIjoiUlMyNTYifQ.eyJjdXN0b206Y3VzdG9tZXJfaWQiOiI1MiIsInN1YiI6ImNjM2NjNTRkLWY3MTMtNDVjOS1hOWUxLWFlMGIxZGZiZTQ2NCIsImNvZ25pdG86Z3JvdXBzIjpbIkN1c3RvbWVyQWRtaW4iXSwiZW1haWxfdmVyaWZpZWQiOnRydWUsImNvZ25pdG86cHJlZmVycmVkX3JvbGUiOiJhcm46YXdzOmlhbTo6NDQ0NDQ3MDQ3ODczOnJvbGVcL3VzZXJwb29sLWN1c3RvbWVyLWFkbWluIiwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfYktSS0ZjTXFBIiwiY29nbml0bzp1c2VybmFtZSI6ImFtYXJqZWV0LnNAc21hcnRpbXMuY29tIiwiZ2l2ZW5fbmFtZSI6IkFtYXJqZWV0IiwiY29nbml0bzpyb2xlcyI6WyJhcm46YXdzOmlhbTo6NDQ0NDQ3MDQ3ODczOnJvbGVcL3VzZXJwb29sLWN1c3RvbWVyLWFkbWluIl0sImF1ZCI6IjNkNWU0ZmptMWljYWhjYjBycDFycTA2NzE1IiwiZXZlbnRfaWQiOiIyODZlNGM1Yy0wNjk5LTExZTgtYTNjZS0zMzEzZmY2ZjlhOTQiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTUxNzQxMTU1MSwibmFtZSI6IkFtYXJqZWV0IFNpbmdoIiwiZXhwIjoxNTE3NDE1MTUxLCJpYXQiOjE1MTc0MTE1NTEsImZhbWlseV9uYW1lIjoiU2luZ2giLCJlbWFpbCI6ImFtYXJqZWV0LnNAc21hcnRpbXMuY29tIn0.s0jBX5QKAfObd5f-Rx4RAoEyZqFBytUTR-Kd3r6PVPGjtxUGL56uPlF2wXFGMRJXV8-DXi4gOvzL5O5MdaZGaElwndTjBSQavMauq71d1t5tQjF7GGw8ZXxL97gvb4rYviie-GWcr8te6LdNxfFm4wIKeXukvqk1GG1_lj1qaoNCOSzCO_zpkI_15f-Qu0rymkxmPljlDgc9x3mPh1lJTbvD8LoWmB7Ch7IRCasidsELeHY8JtwrIiKXpOJfxBZxK4bTH4wrb02vx5qrLDbWbbLzTabY7D3tKJD2C1nR8HMxkDEQ1GIsA3b4AUbHCeEpQyNDopkRpA3yAFBXb3aKIw';
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {
              
                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        'url': CommonService.API_PATH_V2_MEDCON_USER_LIST+'user/list/medcon/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        //'url': 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/list/medcon/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 4]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_MEDCON_USER_LIST + 'user/list/medcon/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=2&columns%5B0%5D%5Bdata%5D=userId&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=firstName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=lastName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=email&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=phoneNumber&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=role&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=logintime&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=sub&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1535032103296'
                                self.reportService.ExportAll(apiUrl, 'Manage Users');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [1,2,3,4,5,6,7]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "userId" },
                        { "data": "firstName" },
                        { "data": "lastName" },
                        { "data": "email" },
                        { "data": "phoneNumber" },
                        { "data": "role" },
                        { "data": "logintime" },
                        { "data": "status" },
                        { "data": "sub" }
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                var status = full.status;   
                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</a> </div>";
                                

                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (status==1)
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button onclick=\"DeleteFn('" + full.sub + "')\" id=\"" + full.userId + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(sub){  localStorage.setItem('SUB', String(sub)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                    else (status == 0)
                                       return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button  disabled title=\"Cannot Delete this User as this user already in active\" onclick=\"DeleteFn('" + full.sub + "')\" id=\"" + full.userId + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(sub){  localStorage.setItem('SUB', String(sub)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {

                                    return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (status == 1)
                                        return "<div class=\"btn-action\"><button onclick=\"DeleteFn('" + full.sub + "')\" id=\"" + full.userId + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(sub){  localStorage.setItem('SUB', String(sub)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                    else (status == 0)
                                        return "<div class=\"btn-action\"><button disabled title=\"Cannot Delete this User as this user already in active\" onclick=\"DeleteFn('" + full.sub + "')\" id=\"" + full.userId + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(sub){  localStorage.setItem('SUB', String(sub)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {

                                    return "";
                                }
                            }
                        }

                    ],
                    "columnDefs": [

                        {
                            "targets": [0],
                            "visible": false
                        },
                        {
                            "targets": [8],
                            "visible": false
                        },
                        {
                            "targets": [7],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                    ],
                     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                });
            }
        
        });
        $('#datatable tbody').on("click", 'tr', function (evt) {


            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });

    }

    public ngAfterViewInit(): void {
        //$("#globalCompanyDropdown").change(function () {
        //    alert($('option:selected', this).text());
        //});
        $("#datatable").dataTable().fnDestroy();
        this.loadUsers();
        if (localStorage.getItem("LOGGED_IN_USER_ROLE")=='Customer User')
            $(".dt-buttons").css("display", "none");

    }


    public hideDeleteModal(): void {
        //alert('kkk');
        //this.userToDelete = null;
        this.deleteModal.hide();
        //$('#pnlDeleteModal').modal('hide');
        ///$('#pnlDeleteModal').modal().hide();
        //$('#pnlDeleteModal').modal('hide');
    }

    public confirmDelete(): void {
        //alert('ll');
        //alert(userId);
        //alert(localStorage.getItem('SUB'));
        //let user = this.userToDelete;
        this.userService
            .deleteMedConUser(localStorage.getItem('SUB'))
            .subscribe(
            (response) => {
                //this.userService.getUsers(this.selectedCustomerId)
                //	.subscribe((users) => {
                //			this.users = users;
                //			this.successMessage = user.givenName + ' ' + user.familyName + ' has been successfully deleted';
                //			this.hideDeleteModal();
                //		}
                //	);

                this.successMessage = 'user has been successfully deleted';
                location.reload();
                //this.hideDeleteModal();
                //this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'users']);
                //this.goBack();
                //this.loadUsers();

            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }


    public goBack(): void {
        //this.form.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'users']);
        //this.url.pushState(null, null, '/' + this.selectedCustomerId + '/users', '');
    }


    public customerChanged(): void {
        this.userService.getUsers(this.selectedCustomerId).subscribe((users) => {
            this.users = users;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/users', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.userService.getUsers(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((users) => {
            this.users = users;
        });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
    //Code added by ramesh on 14th Nov 2017
    public changeUserStatus(user): void {
        this.userToDelete = user;
        this.changeStatusModal.show();
    }

    public hideChangeUserStatusModal(): void {
        this.userToDelete = null;
        this.changeStatusModal.hide();
    }


    public confirmChangeStatusConfirmation(): void {
        let user = this.userToDelete;
        this.successMessage = 'User status has been changed successfully';
        this.hideChangeUserStatusModal();
        //Un comment this when API is available
        //this.userService
        //	.updateUserStatus(user.id, this.selectedCustomerId)
        //	.subscribe(
        //		(response) => {
        //			this.userService.getUsers(this.selectedCustomerId)
        //				.subscribe((users) => {
        //						this.users = users;
        //						this.successMessage = user.firstName + ' ' + user.lastName + ' has been changed status successfully';
        //						this.hideChangeUserStatusModal();
        //					}
        //				);
        //		},
        //		(err) => {
        //			this.errorMessage = err;
        //			this.hideChangeUserStatusModal();
        //		}
        //	);
    }
}
