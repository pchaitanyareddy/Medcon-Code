import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LocationStrategy } from '@angular/common';
import { URLSearchParams } from '@angular/http';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';

@Component({
	templateUrl: './customers-list.component.html'
})

export class CustomersListComponent implements OnInit {
	public customers: Pagination<Customer>;

	public maxSize: number = 5;
	public currentPage: number = 1;

	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private customerService: CustomerService,
		private router: Router,
		private url: LocationStrategy) {
	}

	public ngOnInit(): void {
		this.customers = this.route.snapshot.data['customers'];
		if (this.route.queryParams['page']) {
			this.currentPage = this.route.queryParams['page'];
		}
	}

	public viewCustomer(customer: Customer): void {
		this.router.navigate(['/customers', customer.id, 'view']);
	}

	public deleteCustomer(customer: Customer): void {
		this.customerService.deleteCustomer(customer.id).subscribe((result) => {
			location.reload();
		});
	}

	public pageChanged(event: any): void {
		let queryParams = new URLSearchParams();
		queryParams.set('page', event.page);
		queryParams.set('per_page', event.itemsPerPage);

		this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
		this.customerService.getCustomers(event.page, event.itemsPerPage).subscribe(
			(customers) => this.customers = customers
		);
	}
}
