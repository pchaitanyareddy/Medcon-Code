﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { BroadcastMessagesRequest } from '../../requests/broadcastMessages-request';
import { BroadcastMessagesEditRequest } from '../../requests/broadcastMessagesEdit-request';
import { BroadcastMessagesService } from '../../services/broadcastMessages.service';
import { BroadcastMessages } from '../../models/broadcastMessages';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './broadcast-Messages-list.component.html?v=${new Date().getTime()}'
})

export class BroadcastMessagesListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public Broadcastmsgs: Pagination<BroadcastMessages>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public showErrors: boolean;
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public allTrailsList: any;
    public broadcastmsgs: FormGroup;
    selectedTrialId: number;
    selectedBroadcastId: number;
    public selectedTrial: any;
    public trailId: number;
    //public trialGroupToDelete: BroadcastMessages;
    isEditForm: boolean;
    messageResponse: any;
    public maxSize: number = 5;
    public currentPage: number = 1;
    broadcastMessageList: any;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    isLoading: boolean;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private BroadcastMessagesService: BroadcastMessagesService,
        private reportService: ReportService,
        private fb: FormBuilder,
        private cognitoUtil: CognitoUtil,
        private url: LocationStrategy) {



    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.Broadcastmsgs = this.route.snapshot.data['BroadcastMessages'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.trailId = Number(this.route.snapshot.params['id'])

       
        //alert(this.selectedTrialId);

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        this.broadcastmsgs = this.fb.group({
            messageTitle: ['', Validators.required],
            broadcastMessage: ['', Validators.required],
            listOfTrails: [''],
        });
       
        //alert(this.selectedTrialId);
        if (this.currentUserRole === UserRole.MedConAdmin) {
            this.BroadcastMessagesService.getBroadcastMessageList(this.selectedCustomerId)
                .subscribe((BroadcastMessages) => {
                    this.Broadcastmsgs = BroadcastMessages;

                }
                );
        }

        this.broadcastMessageList = [
            //{ broadcastmsgId: 1, userName: 'priya', email: 'welcome@smartims.com', trailName: 'TestGroup1', patient: 'priya', accepted: '90', msgType: 'Titrate', messageTitle: 'Dose missed in the morning', dateTime: '10/24/2017' },
            //{ broadcastmsgId: 2, userName: 'Robort', email: 'world@world.com', trailName: 'TestGroup1', patient: 'Robort', accepted: '45', msgType: 'Broadcast', messageTitle: 'Overdosed in the afternoon', dateTime: '10/24/2017' },
            //{ broadcastmsgId: 3, userName: 'Sachin', email: 'abc123@gmail.com ', trailName: 'TestGroup2', patient: 'Sachin', accepted: '10', msgType: 'Broadcast', messageTitle: 'Ready to have medicine', dateTime: '10/24/2017' },
            //{ broadcastmsgId: 4, userName: 'Jinga', email: 'happiness@h24s.com', trailName: 'TestGroup3', patient: 'Jinga', accepted: '65', msgType: 'Broadcast', messageTitle: 'Trailgroup is about to expire', dateTime: '10/24/2017' },
        ]

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Broadcast Messages')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);

        this.BroadcastMessagesService.getAllTrails((localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrailsList = response;

            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;

            });



        localStorage.setItem('IS_EDIT_FORM', 'false');


    }

    public ngAfterViewInit(): void {

        //$('#datatable').DataTable();
        //$('#datatable').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                / tslint:disable:no-empty /
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        //'url': 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/broadcast/list',
                        'url': CommonService.API_PATH_V2_GET_LIST_BROADCAST_MESSAGE + 'broadcast/list?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID'),


                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_GET_LIST_BROADCAST_MESSAGE + 'broadcast/list' + '?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID') + '&draw=1&columns%5B0%5D%5Bdata%5D=title&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=type&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=userName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=userMail&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=trialName&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=patients&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=accepted&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=Createdtime&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=iD&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1527162750975'
                                self.reportService.ExportAll(apiUrl, 'Broadcast Messages List');
                            },
                           
                        },
                        { extend: 'print', text: 'Print' }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "title" },//field name should be updated after getting field in API
                        { "data": "type" },//field name should be updated after getting field in API
                        { "data": "userName" },
                        { "data": "userMail" },
                        { "data": "trialName" },
                        { "data": "patients" },//field name should be updated after getting field in API
                        { "data": "accepted" },//field name should be updated after getting field in API                        
                        { "data": "Createdtime" },//field name should be updated after getting field in API
                        { "data": "iD" }

                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                // return "<div class=\"btn-action\"><button onclick=\"EditBroadcast(" + full.id + ",'" + full.trialId + "','" + full.messageTitle + "','" + full.broadcastMessage + "')\" id=\"btnEdit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></button><script>function EditBroadcast(broadcastId,trialId,messageTitle,broadcastMessage){localStorage.setItem('BROADCAST_ID', broadcastId);$('#listOfTrails').val(trialId);localStorage.setItem('IS_EDIT_FORM', true); $('#messageTitle').val(messageTitle);$('#broadcastMessage').val(broadcastMessage);} </script>&nbsp<a href=\"#\" class=\"remove\">Send</a> </div>";
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1) {
                                    return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.trialId + "_" + full.messageTitle + "_" + full.broadcastMessage + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit </a></button><script>function EditBroadcast(broadcastId,trialId,messageTitle,broadcastMessage){localStorage.setItem('BROADCAST_ID', broadcastId);$('#listOfTrails').val(trialId);localStorage.setItem('IS_EDIT_FORM', true); $('#messageTitle').val(messageTitle);$('#broadcastMessage').val(broadcastMessage);} </script></div>";
                                }
                                else {
                                    return "";
                                }
                            }
                        }


                    ],
                    "columnDefs": [

                        {
                            "targets": [8],
                            "visible": false
                        },
                        {
                            "targets": [1],
                            render: function (data, type, row) {
                                return data == '1' ? 'broadcast' : 'titrate'
                            }
                        }
                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                });
            }
        });


        $('#datatable').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            this.selectedBroadcastId = buttonId;
            //alert(buttonId);
            if (buttonName == "editItem") {

                self.EditBroadcast(buttonId);
                self.isLoading = true;

            }

        });





    }

    public onSubmit() {
        
        if (this.broadcastmsgs.invalid) {
            this.showErrors = true;
            
        }
        else if (String(this.selectedTrialId) == 'NaN' || this.selectedTrialId == undefined) {
            
            this.showErrors = true;
            this.errorMessage = "Please Select Trial Name"
        }
        else {
            
            this.isLoading = true;
            //alert(this.selectedTrialId)
            if (localStorage.getItem('IS_EDIT_FORM') == 'true') {
                //alert(this.selectedTrialId)
                let request = new BroadcastMessagesRequest(

                    this.selectedTrialId,
                    this.broadcastmsgs.value.messageTitle,
                    this.broadcastmsgs.value.broadcastMessage,
                    Number((localStorage.getItem('GLOBAL_COMPANY_ID')))

                );
                //alert(this.selectedTrialId);
                this.BroadcastMessagesService.createBroadcastMessages(request).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.broadcastmsgs.markAsPristine();
                        
                        //this.broadcastMessageList = this.BroadcastMessagesService.getBroadcastMessages(1);
                        this.successMessage = "successfully Updated";
                        $(window).scrollTop(5);
                        this.broadcastmsgs.reset();
                        this.goBack();
                        $("#datatable").dataTable().fnDestroy();
                        this.ngAfterViewInit();
                        
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });

            }
            else {
                // TODO: NEED TO ADD COUNTRY SELECTOR TO THE VIEW
                //alert("Insert part");
                let request = new BroadcastMessagesRequest(
                    this.selectedTrialId,
                    this.broadcastmsgs.value.messageTitle,
                    this.broadcastmsgs.value.broadcastMessage,
                    Number((localStorage.getItem('GLOBAL_COMPANY_ID')))

                );
                //alert(this.selectedTrialId);
                //alert(this.broadcastmsgs.value.messageTitle);
                //alert(this.broadcastmsgs.value.broadcastMessage);
                $('#btnSubmit').attr('disabled', true);
                this.BroadcastMessagesService.createBroadcastMessages(request).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.broadcastmsgs.markAsPristine();
                        
                        //this.broadcastMessageList = this.BroadcastMessagesService.getBroadcastMessages(1);
                        this.successMessage = "successfully Added ";
                        $(window).scrollTop(5);
                        this.broadcastmsgs.reset();
                        this.goBack();
                        $("#datatable").dataTable().fnDestroy();
                        this.ngAfterViewInit();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
            }
        }
    }

    public customerChanged(): void {
        this.BroadcastMessagesService.getBroadcastMessageList(this.selectedCustomerId).subscribe((BroadcastMessages) => {
            this.Broadcastmsgs = BroadcastMessages;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/broadcast-Messages', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.BroadcastMessagesService.getBroadcastMessageList(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((BroadcastMessages) => {
            this.Broadcastmsgs = BroadcastMessages;
        });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }


    public editAndPopulateFormValues(measureObject) {
        //alert("Edit Screen");
        this.isEditForm = true;
        this.broadcastmsgs = this.fb.group({
            messageTitle: [, [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            broadcastMessage: [this.messageResponse.broadcastMessage[1], Validators.required],
            listOfTrails: ['', Validators.required]
        });
    }




    onChange_State(selectedValue) {
        //alert(this.selectedTrialId);
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;
        //alert(this.selectedTrialId);

        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }

    }
    public EditBroadcast(id): void {
        this.selectedBroadcastId = id;
        $('#btnSubmit').text('Update');
        //alert(this.selectedTrialId);
        this.getBroadcastDetails();
    }

    public getBroadcastDetails(): void {
        // alert("getBroadcastDetails");
        //alert(this.selectedTrialId);

        this.BroadcastMessagesService.getBroadcastMessage(this.selectedBroadcastId).subscribe(
            (response) => {
                this.isLoading = false;
                this.broadcastmsgs.markAsPristine();

                this.isEditForm = true;
                $('#messageTitle').val(response.messageTitle);
                $('#broadcastMessage').val(response.broadcastMessage);
                this.selectedTrialId = response.trialId;
                //alert(this.selectedTrialId);
                //alert(response.broadcastMessage);
                //alert(response.messageTitle);
                this.broadcastmsgs = this.fb.group({
                    messageTitle: [response.messageTitle, Validators.required],
                    broadcastMessage: [response.broadcastMessage, Validators.required],
                    listOfTrails: [this.selectedTrialId]
                });


                //this.successMessage = "successfully Added ";
                //this.broadcastmsgs.reset();
            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;
            });


    }
    public goBack() {
        this.broadcastmsgs.reset();
        $('#btnSubmit').text('Submit');
        this.showErrors = false;
        this.errorMessage = '';
        $("#error_messageTitle").html("");
        $("#error_addcomment").html("");
        $('#btnSubmit').attr('disabled', false);
    }


}
