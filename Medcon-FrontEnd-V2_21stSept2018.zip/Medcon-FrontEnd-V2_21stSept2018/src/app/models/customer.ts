export class Customer {
	constructor(public id: number,
		public typeId: number,
		public name: string,
		public dosageAdherenceBenchmark: number) {
	}
}
