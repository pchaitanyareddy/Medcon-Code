import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { PendingChangesGuard } from './guards/pending-changes.guard';
import { LoginComponent } from './routes/login/login.component';
import { DashboardComponent } from './routes/dashboard/dashboard.component';
import { DataReportsComponent } from './routes/reports/data-reports.component';
import { PrivilegesComponent } from './routes/privileges/privileges-list.component';
import { PatientReportComponent } from './routes/patient-report/patient-report.component';
import { ImportPatientComponent } from './routes/import-patient/import-patient.component';
import { TrialGroupListComponent } from './routes/trialgroup/trialgroup-list.component';
import { TrialGroupNewComponent } from './routes/trialgroup/trialgroup-new.component';
import { TrialGroupEditComponent } from './routes/trialgroup/trialgroup-edit.component';
import { CompanyListComponent } from './routes/company/company-list.component';
import { CompanyNewComponent } from './routes/company/company-new.component';
import { CompanyEditComponent } from './routes/company/company-edit.component';
import { LabelsCommittedComponent } from './routes/labels-committed/labels-committed.component';
import { MeasurementListComponent } from './routes/measurement/measure-list.component';
import { MeasurementEditComponent } from './routes/measurement/measure-edit.component';
import { BroadcastMessagesListComponent } from './routes/broadcast-Messages/broadcast-Messages-list.component';
import { NotificationsListComponent } from './routes/notifications/notifications-list.component';
import { SettingsListComponent } from './routes/settings/settings-list.component';
import { ExportListComponent } from './routes/export/export-list.component';
import { LabelReportComponent } from './routes/Label-Report/labelReport.component';
import { TitrationReportComponent } from './routes/titration-Report/titrationReport.component';
import {
	CustomersListComponent,
	CustomerNewComponent,
	CustomerEditComponent,
	CustomerViewComponent
} from './routes/customers';
import { SiteNewComponent, SiteListComponent,SiteEditComponent } from './routes/sites';
import {
	TrialsListComponent,
	TrialNewComponent,
	TrialEditComponent,
	TrialViewComponent
} from './routes/trials';
import {
	UsersListComponent,
	UserEditComponent,
	UserNewComponent,
	MedConUsersListComponent,
	MedConUserNewComponent,
	MedConUserEditComponent
} from './routes/users';
import { PatientNewComponent, PatientEditComponent } from './routes/patients';
import { DrugsListComponent, DrugNewComponent, DrugEditComponent } from './routes/drugs';
import { RegimenListComponent, RegimenNewComponent, RegimenEditComponent } from './routes/regimen';
import { AlertsAlarmsComponent } from './routes/alerts-alarms/alerts-alarms-list.component';
import { SettingsComponent } from './routes/settings/settings.component';
import { PageNotFoundComponent } from './routes/errors/page-not-found.component';
import { UserRole } from './models/userrole';
import {
	DashboardStateResolve,
	CustomersResolve,
	CustomerResolve,
	SitesResolve,
	SiteResolve,
	TrialsResolve,
	TrialResolve,
	TrialLabelsResolve,
	TrialContainersResolve,
    TrialPatientsResolve,
    TrialAssociatedGroupListResolve,
	PatientResolve,
	RacesResolve,
	DrugsResolve,
	DrugsAllResolve,
	DrugResolve,
	RegimensResolve,
	RegimensAllResolve,
	RegimenResolve,
	AlertsAlarmsResolve,
	UsersResolve,
	UserResolve,
	MedConUsersResolve,
	CurrentUserRoleResolve,
	CurrentUserResolve,
    ReportSchedulesResolve,
    PrivilegesResolve,
    PatientReportResolve,
    TrialGroupListResolve,
    TrialAssociatedSiteListResolve,
    CompanyResolve,
    NotificationsResolve,
    SettingsResolve,
    ExportResolve,
    SettingsAlertResolve,
    SettingsDosageResolve,
    CompanyOverviewResolve,
    TrialOverviewResolve,
    DashboardDoseOverviewResolve,
    SettingsTimezoneResolve,
    TrialNotificationResolve,
    TrialPatientAlertResolve,
} from './routes/resolvers';

export const ROUTES: Routes = [
	{
		path: '',
		component: LoginComponent
	},
	{
		path: 'dashboard',
		component: DashboardComponent,
		canActivate: [AuthGuard],
		resolve: {
			role: CurrentUserRoleResolve,
			user: CurrentUserResolve,
            state: DashboardStateResolve,
            privileges: PrivilegesResolve,
            //doseoverview: DashboardDoseOverviewResolve,
		}
	},
	{
		path: 'reports',
		component: DataReportsComponent,
		canActivate: [AuthGuard],
		resolve: {
			role: CurrentUserRoleResolve,
			user: CurrentUserResolve,
            report_schedules: ReportSchedulesResolve,
            privileges: PrivilegesResolve,
		}
	},
	{
		path: 'customers',
		canActivate: [AuthGuard],
		children: [
			{
				path: '',
				component: CustomersListComponent,
				resolve: {
                    customers: CustomersResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: 'new',
				component: CustomerNewComponent,
				canDeactivate: [PendingChangesGuard],
			},
			{
				path: ':customer_id/edit',
				component: CustomerEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
					customer: CustomerResolve,
					sites: SitesResolve,
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: ':customer_id/view',
				component: CustomerViewComponent,
				resolve: {
					//customer: CustomerResolve,
					role: CurrentUserRoleResolve,
					//drugs: DrugsAllResolve,
					//regimens: RegimensAllResolve,
                    //sites: SitesResolve,
                    privileges: PrivilegesResolve,
                    companyOverview: CompanyOverviewResolve,
				}
			}
		]
	},
	{
		path: ':customer_id/sites',
		canActivate: [AuthGuard],
		resolve: {
           // privileges: PrivilegesResolve,
		},
        children: [
            {
                path: '',
                component: SiteListComponent,
                resolve: {
                    //site: SiteResolve,
                    privileges: PrivilegesResolve,
                },
            },
			{
				path: 'new',
				component: SiteNewComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {

                    privileges: PrivilegesResolve,
                },

			},
			{
				path: ':id/edit',
				component: SiteEditComponent,
                canDeactivate: [PendingChangesGuard],
				resolve: {
                    site: SiteResolve,
                    privileges: PrivilegesResolve,
				}
			}
		]
	},
	{
		path: ':customer_id/trials',
		canActivateChild: [AuthGuard],
		resolve: {
			//customer: CustomerResolve,
            role: CurrentUserRoleResolve,
            //privileges: PrivilegesResolve,
		},
		children: [
			{
				path: '',
				component: TrialsListComponent,
				resolve: {
                    //trials: TrialsResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: 'new',
				component: TrialNewComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
                    //sites: SitesResolve,
                    privileges: PrivilegesResolve,
				}
			},
			{
				path: ':id/edit',
				component: TrialEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
					role: CurrentUserRoleResolve,
					trial: TrialResolve,
					//drugs: DrugsAllResolve,
					//regimens: RegimensAllResolve,
					//sites: SitesResolve,
					//labels: TrialLabelsResolve,
					//containers: TrialContainersResolve,
                    //patients: TrialPatientsResolve,
                    //associatedTrialGroups: TrialAssociatedGroupListResolve,
                    //associatedSites: TrialAssociatedSiteListResolve,
                    privileges: PrivilegesResolve,
                    trialNotifications: TrialNotificationResolve,
                    patientAlert: TrialPatientAlertResolve,
                    notifications: SettingsResolve,
                    //trialOverview: TrialOverviewResolve,
				},
            },
           
            {
                path: ':id/ViewTrial',
                component: TrialEditComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {
                    role: CurrentUserRoleResolve,
                    trial: TrialResolve,
                    privileges: PrivilegesResolve,
                    trialNotifications: TrialNotificationResolve,
                    patientAlert: TrialPatientAlertResolve,
                    notifications: SettingsResolve,
                    //trialOverview: TrialOverviewResolve,
                },
            },
			{
				path: ':id/view',
				component: TrialViewComponent,
				resolve: {
					trial: TrialResolve,
					//labels: TrialLabelsResolve,
					//containers: TrialContainersResolve,
                    //patients: TrialPatientsResolve,
                    privileges: PrivilegesResolve,
                    trialOverview: TrialOverviewResolve,
				},
			},
		]
    },
    
    {
        path: ':customer_id/trialgroup',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: TrialGroupListComponent,
                resolve: {
                    privileges: PrivilegesResolve,
                },
            }
            ,
            {
                path: 'new',
                component: TrialGroupNewComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {
                    //trialgroup: TrialGroupListResolve,
                    privileges: PrivilegesResolve,
                }
            },
            {
                path: ':id/edit',
                component: TrialGroupEditComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {
                    role: CurrentUserRoleResolve,
                    trialGroup: TrialGroupListResolve,
                    privileges: PrivilegesResolve,
                    //drugs: DrugsAllResolve,
                    //regimens: RegimensAllResolve,
                    //sites: SitesResolve,
                    //labels: TrialLabelsResolve,
                    //containers: TrialContainersResolve,
                    //patients: TrialPatientsResolve,
                },
            }
        ]
    },
	{
		path: ':customer_id/users',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: '', component: UsersListComponent,
				resolve: {
					role: CurrentUserRoleResolve,
                    users: UsersResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: 'new', component: UserNewComponent,
				canDeactivate: [PendingChangesGuard],
                resolve: {
                    
                    privileges: PrivilegesResolve,
                },
			},
			{
				path: ':id/edit', component: UserEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
                    user: UserResolve,
                    privileges: PrivilegesResolve,
				},
			},
		]
	},
	{
		path: 'medcon-users',
		canActivateChild: [AuthGuard],
		data: {
			roles: [UserRole.MedConAdmin]
		}
		,
		children: [
			{
				path: '', component: MedConUsersListComponent,
				resolve: {
                    users: MedConUsersResolve,
                    privileges: PrivilegesResolve,
				}
			},
			{
				path: 'new', component: MedConUserNewComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {

                    privileges: PrivilegesResolve,
                },
			},
			{
				path: ':id/edit', component: MedConUserEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
                    user: UserResolve,
                    privileges: PrivilegesResolve,
				},
			},
		]
	},
	{
		path: ':customer_id/patients',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: 'new',
				component: PatientNewComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
                    //races: RacesResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: ':id/edit',
				component: PatientEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
					patient: PatientResolve,
                    races: RacesResolve,
                    privileges: PrivilegesResolve,
				},
			},
		]
	},
	{
		path: ':customer_id/drugs',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: '',
				component: DrugsListComponent,
				resolve: {
					role: CurrentUserRoleResolve,
                    //drugs: DrugsResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: 'new',
				component: DrugNewComponent,
				canDeactivate: [PendingChangesGuard],
                resolve: {

                    privileges: PrivilegesResolve,
                },
			},
			{
				path: ':id/edit',
				component: DrugEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
                    drug: DrugResolve,
                    privileges: PrivilegesResolve,
				}
			},
		]
	},
	{
		path: ':customer_id/regimens',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: '',
				component: RegimenListComponent,
				resolve: {
					role: CurrentUserRoleResolve,
                    //regimens: RegimensResolve,
                    privileges: PrivilegesResolve,
				},
			},
			{
				path: 'new',
				component: RegimenNewComponent,
				canDeactivate: [PendingChangesGuard],
                resolve: {
                    dosageWindow: SettingsDosageResolve,
                    privileges: PrivilegesResolve,
                },
			},
			{
				path: ':id/edit',
				component: RegimenEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
                    regimen: RegimenResolve,
                    dosageWindow: SettingsDosageResolve,
                    privileges: PrivilegesResolve,
				}
            },
            {
                path: ':id/view',
                component: RegimenEditComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {
                    regimen: RegimenResolve,
                    dosageWindow: SettingsDosageResolve,
                    privileges: PrivilegesResolve,
                }
            },
		]
	},
	{
		path: 'alerts-alarms',
		component: AlertsAlarmsComponent,
		canActivate: [AuthGuard],
		canDeactivate: [PendingChangesGuard],
		resolve: {
			role: CurrentUserRoleResolve,
            alerts: AlertsAlarmsResolve,
            privileges: PrivilegesResolve,
		}
	},
	{
		path: 'settings',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: 'mcc', component: SettingsComponent,
				canDeactivate: [PendingChangesGuard],
			},
		]
    }
    ,
  //  {
		//path: 'privileges',
  //      component: PrivilegesComponent,
		//canActivate: [AuthGuard],
  //      resolve: {
  //          role: CurrentUserRoleResolve,
  //          user: CurrentUserResolve,
  //          privileges: PrivilegesResolve,
  //      }
  //  }, 
    {
        path: ':customer_id/privileges',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: PrivilegesComponent,
                data: {
                    roles: [UserRole.MedConAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                },
            }
            ,
        ]
    }

    ,
    {
        path: 'patient-report',
        //component: PatientReportComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: '',
                component: PatientReportComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //privileges: PatientResolve,
                },
            }
            ,
        ]
        //resolve: {
        //    role: CurrentUserRoleResolve,
        //    user: CurrentUserResolve,
        //    patientreport: PatientReportResolve,
        //}
    }
    ,
    {
        path: ':customer_id/import-patient',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: ImportPatientComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //privileges: PatientResolve,
                },
            }
            ,
        ]
    },

    {
        path: ':customer_id/company',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: CompanyListComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //companies: PrivilegesResolve,
                },
            }
            ,
            {
                path: 'new',
                component: CompanyNewComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {

                    privileges: PrivilegesResolve,
                },
            },
            {
                path: ':id/edit',
                component: CompanyEditComponent,
                canDeactivate: [PendingChangesGuard],
                resolve: {
                    
                    privileges: PrivilegesResolve,
                    company: CompanyResolve,
                },
            },

        ]
    }
    ,

    {
        path: ':customer_id/labels-committed',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: LabelsCommittedComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //labels: PrivilegesResolve,
                },
            }
            ,
            
        ]
    }
    ,
    {
        path: ':customer_id/measurement',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: MeasurementListComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //privileges: PatientResolve,
                },

            },
            {
                path: 'id/edit',
                component: MeasurementEditComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //privileges: PatientResolve,
                },
            },


        ]
    }
    ,
    {
        path: ':customer_id/broadcast-Messages',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: BroadcastMessagesListComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    //privileges: PatientResolve,

                },
            }
            ,
        ]
    }
    ,
    {
        path: ':customer_id/notifications',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: NotificationsListComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                    notifications: SettingsResolve,
                },

            },


        ]
    }

    ,
    {
        path: ':customer_id/settings',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: SettingsListComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    notifications: SettingsResolve,
                    privileges: PrivilegesResolve,
                    dosageWindow: SettingsDosageResolve,
                    alerts: SettingsAlertResolve,
                    timezone: SettingsTimezoneResolve
                },

            },


        ]
    }
    ,
    {
        path: ':customer_id/export',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: ExportListComponent,
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                },

            },


        ]
    }
    ,
    {
        path: 'Label-Report',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: LabelReportComponent,

                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                },

            },


        ]
    }
    ,
    {
        path: 'titration-Report',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: TitrationReportComponent,

                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                },

            },


        ]
    }
    ,
	{
		path: '**',
		component: PageNotFoundComponent
	}
];
