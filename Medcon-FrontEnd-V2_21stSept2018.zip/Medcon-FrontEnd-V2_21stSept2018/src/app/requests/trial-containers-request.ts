export class TrialContainersRequest {
	constructor(public numbers: any,
		public pairId: number,
		public ignoreDuplicates: boolean) {
	}
}
