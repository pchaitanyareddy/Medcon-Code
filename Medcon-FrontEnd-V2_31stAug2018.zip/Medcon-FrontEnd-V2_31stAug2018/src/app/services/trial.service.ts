import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { LabelService } from './label.service';
import { TrialRequest } from '../requests/trial-request';
import { TrialLabelsRequest } from '../requests/trial-labels-request';
import { PairDrugRegimenRequest } from '../requests/pair-drug-regimen-request';
import { TrialContainersRequest } from '../requests/trial-containers-request';
import { TrialGroupRequest } from '../requests/trialgroup-request';
import { SiteRequest } from '../requests/site-request';
import { Trial } from '../models/trial';
import { Pagination } from '../models/pagination';
import { Patient } from '../models/patient';
import { PatientService } from './patient.service';
import { TrialOptionsRequest } from './requests/trial-options-request';
import { TrialPatientAlertsRequest } from './requests/trial-patient-alerts-request';
import { TrialNotificationsRequest } from './requests/trial-notifications';
import { SubscriptionRequest } from '../requests/Subscription-request';
import { TrailGroupAssociateRequest } from '../requests/trailgroupAssociate-request';
import { TrialgroupAddAssociateRequest } from '../requests/trialgroupAddAssociate-request';
import { TrialgroupAssociateSiteRequest } from '../requests/trialgroupAssociateSite-request';
import { DisassociateSiteRequest } from '../requests/disassociateSite-request';
import { CommonService }from '../services/commonService';
import { saveAs } from 'file-saver';

@Injectable()
export class TrialService {
    constructor(private http: Http,
        private labelService: LabelService,
        private patientService: PatientService) {
    }

    public getCustomerOverview(customerId: number): Observable<(any)> {
        return this.http.get(API_PATH + '/trial/overview/customer/' + customerId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getTrials(customerId: number, page?: number, perPage?: number): Observable<(Pagination<Trial>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        return this.http.get(API_PATH + '/trial/list/' + customerId, { search: params })
            .map((res: Response) => {
                let response = res.json();
                response.items = [];
                res.json().items.forEach((item) => {
                    this.labelService.getOverview(item.id, customerId).subscribe((labels) => item.labels = labels);
                    this.getContainers(item.id, customerId).subscribe((containers) => item.containers = containers);
                    this.patientService.getOverview(item.id, customerId).subscribe((patients) => item.patients = patients);
                    this.getStatus(item.id, customerId).subscribe((status) => item.status = status.value);
                    response.items.push(item);
                });
                return response;
            })
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getTrialsAll(customerId?: number): Observable<Trial[]> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/trial/list/all', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //public getTrial(id: number, customerId: number): Observable<(Trial)> {
    //	let params: URLSearchParams = new URLSearchParams();
    //	params.set('customer_id', String(customerId));

    //	return this.http.get(API_PATH + '/trial/' + id, { search: params })
    //		.map((res: Response) => res.json())
    //		.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //   }

    public getTrial(id: number): Observable<(Trial)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/get/' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_TRIAL+'trial/get/' + id)
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getStatus(id: number, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/trial/' + id + '/status', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getContainers(id: number, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/trial/' + id + '/containers', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createContainers(id: number,
        request: TrialContainersRequest,
        customerId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.post(API_PATH + '/trial/' + id + '/containers', request, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteContainer(id: number, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId || ''));

        return this.http.delete(API_PATH + '/trial/container/' + id, { search: params })
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getPatients(id: number, customerId: number): Observable<(Patient[])> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/trial/' + id + '/patients', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createTrial(request: TrialRequest, companyId: number): Observable<(any)> {
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/' + companyId, request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_TRIAL+'trial/' + companyId, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateTrial(id: number, request: TrialRequest): Observable<(any)> {
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_TRIAL_UPDATE+'trial/update/' + id, request)
        
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateTrialOptions(id: number, request: TrialOptionsRequest): Observable<(any)> {

        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/{id}/trial-options
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + id + '/trial-options', request)
        return this.http.post(CommonService.API_PATH_V2_UPDATE_TRIAL_OPTIONS+'trial/update/' + id + '/trial-options', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public deleteTrial(id: number): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId || ''));

        //return this.http.delete(API_PATH + '/trial/' + id, { search: params })
        //	.map((res: Response) => res.status === 200)
        //	.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        
       // return this.http.delete('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/delete/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_TRIAL+'trial/delete/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public addLabels(id: number, customerId: number, request: TrialLabelsRequest): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.post(API_PATH + '/trial/' + id + '/labels', request, { search: params })
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public pairDrugRegimen(id: number, request: PairDrugRegimenRequest): Observable<(any)> {
        return this.http.post(CommonService.API_PATH_V2_CREATE_DRUG_REGIMEN_PAIR+'trial/update/' + id + '/pair', request)
      //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + id + '/pair', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteDrugRegimenPair(id: number, jsonString: string): Observable<(any)> {
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/delete/' + id + '/pair', jsonString)
        return this.http.put(CommonService.API_PATH_V2_DELETE_DRUG_REGIMEN_PAIR+'trial/delete/' + id + '/pair', jsonString)
        
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public titrateDrugRegimenPair(id: number, request: PairDrugRegimenRequest): Observable<(any)> {
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + id + '/titratepair', request)
        return this.http.put(CommonService.API_PATH_V2_TRITRATE_DRUG_REGIMEN_PAIR+'trial/update/' + id + '/titratepair', request)
              .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public formatDate(date: string): string {
        if (date) {
            let d = date.split('-');
            return [d[1], d[2], d[0]].join('/');
        } else {
            return '-';
        }
    }

    //Code added by ramesh on 19th Dec 2017
    public getPatientContainerList(trialId?: number, customerId?: number, patientId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        params.set('customer_id', String(customerId || ''));
        params.set('patient_id', String(patientId || ''));

        //uncomment this code when API is available
        //return this.http.get(API_PATH + '/patient/containerList', { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        return this.http.get(API_PATH + '/patient/overview', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Code added by ramesh on 19th Dec 2017
    public getPatientTitrateList(trialId?: number, customerId?: number, patientId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        params.set('customer_id', String(customerId || ''));
        params.set('patient_id', String(patientId || ''));
        //uncomment this code when API is available
        //return this.http.get(API_PATH + '/patient/titrateList', { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        return this.http.get(API_PATH + '/patient/overview', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Code added by ramesh on 19th Dec 2017
    public updatePatientStatus(trialId?: number, customerId?: number, patientId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        params.set('customer_id', String(customerId || ''));
        //params.set('patient_id', String(patientId || ''));

        return this.http.put(API_PATH + '/patient/updatestatus/updateStatus' + patientId, { search: params })
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //return this.http.put(API_PATH + '/user/updatestatus/updateStatus' + patientId, { search: params })
        //    .map((res: Response) => res.status === 200)
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 20th Dec 2017
    public getAssociatedTrialGroupList(trialId?: number, customerId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        params.set('customer_id', String(customerId || ''));

        //uncomment this code when API is available
        //return this.http.get(API_PATH + '/trial/getAssociatedTrialGroupList', { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup/{id}
        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 20th Dec 2017
    public associateTrialGroup(trialId: number, request: TrailGroupAssociateRequest
    ): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //params.set('trialGroupId', String(customerId));
       // return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trialId + '/trialgroup', request)
        return this.http.post(CommonService.API_PATH_V2_ASSOCIATE_TRAILGROUP+'trial/update/' + trialId + '/trialgroup', request)
        
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Code added by ramesh on 21st Dec 2017
    public addTrialGroupAndAssociateTrialGroup(trialId: number, request: TrialgroupAddAssociateRequest): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/{id}/trialgroup/add
        //
       // return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trialId + '/trialgroup/add', request)
        return this.http.post(CommonService.API_PATH_V2_ADD_ASSOCIATE_TRAILGROUP+'trial/update/' + trialId + '/trialgroup/add', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 21st Dec 2017
    public disassociateTrialGroup(trialId:number,jsonString:string): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //params.set('trialgroup_id', String(trialGroupId));
        //
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trialId + '/trialgroup', jsonString)
        return this.http.put(CommonService.API_PATH_V2_DISASSOCIATE_TRAILGROUP+'trial/update/' + trialId + '/trialgroup', jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 20th Dec 2017
    public getAssociatedSiteList(trialId?: number, customerId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        params.set('customer_id', String(customerId || ''));

        //uncomment this code when API is available
        //return this.http.get(API_PATH + '/trial/getAssociatedSiteList', { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        return this.http.get(API_PATH + '/patient/overview', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 20th Dec 2017
    public associateSite(trialId: number, request: TrialgroupAssociateSiteRequest): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //params.set('site_id', String(siteId));
        //
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trialId + '/site', request)
        return this.http.post(CommonService.API_PATH_V2_ASSOCIATE_SITE+'trial/update/' + trialId + '/site', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 21st Dec 2017
    public addSiteAndAssociateSite(trialId: number, customerId: number, request: TrialGroupRequest): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.post(API_PATH + '/trial/' + trialId + '/addSiteAndAssociateSite', request, { search: params })
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    ////Code added by ramesh on 21st Dec 2017
    public disassociateSite(siteId: number, request: DisassociateSiteRequest): Observable<(any)> {
        //API_PATH_V2_DISSOCIATE_SITE
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + siteId + '/site', request)
        return this.http.put(CommonService.API_PATH_V2_DISSOCIATE_SITE+'trial/update/' + siteId + '/site', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Code added by ramesh on 28th Dec 2017
    //To get the list trial group list that are not associated with the this given trial
    public getTrialGroupList(trialId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        // params.set('customer_id', String(customerId || ''));

        //uncomment this code when API is available
        //return this.http.get(API_PATH + '/trial/getTrialGroupList', { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        // https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup/{id}
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup' + trialId, { search: params })
        return this.http.get(CommonService.API_PATH_V2_GET_TRIALGROUP_UNDER_TRIAL+'trial/list/trialgroup' + trialId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    //Code added by ramesh on 28th Dec 2017
    //To get the list site list that are not associated with the this given trial
    public getSiteList(trialId?: number, customerId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
        params.set('customer_id', String(customerId || ''));

        //uncomment this code when API is available
        //return this.http.get(API_PATH + '/trial/getAssociatedSiteList', { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        return this.http.get(API_PATH + '/patient/overview', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Code added by ramesh on 3rd Jan 2017
    public saveTrialPatientAlerts(id: number,
        jsonString: string): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/{id}/patient-alerts
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + id + '/patient-alerts', jsonString)
        return this.http.post(CommonService.API_PATH_V2_CREATE_PATIENT_ALERTS+'trial/update/' + id + '/patient-alerts', jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Code added by ramesh on 3rd Jan 2017
    public updateTrialNotifications(id: number,
        request: TrialNotificationsRequest,
        customerId?: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.post(API_PATH + '/trial/' + id + '/trialNotifications', request, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getTrialNotifications(id: number, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/trial/' + id + '/getTrialNotifications', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAllTrialGroups(trailId: number, companyId: number): Observable<(any)> {
        
        //return this.http.get('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/company/all')
        //return this.http.get('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/notintrail/all?trialId=' + trailId + '&companyId=' + companyId)
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_GROUP_NOTIN_TRAIL+'trialgroup/list/notintrail/all?trialId=' + trailId + '&companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getAllSites(trailId: number, companyId: number): Observable<(any)> {
        
        //https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/list/company/all?companyId={}
        //return this.http.get('https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/list/notintrail/all?trialId=' + trailId + '&companyId=' + companyId)
        return this.http.get(CommonService.API_PATH_V2_GET_SITE_NOTIN_TRAIL+'site/list/notintrail/all?trialId=' + trailId + '&companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAllDrugs(companyId: number): any {
        
        //return this.http.get('https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/list/company/all?companyId=' + companyId)
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_DRUGS+'drug/list/company/all?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAllRegimens(companyId: number): any {
        
        //return this.http.get('https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/regimen/list/company/all?companyId=' + companyId)
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_REGIMENS+'regimen/list/company/all?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createNotifications(trailId: Number, request: SubscriptionRequest): Observable<(any)> {
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trailId + '/notifications', request)
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trailId + '/notifications', request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_NOTIFICATION +'notifications/' + trailId , request)
        
            //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/5/notifications', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getSelectedDrugRegimenPair(id: number): any {

        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/get/pair/' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_DRUG_REGIMEN_PAIR+'trial/get/pair/' + id)
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }



    public getTrialOverview(trialId: number): any {
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/overview?trialId=' + trialId)
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_OVERVIEW+'trial/overview?trialId=' + trialId)
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }

    public getTrialOverview_DrugRegimenPairDetails(pairId: number): any {
        
        
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/overview/drugregimen?pairId=' + pairId)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_DRUG_REGIMEN_VIEW+'trial/overview/drugregimen?pairId=' + pairId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getTrialOverview_PatientList(trialId: number): any {
        
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId)
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_PATIENTS+'trial/list/trailpatients/' + trialId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }

    public getTitrateDetails(trialId: number, patientID: any): any {
        
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId + '/titrates?patientId=' + patientID)
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_PATIENTS_TRITRATE+'trial/list/trailpatients/' + trialId + '/titrates?patientId=' + patientID)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getTrailPatientContainerDetails(trialId: number, patientID: any): any {
        
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/{id}/containers
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId + '/containers?patientId=' + patientID)
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_PATIENTS_CONTAINER+'trial/list/trailpatients/' + trialId + '/containers?patientId=' + patientID)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getTrialOverview_ContainerList(trialId: number): any {
        
        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/containers/' + trialId)
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_CONTAINER+'trial/list/containers/' + trialId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }

    public getNotification(id: number): Observable<(any)> {
        localStorage.setItem(String(id) + "_notifications", "Trial notifications exists");
        return this.http.get(CommonService.API_PATH_V2_GET_NOTIFICATION+'notifications/' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => {
                if (error.status === 400) {
                    localStorage.setItem(String(id)+"_notifications", "No trial notifications");
                    return this.http.get(CommonService.API_PATH_V2_GET_NOTIFICATION_MESSAGES+'settings/notificationmessages')
                        .map((res: Response) => res.json())
                        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

                }
                else
                    return Observable.throw(error.json().message || 'Server error')


            });
    }
    public updateNotifications(id: number, request: SubscriptionRequest): Observable<(any)> {
        //https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/{id}
        return this.http.put(CommonService.API_PATH_V2_UPDATE_NOTIFICATION + 'notifications/' + id, request)
        //return this.http.put('https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createTrialNotifications(id: number, request: SubscriptionRequest): Observable<(any)> {
        
        return this.http.post(CommonService.API_PATH_V2_UPDATE_NOTIFICATION + 'notifications/' + id, request)
            //return this.http.put('https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAllTrialGroupsDropDown(companyId: number): Observable<(any)> {
        
        //return this.http.get('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/company/all?companyId=' + companyId)
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_TRIAL_GROUPS+'trialgroup/list/company/all?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    } 
    public getAllTrialGroupsDropDownForTritration(companyId: number): Observable<(any)> {

        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/titrates/{companyId}
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_TRIAL_GROUPS + 'trialgroup/list/titrates/' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getPatientAlerts(id: number,companyId?:number): Observable<(any)> {
        

        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + id + '/patient-alerts')
        return this.http.get(CommonService.API_PATH_V2_GET_PATIENT_ALERTS+'trial/update/' + id + '/patient-alerts')
            .map((res: Response) => 
                {
                if (res) {
                    //alert(res.status);
                        if (res.status === 404) {
                            //return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/alertmessages')
                            return this.http.get(CommonService.API_PATH_V2_GET_ALERT_MESSAGES + 'settings/alertmessages/' + companyId)
                                .map((res: Response) => res.json())
                                .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
                        }
                        else if (res.status === 200) {
                            localStorage.setItem(String(id), "trial patient alerts exists");
                            return res.json();
                        }
                }
                
                
            })
            .catch((error: any) =>
            {
                localStorage.setItem(String(id), "No trial patient alerts");
                //alert('catch block' + error.status);
                if (error.status === 404)
                {
                    
                    //return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/alertmessages')
                    return this.http.get(CommonService.API_PATH_V2_GET_ALERT_MESSAGES + 'settings/alertmessages/' + companyId)
                        .map((res: Response) => res.json())
                        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

                }
                else
                return Observable.throw(error.json().message || 'Server error')


            });

    }


    public updateDrugRegimenPair(id: number, jsonString:string): Observable<(any)> {
        
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/pair/' + id, jsonString)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_DRUG_REGIMEN_PAIR+'trial/update/pair/' + id, jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public convertDateToCalendarFormat(date: string)
    {
        var retVal = date.split("/"); //ex: 03/31/2018
        return retVal[2] + '-' + retVal[0] + '-' + retVal[1]; //2018-01-03
        
    }

    public ExportAll(): void {


        // Is supported
        try {
            let isFileSaverSupported = !!new Blob();
        } catch (e) {
            alert('Browser not supported');
            return;
        }

        let params: URLSearchParams = new URLSearchParams();
        //params.set('trial_id', String(trialId || ''));
        //params.set('customer_id', String(customerId || ''));
        //if (filters) {
        //    filters.forEach((filter) => {
        //        params.set(filter.key, String(filter.value || ''));
        //    });
        //}
        let url ='https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/1?draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=startDate&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=endDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=labelsUsed&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=male&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=female&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=containers&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=Id&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false&_=1523902814864'
        this.http.get(url, { search: params })
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'))
            .subscribe((response) => {
                
                var jsonData = response.text();
                //alert(jsonData.split("data")[1]);

                var csv = this.convertToCSV(jsonData);
                let blob = new Blob([decodeURIComponent(encodeURI(csv))], {
                    type: 'text/csv;charset=utf-8;'
                });

                let filename = 'medcon dose export.csv';
                saveAs(blob, filename);
            });
    }

    public convertToCSV(objArray): string {
        //alert(typeof objArray);
                var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
                var str = '';
                str = 'Start Date, Male,End Date, Labels Used, Trial Name,Female,Total,Containers\r\n';
                //alert(array.data);
                for (var i = 1; i < array.data.length; i++) {
                    var line = '';
                    for (var index in array.data[i]) {
                        if (line != '') line += ','

                        line += array.data[i][index];
                    }

                    str += line + '\r\n';
                }

    return str;
    }

    public IsStartDateGreaterThanEndDate(startDate, endDate):boolean {
        let flag;
        flag = false;
        //var startDate1 = this.convertDateToCalendarFormat(startDate);
        //var endDate1 = this.convertDateToCalendarFormat(endDate);

        //alert(startDate);
        //alert(endDate);
        var startDate2 = new Date(startDate);
        var endDate2 = new Date(endDate);
        var todayDate = new Date();
        //alert(startDate1);
        //alert(todayDate);
        if (startDate2 > endDate2) {
            

            flag = true;
        }

        return flag;
    }

    public deletePatient( patientNumber:string,companyId:number,trialId:number ): Observable<(any)> {
        //API_PATH_V2_DISSOCIATE_SITE
        //return this.http.put('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + siteId + '/site', request)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_PATIENT_UNDER_TRIAL_EDIT + 'user/patient/'+patientNumber+'/'+ companyId+'/'+ trialId)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public GetDrugRegimenPairEndDate(startDate,numberOfDays):string
    {
        var tempDate = new Date(this.convertDate(startDate));
        var duration = numberOfDays; //In Days
        tempDate.setTime(tempDate.getTime() + (duration * 24 * 60 * 60 * 1000));
        var month1 = tempDate.getMonth() + 1;
        var day1 = tempDate.getDate();
        day1 = Number(day1);
        return this.dateForView(tempDate.getFullYear() + '-' + month1 + '-' + day1);
    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {

            return (value <= 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }

}
