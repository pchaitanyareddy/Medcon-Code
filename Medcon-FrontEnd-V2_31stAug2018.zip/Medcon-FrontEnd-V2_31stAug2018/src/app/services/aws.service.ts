import { Injectable } from '@angular/core';
import { CognitoUtil, Callback } from './cognito/cognito.service';

/**
 * Created by Vladimir Budilov
 */

declare var AWS: any;

@Injectable()
export class AwsUtil {
	public static firstLogin: boolean = false;
	public static runningInit: boolean = false;

	private static getCognitoParametersForIdConsolidation(idTokenJwt: string): {} {
		console.log('AwsUtil: enter getCognitoParametersForIdConsolidation()');
		let url = 'cognito-idp.'
			+ CognitoUtil._REGION.toLowerCase()
			+ '.amazonaws.com/'
			+ CognitoUtil._USER_POOL_ID;
		let logins: string[] = [];
		logins[url] = idTokenJwt;
		let params = {
			IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID, /* required */
			Logins: logins
		};

		return params;
	}

	constructor() {
		AWS.config.region = CognitoUtil._REGION;
	}

	/**
	 * This is the method that needs to be called in order to init the aws global creds
	 */
	public initAwsService(callback: Callback, isLoggedIn: boolean, idToken: string) {
		if (AwsUtil.runningInit) {
			// Need to make sure I don't get into an infinite loop here,
			// so need to exit if this method is running already
			console.log('AwsUtil: Aborting running initAwsService()...it\'s running already.');
			// instead of aborting here, it's best to put a timer
			if (callback != null) {
				callback.callback();
				callback.callbackWithParam(null);
			}
			return;
		}

		console.log('AwsUtil: Running initAwsService()');
		AwsUtil.runningInit = true;

		let mythis = this;
		// First check if the user is authenticated already
		if (isLoggedIn) {
			mythis.setupAWS(isLoggedIn, callback, idToken);
		}
	}

	public addCognitoCredentials(idTokenJwt: string): void {
		let params = AwsUtil.getCognitoParametersForIdConsolidation(idTokenJwt);

		AWS.config.credentials = new AWS.CognitoIdentityCredentials(params);

		AWS.config.credentials.get((err) => {
			if (!err) {
				if (AwsUtil.firstLogin) {
					AwsUtil.firstLogin = false;
				}
			}
		});
	}

	/**
	 * Sets up the AWS global params
	 *
	 * @param isLoggedIn
	 * @param callback
	 */
	private setupAWS(isLoggedIn: boolean, callback: Callback, idToken: string): void {
		console.log('AwsUtil: in setupAWS()');
		if (isLoggedIn) {
			console.log('AwsUtil: User is logged in');

			this.addCognitoCredentials(idToken);

			console.log('AwsUtil: Retrieving the id token');
		} else {
			console.log('AwsUtil: User is not logged in');
		}

		if (callback != null) {
			callback.callback();
			callback.callbackWithParam(null);
		}

		AwsUtil.runningInit = false;
	}
}
