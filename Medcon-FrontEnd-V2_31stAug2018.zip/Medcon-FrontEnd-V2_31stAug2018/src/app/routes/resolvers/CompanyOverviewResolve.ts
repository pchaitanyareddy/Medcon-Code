﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CompanyService } from '../../services/company.service';
import { CompanyOverview } from '../../models/CompanyOverview';

@Injectable()
export class CompanyOverviewResolve implements Resolve<CompanyOverview> {
    constructor(private companyService: CompanyService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<CompanyOverview> | Promise<CompanyOverview> | CompanyOverview {
        return this.companyService.getCompanyOverview(route.params['customer_id']);
    }
}
