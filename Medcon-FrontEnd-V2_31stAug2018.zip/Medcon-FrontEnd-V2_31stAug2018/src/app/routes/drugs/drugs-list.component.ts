import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { DrugService } from '../../services/drug.service';
import { Drug } from '../../models/drug';
import { UserRole } from '../../models/userrole';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './drugs-list.component.html?v=${new Date().getTime()}',
    styleUrls: ['./drugs-list.component.scss?v=${new Date().getTime()}']
})

export class DrugsListComponent implements OnInit {
	@ViewChild('deleteModal') public deleteModal: ModalDirective;
	public drugs: Pagination<Drug>;
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public drugToDelete: any;
	public successMessage: string;
	public errorMessage: string;
	public customerId: number;
    public sort = { field: 'name', order: 'desc' };
    public selectedDrug: number;
	public maxSize: number = 5;
	public currentPage: number = 1;
    privilegesByModule: any;
    privilegesList: any;
    isLoading: boolean;
    public privileges: Privileges;
	constructor(public templateService: TemplateService,
		private drugService: DrugService,
        private route: ActivatedRoute,
        private reportService: ReportService,
        private cognitoUtil: CognitoUtil,
		private url: LocationStrategy) {
	}

    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
		this.currentUserRole = this.route.snapshot.data['role'];
		//this.drugs = this.route.snapshot.data['drugs'];
		this.customerId = this.route.snapshot.params['customer_id'];

		if (this.route.queryParams['page']) {
			this.currentPage = this.route.queryParams['page'];
        }


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Drugs')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
	}

	public deleteItem(id): void {
		this.selectedDrug = id;
		this.deleteModal.show();
	}

	public hideDeleteModal(): void {
        this.selectedDrug = null;
		this.deleteModal.hide();
    }

    public ngAfterViewInit(): void {
        //$('#datatable').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        this.loadDrugsList();

    }

	public confirmDelete(): void {
		
		this.drugService
            .deleteDrug(this.selectedDrug)
			.subscribe(
				(response) => {
					//this.drugService.getDrugs(this.customerId).subscribe((drugs) => {
					//	this.drugs = drugs;
					//	this.successMessage = drug.name + ' has been successfully deleted';
					//	this.hideDeleteModal();
					//});
                    this.successMessage ='Selected Drug has been successfully deleted';
                    this.hideDeleteModal();
                    location.reload();
				},
				(err) => {
					this.errorMessage = err;
					this.hideDeleteModal();
				}
			);
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public pageChanged(event: any): void {
		let queryParams = new URLSearchParams();
		queryParams.set('page', event.page);
		queryParams.set('per_page', event.itemsPerPage);

		this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
		this.drugService
			.getDrugs(this.customerId, event.page, event.itemsPerPage)
			.subscribe((drugs) => this.drugs = drugs);
	}

	public sortResults(field): void {
		let oppositeSort = (this.sort.order === 'asc') ? 'desc' : 'asc';
		let order = (this.sort.field === field) ? oppositeSort : 'asc';
		this.sort = { field, order };

		this.drugService.getDrugs(this.customerId, null, null, field, order)
			.subscribe((drugs) => this.drugs = drugs);
    }

    public loadDrugsList(): void {
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_LIST_ALL_DRUGS+'drug/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_LIST_ALL_DRUGS + 'drug/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=2&columns%5B0%5D%5Bdata%5D=trailGroupName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=createdBy&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=createdDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=id&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=trailCount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1525343677314'
                                self.reportService.ExportAll(apiUrl, 'Manage Drug List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        //{
                        //    sortable: false,
                        //    "render": function (data, type, full, meta) {

                        //        return '<img src="https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/1_2b0ec320-b4bf-46cf-9070-cd4352d80fb7.png"' + full.bucketKey+'"></img>';
                        //    }
                        //},
                        //{ "data": "drugName" },
                        { "data": "drugName" },
                        { "data":"drugAlias"},
                        { "data": "medicationType" },
                        { "data": "medication_amount" },
                        { "data": "id" },
                        { "data": "status" },
                        { "data":"paircount"}
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/users/" + full.sub + "/edit\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</a> </div>";
                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script> </div>";
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0 ) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Drug as it is deleted \"  disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Cannot Delete this Drug It is deleted already\"  disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.paircount > 0) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Drug as it is associated \"  disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Cannot Delete this Drug  as it is associated \"  disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0 ) {
                                        return "<div class=\"btn-action\"><a " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else if (full.paircount > 0) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Drug as it is associated \"  disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/drugs/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0 ) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this Drug It is deleted already\"  disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.paircount > 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this Drug  as it is associated \"  disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else {
                                    return "";
                                }
                            }
                        }

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [4],
                            "visible": false
                        }
                        ,
                        {
                            "targets": [6],
                            "visible": false
                        },
                        {
                            "render": (data, type, full) => {
                                if (full.bucketKey != null)
                                {
                                    self.SetAndValidateImageUrl('https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + full.bucketKey, full.id);
                                    return '<img id=' + full.id +' src=https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + full.bucketKey + '></img><span>' + full.drugName + '</span>';
                                }
                                else
                                    return '<img  src="../../../assets/images/medication-type-default.png"></img><span>' + full.drugName + '</span>';
                            },
                            "targets": [0],
                            'searchable': false, 
                        },
                        {
                            "targets": [5],
                            "visible": false,
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                        //,

                        //{
                        //    "targets": [4],
                        //    "searchable": false
                        //}
                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                });
            }
        });

        $('#datatable').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            this.selectedSiteId = buttonId;
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });
        $('#datatable tbody').on("click", 'tr', function (evt) {

           
            if ($(evt.target).is("a") && $(evt.target).is('[disabled]')==false) {
                self.isLoading = true;
            }

        });

    }

    SetAndValidateImageUrl(url, imageId): void {
        //alert(url);
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            //alert(" Image Exists...!");
            //flag = true;
        }).on("error ", function () {
            //alert("ERROR");
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            //flag = false;

        });
        //return flag;

    }
}
