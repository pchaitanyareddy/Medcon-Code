import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CognitoCallback, UserLoginService, LoggedInCallback } from '../../services/cognito/cognito.service';
import '../../../styles/custom.scss';
import { CurrentUserService } from '../../services/currentuser.service';
import { UserRole } from '../../models/userrole';
import { QuestionControlService } from '../../services/questioncontrol.service';
import { TextboxQuestion } from '../../models/question/question-textbox';
import { QuestionBase } from '../../models/question/question-base';
import { withIdentifier } from 'codelyzer/util/astQuery';
import { CognitoUser } from '../../models/cognito-user';
import { UserService } from '../../services/user.service';
@Component({
    templateUrl: './login.component.html?v=${new Date().getTime()}',
	providers: [QuestionControlService]
})

export class LoginComponent implements CognitoCallback, LoggedInCallback, OnInit {
    public user: CognitoUser = new CognitoUser(-1, '', '', -1); //added by ramesh
	public form: FormGroup;
	public newPasswordForm: FormGroup;
	public errorMessage: string;
	public newPassword: boolean;
    public forgotPassword: boolean;
    public showErrors: boolean;
    public forgotPasswordForm: FormGroup;
    public recoveryPasswordForm: FormGroup;
	public questions: Array<QuestionBase<any>> = [];
	private userAttributes: { [key: string]: string };
    public sub: string;
    public recoveryPassword: boolean;
    public successMessage: string;
    isLoading: boolean;
	constructor(private router: Router,
		public userService: UserLoginService,
        public currentUserService: CurrentUserService,
        public userService1: UserService,
		@Inject(FormBuilder) private fb: FormBuilder,
        private qcs: QuestionControlService,

        private route: ActivatedRoute
    ) {
		this.form = fb.group({
			email: ['', Validators.required],
			password: ['', Validators.required],
		});

	}

    public ngOnInit(): void {
        this.isLoading = false;
        this.userService.isAuthenticated(this);

        this.recoveryPasswordForm = this.fb.group({
            otp: ['', Validators.required],
            newPassword: ['', Validators.required],
            confirmPassword: ['', Validators.required]
        });
	}

	public cognitoCallback(message: string, result: any): void {
		if (message != null) { // error
			if (message === 'newpassword') {
				let questions = result.required.map((name) => {
					return new TextboxQuestion({
						key: name,
						placeholder: name.charAt(0).toUpperCase() + name.slice(1),
						value: '',
						required: true,
						order: 1
					});
				});

				questions.push(new TextboxQuestion({
					key: 'password',
					placeholder: 'Password',
					value: '',
					required: true,
					type: 'password',
					order: 2
				}), new TextboxQuestion({
					key: 'confirm_password',
					placeholder: 'Confirm password',
					value: '',
					required: true,
					type: 'password',
					order: 3
				}));

				this.questions = questions.sort((a, b) => a.order - b.order);

				this.newPasswordForm = this.qcs.toFormGroup(this.questions);

				this.userAttributes = result.required;

				this.newPassword = true;
			} else {
				this.errorMessage = message;
			}
		} else if (message == null) {
			this.isLoggedIn('', true);
		} else {
			this.isLoggedIn('', false);
		}
	}

	public isLoggedIn(message: string, loggedIn: boolean): void {
		if (loggedIn) {
            this.currentUserService.getRole().subscribe((role) => {
				
                //8th Feb 2018
                this.isLoading = true;
                this.currentUserService.getUserAttributes().subscribe(
                    (attributes) => {
                        this.user.email = attributes['email'];
                        this.user.name = attributes['name'];
                        this.user.customerId = Number(attributes['custom:customer_id']);
                        this.sub = attributes['sub'];
                        //Added by ramesh on 26th Mar 2018 to make sure that email exists in cognito and medcon db
                        this.currentUserService.getUserProfile(this.user.email).subscribe(
                            (UserProfile) => {
                                if (UserProfile!= null)
                                {
                                    
                                    if (UserProfile.status == true) {
                                        let userRole = UserProfile.roleName;
                                        if (userRole != 'Patient') {
                                            localStorage.setItem('GLOBAL_USER_PROFILE_COMPANY_NAME', String(UserProfile.companyName));
                                            localStorage.setItem('GLOBAL_COMPANY_ID', String(UserProfile.companyId));
                                            localStorage.setItem('GLOBAL_COMPANY_NAME', String(UserProfile.companyName));
                                            localStorage.setItem("GLOBAL_LOGGED_IN_USER_ID", String(UserProfile.userId));
                                            localStorage.setItem("LOGGED_IN_USER_ROLE", String(UserProfile.roleName));
                                            localStorage.setItem("LOGGED_IN_USER_ROLE_ID", String(UserProfile.roleId)); //Added on 12th July 2018 to send this role id to API to get privileges
                                            this.updateLoginInformation(this.sub);
                                        }

                                        if (userRole == 'Label User') {
                                            this.router.navigate(['/', this.user.customerId, 'import-patient']);
                                        }
                                        else if (userRole != 'Patient') {
                                            
                                            this.router.navigate(['/dashboard']);
                                        }
                                        else if (userRole == 'Patient') 
                                        {
                                            this.isLoading = false;
                                            this.errorMessage = 'User not found';
                                            this.userService.logout();

                                        }
                                    }
                                    else // if user status is inactive, do not login, display error msg
                                    {
                                        this.isLoading = false;
                                        this.errorMessage = 'Your account has been Inactivated, please coordinate with MedCon admin to get it activate';
                                        this.userService.logout();
                                    }

                                }
                                else //email not exists in db
                                {
                                    this.isLoading = false;
                                    this.errorMessage = 'User not found';
                                    this.userService.logout();
                                }
                            },
                            (err) => {
                                //console.log(err);
                                this.isLoading = false;
                                this.errorMessage = 'User not found';
                                this.userService.logout();
                            }

                        );
                         //End -Added by ramesh on 26th Mar 2018
                    },
                    (err) => {
                        this.isLoading = false;
                        console.log(err);
                    });
                    //End
                
            }, (err) => {
                this.isLoading = false;
				if (err.message === 'Token is null') {
					this.userService.logout();
				}
			});
		}
	}

    public doLogin(event) {
        
		if (!this.form.valid) {
			this.errorMessage = 'All fields are required';
			return;
        }
        
		this.errorMessage = null;
        this.userService.authenticate(this.form.value.email, this.form.value.password, this);
        
	}

	public doChangePassword(event) {
		if (!this.newPasswordForm.valid) {
			this.errorMessage = 'All fields are required';
			return;
		}
		if (this.newPasswordForm.value.password !== this.newPasswordForm.value.confirm_password) {
			this.errorMessage = 'Passwords are not equal';
			return;
		}

		let newAttributes: { [key: string]: string } = {};
		for (let key in this.newPasswordForm.value) {
			if (this.newPasswordForm.value.hasOwnProperty(key) && key !== 'password' && key !== 'confirm_password') {
				newAttributes[key] = this.newPasswordForm.value[key];
			}
		}

		this.errorMessage = null;
		this.userService.authenticate(
			this.form.value.email,
			this.form.value.password,
			this,
			this.newPasswordForm.value.password,
			newAttributes
        );

        //this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'users']);
	}

	public showForgotPassword() {
		this.forgotPasswordForm = this.fb.group({
			email: [
				'', [Validators.required,
					Validators.pattern('^[a-zA-Z0-9]+(\.[_a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,15})$')]
			]
		});
		this.errorMessage = null;
		this.forgotPassword = true;
	}

	public doForgotPassword() {
		if (!this.forgotPasswordForm.valid) {
			this.errorMessage = 'All fields are required';
			return;
		}

        this.userService.forgotPassword(this.forgotPasswordForm.value.email, this);
        this.recoveryPassword = true;
        this.hideForgotPassword();
        this.newPassword = false;
        this.successMessage = '';
	}

	public hideForgotPassword() {
		this.forgotPassword = false;
		this.errorMessage = null;
    }

    public updateLoginInformation(sub) {
        //let ipAddress = this.userService1.getIPAddress();
        //this.userService1.getIPAddress().subscribe((ipAddress) => {
        //    //this.trials = trials;
        //    //this.viewChanged('trial');
        //    ipAddress = ipAddress; 
        //});


        //var d = new Date();
        ////let sub = '';
        //let loginTime = d; //'2018-02-02 18:18:46';
        //alert(d);
        //var d = new Date,
        //    dformat = [d.getMonth() + 1,
        //    d.getDate(),
        //    d.getFullYear()].join('/') + ' ' +
        //        [d.getHours(),
        //        d.getMinutes(),
        //        d.getSeconds()].join(':');
        let loginTime = this.getLoginDateAndTime();
        //alert(d);
        //alert(loginTime);
        let ipAddress = '';
        let url = window.location.protocol + "//" + window.location.host + window.location.pathname;//'https://trial.med-conllc.com';
        let jsonString = '{\r\n    \"loginTime\":\"' + loginTime + '\",\r\n  \"ipAddress\":\"' + ipAddress + '\",\r\n  \"url\":\"' + url+'/\"\r\n}'

        this.userService1.updateLoginInformation(jsonString,sub).subscribe(
            (response) => {
                
            },
            (err) => {
                this.errorMessage = err;
            });

    }

    public getLoginDateAndTime():string
    {

        let now = new Date();
        let year = "" + now.getFullYear();
        let month = "" + (now.getMonth() + 1); if (month.length == 1) { month = "0" + month; }
        let day = "" + now.getDate(); if (day.length == 1) { day = "0" + day; }
        let hour = "" + now.getHours(); if (hour.length == 1) { hour = "0" + hour; }
        let minute = "" + now.getMinutes(); if (minute.length == 1) { minute = "0" + minute; }
        let second = "" + now.getSeconds(); if (second.length == 1) { second = "0" + second; }
        return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
    }


    public doRecoveryPassword() {
        //this.recoveryPassword = true;
        //this.hideForgotPassword();
        //this.forgotPassword = false;
        if (!this.recoveryPasswordForm.valid) {
            this.errorMessage = 'All fields are required';
            this.showErrors = true;
            return;
        }
        if (this.recoveryPasswordForm.value.newPassword !== this.recoveryPasswordForm.value.confirmPassword) {
            this.errorMessage = 'Passwords are not equal';
            this.showErrors = true;
            return;
        }

        let newAttributes: { [key: string]: string } = {};
        for (let key in this.recoveryPasswordForm.value) {
            if (this.recoveryPasswordForm.value.hasOwnProperty(key) && key !== 'password' && key !== 'confirm_password') {
                newAttributes[key] = this.recoveryPasswordForm.value[key];
            }
        }


        this.errorMessage = null;
        this.recoveryPassword = true;
        this.userService.confirmNewPassword(
            this.forgotPasswordForm.value.email,
            this.recoveryPasswordForm.value.otp,
            this.recoveryPasswordForm.value.newPassword,
            this
            
        );
        //alert(this.forgotPasswordForm.value.email);
        //alert(this.newPasswordForm.value.newPassword);
        //alert(this.newPasswordForm.value.confirmPassword);
        //this.userService.authenticate(
        //    this.forgotPasswordForm.value.email,
        //    this.recoveryPasswordForm.value.newPassword,
        //    this,
        //    this.recoveryPasswordForm.value.confirmPassword,
        //    newAttributes
        //);
        //this.userService.authenticate(this.form.value.email, this.form.value.password, this);
        this.successMessage = 'Password has been changed successfully.';
        //this.hideRecoveryPassword();
        this.recoveryPasswordForm.reset();
        this.form.reset();
    }
    public hideRecoveryPassword() {
        this.recoveryPassword = false;
        this.errorMessage = null;
    }

    public redirectToLogin() {

        this.newPassword = false;
        this.forgotPassword = false;
        this.recoveryPassword = false;
    }


}
