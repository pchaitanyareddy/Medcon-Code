import { Component, HostListener, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-dosage-history',
	templateUrl: './widget-dosage-history.component.html',
	styleUrls: ['./widget-dosage-history.component.scss']
})

export class WidgetDosageHistoryComponent implements OnInit {
	public showMenu = false;
    public activeOption: any;
    public defaultOption: string;
    public options = [
        {
            id: 'daily',
            name: 'Daily'
        },
        {
            id: 'weekly',
            name: 'Weekly'
        },
        {
            id: 'monthly',
            name: 'Monthly'
        }
    ];
	public options1 = [
		{
			id: 'DosageHistory',
            name: 'Dosage History'
        }
  //      ,
		//{
		//	id: 'PatientMinimumAdherence',
  //          name: 'Patient Minimum Adherence'
  //      }
  //      ,
		//{
		//	id: 'monthly',
		//	name: 'Monthly'
		//}
	];

	// Area graph values
	public chartData: any;
	public chartLabels = {
		daily: [
			'6 Days ago', '5 Days ago', '4 Days ago', '3 Days ago', '2 Days ago', 'Yesterday', 'Today'
		],
		weekly: [
			'6 Wks/ago', '5 Wks/ago', '4 Wks/ago', '3 Wks/ago', '2 Wks/ago', 'Last week', 'This week'
		],
		monthly: [
			'6 Mths/ago', '5 Mths/ago', '4 Mths/ago', '3 Mths/ago', '2 Mths/ago', 'Last Month', 'This Month'
		]
	};
	public lineChartData: any[] = [
		{ data: [0, 0, 0, 0, 0, 0, 0], label: 'Missed' },
		{ data: [0, 0, 0, 0, 0, 0, 0], label: 'Taken' }
	];
	public lineChartLabels = [];

	// Area graph set up
	public lineChartOptions: any = {
		responsive: true,
		maintainAspectRatio: false
	};
	public lineChartColors: any[] = [
		{ // blue
			backgroundColor: 'rgba(140,164,239,0.6)',
			borderColor: 'rgba(140,164,239,1)',
			pointBackgroundColor: 'rgba(140,164,239,1)',
			pointBorderColor: '#fff',
			pointHoverBackgroundColor: '#fff',
			pointHoverBorderColor: 'rgba(140,164,239,1)'
		},
		{ // purple
			backgroundColor: 'rgba(127,63,152,0.6)',
			borderColor: 'rgba(127,63,152,1)',
			pointBackgroundColor: 'rgba(127,63,152,1)',
			pointBorderColor: '#fff',
			pointHoverBackgroundColor: '#fff',
			pointHoverBorderColor: 'rgba(127,63,152,0.8)'
		}
	];
	public lineChartLegend: boolean = true;
	public lineChartType: string = 'line';

	constructor(private dashboardService: DashboardService) {
	}

    public ngOnInit() {
       
		this.dashboardService.viewState.subscribe((state) => {
			let savedOption = this.options.filter((option) => option.id === state.dosageHistory);
            this.activeOption = (savedOption[0]) ? savedOption[0] : this.options[1];
            if (this.activeOption != undefined)
			this.lineChartLabels = this.chartLabels[this.activeOption.id];
        });
        //alert(this.activeOption);
        if (this.activeOption != undefined) {
            this.dashboardService.dosageHistory.subscribe((value) => {
                if (value) {
                    this.chartData = value;
                    this.toggleMenuOption('daily', false);
                }
            });

        }
        //$('input:radio[id="pnlDosageHistoryRadBtns"][name="Daily"]').prop('checked', true);
        //$('input:radio[name="Daily"][value="Daily"]').prop('checked', true);
        this.defaultOption = 'Daily';
       
    }

    public ngAfterViewInit(): void {
        //To display the Daily graph by default on the page load
        //this.lineChartLabels = this.chartLabels['daily'];
        //setTimeout(() => {
        //    this.lineChartData = [
        //        { data: this.chartData['daily'].missed, label: 'Missed' },
        //        { data: this.chartData['daily'].taken, label: 'Taken' }
        //    ];
        //});
        //End
    }

    selectedRadBtn_DosageHistory(selectedValue)
    {

        if (selectedValue == "daily") {
            
            $('input:radio[id="pnlDosageHistoryRadBtns"][name="Weekly"]').prop('checked', false);
            $('input:radio[id="pnlDosageHistoryRadBtns"][name="Monthly"]').prop('checked', false);

        }
        else if (selectedValue == "weekly") {

            $('input:radio[id="pnlDosageHistoryRadBtns"][name="Daily"]').prop('checked', false);
            $('input:radio[id="pnlDosageHistoryRadBtns"][name="Monthly"]').prop('checked', false);
        }
        else if (selectedValue == "monthly") {
           
            $('input:radio[id="pnlDosageHistoryRadBtns"][name="Daily"]').prop('checked', false);
            $('input:radio[id="pnlDosageHistoryRadBtns"][name="Weekly"]').prop('checked', false);
        }


        this.showMenu = false;
        //this.activeOption = this.options1.filter((option) => option.id === optionID)[0];
        //if (updateServer !== false) {
        //    this.dashboardService.setDashboardStateValue('dosageHistory', this.activeOption.id);
        //}
        //Code added by ramesh on 19th Mar 2018
        //selectedValue is nothing but radio button selected value(i.e daily, weekly, monthly)
        this.lineChartLabels = this.chartLabels[selectedValue];
        setTimeout(() => {
            this.lineChartData = [
                { data: this.chartData[selectedValue].missed, label: 'Missed' },
                { data: this.chartData[selectedValue].taken, label: 'Taken' }
            ];
        });


    }

    public toggleMenuOption(optionID, updateServer?: boolean): void {
  //      var dailyRadioButton = $('input[id="radDaily"]');
  //      var dailyRadioButtonCheckedValue = dailyRadioButton.filter(':checked').val();
  //      //alert(dailyRadioButtonCheckedValue);
		//this.showMenu = false;
		//this.activeOption = this.options1.filter((option) => option.id === optionID)[0];
		//if (updateServer !== false) {
		//	this.dashboardService.setDashboardStateValue('dosageHistory', this.activeOption.id);
		//}

		//this.lineChartLabels = this.chartLabels[this.activeOption.id];
		//setTimeout(() => {
		//	this.lineChartData = [
		//		{ data: this.chartData[this.activeOption.id].missed, label: 'Missed' },
		//		{ data: this.chartData[this.activeOption.id].taken, label: 'Taken' }
		//	];
		//});
        //alert(optionID);
        this.showMenu = false;
        this.activeOption = this.options.filter((option) => option.id === optionID)[0];
        if (updateServer !== false) {
            this.dashboardService.setDashboardStateValue('dosageHistory', this.activeOption.id);
        }

        this.lineChartLabels = this.chartLabels[this.activeOption.id];
        setTimeout(() => {
            this.lineChartData = [
                { data: this.chartData[this.activeOption.id].missed, label: 'Missed' },
                { data: this.chartData[this.activeOption.id].taken, label: 'Taken' }
            ];
        });
	}

	public toggleMenu(): void {
		this.showMenu = !this.showMenu;
	}

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-menu-dh') {
			this.showMenu = false;
		}
	}
}
