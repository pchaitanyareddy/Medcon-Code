import { Component, OnInit, ViewChild  } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { RegimenService } from '../../services/regimen.service';
import { PatientService } from '../../services/patient.service';
import { TrialService } from '../../services/trial.service';
import { Trial } from '../../models/trial';
import { TrialOverview } from '../../models/trialoverview';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { ModalDirective } from 'ngx-bootstrap';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import 'rxjs/add/operator/switchMap';

var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
	templateUrl: './trial-view.component.html',
	styleUrls: ['./trial-view.component.scss']
})

export class TrialViewComponent implements OnInit {
    @ViewChild('assignDrugRegimenModal') public assignDrugRegimenModal: ModalDirective;
    public trial: Trial;
    public trialOverview: TrialOverview;
	public containerLimit = 5;
	public activeContainer: Object;
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public customer: Customer;
	public drugs = [];
    selectedCompanyId: number;
    public errorMessage: string;
	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private regimenService: RegimenService,
        private patientService: PatientService,
        private cognitoUtil: CognitoUtil,
		private trialService: TrialService) {
	}

	public ngOnInit(): void {
		this.currentUserRole = this.route.snapshot.data['role'];
		this.trial = this.route.snapshot.data['trial'];
		this.customer = this.route.snapshot.data['customer'];
		//this.trial.labels = this.route.snapshot.data['labels'];
		//this.trial.containers = this.route.snapshot.data['containers'];
		//this.trial.patients = this.route.snapshot.data['patients'];
        this.trialOverview = this.route.snapshot.data['trialOverview'];
        //this.trialOverview.lastScan = this.route.snapshot.data['trialOverview'].lastScan;
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        //alert(this.trialOverview.lastScan);
		// Unique list of drugs on this trial, for each drug add all regimens on this trial using it
		//this.trial.drPairs.forEach((pair) => {
		//	if (!this.drugs[pair.drug.id]) {
		//		this.drugs[pair.drug.id] = {
		//			drug: pair.drug,
		//			regimen: [pair.regimen.name]
		//		};
		//	} else {
		//		let drug = this.drugs[pair.drug.id];
		//		if (!drug.regimen.includes(pair.regimen.name)) {
		//			drug.regimen.push(pair.regimen.name);
		//		}
		//	}
		//});
		// Reset the indexes (otherwise the array length matches the highest drug id)
		this.drugs = this.drugs.filter(() => {
			return true;
		});
	}


    public ngAfterViewInit(): void {

        //$('#datatable_trialOverviewPatientList').DataTable();
        this.loadTrialOverViewPatientList();

    }

	public moreContainers(): void {
		this.containerLimit = 6;
	}

	public populateContainerPopover(container): void {
		this.activeContainer = container;
	}

	public convertMinutes(totalMinutes: number): string {
		return this.regimenService.convertMinutesToString(totalMinutes);
	}

	public getAge(date) {
		return this.patientService.getAge(date);
	}

	public formatDate(date: string): string {
		return this.trialService.formatDate(date);
    }

    public hideAssignDrugRegimenModal(): void {
        this.assignDrugRegimenModal.hide();
    }

    viewAssignDrugRegimenPairDetails(id)
    {
        this.trialService.getTrialOverview_DrugRegimenPairDetails(Number(id)).subscribe(
            (response) => {
                //this.patientInformation = response;
                //this.viewSummaryModal.show();
                //alert(response.firstName);
                //let status = (response.status) ? "Active" : "Inactive";
                $("#spnDrug").text(response.drugname);
                $("#spnRegimen").text(response.regimenname);
                $("#spnDurationBetweenDoses").text(response.doseduration);
                $("#spnAdheranceThreshold").text(response.threshold);
                $("#spnScheduleType").text(response.scheduletype);
                $("#spnTotalDoses").text(response.dosetotal);
                $("#spnDoseType").text(response.dosetype);
                $("#spnDoseAmount").text(response.doseAmount);
                $("#spnDoseUnit").text(response.doseunit);
                $("#spnDoseTotal").text(response.dosetotal);
               
                ///this.viewSummaryModal.show();
                this.assignDrugRegimenModal.show();
            },
            (err) => {
                this.errorMessage = err;

            });

        


    }

    public loadTrialOverViewPatientList():void
    {

        let trialId = 9;//this.trial.id;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_trialOverviewPatientList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        'csv', 'print'

                    ],
                    "columns": [
                        
                        { "data": "PatientID" },
                        { "data": "age" },
                        { "data": "Sex" },
                        { "data": "Race" },
                        { "data": "FirstScan" },
                        { "data": "LastScan" },
                        { "data": "Containers" }
                    ]
                    
                });
            }
        });


    }
    
}
