import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { PatientService } from '../../services/patient.service';
import { DoseService } from '../../services/dose.service';
import { UserService } from '../../services/user.service';
import { TrialService } from '../../services/trial.service';
import { LabelService } from '../../services/label.service';
import { CompanyService } from '../../services/company.service';
import { Customer } from '../../models/customer';
import { CompanyOverview } from '../../models/CompanyOverview';
import { Drug } from '../../models/drug';
import { Regimen } from '../../models/regimen';
import { Site } from '../../models/site';
import { UserRole } from '../../models/userrole';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { Privileges } from '../../models/privileges';
@Component({
    templateUrl: './customer-view.component.html?v=${new Date().getTime()}',
    styleUrls: ['./customer-view.component.scss?v=${new Date().getTime()}']
})

export class CustomerViewComponent implements OnInit {
    //public customer: Customer;
    public customer: CompanyOverview;
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public regimens: Regimen[];
	public drugs: Drug[];
	public site: Site;
	public patientOverview: any;
	public doseOverview: any;
	public userOverview: any;
	public trialOverview: any;
	public labelOverview: any;
	public activeYear: number;
	public years = [];
    public labelDetailsList: any;
    public companyId: number;
    public labelDetailsObject: number;
    public errorMessage: string;
    public isLoading: boolean;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    @ViewChild('labelDetailsModal') public labelDetailsModal: ModalDirective;
	constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
		private patientService: PatientService,
		private doseService: DoseService,
		private userService: UserService,
        private trialService: TrialService,
        private companyService: CompanyService,
		private labelService: LabelService) {
	}

	public ngOnInit(): void {
		//this.customer = this.route.snapshot.data['customer'];
		this.currentUserRole = this.route.snapshot.data['role'];
		//this.regimens = this.route.snapshot.data['regimens'];
        //this.drugs = this.route.snapshot.data['drugs'];
        this.customer = this.route.snapshot.data['companyOverview'];
        //if (this.customer == undefined || this.customer == null)
        //{
        //    this.companyService
        //        .getCompanyOverviewInformation(1)
        //        .subscribe((overview) => this.customer = overview);


        //}
        //alert(this.customer[2].companyinfo.name);
        //alert(this.route.snapshot.params['customer_id']);
        if (this.route.snapshot.params['customer_id'] != undefined)
        {
            this.companyId = Number(this.route.snapshot.params['customer_id']);
        }
        else if (localStorage.getItem("GLOBAL_COMPANY_ID") != undefined)
        {
            this.companyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));

        }
		for (let i = 2017; i <= 2017 + 1; i++) {
			this.years.push(i);
		}
		this.activeYear = this.years[0];
        this.yearChanged();


        //Uncomment these APIs when available
		//this.patientService
		//	.getOverview(null, this.customer.id)
		//	.subscribe((overview) => this.patientOverview = overview);

		//this.doseService
		//	.getCustomerOverview(this.customer.id)
		//	.subscribe((overview) => this.doseOverview = overview);

		//this.userService
		//	.getCustomerOverview(this.customer.id)
		//	.subscribe((overview) => this.userOverview = overview);

		//this.trialService
		//	.getCustomerOverview(this.customer.id)
		//	.subscribe((overview) => this.trialOverview = overview);

		//if (this.route.snapshot.data['sites'][0]) {
		//	this.site = this.route.snapshot.data['sites'][0];
  //      }

        //this.labelDetailsList = [
        //    { labelName: 'Label1Aug2017', labelsPurchased: '1000', date: '11/29/2017' },
        //    { labelName: 'Label1Sept2017', labelsPurchased: '2000', date: '10/18/2017' },
        //    { labelName: 'Label1Oct2017', labelsPurchased: '800', date: '09/03/2017' },
        //    { labelName: 'Label1Nov2017', labelsPurchased: '1500', date: '08/30/2017' },

        //]

        //19th July 2018 code added to check edit company access privileges to the given role
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Company') 

        //localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);


        //End

       
	}

	public yearChanged(): void {
		//this.labelService
		//	.getOverview(null, this.customer.id, this.activeYear)
		//	.subscribe((overview) => this.labelOverview = overview);
    }

    public hideLabelDetailsModal(): void {
        
        this.labelDetailsModal.hide();
    }

    public viewLabelDetails(): void {

        this.companyService.getCompanyOverview_LabelDetails(this.companyId,2018).subscribe(
            (response) => {
                //this.patientInformation = response;
                //this.viewSummaryModal.show();
                //alert(response.firstName);
                let status = (response.status) ? "Active" : "Inactive";
                $("#spnActive").text(status);
                $("#spnCommitted").text(response.committed);
                $("#spnPurchased").text(response.purchased);
                $("#spnUsed").text(response.used);
                $("#spnRemaining").text(response.remaining);
                $("#Country").text(response.country);
                $("#Gender").text(response.gender);
                $("#State").text(response.state);
                $("#EmailAddress").text(response.emailAddress);
                $("#City").text(response.location);
                $("#Mobile").text(response.phoneNumber);
                $("#Zipcode").text(response.zipcode);
                $("#Race").text(response.race);
                $("#City").text(response.city);
                this.LoadLabelPurchaseData(this.companyId);
                this.labelDetailsModal.show();
                //$('#pnlViewSummaryModal').modal('show'); 
            },
            (err) => {
                this.errorMessage = err;

            });

        ///this.labelDetailsModal.show();
    }

    public LoadLabelPurchaseData(companyId): void {

        //alert(companyId);
        //alert("LoadLabelData Entered");


        this.labelService.getLabelPurchase(companyId).subscribe(
            (response) => {
                this.labelDetailsList = response



            },
            (err) => {
                this.errorMessage = err;

            });

    }

    public btnEditCompany(): void {
        //alert(this.companyId);
        this.isLoading = true;
        this.router.navigate(['/', this.companyId, 'company', this.companyId, 'edit']);
    }


}
