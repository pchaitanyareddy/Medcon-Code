import { UserRole } from './userrole';

export class User {
    constructor(public userId: number,
        public firstName: string,
        public lastName: string,
        public emailAddress: string,
        public phoneNumber: string,
        public password: string,
        public dateOfBirth: Date,
        public gender: string,
        public raceName: string,
        public roleName: string,
        public roleId: number,
        public createdBy: string,
        public createdDate: Date,
        public lastUpdatedBy: string,
        public lastUpdatedDate: Date,
        public companyName: string,
        public active: string,
        public sub: string,
        public email: string,
        public givenName: string,
        public familyName: string,
        public companyId: number
    ) {
	}
	
	
}
