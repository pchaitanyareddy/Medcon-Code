﻿export class UserProfile {
	constructor(public status: boolean,
		public companyName: string,
		public userId: number,
		public emailAddress: string,
		public sub:string,
		public firstName:string,
		public companyId:number,
		public gender:string,
		public phoneNumber:string,
		public location:string,
		public roleId:number,
		public lastName:string,
		public roleName:string
		) {
	}
}
