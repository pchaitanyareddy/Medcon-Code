﻿import { UserRole } from './userrole';

export class TrialGroup {
    constructor(public trialGroupId: number,
        public trialGroupName: string,
        public createdBy: string,
        public createdDate: string,
        public trialCount: number
        ) {
    }


}
