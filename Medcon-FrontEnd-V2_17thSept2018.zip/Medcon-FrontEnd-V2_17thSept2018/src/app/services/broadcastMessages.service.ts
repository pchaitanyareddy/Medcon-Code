﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { BroadcastMessages } from '../models/broadcastMessages';
import { BroadcastMessagesRequest } from '../requests/broadcastMessages-request';
import { Observable } from 'rxjs';
import { Pagination } from '../models/pagination';
import {CommonService} from '../services/commonService';

@Injectable()
export class BroadcastMessagesService {
    constructor(private http: Http) {
    }

    public getBroadcastMessages(customerId?: number): Observable<Pagination<BroadcastMessages>> {
        let customer = (customerId) ? '/' + customerId : '';

        return this.http.get(API_PATH + '/site/list' + customer)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createBroadcastMessages(request: BroadcastMessagesRequest): Observable<(any)> {
        

        //return this.http.post(' https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/broadcast', request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_BROADCAST_MESSAGE+'broadcast', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateBroadcastMessages(id: number, request: BroadcastMessagesRequest): Observable<(any)> {
        
        //return this.http.put('https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/broadcast/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_EDIT_BROADCAST_MESSAGE+'broadcast/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getBroadcastMessage(id: number): Observable<(BroadcastMessages)> {
        
        //return this.http.get('https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/broadcast/' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_BROADCAST_MESSAGE+'broadcast/' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getBroadcastMessageList(customerId: number, page?: number, perPage?: number): Observable<(Pagination<BroadcastMessages>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        //Uncomment this when API service is ready
        //return this.http.get(API_PATH + '/trialgroup/list/' + customerId, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAllTrails(companyId: number): any {

        //return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trail/list/1/all')
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_LIST_ALL + 'trail/list/' + companyId + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


}
