export class RegimenRequest {
    constructor(public name: string,
        public medicationPerDose: number,
        public totalDoses: number,
        public extraDoses: number,
        public durationBetweenDoses: number,
        public thresholdTime: number,
        public scheduleType: string,
        public morningDosingWindowSchedule: string,
        public afternoonDosingWindowSchedule: string,
        public eveningDosingWindowSchedule: string,
        public bedtimeDosingWindowSchedule: string,
        public userId:number) {
	}
}
