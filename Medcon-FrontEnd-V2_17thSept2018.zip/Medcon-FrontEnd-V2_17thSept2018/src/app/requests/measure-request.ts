﻿export class MeasureRequest {
    constructor(
        public medicationTypeName: string,
       
        public unitOfMeasure: string,
        public image: string,
        public userId?: number
       
       
    ) {
    }
}
