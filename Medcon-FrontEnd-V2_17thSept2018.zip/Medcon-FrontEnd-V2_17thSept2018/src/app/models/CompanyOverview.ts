﻿export class CompanyOverview {
    constructor(
        public trialadmin: number,
        public customerusers: number,
        public companyadmin: number,
        public companyadherence: number,
        public actualadherence: number,
        public delta: number,
        public phone: string,
        public containers: number,
        public regimens: number,
        public name: string,
        public dosecounts: number,
        public drugs: number,
        public adress: string,
        public type: string,
        public totalpatients: string,
        public dosesunits: number,
        public used: number,
        public remaining: number,
        public purchased: number,
        public committed: number,
        public active: number,
        public completed: number,
        public pending:number

    ) {
    }
}
