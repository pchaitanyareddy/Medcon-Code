import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-monthly-adherence-info',
	templateUrl: './widget-adherence-info.component.html'
})

export class WidgetMonthlyAdherenceInfoComponent implements OnInit {
	public stats: any;

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit(): void {
		this.dashboardService.doseAdherenceInfo.subscribe((value) => {
			if (value) {
				this.stats = value.monthly;
			}
		});
	}
}
