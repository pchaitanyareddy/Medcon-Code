﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { TrialGroupService } from '../../services/trialgroup.service';
import { TrialGroup } from '../../models/trialgroup';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './trialgroup-list.component.html?v=${new Date().getTime()}'
})

export class TrialGroupListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public trialGroups: Pagination<TrialGroup>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public trialGroupToDelete: TrialGroup;
    isLoading: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    trialGroupList: any;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    public selectedTrialGroupID: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private trialGroupService: TrialGroupService,
        private reportService: ReportService,
        private cognitoUtil:CognitoUtil,
        private url: LocationStrategy) {

    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.trialGroups = this.route.snapshot.data['trialGroups'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        if (this.currentUserRole === UserRole.MedConAdmin) {
            this.trialGroupService.getTrialGroupList(this.selectedCustomerId)
                .subscribe((trialGroup) => {
                    this.trialGroups = trialGroup;
                    this.successMessage = ' has been successfully deleted';
                    this.hideDeleteModal();
                }
                );
        }
        

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Trial Groups')

        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
    }

    public ngAfterViewInit(): void {
               
        //API code for list
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                / tslint:disable:no-empty /
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_LIST_TRIAL_GROUP+'trialgroup/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),


                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 4]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_LIST_TRIAL_GROUP + 'trialgroup/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=2&columns%5B0%5D%5Bdata%5D=trailGroupName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=createdBy&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=createdDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=id&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=trailCount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1525343677314'
                                self.reportService.ExportAll(apiUrl, 'Trialgroup List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 4]
                            }}

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "trailGroupName" },
                        { "data": "createdBy" },
                        { "data": "createdDate" },
                        { "data": "id" },
                        { "data": "trailCount" },
                        { "data": "status" }

                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                //return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script> </div>";
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Trial as it is already deleted\" disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Cannot Delete this TrialGroup its already Deleted\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.trailCount > 0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Cannot Delete this Trialgroup as trialCount is associated with \" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else { //general scenario
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Trial as it is already deleted\" disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a>  </div>";
                                    }
                                    else if (full.trailCount > 0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a>   </div>";
                                    }
                                    else { //general scenario
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trialgroup/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this TrialGroup its already Deleted\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.trailCount > 0) {
                                        return "<div class=\"btn-action\"> <button title=\"Cannot Delete this Trialgroup as trialCount is associated with \" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else { //general scenario
                                        return "<div class=\"btn-action\"> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else {

                                    return "";
                                }
                            }
                        }


                    ],
                    "columnDefs": [

                        {
                            "targets": [3],
                            "visible": false
                        },
                        {
                            "targets": [5],
                            "visible": false,
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }

                        }
                    ],
                     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                });
            }
        });

        $('#datatable').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            this.selectedTrialGroupID = buttonId;
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });
        $('#datatable tbody').on("click", 'tr', function (evt) {


            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });


    }

    public deleteItem(id): void {
        this.selectedTrialGroupID = id;
        this.deleteModal.show();
    }

    public hideDeleteModal(): void {
        this.trialGroupToDelete = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        let trialGroup = this.trialGroupToDelete;
        this.trialGroupService
            .deleteTrialGroup(this.selectedTrialGroupID)
            .subscribe(
            (response) => {
                //this.trialGroupService.getTrialGroupList(this.selectedCustomerId)
                //    .subscribe((trialGroups) => {
                //        this.trialGroups = trialGroups;

                //        this.hideDeleteModal();
                //    }
                //    );
                this.successMessage = "Successfully deleted TrialGroup";
                this.hideDeleteModal();
                location.reload();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public customerChanged(): void {
        this.trialGroupService.getTrialGroupList(this.selectedCustomerId).subscribe((trialGroups) => {
            this.trialGroups = trialGroups;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/trialGroups', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.trialGroupService.getTrialGroupList(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((trialGroups) => {
            this.trialGroups = trialGroups;
        });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
   
    //public changeUserStatus(trialGroup): void {
    //    this.trialGroupToDelete = trialGroup;
    //    this.changeStatusModal.show();
    //}

    //public hideChangeUserStatusModal(): void {
    //    this.trialGroupToDelete = null;
    //    this.changeStatusModal.hide();
    //}


    //public confirmChangeStatusConfirmation(): void {
    //    let user = this.trialGroupToDelete;
    //    this.userService
    //        .updateUserStatus(user.id, this.selectedCustomerId)
    //        .subscribe(
    //        (response) => {
    //            this.userService.getUsers(this.selectedCustomerId)
    //                .subscribe((users) => {
    //                    this.users = users;
    //                    this.successMessage = user.firstName + ' ' + user.lastName + ' has been changed status successfully';
    //                    this.hideChangeUserStatusModal();
    //                }
    //                );
    //        },
    //        (err) => {
    //            this.errorMessage = err;
    //            this.hideChangeUserStatusModal();
    //        }
    //        );
    //}
}
