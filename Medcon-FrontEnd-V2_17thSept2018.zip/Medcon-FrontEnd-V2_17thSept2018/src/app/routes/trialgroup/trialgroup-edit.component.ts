﻿import { Component, HostListener, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import 'rxjs/add/operator/switchMap';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialGroupService } from '../../services/trialgroup.service';
import { PatientService } from '../../services/patient.service';
import { LabelService } from '../../services/label.service';
import { TrialGroup } from '../../models/trialgroup';
import { Drug } from '../../models/drug';
import { Regimen } from '../../models/regimen';
import { Customer } from '../../models/customer';
import { UserRole } from '../../models/userrole';
import { Site } from '../../models/site';
import { PairDrugRegimenRequest } from '../../requests/pair-drug-regimen-request';
import { TrialGroupRequest } from '../../requests/trialgroup-request';
import { Observable } from 'rxjs/Observable';
import _ from 'lodash';

@Component({
    templateUrl: './trialgroup-edit.component.html?v=${new Date().getTime()}'
    
})

export class TrialGroupEditComponent implements OnInit {
    //@ViewChild('deleteModal') public deleteModal: ModalDirective;
    //@ViewChild('dataMatrixModal') public dataMatrixModal: ModalDirective;
    //@ViewChild('trialMenu') public trialMenu: TabsetComponent;
    public deleteType: string;
    public deleteObject: any;
    public trialGroup: TrialGroup;
    public trailGroupName: TrialGroup;
    public drugs: Drug[];
    public regimens: Regimen[];
    public containerLimit = 5;
    public activeContainer: Object;
    public trialGroupEdit: FormGroup;
    //public formPair: FormGroup;
    //public formLabels: FormGroup;
    //public formAssignContainers: FormGroup;
    //public formTrialOptions: FormGroup;
    public dataMatrixCodes = [];
    public showErrors: boolean;
    public error: any;
    public assignDrug: Drug;
    public assignRegimen: Regimen;
    public assignDrugRegimenError: String;
    public assignDrugRegimenSuccess: boolean;
    public drugRegimenPairs = [];
    public customer: Customer;
    public userId: UserRole;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public sites: Site[];
    public successMessage: string;
    public errorMessage: string;
    public durationError: boolean;
    public earlyDosingThreshholdError: boolean;
    public days = [];
    public hours = [];
    public minutes = [];
    public trailGroupId: number;
    public trailCount: number;
    isLoading: boolean;
    public createdDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    
    constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
        private fb: FormBuilder,
        private trialGroupService: TrialGroupService,
        private changeDetectorRef: ChangeDetectorRef) {
    }

    public ngOnInit(): void {
        this.isLoading = false;
        //Added by ramesh on 8th Oct 2017
        let createdDate = new Date();
        let day = createdDate.getDate();
        let month = createdDate.getMonth() + 1;
        let year = createdDate.getFullYear();
        let today = year + '-' + month + '-' + day;
        //End

        this.currentUserRole = this.route.snapshot.data['role'];
        this.trialGroup = this.route.snapshot.data['trialGroup'];
        this.userId = Number(this.route.snapshot.params['customer_id'])
        this.trailGroupId = Number(this.route.snapshot.params['id'])
        

        
        //this.trailGroupName = this.route.snapshot.data['trialGroupName'];
        var createDate = this.trialGroup.createdDate.split("/"); //ex: 03/31/2018
        var trialGroupStartDate = createDate[2] + '-' + createDate[0] + '-' + createDate[1]; //2018-01-03
        
        this.trialGroupEdit = this.fb.group({

            //trialGroupName: [this.trialGroup.trialGroupName, Validators.required],
            //createdBy: [this.trialGroup.createdBy, Validators.nullValidator],
            //createdDate: [this.dateForView(this.trialGroup.createdDate), Validators.nullValidator],
            trialGroupName: [this.trialGroup.trialGroupName, Validators.required],
            createdBy: [this.trialGroup.createdBy],
            //createdDate: [this.dateForView(this.trialGroup.createdDate)],
            createdDate: [this.dateForView(trialGroupStartDate)],
        });

        // Make sure start date can't come after end date
        //this.setStartDateDisableSince(this.trialGroupEdit.value.createdDate.date);

        let copy: IMyOptions = this.getCopyOfDateOptions(this.createdDateOptions);
        copy.componentDisabled = true;
        this.createdDateOptions = copy;
    }

    public moreContainers(): void {
        this.containerLimit = 6;
    }

    public cancelForm(): void {
        this.trialGroupEdit.markAsPristine();
        this.router.navigate([this.userId, 'trialgroup']);
    }

    public populateContainerPopover(container): void {
        this.activeContainer = container;
    }

    public onSubmit() {
        //alert(this.trialGroupEdit.invalid);
        if (this.trialGroupEdit.invalid) {
            this.showErrors = true;
        } else {
            this.isLoading = true;
            let request = new TrialGroupRequest(
                
                this.trialGroupEdit.value.trialGroupName,
                1
                
               
            );

            this.trialGroupService
                .updateTrialGroup(this.trailGroupId, request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.trialGroupEdit.markAsPristine();
                    this.successMessage = 'Trial Group has been successfully updated';
                    this.goBack();
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                }
                );
        }
    }


    public drugSelected(drug): void {
        this.assignDrug = drug.item;
    }

    public regimenSelected(regimen): void {
        this.assignRegimen = regimen.item;
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
        this.assignDrugRegimenSuccess = false;
        this.assignDrugRegimenError = null;
        this.error = null;
    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

        if (event.valid) {
               this.setStartDateDisableSince(date.date);
            
        }
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {
            return (value < 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }

    //public fileChange(input) {
    //    this.processContainersFile(input.target.files);
    //}

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.trialGroupEdit.dirty;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.createdDateOptions);
        copy.disableSince = date;
        this.createdDateOptions = copy;
    }

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    public goBack(): void {
        this.trialGroupEdit.markAsPristine();
        this.router.navigate([this.userId, 'trialgroup']);
    }
    //private setDrugRegimenPairs(): void {
    //    this.trial.drPairs.forEach((pair) => {
    //        this.drugRegimenPairs.push({
    //            id: pair.id,
    //            drug: pair.drug,
    //            regimen: { id: pair.regimen.id, name: pair.regimen.name },
    //            inUse: pair.inUse
    //        });
    //    });
    //}

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

   

    

    
}
