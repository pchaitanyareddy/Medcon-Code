import { Component, OnInit, ViewChild  } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { RegimenService } from '../../services/regimen.service';
import { PatientService } from '../../services/patient.service';
import { TrialService } from '../../services/trial.service';
import { Trial } from '../../models/trial';
import { TrialOverview } from '../../models/trialoverview';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { ModalDirective } from 'ngx-bootstrap';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import 'rxjs/add/operator/switchMap';
import { ReportService } from '../../services/report.service';
import { Privileges } from '../../models/privileges';

var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './trial-view.component.html?v=${new Date().getTime()}',
    styleUrls: ['./trial-view.component.scss?v=${new Date().getTime()}']
})

export class TrialViewComponent implements OnInit {
    @ViewChild('assignDrugRegimenModal') public assignDrugRegimenModal: ModalDirective;
    public trial: Trial;
    public trialOverview: TrialOverview;
	public containerLimit = 5;
	public activeContainer: Object;
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public customer: Customer;
	public drugs = [];
    selectedCompanyId: number;
    public errorMessage: string;
    totalDrugsCount: number;
    totalDrugsToDisplayPerSlide: number;
    totalSlides: number;
    displayedDrugs: number;
    trialDrugsList: any;
    selectedDrugId: number;
    containerDetailsList: any;
    isLoading: boolean;
    privilegesByModule: any;
    privilegesList: any;
   
    public privileges: Privileges;
	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private regimenService: RegimenService,
        private patientService: PatientService,
        private router: Router,
        private cognitoUtil: CognitoUtil,
        private reportService: ReportService,
		private trialService: TrialService) {
	}

	public ngOnInit(): void {
		this.currentUserRole = this.route.snapshot.data['role'];
		this.trial = this.route.snapshot.data['trial'];
		this.customer = this.route.snapshot.data['customer'];
		//this.trial.labels = this.route.snapshot.data['labels'];
		//this.trial.containers = this.route.snapshot.data['containers'];
		//this.trial.patients = this.route.snapshot.data['patients'];
        this.trialOverview = this.route.snapshot.data['trialOverview'];
        this.totalDrugsCount = this.trialOverview.drug.length;
        this.totalDrugsToDisplayPerSlide = 2;
        this.totalSlides = (this.totalDrugsCount) / 2;
        this.displayedDrugs = (this.totalDrugsCount==1)?1:2;
        //alert(this.totalDrugsCount);
        //this.trialOverview.lastScan = this.route.snapshot.data['trialOverview'].lastScan;
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        var endDate = new Date(this.trialOverview.trialinfo.enddate);
        var todayDate = new Date();
        var trailStatus = todayDate < endDate;
        
        if (todayDate > endDate) {
            
            $('#btnedit').attr("disabled", "disabled");
            $('#btnedit').attr("title", "Cannot edit this trial its completed");
        }
        else
            $('#btnedit').removeAttr("disabled");
        //alert(this.trialOverview.lastScan);
		// Unique list of drugs on this trial, for each drug add all regimens on this trial using it
		//this.trial.drPairs.forEach((pair) => {
		//	if (!this.drugs[pair.drug.id]) {
		//		this.drugs[pair.drug.id] = {
		//			drug: pair.drug,
		//			regimen: [pair.regimen.name]
		//		};
		//	} else {
		//		let drug = this.drugs[pair.drug.id];
		//		if (!drug.regimen.includes(pair.regimen.name)) {
		//			drug.regimen.push(pair.regimen.name);
		//		}
		//	}
		//});
		// Reset the indexes (otherwise the array length matches the highest drug id)
		this.drugs = this.drugs.filter(() => {
			return true;
        });

        this.trialDrugsList = this.trialOverview.drug;

        //19th July 2018 code added to check edit trial access privileges to the given role
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Trials')

        //localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        

        //End
        
	}


    public ngAfterViewInit(): void {

        //$('#datatable_trialOverviewPatientList').DataTable();
        this.loadTrialOverViewPatientList();
        if (this.trialDrugsList != null) {
            for (var i = 0; i < this.totalDrugsCount; i++) {
                if (this.trialDrugsList[i].bucket != null) {
                    if (i == 0)
                        this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.trialDrugsList[i].bucket, "imgDiv_0");
                    if(i==1)
                        this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.trialDrugsList[i].bucket, "imgDiv_1");
                }
                else {
                    if (i == 0)
                        $("#imgDiv_0").attr("src", "../../../assets/images/medication-type-default.png");
                    if (i == 1)
                        $("#imgDiv_1").attr("src", "../../../assets/images/medication-type-default.png");
                }
            }

        }


        var endDate = new Date(this.trialOverview.trialinfo.enddate);
        var todayDate = new Date();
        var trailStatus = todayDate < endDate;
        
        if (todayDate > endDate) {
            
            $('#btnedit').attr("disabled", "disabled");
            $('#btnedit').attr("title", "Cannot edit this trial its completed");
        }
        else
            $('#btnedit').removeAttr("disabled");


        
    }

	public moreContainers(): void {
		this.containerLimit = 6;
	}

	public populateContainerPopover(container): void {
		this.activeContainer = container;
	}

	public convertMinutes(totalMinutes: number): string {
		return this.regimenService.convertMinutesToString(totalMinutes);
	}

	public getAge(date) {
		return this.patientService.getAge(date);
	}

	public formatDate(date: string): string {
		return this.trialService.formatDate(date);
    }

    public hideAssignDrugRegimenModal(): void {
        this.assignDrugRegimenModal.hide();
    }

    viewAssignDrugRegimenPairDetails(id,counter)
    {
        this.isLoading = true;
        //alert($('#hdnDrugId_'+counter).val());
        let drugId = '';
        if ($('#hdnDrugId_' + counter).val() != undefined && $('#hdnDrugId_' + counter).val() !='')
        {
            drugId = $('#hdnDrugId_' + counter).val();
        }
        else
        {
            drugId = id;

        }
        //alert(drugId);
        this.trialService.getTrialOverview_DrugRegimenPairDetails(Number(drugId)).subscribe(
            (response) => {
                this.isLoading = false;
                let minsPerDay = 24 * 60;
                let minsPerHour = 60;
                let minutes = response.doseduration;
                let converted = '';
                let minutes1 = response.threshold;
                let converted1 = '';

                let days = Math.floor(minutes / minsPerDay);

                converted += (days < 10) ? '0' + days + 'D ' : days + 'D ';
                minutes = minutes - days * minsPerDay;
                let hours = Math.floor(minutes / minsPerHour);
                converted += (hours < 10) ? '0' + hours + 'HRS ' : hours + 'HRS ';
                minutes = minutes - hours * minsPerHour;
                converted += (hours < 10) ? '0' + minutes + 'MINS' : minutes + 'MINS';

                let days1 = Math.floor(minutes1 / minsPerDay);

                converted1 += (days1 < 10) ? '0' + days1 + 'D ' : days1 + 'D ';
                minutes1 = minutes1 - days1 * minsPerDay;
                let hours1 = Math.floor(minutes1 / minsPerHour);
                converted1 += (hours1 < 10) ? '0' + hours1 + 'HRS ' : hours1 + 'HRS ';
                minutes1 = minutes1 - hours1 * minsPerHour;
                converted1 += (hours1 < 10) ? '0' + minutes1 + 'MINS' : minutes1 + 'MINS';



                $("#imgDiv").attr("src", CommonService.MEDCON_V2_S3_BUCKET_URL + response.imagepath);
                $("#spnDrug").text(response.drugname);
                $("#spnRegimen").text(response.regimenname);
                $("#spnDurationBetweenDoses").text(converted);
                $("#spnAdheranceThreshold").text(converted1);
                $("#spnScheduleType").text(response.scheduletype);
                $("#spnTotalDoses").text(response.totaldoses);
                $("#spnDoseType").text(response.dosetype);
                $("#spnDoseAmount").text(response.doseAmount);
                $("#spnDoseUnit").html(response.doseunit + "<div>" + response.unit+ "</div>");
                $("#spnDoseTotal").html(response.dosetotal + "<div>" + response.unit +"</div>");
               
                ///this.viewSummaryModal.show();
                this.assignDrugRegimenModal.show();
            },
            (err) => {
                this.errorMessage = err;

            });

        


    }

    public loadTrialOverViewPatientList():void
    {
        
        var self = this;
        let trialId = this.trial.id;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_trialOverviewPatientList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "rowId": "PatientID",
                    'ajax': {
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId,
                        'url': CommonService.API_PATH_V2_TRIAL_VIEW_LIST+'trial/list/trailpatients/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 3, 4, 5, 6]
                            },
                            action: function () {
                                //alert($("input[type=search").val());
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_VIEW_LIST + 'trial/list/trailpatients/' + trialId + '?draw=4&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=trialName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=TrialGroups&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Company&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=startDate&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=endDate&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $("input[type=search").val()+'&search%5Bregex%5D=false&_=15';
                                self.reportService.ExportAll(apiUrl, 'TrialOverView-PatientList');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 3, 4, 5, 6]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        
                        { "data": "PatientID" },
                        { "data": "age" },
                        { "data": "Sex" },
                        { "data": "Race" },
                        { "data": "FirstScan" },
                        { "data": "LastScan" },
                        //{ "data": "Containers" }
                        {
                            "data": "Containers"
                            ,
                            "render": function (data, type, full, meta) {

                                if (full.Containers == null) {
                                    return '0';
                                }
                                else {
                                    return '<div class="tooltip1" ><u>' + full.Containers + '</u><span id="spnSpanTooltip_' + full.PatientID.replace(" ", "_") + '" class="tooltiptext"  >' + self.loadTrailPatientContainer(full.PatientID, '') + '</span></div>';
                                }
                            }
                        },
                    ],
                    "columnDefs": [

                        {
                            "targets": [6],
                            "orderable": true,
                        }

                        ,
                        {
                            "targets": [1],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == 0 ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [2],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [3],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [4],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [5],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    
                });
            }

            
        });
        //$('#datatable_trialOverviewPatientList').
        //    on('mouseover', 'td:nth-child(7) ', function () {
        //        // jQuery(this).find('span:first').show();
        //        var attId = this.parentNode.id;
        //        //this.viewContainerDetailsModal.show();
        //        //<div class="tooltiptext" > Tooltip text< /div>
        //        self.loadTrailPatientContainer(attId, '');
        //        //self.isLoading = false;

        //    }).
        //    on('mouseout', 'td:nth-child(7) ', function () {
        //        $('#pnlContainers').css('display', 'none');
        //    });

    }


    public nextSlide()
    {
        //alert('displayed' + Number(this.displayedDrugs))
        if (Number(this.displayedDrugs) < Number(this.totalDrugsCount)) {
            
            let lowerBoundary = Number(this.displayedDrugs);
            let upperBoundary = lowerBoundary + 1;
            //alert(lowerBoundary);
            //alert(upperBoundary);
            this.displayedDrugs = Number(this.displayedDrugs) + 2;
            if (Number(this.displayedDrugs) > Number(this.totalDrugsCount)) {
                this.displayedDrugs = Number(this.totalDrugsCount);

            }

            for (var _i = lowerBoundary; _i < upperBoundary; _i++) {
                if (_i = lowerBoundary) {
                    if (this.trialDrugsList[_i] != undefined) {
                        if (this.trialDrugsList[_i].bucket != null)
                            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.trialDrugsList[_i].bucket, "imgDiv_0");
                            //$("#imgDiv_0").attr("src", "https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/" + this.trialDrugsList[_i].bucket);
                        else
                            $("#imgDiv_0").attr("src", "../../../assets/images/medication-type-default.png");
                        $("#spnDrugName_0").html(this.trialDrugsList[_i].drugName);
                        $("#spnDrugAlias_0").html(this.trialDrugsList[_i].drugName);
                        $("#spnRegimenName_0").html(this.trialDrugsList[_i].regimenName);
                        //$("#anchViewDetails").attr("live", this.viewAssignDrugRegimenPairDetails(this.trialDrugsList[_i].id));
                        //this.selectedDrugId = this.trialDrugsList[_i].id;
                        $('#hdnDrugId_0').val(this.trialDrugsList[_i].id);
                        //$("#anchViewDetails").click(function () {
                        //    alert(this.trialDrugsList[_i].id);
                        //});
                    }
                   
                }

                if (_i = lowerBoundary + 1) {
                    if (this.trialDrugsList[_i] != undefined)
                    {
                        //$("#imgDiv_1").attr("src", "https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/" + this.trialDrugsList[_i].bucket);
                        if (this.trialDrugsList[_i].bucket != null)
                            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.trialDrugsList[_i].bucket, "imgDiv_1");
                        
                        else
                            $("#imgDiv_1").attr("src", "../../../assets/images/medication-type-default.png");
                        $("#spnDrugName_1").html(this.trialDrugsList[_i].drugName);
                        $("#spnDrugAlias_1").html(this.trialDrugsList[_i].drugName);
                        $("#spnRegimenName_1").html(this.trialDrugsList[_i].regimenName);
                        //$("#anchViewDetails").attr("live", this.viewAssignDrugRegimenPairDetails(this.trialDrugsList[_i].id));
                        this.selectedDrugId = this.trialDrugsList[_i].id;
                        $('#hdnDrugId_1').val(this.trialDrugsList[_i].id);
                        //$("#anchViewDetails").click(function () {
                        //    alert(this.trialDrugsList[_i].id);
                        //});

                        this.displaySecondDrugBox();

                    }
                    else
                    {

                        this.hideSecondDrugBox();
                    }
                    
                }
                else
                {
                    this.hideSecondDrugBox();
                }

            }

        }

       


        //$("#imgDiv").attr("src", "https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/" + this.trialDrugsList[2].bucket);
        //$("#spnDrugName").html(this.trialDrugsList[2].drugName);
        //$("#spnDrugAlias").html(this.trialDrugsList[2].drugName);
        //$("#spnRegimenName").html(this.trialDrugsList[2].regimenName);
        //$("#anchViewDetails").click(this.viewAssignDrugRegimenPairDetails(this.trialDrugsList[2].id));
        //this.trialDrugsList = this.trialDrugsList.filter(
        //    drugObj => drugObj. === company)
    }

    displaySecondDrugBox()
    {

        $("#imgDiv_1").css("display", "block");
        $("#spnDrugName_1").css("display", "block");
        $("#spnDrugAlias_1").css("display", "block");
        $("#spnRegimenName_1").css("display", "block");
        $('#drugBox_1').css("display", "block");
    }

    hideSecondDrugBox()
    {

        $("#imgDiv_1").css("display", "none");
        $("#spnDrugName_1").css("display", "none");
        $("#spnDrugAlias_1").css("display", "none");
        $("#spnRegimenName_1").css("display", "none");
        for (var _i = 1; _i < Number(this.totalDrugsCount); _i++) {
            $('#drugBox_' + _i).css("display", "none");
        }
    }

    public prevSlide() {
        let lowerBoundary = 0;
        let upperBoundary = 0;
        if (Number(this.displayedDrugs) > 0 && Number(this.totalDrugsCount)>1) {
            if (Number(this.displayedDrugs) == Number(this.totalDrugsCount)) {
                if (Number(this.displayedDrugs) % 2 != 0) {
                    this.displayedDrugs = Number(this.displayedDrugs) - 1;
                    lowerBoundary = Number(this.displayedDrugs) - 2;
                    upperBoundary = lowerBoundary + 1;
                }
                else
                {
                    this.displayedDrugs = Number(this.displayedDrugs) - 2;
                    upperBoundary = Number(this.displayedDrugs);
                    lowerBoundary = upperBoundary - 2;

                }
            }
            else {
                this.displayedDrugs = Number(this.displayedDrugs) - 2;
                upperBoundary = Number(this.displayedDrugs);
                lowerBoundary = upperBoundary - 2;
                //alert(upperBoundary);
                //alert(lowerBoundary);
            }
            
             
            //alert(upperBoundary);
            //    alert(lowerBoundary);
            if (Number(this.displayedDrugs) == 0)
                this.displayedDrugs = 2;
            for (var _i = lowerBoundary; _i < upperBoundary; _i++) {
                
                if (_i == lowerBoundary) {
                    //alert(_i);
                    //if (_i==0)
                    //alert('i' + _i);
                   // alert('lowerBoundary' + lowerBoundary);
                        //alert(this.trialDrugsList[_i].drugName);
                    if (this.trialDrugsList[_i] != undefined) {
                        //$("#imgDiv_0").attr("src", "https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/" + this.trialDrugsList[_i].bucket);
                        if (this.trialDrugsList[_i].bucket != null)
                            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.trialDrugsList[_i].bucket, "imgDiv_0");

                        else
                            $("#imgDiv_0").attr("src", "../../../assets/images/medication-type-default.png");
                        $("#spnDrugName_0").html(this.trialDrugsList[_i].drugName);
                        $("#spnDrugAlias_0").html(this.trialDrugsList[_i].drugName);
                        $("#spnRegimenName_0").html(this.trialDrugsList[_i].regimenName);
                        //$("#anchViewDetails").attr("onclick",this.viewAssignDrugRegimenPairDetails(this.trialDrugsList[_i].id));
                        //this.selectedDrugId = this.trialDrugsList[_i].id;
                        $('#hdnDrugId_0').val(this.trialDrugsList[_i].id);
                    }
                   
                }
                if (_i = lowerBoundary + 1) {
                    if (this.trialDrugsList[_i] != undefined) {
                        //$("#imgDiv_1").attr("src", "https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/" + this.trialDrugsList[_i].bucket);
                        if (this.trialDrugsList[_i].bucket != null)
                            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.trialDrugsList[_i].bucket, "imgDiv_1");

                        else
                            $("#imgDiv_1").attr("src", "../../../assets/images/medication-type-default.png");
                        $("#spnDrugName_1").html(this.trialDrugsList[_i].drugName);
                        $("#spnDrugAlias_1").html(this.trialDrugsList[_i].drugName);
                        $("#spnRegimenName_1").html(this.trialDrugsList[_i].regimenName);
                        //$("#anchViewDetails").attr("onclick",this.viewAssignDrugRegimenPairDetails(this.trialDrugsList[_i].id));
                        //this.selectedDrugId = this.trialDrugsList[_i].id;
                        $('#hdnDrugId_1').val(this.trialDrugsList[_i].id);

                        this.displaySecondDrugBox();
                    }
                    
                }
            }

        }
    }

    SetAndValidateImageUrl(url, imageId): void {
        //alert(url);
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            //alert(" Image Exists...!");
            //flag = true;
        }).on("error ", function () {
            //alert("ERROR");
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            //flag = false;

        });
        //return flag;

    }

    public loadTrailPatientContainer(id, data): void {
        let finalContainerString = '';
        let containerIds = '';
        let trialId = this.trial.id;
        let patientId = id;
        //alert(patientId);
        //this.isLoading = true;
        this.trialService.getTrailPatientContainerDetails(trialId, patientId).subscribe(
            (response) => {
                //this.isLoading = false;
                //this.patientTitrateList = response;
                this.containerDetailsList = response;
                //this.viewContainerDetailsModal.show();
                //$('#pnlContainers').css('display', 'block');
                // this.viewTitrateModal.show();
                if (this.containerDetailsList != undefined) {
                    //alert('ented');
                    this.containerDetailsList.forEach((item, index) => {
                        //alert(this.containerDetailsList[index].ContainerId);
                        if (containerIds == undefined) {
                            containerIds = this.containerDetailsList[index].ContainerId.split('_')[3];
                        }
                        else {
                            containerIds = containerIds + '\n' + this.containerDetailsList[index].ContainerId.split('_')[3];

                        }
                    });
                    if (containerIds != "undefined") {

                        $("#spnSpanTooltip_" + id.replace(" ", "_")).html(containerIds.replace("undefined",""));
                    }
                    else {
                        $("#spnSpanTooltip_" + id.replace(" ", "_")).html("");
                    }
                    //$("#spnSpanTooltip_" + id).attr('title', containerIds);
                    
                    //$("#spnSpanTooltip_" + id).attr('matTooltip', containerIds);
                }
                else {
                    $("#spnSpanTooltip_" + id.replace(" ", "_")).html("");
                }

                
            });
        //alert(this.containerIds);
        //finalContainerString = '<span data-toggle="tooltip" title="vvvvv' + this.containerIds  + '">' + data + '</span>';
        //return finalContainerString;
        $("#spnSpanTooltip_" + id.replace(" ", "_")).html("");
    }
    public editTrial(): void {
        this.isLoading = true;
        this.router.navigate(['/', this.selectedCompanyId, 'trials', this.trial.id, 'edit']);
    }
}
