import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { AlertAlarmService } from '../../services/alert-alarms.service';
import { AlertAlarm } from '../../models/alert-alarm';
import { UserRole } from '../../models/userrole';
import { AlertsAlarmsRequest } from '../../requests/alerts-alarms-request';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './alerts-alarms-list.component.html',
	styleUrls: ['./alerts-alarms-list.component.scss']
})

export class AlertsAlarmsComponent implements OnInit {
	public alertsAlarms: AlertAlarm[];
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public form: FormGroup;
	public showErrors: boolean;
	public successMessage: string;
	public errorMessage: string;
	public control: FormArray;

	public tags = [
		{
			index: 0,
			name: 'Drug Name',
			value: '[DRUG_NAME]'
		},
		{
			index: 1,
			name: 'Next Dose Date',
			value: '[NEXT_DOSE_DATE]'
		},
		{
			index: 2,
			name: 'Due Time',
			value: '[DUE_TIME]'
		},
		{
			index: 3,
			name: 'Threshold Date',
			value: '[THRESHOLD_DATE]'
		},
		{
			index: 4,
			name: 'Dose Number',
			value: '[DOSE_NUMBER]'
		}
	];

	constructor(public templateService: TemplateService,
		public aas: AlertAlarmService,
		private route: ActivatedRoute,
		private fb: FormBuilder) {
	}

	public ngOnInit() {
		this.currentUserRole = this.route.snapshot.data['role'];
		this.alertsAlarms = this.route.snapshot.data['alerts'];

		this.resetAlerts();
	}

	public addAlerts(alert: AlertAlarm) {
		this.control = <FormArray> this.form.controls['alerts'];
		let alertControl = this.fb.group({
			id: [alert.id],
			message: [alert.message, Validators.required],
		});

		this.control.push(alertControl);
	}

	public onSubmit(): void {
		if (this.form.invalid) {
			this.showErrors = true;
		} else {
			let request = new AlertsAlarmsRequest(
				this.form.value.alerts
			);

			let updateType = (this.currentUserRole === this.UserRole.MedConAdmin) ?
				'defaults' :
				'customer';
			this.aas.updateAlertsAlarms(updateType, request).subscribe(
				(response) => {
					this.aas.getAlertsAlarms().subscribe(
						(alerts) => {
							this.alertsAlarms = alerts;
							this.resetAlerts();
							this.successMessage = 'Alerts / alarms have been successfully updated.';
						}
					);
				},
				(err) => {
					this.errorMessage = err;
				}
			);
		}
	}

	public tagButton(tagIndex, alertIndex) {
		// TODO: Insert code where the cursor is
		let tag = this.tags[tagIndex];
		let message = this.form.controls['alerts']['controls'][alertIndex]['controls']['message'];
		message.setValue(message['value'] + tag.value);
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

	private resetAlerts(): void {
		this.control = null;

		this.form = this.fb.group({
			alerts: this.fb.array([]),
		});

		if (this.alertsAlarms) {
			this.alertsAlarms.forEach((alert) => {
				this.addAlerts(alert);
			});
		}
	}
}
