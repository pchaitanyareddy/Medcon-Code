﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialService } from '../../services/trial.service';
import { TrialOverview } from '../../models/trialoverview';

@Injectable()
export class TrialOverviewResolve implements Resolve<TrialOverview> {
    constructor(private trialService: TrialService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<TrialOverview> | Promise<TrialOverview> | TrialOverview {
        return this.trialService.getTrialOverview(route.params['id']);
        //return this.trialService.getTrialOverview(route.params['id']);
    }
}

