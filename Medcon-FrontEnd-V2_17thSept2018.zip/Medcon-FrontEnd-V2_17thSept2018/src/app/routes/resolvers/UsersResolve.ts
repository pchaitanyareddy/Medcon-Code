import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { Pagination } from '../../models/pagination';

@Injectable()
export class UsersResolve implements Resolve<(Pagination<User>)> {
	constructor(private userService: UserService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(Pagination<User>)>
		| Promise<(Pagination<User>)>
		| (Pagination<User>) {
		//return this.userService
		//	.getUsers(route.params['customer_id'], route.queryParams['page'], route.queryParams['perPage']);

        return this.userService
            .getAllUsersByCompany(route.params['customer_id']);
	}
}
