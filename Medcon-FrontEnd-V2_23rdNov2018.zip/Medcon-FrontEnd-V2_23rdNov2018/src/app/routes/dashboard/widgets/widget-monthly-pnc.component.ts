import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-monthly-pnc',
	templateUrl: './widget-pnc.component.html'
})

export class WidgetMonthlyPncComponent implements OnInit {
	public patients: any;

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit(): void {
		this.dashboardService.doseComplianceInfo.subscribe((value) => {
			if (value) {
				this.patients = value.monthly;
			}
		});
	}
}
