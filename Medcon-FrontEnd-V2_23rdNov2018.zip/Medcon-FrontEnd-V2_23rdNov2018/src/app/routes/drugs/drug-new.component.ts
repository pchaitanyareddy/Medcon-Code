import { ChangeDetectorRef, Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { DrugService } from '../../services/drug.service';
import { DrugRequest } from '../../requests/drug-request';
import { Observable } from 'rxjs/Observable';
import { CommonService } from '../../services/commonService';
@Component({
    templateUrl: './drug-new.component.html?v=${new Date().getTime()}'
})

export class DrugNewComponent implements OnInit {
	public drug: FormGroup;
	public showErrors: boolean;
    public errorMessage: string;
    public successMessage: string;
    public drugImage = 'assets/images/medication-type-default.png';
	public drugImageBase64: string;
	public medicationAmount: number;
    public unitOfMeasure: string;
    public allmedicationTypeList: any;
    public allmedicationTypeFilteredList: any;
    public medicationTypes: MedicationTypes[];
    public selectedMedicationTypeId: number;
    public userId: number;
    public selectedMedicationType: any;
    public selectedUnitOfMeasure: string;
    isLoading: boolean;
    public distinctMedicationTypesList: any;
    selectedMedicationTypeIdFinalVal: number;
	constructor(public templateService: TemplateService,
		private router: Router,
		private route: ActivatedRoute,
		private fb: FormBuilder,
		private drugService: DrugService,
		private changeDetectorRef: ChangeDetectorRef) {
    }

    loadDrugImage(selectedImage)
    {
        //if (this.allmedicationTypeList != undefined) {

        if (selectedImage == null || selectedImage == '') {
            this.drugImage = 'assets/images/medication-type-default.png';
            this.drugImageBase64 = '';
        }
        else {
            this.drugImage = CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage;
            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage, "newDrugImageId");
            this.drugImageBase64 = selectedImage;
        }
        //}

    }
    public ngAfterViewInit() {
        this.drugImageBase64 = "";
        this.drugService.getAllMedicationType((localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allmedicationTypeList = response;

                //To get the distinct medication type names
                var lookup = {};
                var items = response;
                var result = [];

                for (var item, i = 0; item = items[i++];) {
                    var name = item.name;
                   
                    if (!(name in lookup)) {
                        lookup[name] = 1;
                        result.push(item);
                    }
                }
                this.distinctMedicationTypesList = result;
               //End To get the distinct medication type names
                
                if (this.allmedicationTypeList != undefined) {
                    this.loadDrugImage(this.allmedicationTypeList[0].image);
                    this.allmedicationTypeFilteredList = this.allmedicationTypeList.filter(
                        medtypes => medtypes.name === 'Tablet');

                    var unique = {};
                    var distinct = [];
                    this.allmedicationTypeFilteredList.forEach(function (x) {
                        if (!unique[x.measure]) {
                            distinct.push(x.measure);
                            unique[x.measure] = true;
                        }
                    });
                    //alert(distinct[0]);
                    this.allmedicationTypeFilteredList = distinct;
                }
            },
            (err) => {
                this.errorMessage = err;

            });
        
    }

    public ngOnInit() {
        this.isLoading = false;
        this.userId = this.route.snapshot.params['customer_id'];
        
		this.drug = this.fb.group({
			name: ['', Validators.required],
			alias: ['', Validators.required],
			image: [''],
			medicationAmount: ['', Validators.required],
            unitOfMeasure: ['', Validators.required],
            medicationTypeId: ['']
		});
		

        this.selectedMedicationTypeId = 1;
        this.selectedUnitOfMeasure = 'MG';
        this.selectedMedicationType = 'Tablet';
        ///this.allmedicationTypeFilteredList = ['MG'];
        
	}

	public onSubmit() {
		if (this.drug.invalid) {
			this.showErrors = true;
        } else {
            //alert(this.selectedMedicationTypeId);
            $('#btnSubmit').attr('disabled', 'disabled');
            this.isLoading = true;
			let request = new DrugRequest(
				this.drug.value.name,
				this.drug.value.alias,
				this.drugImageBase64,
				Number(this.drug.value.medicationAmount),
                //this.drug.value.unitOfMeasure,
                //this.drug.value.medicationTypeId
                Number(this.userId),
                //Number(this.selectedMedicationTypeId)
                Number(this.selectedMedicationTypeIdFinalVal)
			);

			this.drugService.createDrug(request).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.drug.markAsPristine();
                    this.successMessage = 'Drug has been successfully added';
                    $(window).scrollTop(5);
					this.goBack();
				},
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                    $('#btnSubmit').removeAttr('disabled');
				});
		}
	}

    public fileChange(input) {
        
		this.processImage(input.target.files);
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

    public goBack(): void {
        this.isLoading = true;
		this.drug.markAsPristine();
		this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'drugs']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.drug.dirty;
	}

	private processImage(files, index = 0) {
		let reader = new FileReader();

		if (index in files) {
            this.readFile(files[index], reader, (result) => {
                
				// Create an img element and add the image file data to it
				let img = document.createElement('img');
				img.src = result;

				// Send this img to the resize function (and wait for callback)
				this.drugService.resizeImage(img, (croppedImage) => {

					// This is the file you want to upload.
					// Either as a base64 string or img.src = croppedImage if you prefer a file.
					this.drugImage = croppedImage;
					this.drugImageBase64 = croppedImage;
				});
			});
		} else {
			// When all files are done this forces a change detection
			this.changeDetectorRef.detectChanges();
		}
	}

	private readFile(file, reader, callback) {
		reader.onload = () => {
			callback(reader.result);
		};

		reader.readAsDataURL(file);
    }


    onChange_MedicationType(selectedValue) {
        
        //alert("hi");
        //alert(this.selectedMedicationTypeId);
        let selectedImage = '';
        this.selectedMedicationTypeId = Number(selectedValue);
        this.selectedMedicationType = null;

        if (this.allmedicationTypeList != null) {
            for (var i = 0; i < this.allmedicationTypeList.length; i++) {
                if (this.allmedicationTypeList[i].id == this.selectedMedicationTypeId) {
                    this.selectedMedicationType = this.allmedicationTypeList[i].name;
                    this.selectedUnitOfMeasure = this.allmedicationTypeList[i].measure;
                    selectedImage = this.allmedicationTypeList[i].image;
                    //alert(this.selectedUnitOfMeasure);
                }
            }

            this.allmedicationTypeFilteredList = this.allmedicationTypeList.filter(
                medtypes => medtypes.name === this.selectedMedicationType);

            var unique = {};
            var distinct = [];
            this.allmedicationTypeFilteredList.forEach(function (x) {
                if (!unique[x.measure]) {
                    distinct.push(x.measure);
                    unique[x.measure] = true;
                }
            });
            //alert(distinct[0]);
            this.allmedicationTypeFilteredList = distinct;
            //this.allmedicationTypeFilteredList = this.allmedicationTypeFilteredList.filter(function (item, i, ar) { return ar.indexOf(item) === i; });
            //this.allmedicationTypeFilteredList = this.allmedicationTypeFilteredList.map(item => item.measure)
            //    .filter((value, index, self) => self.indexOf(value) === index)

            //this.allmedicationTypeFilteredList = this.allmedicationTypeFilteredList.map(function (obj) { return obj.measure; });
            //this.allmedicationTypeFilteredList = this.allmedicationTypeFilteredList.filter(function (v, i) { return this.allmedicationTypeFilteredList.indexOf(v) == i; });

            this.loadDrugImage(selectedImage);
            //this.processImage(this.drug.value.image.target.files);
        }

        
    }
    onChange_UnitOfMeasure(selectedValue) {

        //alert("selectedValue" + selectedValue);
        //alert('BEFORE' + this.selectedMedicationTypeId);
        //alert('this.selectedMedicationType' + this.selectedMedicationType);
        //this.selectedMedicationTypeId = Number(selectedValue);
        //this.selectedMedicationType = null;
        this.selectedMedicationTypeIdFinalVal = this.selectedMedicationTypeId;
        let selectedImage = '';
        this.selectedMedicationType = (this.selectedMedicationType == null) ? 'Tablet' : this.selectedMedicationType;
        if (this.allmedicationTypeList != null) {
            for (var i = 0; i < this.allmedicationTypeList.length; i++) {
                if (this.allmedicationTypeList[i].measure == selectedValue && this.allmedicationTypeList[i].name == this.selectedMedicationType) {
                    this.selectedMedicationTypeIdFinalVal = this.allmedicationTypeList[i].id;
                    if (this.allmedicationTypeList[i].image != null)
                        selectedImage = this.allmedicationTypeList[i].image;
                    else
                        selectedImage = '';
                }
                

            }

        }
        
        this.loadDrugImage(selectedImage);

    }

    clearData() {

        this.drug.reset();
        $('#newDrugImageId').attr("src", 'assets/images/medication-type-default.png');
    }


    SetAndValidateImageUrl(url, imageId): void {
        //alert(url);
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            //alert(" Image Exists...!");
            //flag = true;
        }).on("error ", function () {
            //alert("ERROR");
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            //flag = false;

        });
        //return flag;

    }
}
