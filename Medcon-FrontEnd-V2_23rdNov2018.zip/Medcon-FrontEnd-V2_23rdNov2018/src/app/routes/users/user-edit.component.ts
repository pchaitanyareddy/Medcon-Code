import { Component, HostListener, OnInit, ViewChild} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { User } from '../../models/user';
import 'rxjs/add/operator/switchMap';
import { UserRequest } from '../../requests/user-request';
import { UserService } from '../../services/user.service';
import { Observable } from 'rxjs/Observable';
import { CustomerService } from '../services/customer.service';
import { UserRole } from '../../models/userrole';
import { CurrentUserService } from '../../services/currentuser.service';
import { ModalDirective } from 'ngx-bootstrap';
//import { CompanyService } from '../../services/company.service';
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}

enum Companies {

    'ABC Pharmaticual',
    'Test1',
    'Test2'
}
@Component({
    templateUrl: './user-edit.component.html?v=${new Date().getTime()}'
})

export class UserEditComponent implements OnInit {
    @ViewChild('changeStatusModal') public changeStatusModal: ModalDirective;
    public user: User;
    public successMessage: string;
    public errorMessage: string;
    public userEdit: FormGroup;
    public showErrors: boolean;
    public UserRole: typeof UserRole = UserRole;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    companyOptions: string[];
    Companies: typeof Companies = Companies;
    selectedRole;
    selectedCompany;
    selectedUserId: number;
    selectedRoleId: number;
    selectedRoleName: string;
    public allRoleList: any;
    selectedCompanyId: number;
    public loggedInUserRole: string;
    allCompanyList: any;
    subscribe: string;
    selectedUserObject: any;
    selectedUserStatus: boolean;
    statusFlag: string;
    isLoading: boolean;
    constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
        private fb: FormBuilder,
        public currentUserService: CurrentUserService,
        //private companyService: CompanyService,
        private userService: UserService) {
    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.user = this.route.snapshot.data['user'];
        //this.subscribe = this.route.snapshot.params['customer_id']
        //alert(this.subscribe);
        this.currentUserService.getRole().subscribe((role) => {
            if (role === UserRole.MedConAdmin) {

                this.loggedInUserRole = "MedConAdmin";
            }
            
        }, (err) => {
            
        });
        this.route.params.subscribe(params => {
            this.subscribe = params['id'];
            //alert(params['id']) //log the value of id
        });
        //alert(this.subscribe);
        //this.selectedUserObject = this.userService.getSelectedUser(this.subscribe);
        //alert(this.selectedUserObject[0].companyName);
        this.userEdit = this.fb.group({
            firstName: [this.user.firstName, [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            lastName: [this.user.lastName, [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            emailAddress: [this.user.emailAddress],
            phoneNumber: [this.user.phoneNumber, [Validators.required]],
            role: [this.user.roleName, [Validators.required]],
            company: [this.user.companyName]
        });

        this.selectedUserId = this.user.userId;
        this.selectedRoleId = this.user.roleId; //Todo we have to list of users along with selected roleid
        this.selectedCompanyId = this.user.companyId;
        this.selectedRoleName = this.user.roleName;
        this.selectedUserStatus = this.user.status;
        
        //if (this.selectedUserStatus) {
        //    $('#btnActive').addClass('btn btn-default btn-on btn-xs active');
        //}
        //else if (!this.selectedUserStatus) {
        //    alert(this.selectedUserStatus);
        //    $('#btnInActive').addClass("btn btn-default btn-off btn-xs active");
        //    $('#btnActive').addClass("btn btn-default btn-off btn-xs");
        //}
        
       // alert(this.selectedRoleName);
        //alert(this.selectedRoleId);
        //var x = Roles;
        //var options = Object.keys(Roles);
        //this.options = options.slice(options.length / 2);
        //this.selectedRole = this.options[1];

        //var z = Companies;
        //var companyOptions = Object.keys(Companies);
        //this.companyOptions = companyOptions.slice(companyOptions.length / 2);
        //this.selectedCompany = this.companyOptions[0];

        this.userService.getAllRoles().subscribe(
            (response) => {
                this.allRoleList = response;

            },
            (err) => {
                this.errorMessage = err;

            });
        
        //if (this.loggedInUserRole == "MedConAdmin") {
            this.userService.getAllCompanies().subscribe(
                (response) => {
                    this.allCompanyList = response;

                },
                (err) => {
                    this.errorMessage = err;

                });
        //}
        //else {
        //    this.allCompanyList = [
        //        { companyId: 1, companyName: 'ABC Pharmaticual' },
        //    ]

        //}

        this.selectedCompany = this.user.companyName;
        //alert(this.selectedCompany);

        
    }

    public ngAfterViewInit(): void {
        if (this.selectedUserStatus) {
            $('#btnInActive').addClass("btn btn-default btn-off btn-xs");
            $('#btnActive').addClass("btn btn-default btn-off btn-xs active");
        }
        else if (!this.selectedUserStatus) {
            //alert(this.selectedUserStatus);
            $('#btnInActive').addClass("btn btn-default btn-off btn-xs active");
            $('#btnActive').addClass("btn btn-default btn-off btn-xs");
        }
    }

    public onSubmit() {
        //alert(this.userEdit.invalid);
        if (this.userEdit.invalid) {
            this.showErrors = true;
            return;
        }
        
        this.route.params.subscribe((params) => {
            this.isLoading = true;
            let request = new UserRequest(
                this.selectedUserId,
                this.userEdit.value.firstName,
                this.userEdit.value.lastName,
                this.userEdit.value.emailAddress,
                this.selectedRoleId,
                this.selectedRoleName,
                this.userEdit.value.phoneNumber,
                this.selectedCompanyId
                //this.userEdit.value.password,
                //this.userEdit.value.dateOfBirth,
                //this.userEdit.value.gender,
                //this.userEdit.value.raceName,
                //this.userEdit.value.roleName,
                //this.userEdit.value.roleId,

                //this.userEdit.value.createdBy,
                //this.userEdit.value.createdDate,
                //this.userEdit.value.lastUpdatedBy,
                //this.userEdit.value.lastUpdatedDate,
                //this.userEdit.value.active
            );

            this.userService.updateCustomerUser(this.user.sub, this.route.snapshot.params['customer_id'], request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.userEdit.markAsPristine();
                    this.successMessage = 'User successfully updated';
                    $(window).scrollTop(5);
                    this.goBack();
                },
                (err) => {
		    this.isLoading = false;
                    this.errorMessage = err;
                }
            );



        });
    }

    public alertClosed(): void {
        this.errorMessage = null;
        this.successMessage = null;
    }

    public resetPassword(): void {
        this.userService.resetCustomerUser(this.user.sub, this.route.snapshot.params['customer_id'])
            .subscribe(
            (response) => {
                this.successMessage = 'Password reset instructions have been emailed to the user';
            },
            (err) => {
                this.errorMessage = err;
            }
            );
    }

    public goBack(): void {
        this.isLoading = true;
        this.userEdit.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'users']);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.userEdit.dirty;
    }

    onChange(selectedValue) {
        this.selectedRoleId = Number(selectedValue);
        //this.selectedRoleName = null;
        
        //alert('roles list length' + this.allRoleList.length)
        //To get selected role name
        this.userService.getAllRoles().subscribe(
            (response) => {
                this.allRoleList = response;

            },
            (err) => {
                this.errorMessage = err;

            });
        
        if (this.allRoleList != null) {
            //alert('gggg');
            for (var i = 0; i < this.allRoleList.length; i++) {
                if (this.allRoleList[i].roleId == this.selectedRoleId) {
                    this.selectedRoleName = this.allRoleList[i].roleName;
                }
            }

        }

    }

    updateUserStatus(statusFlag)
    {
        this.isLoading = true;
        let jsonString = "{\r\n    \"status\":" + statusFlag+", \r\n  \"userId\" :" + Number(this.selectedUserId) + "\r\n}";
        this.userService.updateStatusOfUser(this.user.sub, jsonString)
            .subscribe(
            (response) => {
                this.isLoading = false;
                this.userEdit.markAsPristine();
                this.successMessage = 'User status successfully updated';
                $(window).scrollTop(5);
                this.goBack();
            },
            (err) => {
	        this.isLoading = false;
                this.errorMessage = err;
            }
            );

    }

    
    public changeUserStatus(statusFlag): void {
        this.statusFlag = statusFlag;
        //this.userToDelete = user;
        this.changeStatusModal.show();
    }

    public confirmChangeStatusConfirmation(): void {
        //let user = this.userToDelete;
       // this.successMessage = 'User status has been changed successfully';
        this.hideChangeUserStatusModal();
        this.updateUserStatus(this.statusFlag);
        //Un comment this when API is available
        //this.userService
        //	.updateUserStatus(user.id, this.selectedCustomerId)
        //	.subscribe(
        //		(response) => {
        //			this.userService.getUsers(this.selectedCustomerId)
        //				.subscribe((users) => {
        //						this.users = users;
        //						this.successMessage = user.firstName + ' ' + user.lastName + ' has been changed status successfully';
        //						this.hideChangeUserStatusModal();
        //					}
        //				);
        //		},
        //		(err) => {
        //			this.errorMessage = err;
        //			this.hideChangeUserStatusModal();
        //		}
        //	);
    }

    public hideChangeUserStatusModal(): void {
        //this.userToDelete = null;
        this.changeStatusModal.hide();
    }
    
}
