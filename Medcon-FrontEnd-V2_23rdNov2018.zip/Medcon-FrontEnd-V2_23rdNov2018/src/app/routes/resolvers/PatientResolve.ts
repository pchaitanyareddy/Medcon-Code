import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PatientService } from '../../services/patient.service';
import { Patient } from '../../models/patient';

@Injectable()
export class PatientResolve implements Resolve<Patient> {
	constructor(private patientService: PatientService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Patient> | Promise<Patient> | Patient {
		return this.patientService.getPatient(route.params['id'], route.params['customer_id']);
	}
}
