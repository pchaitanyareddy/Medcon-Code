﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { Pagination } from '../../models/pagination';
import { CurrentUserService } from '../../services/currentuser.service';
import { UserRole } from '../../models/userrole';
import { ActivatedRoute } from '@angular/router';
@Injectable()
export class PrivilegesResolve implements Resolve<(Privileges)> {
    public currentUserRole: UserRole;
    constructor(private privilegesService: PrivilegesService, private route: ActivatedRoute, private currentUserService: CurrentUserService) {
       
        
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<(Privileges)>
        | Promise<(Privileges)>
        | (Privileges) {
        //alert(this.currentUserRole);
        this.currentUserService.getRole().subscribe(
            (role) => this.currentUserRole = role,
            (err) => console.log(err)
        );
        //this.currentUserRole = this.route.snapshot.data['role'];
        //alert(this.currentUserRole);
        //if (this.currentUserRole == 0) this.currentUserRole = 1;
        //else if (this.currentUserRole == 1) this.currentUserRole = 2;
        return this.privilegesService
            .getPrivileges(Number(localStorage.getItem("LOGGED_IN_USER_ROLE_ID")));
    }
}

