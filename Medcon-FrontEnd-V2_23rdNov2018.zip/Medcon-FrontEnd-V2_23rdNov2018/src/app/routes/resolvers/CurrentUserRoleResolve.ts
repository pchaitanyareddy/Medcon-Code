import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CurrentUserService } from '../../services/currentuser.service';
import { UserRole } from '../../models/userrole';

@Injectable()
export class CurrentUserRoleResolve implements Resolve<UserRole> {
	constructor(private currentUserService: CurrentUserService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<UserRole> | Promise<UserRole> | UserRole {

		return this.currentUserService.getRole();
	}
}
