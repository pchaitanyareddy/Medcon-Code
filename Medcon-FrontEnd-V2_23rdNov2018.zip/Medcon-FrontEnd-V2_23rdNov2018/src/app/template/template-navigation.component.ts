import { Component, HostListener, OnInit, Compiler } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserLoginService } from '../services/cognito/cognito.service';
import { TemplateService } from '../services/template.service';
import { CurrentUserService } from '../services/currentuser.service';
import { CustomerService } from '../services/customer.service';
import { CognitoUser } from '../models/cognito-user';
import { UserRole } from '../models/userrole';
import { Customer } from '../models/customer';
import { CompanyService } from '../services/company.service';
import { Privileges } from '../models/privileges';
import { PrivilegesService } from '../services/privileges.service';
import { LocalStorageService } from '@angular2-localstorage/LocalStorageEmitter'
import { SessionStorage } from '@angular2-localstorage/WebStorage'
import { LocationStrategy } from '@angular/common';
import { UserProfile } from '../models/UserProfile';
//import * as myGlobals from '../services/globals'; 
//import { CommonService } from '../services/CommonService';
@Component({
	selector: 'navigation-template',
    templateUrl: './template-navigation.component.html?v=${new Date().getTime()}'
})

export class TemplateNavigationComponent implements OnInit {
	public UserRole: typeof UserRole = UserRole;
	public date = new Date();
	public userMenuExtended = false;
	public user: CognitoUser = new CognitoUser(-1, '', '', -1);
	public customer: Customer;
    allCompanyList: any;
    allCompanyListWithCompanyType: any = [];
    public selectedCompanyId: number;
    public currentUserRole: UserRole;
    privilegesList1: any;
    public privilegesFilterList: any;
    selectedRoleId: number;
    public isDashBoardHasAccess: boolean;
    public isDataReportsHasAccess: boolean;
    public isPatientReportsHasAccess: boolean;
    public isTrialsHasAccess: boolean;
    public isTrialGroupHasAccess: boolean;
    public isNotificationHasAccess: boolean;
    public isManageUserHasAccess: boolean;
    public isManageMedconUserHasAccess: boolean;
    public isPrivilegesHasAccess: boolean;
    public isManageCompanyHasAccess: boolean;
    public isLabelsHasAccess: boolean;
    public isManageSitesHasAccess: boolean;
    public isPatientAlertHasAccess: boolean;
    public isScheduleHasAccess: boolean;
    public isImportPatientHasAccess: boolean;
    public isBroadcastMessagesHasAccess: boolean;
    //public isNotificationHasAccess: true;
    public isMeasurementHasAccess: boolean;
    public isSettingsHasAccess: boolean;
    public isManageDrugHasAccess: boolean;
    public isManageRegimenHasAccess: boolean;
    public isManageCustomerUsersHasAccess: boolean;
    public isCustomersHasAccess: boolean;
    public isOverviewMenuVisible: boolean;
    public isReportingMenuVisible: boolean;
    public isClinicalTrialsMenuVisible: boolean;
    public isUserManagementMenuVisible: boolean;
    public isAdministrationMenuVisible: boolean;
    public privileges: Privileges;
    public isExportMenuHasAccess: boolean;
    public isPrivilegesMenuHasAccess: boolean;
    usersList: any;
    selectCompany: string;
    loggedInUserRole: number;
    loggedInUserRoleName: string;
    userProfileCompanyName: string;
    public userProfile: UserProfile;
    isLoading: boolean;
	constructor(private router: Router,
		private templateService: TemplateService,
		public userService: UserLoginService,
		public currentUserService: CurrentUserService,
        private customerService: CustomerService,
        private companyService: CompanyService,
        private privilegesService: PrivilegesService,
        private route: ActivatedRoute,
        private url: LocationStrategy,
        private _compiler: Compiler
      ) {
		setInterval(() => {
			this.date = new Date();
        }, 32000);

	}

	// Toggle navigation menu
	public toggleNavigationMenu(): void {
		this.templateService.navigationMenuExtended = !this.templateService.navigationMenuExtended;
	}

	// Toggle User Menu
	public toggleUserMenu(event) {
		this.userMenuExtended = !this.userMenuExtended;
	}

	public logout() {
		this.userService.logout();
		this.router.navigate(['/']);
	}

    public ngOnInit(): void {
    this._compiler.clearCache();
        //alert(CommonService.API_URL_CREATE_MEDCON_USER_URL);
    this.privileges = this.route.snapshot.data['privileges'];
    this.privilegesList1 = this.privileges;
    //let key: 'privileges';
    //localStorage.setItem(key, this.privilegesList1);
    this.isDashBoardHasAccess=false;
    this.isDataReportsHasAccess = false;
    this.isPatientReportsHasAccess = false;
    this.isTrialsHasAccess = false;
    this.isTrialGroupHasAccess = false;
    this.isNotificationHasAccess = false;
    this.isManageUserHasAccess = false;
    this.isManageMedconUserHasAccess = false;
    this.isPrivilegesHasAccess = false;
    this.isManageCompanyHasAccess = false;
    this.isLabelsHasAccess = false;
    this.isManageSitesHasAccess = false;
    this.isPatientAlertHasAccess = false;
    this.isScheduleHasAccess = false;
    this.isImportPatientHasAccess = false;
    this.isBroadcastMessagesHasAccess = false;
    //public isNotificationHasAccess: true;
    this.isMeasurementHasAccess = false;
    this.isSettingsHasAccess = false;
    this.isOverviewMenuVisible = false;
    this.isReportingMenuVisible = false;
    this.isClinicalTrialsMenuVisible = false;
    this.isUserManagementMenuVisible = false;
    this.isAdministrationMenuVisible = false;
    this.isExportMenuHasAccess = false;
        //alert(this.isDataReportsHasAccess);
        this.selectedCompanyId = 1;
        this.selectCompany = "Medcon";//this.allCompanyList[0].companyName;
        this.userProfileCompanyName = localStorage.getItem('GLOBAL_USER_PROFILE_COMPANY_NAME');
		this.currentUserService.getRole().subscribe(
			(role) => this.user.role = role,
			(err) => console.log(err)
		);
        //alert(this.user.role);
        this.currentUserRole = this.user.role;
        //alert(this.currentUserRole);
		this.currentUserService.getUserAttributes().subscribe(
			(attributes) => {
				this.user.email = attributes['email'];
				this.user.name = attributes['name'];
                this.user.customerId = Number(attributes['custom:customer_id']); //This is companyId for all medcon users
                this.selectedCompanyId = this.user.customerId;
                //alert(this.user.id);
                //alert(this.selectedCompanyId);
                this.loggedInUserRole = this.user.role;
                
                //localStorage.setItem("LOGGED_IN_USER_ID", this.loggedInUserRole);
                //alert('user role' + this.user.role);
                //this.currentUserService.getUserProfile(this.user.email).subscribe(
                //    (UserProfile) => {
                //        this.userProfile = UserProfile;
                //        this.loggedInUserRoleName = this.userProfile.roleName;
                //        localStorage.setItem("GLOBAL_LOGGED_IN_USER_ID", String(this.userProfile.userId));
                //        if (this.userProfile.roleName != 'MedCon Admin') {
                //            this.selectCompany = this.userProfile.companyName;
                //            localStorage.setItem('GLOBAL_COMPANY_NAME', String(this.selectCompany));
                //        }
                //    }
                //);
                this.loggedInUserRoleName = localStorage.getItem("LOGGED_IN_USER_ROLE");
                if (this.loggedInUserRoleName != 'MedCon Admin') {
                    this.selectCompany = localStorage.getItem("GLOBAL_COMPANY_NAME");
                            
                        }
                //if (localStorage.getItem("USER_LIST") == undefined) {
                //    this.customerService.getUsersAll().subscribe(
                //        (users) => {
                //            this.usersList = users.filter(user => user.email === this.user.email);
                //            localStorage.setItem("USER_LIST", this.usersList);
                //            //alert(this.usersList[0].email);
                //        }
                //    );
                //}
                //else
                //{
                //    this.usersList = localStorage.getItem("USER_LIST");

                //}
                
                if (this.loggedInUserRoleName === 'MedCon Admin')
                {

                    if (this.usersList != null)
                        this.user.customerId = this.usersList[0].userId; //As this user is medcon admin, we r getting userId instead of companyId
                }
                if (this.loggedInUserRoleName === 'MedCon Admin' || this.loggedInUserRoleName === 'Label User') {
                   
                    //alert('entered');
                    this.companyService.getAllCompanies().subscribe(
                        (response) => {
                            this.allCompanyList = response;
                            
                        },
                        (err) => {
                            //this.errorMessage = err;

                        });

                }
    //            else {
				//	this.customerService.getCustomer(this.user.customerId).subscribe((customer) => {
				//		this.customer = customer;
				//	});
				//}
			},
			(err) => {
				console.log(err);
            });
        //alert(localStorage.getItem('GLOBAL_COMPANY_ID'));
        if (localStorage.getItem('GLOBAL_COMPANY_ID') == "undefined" || Number(localStorage.getItem('GLOBAL_COMPANY_ID'))==0) {
            
            if (this.loggedInUserRoleName != 'MedCon Admin')
                localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
            else if (this.loggedInUserRoleName == 'MedCon Admin') {
                this.selectedCompanyId = 1;
                this.selectCompany = "Medcon";//this.allCompanyList[0].companyName;
                localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
                localStorage.setItem('GLOBAL_COMPANY_NAME', String(this.selectCompany));
            }

        }
        else 
        {
            //alert(this.selectedCompanyId);
            this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
            //alert(this.selectedCompanyId);
            //alert(localStorage.getItem('GLOBAL_COMPANY_NAME'));
            this.selectCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        }
        //localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
        
        //myGlobals.GLOBAL_COMPANYID = 1
        //alert(myGlobals.GLOBAL_COMPANYID);
        
       

        //alert(this.currentUserRole);
        //if (this.currentUserRole == 0) this.currentUserRole = 1; //for medcon admin 
        //this.privilegesService.getPrivileges(2).subscribe(
        //    (response) => {
        //        this.privilegesList1 = response;
               
        //    },
        //    (err) => {
        //        //this.errorMessage = err;

        //    });

       

        //alert(this.privilegesList[0].moduleName);
        //alert(this.privilegesFilterList.length);

	}

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-user-menu') {
			this.userMenuExtended = false;
		}
    }

    onChange(selectedValue) {
        this.selectedCompanyId = Number(selectedValue);
        localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
        this.performCompanyWiseNavigation(this.selectedCompanyId);
        
        //alert(this.selectedCompanyId);
        //this.router.navigate(['/', this.selectedCompanyId, 'users']);
        //alert(this.router.url);
        //location.reload();
        //this.url.pushState(null, null, '/' + this.selectedCompanyId + '/users', '');

        //GLOBAL_COMPANY_ID = this.selectedCompanyId;
        //alert(GLOBAL_COMPANY_ID);
        //alert(this.selectedCompanyId);
        //this.selectedCompanyName = null;
        ////To get selected role name
        if (this.allCompanyList != null) {
            for (var i = 0; i < this.allCompanyList.length; i++) {
                if (this.allCompanyList[i].companyId == this.selectedCompanyId) {
                    this.selectCompany = this.allCompanyList[i].companyName;
                }
            }

        }
        //alert(this.selectCompany);
        localStorage.setItem('GLOBAL_COMPANY_NAME', String(this.selectCompany));

    }

    public ngAfterViewInit(): void {
        
        //if (this.usersList != null && this.usersList[0].userId != undefined) {
            
        //    localStorage.setItem('GLOBAL_LOGGED_IN_USER_ID', String(this.usersList[0].userId));
        //}
        //else
        //{
        //    //alert('esle');
        //    //this.customerService.getUsersAll().subscribe(
        //    //    (users) => {
        //    //        this.usersList = users.filter(user => user.email === this.user.email);
        //    //        localStorage.setItem('GLOBAL_LOGGED_IN_USER_ID', String(this.usersList[0].userId))
        //    //        //alert(this.usersList[0].email);
        //    //    }
        //    //);

        //    if (localStorage.getItem("USER_LIST") == undefined) {
        //        alert('empty user');
        //        this.customerService.getUsersAll().subscribe(
        //            (users) => {
        //                this.usersList = users.filter(user => user.email === this.user.email);
        //                localStorage.setItem("USER_LIST", this.usersList);
        //                localStorage.setItem('GLOBAL_LOGGED_IN_USER_ID', String(this.usersList[0].userId))
        //            }
        //        );
        //    }
        //    else {
        //        this.usersList = localStorage.getItem("USER_LIST");
        //        localStorage.setItem('GLOBAL_LOGGED_IN_USER_ID', String(this.usersList[0].userId))
        //    }

        //}
        //alert(this.privilegesList1);
        if (this.privilegesList1 != null) {
            for (let i = 0; i < this.privilegesList1.length; i++) {
                let moduleName = this.privilegesList1[i].moduleName;
                let add = this.privilegesList1[i].add;
                let status = this.privilegesList1[i].status;
                //alert(moduleName);
                if (moduleName == "Dashboard") {
                    
                    this.isDataReportsHasAccess = status;
                    this.isOverviewMenuVisible = status;
                    this.isDashBoardHasAccess = status;
                }

                if (moduleName == "Reports") {

                    this.isDataReportsHasAccess = status;
                    this.isReportingMenuVisible = status;
                }

                //if (moduleName == "Patient Report") {

                //    this.isPatientReportsHasAccess = status;
                //    this.isReportingMenuVisible = status;
                //}

                if (moduleName == "Trials") {

                    this.isTrialsHasAccess = status;
                    this.isClinicalTrialsMenuVisible = status;
                }

                if (moduleName == "Trial Groups") {

                    this.isTrialGroupHasAccess = status;
                    this.isClinicalTrialsMenuVisible = status;
                }

                if (moduleName == "Notification") {

                    this.isNotificationHasAccess = status;
                    this.isClinicalTrialsMenuVisible = status;
                }

                if (moduleName == "Manage Users") {

                    this.isManageUserHasAccess = status;
                    this.isUserManagementMenuVisible = status;
                }


                if (moduleName == "Manage Medcon Users") {

                    this.isManageMedconUserHasAccess = status;
                    this.isUserManagementMenuVisible = status;
                }

                if (moduleName == "Privileges" && add=="1" ) {

                    this.privileges = status;
                    this.isUserManagementMenuVisible = status;
                    this.isPrivilegesMenuHasAccess = status;
                }

                if (moduleName == "Manage Company") {

                    this.isManageCompanyHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Labels") {

                    this.isLabelsHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }
                
                if (moduleName == "Manage Sites") {

                    this.isManageSitesHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Manage Drugs") {

                    this.isManageDrugHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Manage Regimen") {

                    this.isManageRegimenHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Patient Alerts") {

                    this.isPatientAlertHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Schedules") {

                    this.isScheduleHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Import Patient" && add == "1") {

                    this.isImportPatientHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Broadcast Messages") {

                    this.isBroadcastMessagesHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Settings") {

                    this.isSettingsHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Measurement") {

                    this.isMeasurementHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                if (moduleName == "Export") {

                    this.isExportMenuHasAccess = status;
                    this.isAdministrationMenuVisible = status;
                }

                
            }
        }



        
    }

    public performCompanyWiseNavigationOld(companyId)
    {
        //alert(companyId);
        if (this.router.url.indexOf("/dashboard") != -1)
        {
            this.router.navigate(['/dashboard']);

        }
        else if (this.router.url.indexOf("/reports") != -1) {
            this.router.navigate(['/reports']);

        }
        else if (this.router.url.indexOf("/patient-report") != -1) {
            this.router.navigate(['/patient-report']);

        }
        else if (this.router.url.indexOf("/trials") != -1) {
            //this.router.navigate(['/', companyId, 'trials']);
            this.url.pushState(null, null, '/' + companyId + '/trials', '');
        }
        else if (this.router.url.indexOf("/trialgroup") != -1) {
            //this.router.navigate(['/', companyId, 'trialgroup']);
            this.url.pushState(null, null, '/' + companyId + '/trialgroup', '');
        }
        else if (this.router.url.indexOf("/notifications") != -1) {
            //this.router.navigate(['/', companyId, 'notifications']);
            this.url.pushState(null, null, '/' + companyId + '/notifications', '');
        }
        else if (this.router.url.indexOf("/users") != -1) {
            //alert('users');
            //this.router.navigate(['/dashboard']);
            //this.router.navigate(['/', companyId, 'users']);
            this.url.pushState(null, null, '/' + companyId + '/users', '');


        }
        else if (this.router.url.indexOf("/privileges") != -1) {
            //this.router.navigate(['/', companyId, 'privileges']);
            this.url.pushState(null, null, '/' + companyId + '/privileges', '');
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId!=1 ) {
            //this.router.navigate(['/', companyId, 'company']);
            this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
            //this.router.navigate(['/customers', companyId, 'view']);
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId == 1) {
            //this.router.navigate(['/', companyId, 'company']);
            //this.url.pushState(null, null, '/customers' + companyId + '/view', '');
            //this.router.navigate(['/customers', companyId, 'view']);
            this.url.pushState(null, null, '/' + companyId + '/company', '');
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId == 1) {
            
            this.url.pushState(null, null, '/' + companyId + '/company', '');
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId != 1) {

            this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
        }
        else if (this.router.url.indexOf("/labels-committed") != -1) {
            //this.router.navigate(['/', companyId, 'labels-committed']);
            this.url.pushState(null, null, '/' + companyId + '/labels-committed', '');
        }
        else if (this.router.url.indexOf("/sites") != -1) {
           // this.router.navigate(['/', companyId, 'sites']);
            this.url.pushState(null, null, '/' + companyId + '/sites', '');
        }
        else if (this.router.url.indexOf("/drugs") != -1) {
            //this.router.navigate(['/', companyId, 'drugs']);
            this.url.pushState(null, null, '/' + companyId + '/drugs', '');
        }
        else if (this.router.url.indexOf("/regimens") != -1) {
            //this.router.navigate(['/', companyId, 'regimens']);
            this.url.pushState(null, null, '/' + companyId + '/regimens', '');
        }
        else if (this.router.url.indexOf("/import-patient") != -1) {
            //this.router.navigate(['/', companyId, 'import-patient']);
            this.url.pushState(null, null, '/' + companyId + '/import-patient', '');
        }
        else if (this.router.url.indexOf("/broadcast-Messages") != -1) {
            //this.router.navigate(['/', companyId, 'broadcast-Messages']);
            this.url.pushState(null, null, '/' + companyId + '/broadcast-Messages', '');
        }
        else if (this.router.url.indexOf("/measurement") != -1) {
            //this.router.navigate(['/', companyId, 'measurement']);
            this.url.pushState(null, null, '/' + companyId + '/measurement', '');
        }
        else if (this.router.url.indexOf("/settings") != -1) {
            //this.router.navigate(['/', companyId, 'settings']);
            this.url.pushState(null, null, '/' + companyId + '/settings', '');
        }
        else if (this.router.url.indexOf("/export") != -1) {
            //this.router.navigate(['/', companyId, 'export']);
            this.url.pushState(null, null, '/' + companyId + '/export', '');
        }


        location.reload();

    }


    public performCompanyWiseNavigation(companyId)
    {
        if (this.router.url.indexOf("/dashboard") != -1) {
            //this.router.navigate(['/dashboard']);
            this.onRefresh('', 'dashboard');

        }
        else if (this.router.url.indexOf("/reports") != -1) {
            //this.router.navigate(['/reports']);
            this.onRefresh('', 'reports');

        }
        else if (this.router.url.indexOf("/patient-report") != -1) {
            //this.router.navigate(['/patient-report']);
            this.onRefresh('', 'patient-report');

        }
        else if (this.router.url.indexOf("/Label-Report") != -1) {
            //this.router.navigate(['/patient-report']);
            this.onRefresh('', 'Label-Report');

        }
        else if (this.router.url.indexOf("/titration-Report") != -1) {
            //this.router.navigate(['/patient-report']);
            this.onRefresh('', 'titration-Report');

        }
        else if (this.router.url.indexOf("/trials") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1 || this.router.url.indexOf("/view") != -1)) {
            this.router.navigate(['/', companyId, 'trials']);
            //this.url.pushState(null, null, '/' + companyId + '/trials', '');
        }
        else if (this.router.url.indexOf("/trials") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1 || this.router.url.indexOf("/view") == -1)) {
            //this.router.navigate(['/', companyId, 'trials']);
            //this.url.pushState(null, null, '/' + companyId + '/trials', '');
            this.onRefresh(companyId, 'trials');
        }
        else if (this.router.url.indexOf("/trialgroup") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'trialgroup']);
            ///this.url.pushState(null, null, '/' + companyId + '/trialgroup', '');
        }
        else if (this.router.url.indexOf("/trialgroup") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            //this.router.navigate(['/', companyId, 'trialgroup']);
            //this.url.pushState(null, null, '/' + companyId + '/trialgroup', '');
            this.onRefresh(companyId, 'trialgroup');
        }
        else if (this.router.url.indexOf("/notifications") != -1) {
            //this.router.navigate(['/', companyId, 'notifications']);
            //this.url.pushState(null, null, '/' + companyId + '/notifications', '');
            this.onRefresh(companyId, 'notifications');
        }
        else if (this.router.url.indexOf("/users") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            //alert('users');
            //this.router.navigate(['/dashboard']);
            this.router.navigate(['/', companyId, 'users']);
            //this.url.pushState(null, null, '/' + companyId + '/users', '');


        }
        else if (this.router.url.indexOf("/users") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            //alert('users');
            //this.router.navigate(['/dashboard']);
            //this.router.navigate(['/', companyId, 'users']);
            //this.url.pushState(null, null, '/' + companyId + '/users', '');
            this.onRefresh(companyId, 'users');

        }
        else if (this.router.url.indexOf("/privileges") != -1) {
            this.router.navigate(['/', companyId, 'privileges']);
            //this.url.pushState(null, null, '/' + companyId + '/privileges', '');
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId != 1) {
            //this.router.navigate(['/', companyId, 'company']);
            //this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
            this.router.navigate(['/customers', companyId, 'view']);
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId == 1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'company']);
            //this.url.pushState(null, null, '/customers' + companyId + '/view', '');
            //this.router.navigate(['/customers', companyId, 'view']);
            //this.url.pushState(null, null, '/' + companyId + '/company', '');
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId == 1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            //this.router.navigate(['/', companyId, 'company']);
            //this.url.pushState(null, null, '/customers' + companyId + '/view', '');
            //this.router.navigate(['/customers', companyId, 'view']);
            //this.url.pushState(null, null, '/' + companyId + '/company', '');
            this.onRefresh(companyId, 'company');
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId == 1) {

            //this.url.pushState(null, null, '/' + companyId + '/company', '');
            this.router.navigate(['/', companyId, 'company']);
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId != 1) {
            //alert('companyId' + companyId);
            this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
            location.reload();
            //this.router.navigate(['/customers', companyId, 'view']);
        }
        else if (this.router.url.indexOf("/labels-committed") != -1) {
            //this.router.navigate(['/', companyId, 'labels-committed']);
            //this.url.pushState(null, null, '/' + companyId + '/labels-committed', '');
            this.onRefresh(companyId, 'labels-committed');
        }
        else if (this.router.url.indexOf("/sites") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'sites']);
            //this.url.pushState(null, null, '/' + companyId + '/sites', '');
        }
        else if (this.router.url.indexOf("/sites") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            //this.router.navigate(['/', companyId, 'sites']);
            //this.url.pushState(null, null, '/' + companyId + '/sites', '');
            this.onRefresh(companyId, 'sites');
        }
        else if (this.router.url.indexOf("/drugs") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'drugs']);
            //this.url.pushState(null, null, '/' + companyId + '/drugs', '');
        }
        else if (this.router.url.indexOf("/drugs") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            ///this.router.navigate(['/', companyId, 'drugs']);
            //this.url.pushState(null, null, '/' + companyId + '/drugs', '');
            this.onRefresh(companyId, 'drugs');
        }
        else if (this.router.url.indexOf("/regimens") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1 || this.router.url.indexOf("/view") != -1)) {
            this.router.navigate(['/', companyId, 'regimens']);
            //this.url.pushState(null, null, '/' + companyId + '/regimens', '');
        }
        else if (this.router.url.indexOf("/regimens") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1 || this.router.url.indexOf("/view") == -1)) {
            //this.router.navigate(['/', companyId, 'regimens']);
            //this.url.pushState(null, null, '/' + companyId + '/regimens', '');
            this.onRefresh(companyId, 'regimens');
        }
        else if (this.router.url.indexOf("/import-patient") != -1) {
            //this.router.navigate(['/', companyId, 'import-patient']);
            //this.url.pushState(null, null, '/' + companyId + '/import-patient', '');
            this.onRefresh(companyId, 'import-patient');
        }
        else if (this.router.url.indexOf("/broadcast-Messages") != -1) {
            //this.router.navigate(['/', companyId, 'broadcast-Messages']);
            //this.url.pushState(null, null, '/' + companyId + '/broadcast-Messages', '');
            this.onRefresh(companyId, 'broadcast-Messages');
        }
        else if (this.router.url.indexOf("/measurement") != -1) {
            //this.router.navigate(['/', companyId, 'measurement']);
            //this.url.pushState(null, null, '/' + companyId + '/measurement', '');
            this.onRefresh(companyId, 'measurement');
        }
        else if (this.router.url.indexOf("/settings") != -1) {
            //this.router.navigate(['/', companyId, 'settings']);
            this.url.pushState(null, null, '/' + companyId + '/settings', '');
            //this.onRefresh();
            location.reload();
        }
        else if (this.router.url.indexOf("/export") != -1) {
            //this.router.navigate(['/', companyId, 'export']);
            //this.url.pushState(null, null, '/' + companyId + '/export', '');
            this.onRefresh(companyId,'export');
        }
        else if (this.router.url.indexOf("/patients/new") != -1) {
            //this.router.navigate(['/', companyId, 'export']);
            //this.url.pushState(null, null, '/' + companyId + '/export', '');
            this.onRefresh(companyId, 'trials');
        }

    }

    onRefresh_Old() {
  this.router.routeReuseStrategy.shouldReuseRoute = function(){return false;};

  let currentUrl = this.router.url + '?';

  this.router.navigateByUrl(currentUrl)
    .then(() => {
      this.router.navigated = false;
      this.router.navigate([this.router.url]);
    });
    }

    //10th July 2018
    onRefresh(companyId,viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId!='')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }

    //end 10th july 2018

    //26th June 2018 

    navigateToMenuItem(menuItem)
    {
        
        
        if (this.router.url.indexOf("/" + menuItem) == -1)
        {
            
            if (!$('#datatable_processing').is(':visible')) {
                this.isLoading = true;
            }
            
            this.router.navigate(['/', this.selectedCompanyId, menuItem]);
            
        }
        else
        {
            if (!$('#datatable_processing').is(':visible')) {
                this.isLoading = true;
            }
            this.onRefresh(this.selectedCompanyId, menuItem);
        }

        
        
    }
    navigateToCompanyView(menuItem) {
        if (this.router.url.indexOf("/" + menuItem) == -1) {

            this.isLoading = true;
            this.router.navigate(['/customers', this.selectedCompanyId, 'view']);

        }

    }

    navigateToReportMenuItem(menuItem) {
        if (this.router.url.indexOf("/" + menuItem) == -1) {

            if (!$('#datatable_processing').is(':visible')) {
                this.isLoading = true;
            }
            this.router.navigate(['/', menuItem]);

        }
    }

    //12th July 2018
    redirectToDashBoard()
    {

        if (this.loggedInUserRoleName != 'Label User') //to do not display dashboard for label user
        {
            this.isLoading = true;
            this.router.navigate(['/dashboard']);

        }

    }

    //End

    ////27th June 2018

    //getAllCompanyListWithCompanyType(allCompanyList)
    //{
    //    //this.allCompanyListWithCompanyType = allCompanyList;

    //    allCompanyList.forEach(function (x) {
    //        let companyTypeFirstLetter = x.companyType.substring(0, 1);
    //        alert(companyTypeFirstLetter)
    //        let companyName = x.companyName + '(' + companyTypeFirstLetter + ')';
    //        alert(companyName);
    //        this.allCompanyListWithCompanyType.push({ "companyName": companyName, "companyType": x.companyType, "companyId": x.companyId });
    //    });

    //}

    ////End
}
