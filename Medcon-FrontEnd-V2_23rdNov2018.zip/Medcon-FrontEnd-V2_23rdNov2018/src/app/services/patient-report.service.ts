﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { PatientReport } from '../models/patientreport';
import { PatientInformation } from '../models/PatientInformation';
import { PatientDosageDetails } from '../models/PatientDosageDetails';
import { PatientSummaryGrid } from '../models/PatientSummaryGrid';
import { Pagination } from '../models/pagination';
import {CommonService} from '../services/commonService';
//import { Race } from '../models/race';
//import { PatientRequest } from '../requests/patient-request';
//import { PatientUploadRequest } from '../requests/patient-upload-request';

@Injectable()
export class PatientReportService {
    constructor(private http: Http) {
    }

    
    //public getPatientReportData(customerId: number, 
    //    page?: number, perPage?: number,
    //    sortField?: string,
    //    sortOrder?: string): Observable<(PatientReport)> {
    //    let params: URLSearchParams = new URLSearchParams();
    //    params.set('customer_id', String(customerId || ''));

    //    //return this.http.get(API_PATH + '/patient/list/' + customerId, { search: params })
    //    //    .map((res: Response) => res.json())
    //    //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //    return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
    //        .map((res: Response) => res.json())
    //        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //}


    public getPatientReportData(customerId: number, 
        page?: number, perPage?: number,
        sortField?: string,
        sortOrder?: string): Observable<(Pagination<PatientReport>)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('sortField', sortField);
        params.set('sortOrder', sortOrder);
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }
        //To fix the runtime errors, commented this code, once service is available then uncomment it
        //return this.http.get(API_PATH + '/patient/list/' + customerId, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getPatientInformation(id: number): any {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));

        //To fix the runtime errors, commented this code, once service is available then uncomment it
        //return this.http.get(API_PATH + '/patient/getPatientInformation' + id, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        //return this.http.get('https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/getpatientdetails?patientNumber=' + id)
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        
        //return this.http.get('https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/getpatientdetails?patientId=' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_PATIENT_DETAILS +'user/patient/getpatientdetails?patientNumber=' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getPatientDosageDetails(id: string): Observable<(PatientDosageDetails)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //To fix the runtime errors, commented this code, once service is available then uncomment it
        //return this.http.get(API_PATH + '/patient/getPatientDosageDetails' + id, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        
        //return this.http.get('https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/getpatientdosagesummary?patientNumber=' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_SUMMARY+'user/patient/getpatientdosagesummary?patientNumber=' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getPatientSummaryGridData(id: number):any {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //To fix the runtime errors, commented this code, once service is available then uncomment it
        //return this.http.get(API_PATH + '/patient/getPatientSummaryGridData' + id, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        
        //return this.http.get('https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/getpatientdetails?patientId=' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_PATIENT_DETAILS+'user/patient/getpatientdetails?patientId=' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
   
}
