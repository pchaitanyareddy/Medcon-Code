export class LabelCommittedRequest {
    constructor(
                
                public total: number,
                public userId: number,
                public year?: number,
                public companyName?: string,
                public companyId?: number


    ) {

	}
}
