export class SettingsRequest {
    constructor(
        public adherenceHours: number,
        public adherenceMinutes: number,
        public adherence: string 
    ) {
	}
}
