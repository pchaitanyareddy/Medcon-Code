import { UserRequest } from './user-request';

export class UserCreateRequest extends UserRequest {
	/*constructor(public customer: number,
		public givenName: string,
		public familyName: string,
		public type: string,
		public email: string) {
		super(givenName, familyName, type, email);
	} */

      constructor(public userId: number,
		public firstName: string,
		public lastName: string,
		public emailAddress: string,
		public phoneNumber: string,
		public roleName: string,
        public roleId: number,
        public CompanyId: number,
        public active: string,
        public dateOfBirth?: Date ,
        public gender?: string,
        public raceName?: string,
        public createdBy?: number,
        public createdDate?: Date,
        public lastUpdatedBy?: number,
        public lastUpdatedDate?: Date,
        public password?: string,
      ) {
        super(firstName, lastName, emailAddress, phoneNumber, password, dateOfBirth, gender, raceName, roleName, roleId, createdBy, createdDate, lastUpdatedBy, lastUpdatedDate, active);
	}
   

	
	
}
