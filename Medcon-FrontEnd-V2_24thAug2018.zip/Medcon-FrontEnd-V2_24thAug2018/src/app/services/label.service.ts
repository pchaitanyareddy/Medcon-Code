import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import { LabelCommittedRequest } from '../requests/label-committed-request';
import { LabelPurchasedRequest } from '../requests/label-purchased-request';
import { LabelDetails } from '../models/labeldetails';
import {CommonService} from '../services/commonService';
@Injectable()
export class LabelService {
	constructor(private http: Http) {
	}

	public getOverview(trialId?: number, customerId?: number, year?: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('trial_id', String(trialId || ''));
		params.set('customer_id', String(customerId || ''));
		params.set('year', String(year || ''));

		return this.http.get(API_PATH + '/label/overview', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getCustomerOverview(customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.get(API_PATH + '/label/overview/customer', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getCommitted(customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.get(API_PATH + '/label/committed', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updateCommitted(companyId: number, request: LabelCommittedRequest): Observable<(any)> {
		//let params: URLSearchParams = new URLSearchParams();
		//params.set('customer_id', String(customerId || ''));
        
        //return this.http.post('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/commit/' + companyId, request)
        return this.http.post(CommonService.API_PATH_V2_UPDATE_COMMITMENT+'label/commit/' + companyId, request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateCommittedById(id:number, request: LabelCommittedRequest): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId || ''));
        //return this.http.put('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/commit/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_COMMITMENT +'label/commit/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteCommitment(id: number): Observable<(any)> {
        
        //return this.http.delete('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/commit/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_COMMITMENT+'label/commit/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public addLabelPurchased(companyId: number, request: LabelPurchasedRequest): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId || ''));
        
        //return this.http.post('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/purchase/' + companyId, request)
        return this.http.post(CommonService.API_PATH_V2_PURCHASE_LABEL+'label/purchase/' + companyId, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getLabelDetails(companyId: number, year: number): any {
        //return [
        //    { labelName: 'Label1Aug2017', companyName:'Company1', status: 'Active', committed: 2000, purchased: 1000, used:1500,remaining:500, date:'11/29/2017' },
        //    { labelName: 'Label1Aug2017', companyName: 'Company2', status: 'Active', committed: 2000, purchased: 2000, used: 1500, remaining: 500, date: '10/18/2017' },
        //    { labelName: 'Label1Aug2017', companyName: 'Company3', status: 'Active', committed: 2000, purchased: 800, used: 1500, remaining: 500, date: '09/03/2017' },
        //    { labelName: 'Label1Aug2017', companyName: 'Company4', status: 'Active', committed: 2000, purchased: 1500, used: 1500, remaining: 500, date: '08/30/2017' },

        //]
        
        //return this.http.get('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/details/' + companyId + '?year=' + year)
        return this.http.get(CommonService.API_PATH_V2_GET_LABEL_DETAILS+'label/details/' + companyId + '?year=' + year)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getLabelsByYear(companyId: number,year:number): any {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId || ''));

        //if (year == 2018) {
        //    return [

        //        { id: 1, company: 'Company1', committed: '2000', purchased: '2000', used: '1500', remaining: '500' },
        //        { id: 2, company: 'Company2', committed: '1000', purchased: '1000', used: '800', remaining: '200' },
        //        { id: 3, company: 'Company3', committed: '1000', purchased: '1000', used: '600', remaining: '400' },

        //    ]
        //}
        //else if (year == 2017) {
        //    return [

        //        { id: 4, company: 'Company4', committed: '3000', purchased: '3000', used: '1500', remaining: '500' },
        //        { id: 5, company: 'Company5', committed: '1500', purchased: '1500', used: '800', remaining: '200' },
        //        { id: 6, company: 'Company6', committed: '1500', purchased: '1500', used: '600', remaining: '400' },

        //    ]
        //}
        return this.http.get(API_PATH + '/label/getLabelsByYear/'+year)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getLabelPurchase(companyId: number): any {
        
        //https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/purchase/{companyId}/all
        //return this.http.get('https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/purchase/' + companyId + '/all')
        return this.http.get(CommonService.API_PATH_V2_GET_LIST_LABEL_PURCHASE+'label/purchase/' + companyId + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
}
