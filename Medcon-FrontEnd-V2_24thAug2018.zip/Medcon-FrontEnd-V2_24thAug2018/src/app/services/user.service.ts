/// <reference path="commonservice.ts" />
/// <reference path="commonservice.ts" />
/// <reference path="commonservice.ts" />
import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { UserRequest } from '../requests/user-request';
import { UserCreateRequest } from '../requests/user-create-request';
import { Pagination } from '../models/pagination';
import { User } from '../models/user';
import { MedConUser } from '../models/medconuser';
import { UserMedConCreateRequest } from '../requests/user-medcon-create-request';
import { UserPreferenceRequest } from '../requests/user-preference-request';
import { Role } from '../models/role';
import { Country } from '../models/country';
import { State } from '../models/state';
import { CommonService }from '../services/commonService';


@Injectable()
export class UserService {
	constructor(private http: Http) {
	}

	public getCustomerOverview(customerId: number): Observable<(any)> {
		return this.http.get(API_PATH + '/user/overview/customer/' + customerId)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public createUser(request: UserCreateRequest): Observable<(any)> {
        //return this.http.post("https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev" + '/user', request)
       return this.http.post(CommonService.API_PATH_V2_CREATE_MEDCON_USER + 'user', request)
            .map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public createMedConUser(request: UserMedConCreateRequest): Observable<(any)> {
		return this.http.post(API_PATH + '/user/medcon', request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getMedConUsers(page?: number, perPage?: number): Observable<(Pagination<MedConUser>)> {
		let params: URLSearchParams = new URLSearchParams();
		if (page) {
			params.set('page', String(page));
		}
		if (perPage) {
			params.set('per_page', String(perPage));
		}

		return this.http.get(API_PATH + '/user/list', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getUsers(customerId: number, page?: number, perPage?: number): Observable<(Pagination<User>)> {
		let params: URLSearchParams = new URLSearchParams();
		if (page) {
			params.set('page', String(page));
		}
		if (perPage) {
			params.set('per_page', String(perPage));
		}

		return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getUser(id: string): Observable<(any)> {
		return this.http.get(API_PATH + '/user/' + id)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updateCustomerUser(sub: string, customerId: number, request: UserRequest): Observable<(any)> {
		//let params: URLSearchParams = new URLSearchParams();
		//params.set('customer_id', String(customerId || ''));

		//return this.http.put(API_PATH + '/user/update/customer/' + sub, request, { search: params })
		//	.map((res: Response) => res.status === 200)
		//	.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //return this.http.put('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/update/medcon/' + sub, request)
        return this.http.put(CommonService.API_PATH_V1_UPDATE_MEDCON_USER +'user/update/medcon/'+ sub, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updateMedConUser(sub: string, request: UserMedConCreateRequest): Observable<(any)> {
		return this.http.put(API_PATH + '/user/update/medcon/' + sub, request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public deleteMedConUser(sub: string): Observable<(any)> {
       // return this.http.delete('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/medcon/' + sub)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_SELECTED_MEDCON_USER +'user/medcon/'+ sub)

        
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

		//return this.http.delete(API_PATH + '/user/medcon/' + id)
		//	.map((res: Response) => res.status === 200)
		//	.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public deleteCustomerUser(id: number, customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.delete(API_PATH + '/user/customer/' + id, { search: params })
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public resetCustomerUser(sub: string, customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.put(API_PATH + '/user/password/customer/' + sub, null, { search: params })
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public resetMedConUser(sub: string): Observable<(any)> {
		return this.http.put(API_PATH + '/user/password/medcon/' + sub, null)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getPreference(metaKey: string): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('meta_key', String(metaKey || ''));

		return this.http.get(API_PATH + '/user/preference', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updatePreference(request: UserPreferenceRequest): Observable<(any)> {
		return this.http.put(API_PATH + '/user/preference', request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}
	//Added by ramesh on 14th Nov 2017
	public updateUserStatus(userId: number, customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.put(API_PATH + '/user/updatestatus/updateStatus' + userId, { search: params })
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //Added by ramesh on 21st Nov 2017
    public sendPassword(sub: string, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId || ''));

        return this.http.put(API_PATH + '/user/password/customer/' + sub, null, { search: params })
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    

    public getAllCompanies(): any {
        //return [
        //    { companyId: 1, companyName: 'ABC Pharmaticual' },
        //    { companyId: 2, companyName: 'Test1' },
        //    { companyId: 3, companyName: 'Test2' },

        //]
        //alert(API_PATH_V2_LIST_ALL_COMPANIES);
        //return this.http.get('https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/list/all')
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_COMPANIES +'company/list/all')
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAllRoles(): any {
        //return [
        //    { companyId: 1, companyName: 'ABC Pharmaticual' },
        //    { companyId: 2, companyName: 'Test1' },
        //    { companyId: 3, companyName: 'Test2' },

        //]
       //alert(CommonService.API_PATH_V2_GET_ROLES + 'roles');
        //return this.http.get('https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/roles')
        return this.http.get(CommonService.API_PATH_V2_GET_ROLES+'roles')
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getUserInfoByUserId(sub: string): any {
       return [
           { userId: 1, firstName: 'Venkat', lastName: 'Raman', emailAddress: 'venkatraman.b@smartims.com', phoneNumber: '123123123', roleName: 'Customer Admin', companyName: 'ABC Pharma Global', roleId: 2, companyId: 1, sub:'b78e53f3-1064-4dd7-b278-87c9dee4038c'},
           
        ]
        //return this.http.get(API_PATH + '/user/' + id)
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    //public updateUser(sub: string, request: UserRequest): Observable<(any)> {
    //    //let params: URLSearchParams = new URLSearchParams();
    //    //params.set('customer_id', String(customerId || ''));

    //    //return this.http.put(API_PATH + '/user/update/customer/' + sub, request, { search: params })
    //    //	.map((res: Response) => res.status === 200)
    //    //	.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //    return this.http.put('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/update/medcon/' + sub, request)
    //        .map((res: Response) => res.status === 200)
    //        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //}

    public getAllUsersByCompany(companyId:number): any {
        
        //return this.http.get('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/list/medcon/'+companyId+'/all')
        return this.http.get(CommonService.API_PATH_V2_GET_MEDCON_USER_LIST_ALL +'user/list/medcon/'+ companyId + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getSelectedUser(sub: string): any {
        
        //return this.http.get('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/' + sub)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_MEDCON_USER +'user/'+ sub)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }


    public getCountries(): Observable<(Country[])> {
        //return this.http.get('https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/masterdata/list/countries')
        return this.http.get(CommonService.API_PATH_V2_LIST_OF_COUNTRIES +'masterdata/list/countries')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getStatesByCountry(countryId: number): Observable<(State[])> {
        //if (countryId == 1) {
        //    return  [{ id: 1, name: 'New york' },]
        //}
        //else if (countryId == 2) {
        //    return [
        //        { id: 1, name: 'Telangana' },
        //        { id: 2, name: 'AndhraPradesh' },

        //    ]
        //}
        //return this.http.get('https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/masterdata/list/countries/' + countryId + '/states')
        return this.http.get(CommonService.API_PATH_V2_LIST_OF_STATES+'masterdata/list/countries/' + countryId + '/states')
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateLoginInformation(jsonString: string,sub:string): Observable<(any)> {
        //return this.http.put('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/update/login/' + sub, jsonString)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_MEDCON_USER_LOGIN_TIME+'user/update/login/' + sub, jsonString)
        
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getIPAddress() {
        var json = 'http://ipv4.myexternalip.com/json';
        return this.http.get(json)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));


    }


    public updateStatusOfUser(sub: string,jsonString)
    {
        //return this.http.put(' https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/medcon/update/status/' + sub, jsonString)
         return this.http.put(CommonService.API_PATH_V2_UPDATE_MEDCON_USER_STATUS+'user/medcon/update/status/' + sub, jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    

    




}
