﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Notifications } from '../models/notifications';
import { NotificationsRequest } from '../requests/notifications-request';
import { Observable } from 'rxjs';
import { Pagination } from '../models/pagination';
import {CommonService} from '../services/commonService';
@Injectable()
export class NotificationsService {
    constructor(private http: Http) {
    }

    public getNotifications(customerId?: number): Observable<Pagination<Notifications>> {
        let customer = (customerId) ? '/' + customerId : '';

        return this.http.get(API_PATH + '/notifications/list' + customer)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createNotifications(trailId: Number, request: NotificationsRequest): Observable<(any)> {
        
       // https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/{id}
        //return this.http.post('https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/' + trailId, request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_NOTIFICATION+'notifications/' + trailId, request)
        
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateNotifications(id: number, request: NotificationsRequest): Observable<(any)> {
        //https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/{id}
        
        //return this.http.put('https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_NOTIFICATION+'notifications/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getNotification(id: number): Observable<(Notifications)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));
        //uncomment below code after getting api

        //return this.http.get(API_PATH + '/site/' + id, { search: params })
        //	.map((res: Response) => res.json())
        //	.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/{id}
        return this.http.get('https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/' + id)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getNotificationsList(customerId: number, page?: number, perPage?: number): Observable<(Pagination<Notifications>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        //Uncomment this when API service is ready
        //return this.http.get(API_PATH + '/trialgroup/list/' + customerId, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteNotifications(id: number): Observable<(any)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId || ''));

        //Uncomment this when API service is ready
        //return this.http.delete(API_PATH + '/trialgroup/' + id, { search: params })
        //    .map((res: Response) => res.status === 200)
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/{id}
       
        //return this.http.delete('https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_NOTIFICATION+'notifications/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getAllTrails(companyId:number): any {
        
       // return this.http.get('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trail/list/' + companyId + '/all')
        return this.http.get(CommonService.API_PATH_V2_GET_TRIAL_LIST_ALL+'trail/list/' + companyId + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedTrailsFromTrialGroup(companyId: number,trailgroupId:number): any {
        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/{companyId}/{trialgroupId}
        return this.http.get(CommonService.API_PATH_V2_SELECTING_TRIAL_GROUP_FOR_TRIAL_LIST + 'trialgroup/list/' + companyId + '/' + trailgroupId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    
    public getSelectedTrailsFromTrialGroupForTitrateReport(companyId: number, trailgroupId: number): any {
        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/titrated/{companyId}/{trialgroup_Id}
        return this.http.get(CommonService.API_PATH_V2_SELECTING_TRIAL_GROUP_FOR_TRIAL_LIST + 'trialgroup/list/titrated/' + companyId + '/' + trailgroupId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedPatientsFromTrials(companyId: number, trailgroupId: number, trailId: number): any {
        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/{companyId}/{trialgroupId}/{trialId}
        
        return this.http.get(CommonService.API_PATH_V2_SELECTING_TRAIL_FOR_PATIENT_LIST + 'trialgroup/list/' + companyId + '/' + trailgroupId + '/' + trailId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedContainerFromPatients(companyId: number, trailgroupId: number, trailId: number, patientId: number): any {
        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/{companyId}/{trialgroupId}/{trialId}/{patientId}

        return this.http.get(CommonService.API_PATH_V2_SELECTING_PATIENT_LIST_FOR_CONTAINER + 'trialgroup/list/' + companyId + '/' + trailgroupId + '/' + trailId + '/' + patientId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedLocationFromTrail(companyId: number, trailId: number): any {
       
        return this.http.get(CommonService.API_PATH_V2_SELECTING_LOCATION_LIST_FORM_TRAIL + 'trialgroup/list/loc/' + companyId + '/'  + trailId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedPatientsFromLocation(companyId: number, location: number): any {
        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/location/{companyId}/{location_name}
        return this.http.get(CommonService.API_PATH_V2_SELECTING_PATIENT_LIST_FORM_LOCATION + 'trialgroup/list/location/' + companyId + '/' + location)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedDrugFromTrial(companyId: number, trailId: number): any {
        
        return this.http.get(CommonService.API_PATH_V2_SELECTING_DRUG_LIST_FORM_TRAIL + 'trialgroup/list/titrate/' + companyId + '/' + trailId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSelectedRegimenFromDrug(trialId: number, drugId: number,companyId:number): any {
        // https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/list/drug/{companyId}/{drug_id}
        let params: URLSearchParams = new URLSearchParams();
        params.set('companyId', String(companyId));
        return this.http.get(CommonService.API_PATH_V2_SELECTING_REGIMEN_LIST_FORM_DRUG + 'trialgroup/list/drug/' + trialId + '/' + drugId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
}
