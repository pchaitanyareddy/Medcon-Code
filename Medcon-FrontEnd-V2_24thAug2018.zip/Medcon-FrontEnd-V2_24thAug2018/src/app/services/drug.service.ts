import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import { DrugRequest } from '../requests/drug-request';
import { Pagination } from '../models/pagination';
import { Drug } from '../models/drug';
import {CommonService} from '../services/commonService';
@Injectable()
export class DrugService {
	constructor(private http: Http) {
	}

	public getDrugs(customerId: number,
		page?: number, perPage?: number,
		sortField?: string,
		sortOrder?: string): Observable<(Pagination<Drug>)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('sortField', sortField);
		params.set('sortOrder', sortOrder);
		if (page) {
			params.set('page', String(page));
		}
		if (perPage) {
			params.set('per_page', String(perPage));
		}

		return this.http.get(API_PATH + '/drug/lists', { search: params })
			.map((res: Response) => {
				let response = res.json();
				response.items = [];
				res.json().items.forEach((item) => {
					this.getCheckDosesLogged(item.id, customerId)
						.subscribe((r) => item.inUse = r.value);
					response.items.push(item);
				});
				
				return response;
			})
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getDrugsAll(customerId: number): Observable<Drug[]> {
		return this.http.get(API_PATH + '/drug/lists/' + customerId + '/all')
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public createDrug(request: DrugRequest): Observable<(any)> {
        
        //return this.http.post('https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')), request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_DRUG+'drug/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')), request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public updateDrug(id: number, request: DrugRequest): Observable<(any)> {
        
        //return this.http.put('https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/update/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_DRUG+'drug/update/' + id, request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public deleteDrug(id: number): Observable<(any)> {
        
        //https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/delete/{id}
        //return this.http.delete('https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/delete/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_DRUGS+'drug/delete/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

	public getDrug(id: number): Observable<(Drug)> {
        
        //return this.http.get('https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/get/' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_DRUGS+'drug/get/' + id)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getCheckDosesLogged(id: number, customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId));

		return this.http.get(API_PATH + '/drug/' + id + '/check/doses-logged', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public resizeImage(img, callback) {
		return img.onload = () => {
			let width = img.width;
			let height = img.height;
			let MAX_HEIGHT = 250;
			let MAX_WIDTH = 250;
			let MIN_HEIGHT = 250;
			let MIN_WIDTH = 250;
			let ratio;

			// Set the WxH to fit the min and max values (but maintain proportions)
			if (width > height) {
				if (width > MAX_WIDTH) {
					height *= MAX_WIDTH / width;

					if (height < MIN_HEIGHT) {
						ratio = MIN_HEIGHT / height;
						height = MIN_HEIGHT;
						width = MAX_WIDTH * ratio;
					} else {
						width = MAX_WIDTH;
					}
				}
			} else {
				if (height > MAX_HEIGHT) {
					width *= MAX_HEIGHT / height;

					if (width < MIN_WIDTH) {
						ratio = MIN_WIDTH / width;
						width = MIN_WIDTH;
						height = MIN_HEIGHT * ratio;
					} else {
						height = MAX_HEIGHT;
					}
				}
			}

			// Create a canvas object
			let canvas = document.createElement('canvas');
			canvas.width = 250;
			canvas.height = 250;

			let ctx = canvas.getContext('2d');
			ctx.drawImage(img, 0, 0, width, height);

			// Get this encoded as a png
			let dataUrl = canvas.toDataURL('image/png');

			// Callback with the results
			callback(dataUrl);
		};
    }


    public getAllMedicationType(request: DrugRequest): any {
        
        //return this.http.get('https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/measurement/list/all')
        return this.http.get(CommonService.API_PATH_V2_LIST_ALL_MEASUREMENTS+'measurement/list/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getAllDrug(companyId:number): any {
        //https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/drug/list/company/all
        return this.http.get(CommonService.API_PATH_V2_GET_ALL_DRUG + 'drug/list/company/all?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }
}
