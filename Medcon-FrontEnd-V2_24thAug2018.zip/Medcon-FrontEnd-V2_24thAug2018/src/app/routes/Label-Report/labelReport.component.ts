﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../../services/customer.service';
import { SiteService } from '../../services/site.service';
import { LabelReport } from '../../models/labelReport';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CompanyService } from '../../services/company.service';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { CommonService } from '../../services/commonService';
import { TrialService } from '../../services/trial.service';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './labelReport.component.html?v=${new Date().getTime()}'
})

export class LabelReportComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public labelReport: Pagination<LabelReport>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public labelReportsForm: FormGroup;
    public companyList: any;
    public companyListFiltered: any;
    public maxSize: number = 5;
    public currentPage: number = 1;
    labelReportList: any;
    privilegesByModule: any;
    privilegesList: any;
    selectedTrialGroupId: number;
    selectedTrialGroupName: string;
    allTrialGroupList: any;
    public privileges: Privileges;

    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public yearList = [];
    private yy: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private SiteService: SiteService,
        private cognitoUtil: CognitoUtil,
        private fb: FormBuilder,
        public companyService: CompanyService,
        private reportService: ReportService,
        private trialService: TrialService,
        private url: LocationStrategy) {


    }

    public ngOnInit(): void {
        this.getYear();
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        this.companyService.getAllCompanies().subscribe(
            (response) => {
                this.companyList = response;
                //alert(this.loggedInUserRole);
            },
            (err) => {
                this.errorMessage = err;

            });

        this.labelReportsForm = this.fb.group({

            fromDate: ['', Validators.required],
            toDate: ['', Validators.required],
            company: ['', Validators.required],
            committed: ['', [Validators.required]],
            used: ['', [Validators.required]],
            remaining: ['', [Validators.required]],
            trialGroup: ['', [Validators.required]],
        });


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Label Report')

        //this.trialService.getAllTrialGroupsDropDown(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
        //    (response) => {
        //        this.allTrialGroupList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });
    }

    public loadLabelReport(submitType): void {
        let isValid = true;
        let fromDate = '';
        let toDate = '';
        let company = '';
        let committed = '';
        let used = '';
        let remaining = '';
        let url = '';
        let companyIds = '';
        let companyIdGobalID = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        var arrCompanyIds;
        //alert(submitType);
        let pageLength = 0;
        if (submitType == 'buttonClick') {
            pageLength = Number($("select[name='datatable_length'] option:selected").text());
            $("#datatable").dataTable().fnDestroy();
            fromDate = this.labelReportsForm.value.fromDate;//this.convertDate(this.labelReportsForm.value.fromDate.date);
            toDate = this.labelReportsForm.value.toDate;//this.convertDate(this.labelReportsForm.value.toDate.date);
            //company = this.labelReportsForm.value.company;
            company = String(companyIdGobalID);
            committed = this.labelReportsForm.value.committed;
            used = this.labelReportsForm.value.used;
            remaining = this.labelReportsForm.value.remaining;
            companyIds = String(companyIdGobalID);
            let trialGroupIds = (String(this.selectedTrialGroupId) == 'NaN') ? '' : String(this.selectedTrialGroupId);
            //alert(company);

        
           
            isValid = true;
            //var startDate1 = new Date(fromDate);
            //var endDate1 = new Date(toDate);
            //var todayDate = new Date();
            if (Number(fromDate) > Number(toDate)) {

                this.errorMessage = "From Year Date should be Less than To Year Date";
                isValid = false;
            }
            if (fromDate != '' && toDate == '') {
                this.errorMessage = "Please Select To Year"
                isValid = false;
            }
            else if (fromDate == '' && toDate != '') {
                this.errorMessage = "Please Select From Year"
                isValid = false;
            }
            //else if (fromDate == '' && toDate == '') {
            //    this.errorMessage = "Please Select From and To Year"
            //    isValid = false;
            //}
            if (fromDate != 'Select' && toDate == 'Select') {
                this.errorMessage = "Please Select To Year"
                isValid = false;
            }
            else if (fromDate == 'Select' && toDate != 'Select') {
                this.errorMessage = "Please Select From Year"
                isValid = false;
            }
            else if (fromDate == 'Select' && toDate == 'Select') {
                //this.errorMessage = "Please Select From Year"
                isValid = true;
            }
            //alert(company);
                //if (company != undefined && company != '' && company != null) {
                //        if (company.indexOf(",") != -1) {
                //            arrCompanyIds = company.split(',');
                //            arrCompanyIds.forEach((item, index) => {
                //                if (this.companyList != undefined) {
                //                    //alert(this.companyList.length);
                //                    this.companyListFiltered = this.companyList.filter(
                //                        companyObj => companyObj.companyName.toLowerCase() === item.toLowerCase())
                //                    if (companyIds == '') {
                //                        //alert(this.companyList[0].companyId);
                //                        if (this.companyListFiltered[0] != undefined)
                //                            companyIds = this.companyListFiltered[0].companyId;
                //                        else
                //                            companyIds = item;

                //                    }
                //                    else {
                //                        if (this.companyListFiltered[0] != undefined)
                //                            companyIds = companyIds + ',' + this.companyListFiltered[0].companyId;
                //                        else
                //                            companyIds = companyIds + ',' + company;

                //                    }
                //                }
                //            });
                //        }
                //        else {
                //            //alert(this.companyList.length);
                //            if (this.companyList != undefined) {
                //                this.companyListFiltered = this.companyList.filter(
                //                    companyObj => companyObj.companyName.toLowerCase() === company.toLowerCase())
                //                if (companyIds == '') {
                //                    if (this.companyListFiltered[0] != undefined)
                //                        companyIds = this.companyListFiltered[0].companyId;
                //                    else
                //                        companyIds = company;
                //                }
                                
                //            }

                //        }

                //}

            if ((fromDate == '' && toDate == '') || (fromDate == 'Select' && toDate == 'Select')) {
                    //url = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/reports/labelsreport';
                    url = CommonService.API_PATH_V2_LABEL_REPORT + 'reports/labelsreport?companyIds=' + companyIdGobalID;

                }
                else
                {
                    //url = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/reports/labelsreport?companyIds=' + companyIds + '&startdate=' + fromDate + '&enddate=' + toDate;
                    //url = CommonService.API_PATH_V2_LABEL_REPORT + 'reports/labelsreport?companyIds=' + companyIds + '&startdate=' + fromDate + '&enddate=' + toDate + '&trialGroupIds=' + trialGroupIds;
                    url = CommonService.API_PATH_V2_LABEL_REPORT + 'reports/labelsreport?companyIds=' + companyIds + '&startdate=' + fromDate + '&enddate=' + toDate;
                }
                    
                
            }

       
        else {
            //url = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/reports/labelsreport?companyIds=' + companyIdGobalID;
            //url = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/reports/labelsreport';
	    url = CommonService.API_PATH_V2_LABEL_REPORT +'reports/labelsreport?companyIds=' + companyIdGobalID;
        }

        if (isValid) {
            $("#datatable").css("display", "block");
            var self = this;
            this.cognitoUtil.getIdToken({
                callback() {
                    /* tslint:disable:no-empty */
                },
                callbackWithParam(token: any) {

                    this.authorizationToken = token;
                    //alert(this.authorizationToken);
                    $('#datatable').DataTable({
                        "processing": true,
                        "serverSide": true,
                        'ajax': {
                            'url': url,
                            'type': 'GET',
                            'beforeSend': function (request) {
                                request.setRequestHeader("Authorization", token);
                            }
                        },
                        dom: 'lBfrtip',
                        buttons: [
                            {
                                extend: 'csv', text: 'Export', exportOptions: {
                                    columns: [0, 1, 2, 3]
                                }
                                ,
                                action: function () {
                                    //let apiUrl = CommonService.API_PATH_V2_LABEL_REPORT + 'reports/labelsreport?draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=patientId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=Container&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=dose&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=type&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=extraDose&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=doseWindow&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=entry&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=location&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B10%5D%5Bdata%5D=timeTaken&columns%5B10%5D%5Bname%5D=&columns%5B10%5D%5Bsearchable%5D=true&columns%5B10%5D%5Borderable%5D=true&columns%5B10%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B10%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B11%5D%5Bdata%5D=timeTaken&columns%5B11%5D%5Bname%5D=&columns%5B11%5D%5Bsearchable%5D=true&columns%5B11%5D%5Borderable%5D=true&columns%5B11%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B11%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=asc&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false&_=1523950744748'
                                    url = (url.indexOf("?") == -1) ? url + '?' : url + '&';
                                    let apiUrl = url + 'draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=patientId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=Container&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=dose&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=type&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=extraDose&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=doseWindow&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=entry&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=location&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B10%5D%5Bdata%5D=timeTaken&columns%5B10%5D%5Bname%5D=&columns%5B10%5D%5Bsearchable%5D=true&columns%5B10%5D%5Borderable%5D=true&columns%5B10%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B10%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B11%5D%5Bdata%5D=timeTaken&columns%5B11%5D%5Bname%5D=&columns%5B11%5D%5Bsearchable%5D=true&columns%5B11%5D%5Borderable%5D=true&columns%5B11%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B11%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1523950744748'
                                    self.reportService.ExportAll(apiUrl, 'Label Report');
                                },
                            },
                            {
                                extend: 'print', text: 'Print', exportOptions: {
                                    columns: [0, 1, 2, 3]
                                }
                            }

                        ],
                        "order": [[0, "desc"]],
                        "columns": [
                            { "data": "companyName" },
                            { "data": "labelsCommitted" },
                            { "data": "labelsPurchased" },
                            { "data": "labelsUsed" },
                            { "data": "labelsRemaining" },
                            { "data": "year" }

                        ]
                        ,
                        "columnDefs": [



                        ]
                        ,
                        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                        "pageLength": pageLength
                    });
                }
            });

        }
        else
        {
            $("#datatable").css("display", "none");

        }
     
    }



    public ngAfterViewInit(): void {



        this.loadLabelReport('PageLoad');

    }

    public deleteItem(id): void {
       
        this.deleteModal.show();
    }

    public hideDeleteModal(): void {
        
        this.deleteModal.hide();
    }

    //public onDateChange(event: IMyInputFieldChanged, field): void {
    //    let d = event.value.split('/');
    //    let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

    //    if (event.valid) {
    //        if (field === 'start') {
    //            this.setEndDateDisableUntil(date.date);
    //        } else if (field === 'end') {
    //            this.setStartDateDisableSince(date.date);
    //        }
    //    }
    //}

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let day = Number(d[1]) - 1;
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + day);
        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            }
            //else if (field === 'end') {
            //    this.setStartDateDisableSince(date.date);
            //}
        }
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    public customerChanged(): void {
        
    }


    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }
    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }
    private dateForView(date: string): any {
        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2].replace('0', '') } };
        } else {
            return '';
        }
    }

    //onChangeTrialGroip(selectedValue) {
    //    this.selectedTrialGroupId = Number(selectedValue);
    //    this.selectedTrialGroupName = null;
    //    //To get selected role name
    //    if (this.allTrialGroupList != null) {
    //        for (var i = 0; i < this.allTrialGroupList.length; i++) {
    //            if (this.allTrialGroupList[i].id == this.selectedTrialGroupId) {
    //                this.selectedTrialGroupName = this.allTrialGroupList[i].name;
    //            }
    //        }

    //    }

    //}

    getYear() {
        var today = new Date();
        this.yy = today.getFullYear();
        for (var i = this.yy; i <= (this.yy + 100); i++) {
            this.yearList.push(i);
        }
    }
}
