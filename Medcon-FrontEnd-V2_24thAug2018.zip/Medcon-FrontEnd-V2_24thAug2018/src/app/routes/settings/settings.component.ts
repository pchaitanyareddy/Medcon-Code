import { Component, HostListener, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { TemplateService } from '../../services/template.service';
import { SettingsRequest } from '../../requests/settings-request';
import { SettingsService } from '../../services/settings.service';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './settings.component.html'
})

export class SettingsComponent implements OnInit {
	public form: FormGroup;
	public showErrors: boolean;
	public successMessage: string;
	public errorMessage: string;
	public industryAdherenceBenchmark: number;

	constructor(public templateService: TemplateService,
		private fb: FormBuilder,
		private location: Location,
		private settingsService: SettingsService) {
	}

	public ngOnInit() {
		this.settingsService.getSetting('industry_adherence_target')
			.subscribe((setting) => {
				this.industryAdherenceBenchmark = setting.value;
				this.form.controls['industryAdherenceBenchmark'].setValue(setting.value);
			});

		this.form = this.fb.group({
			industryAdherenceBenchmark: [
				'',
				[Validators.required, Validators.pattern(/^(\d{0,2}(\.\d{1,2})?|100(\.00?)?)$/)]
			]
		});
	}

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
		} else {
			let request = new SettingsRequest(
				this.form.value.industryAdherenceBenchmark
			);

			this.settingsService.updateSettings(request).subscribe(
				(response) => {
					this.form.markAsPristine();
					this.successMessage = 'Settings have been successfully updated';
				},
				(err) => {
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.location.back();
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}
}
