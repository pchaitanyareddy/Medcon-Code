﻿import { UserRole } from './userrole';

export class Privileges {
    constructor(public id: number,
        public moduleName: string,
        public subModuleName: string,
        public view: number,
        public add: number,
        public edit: number,
        public deleteAction: number,
        public role_name: string,
        public role_id: number,
        public created_by: number,
        public created_date: Date,
        public roleId: number,
        public last_updated_by: string,
        public createdDate: Date,
        public lastUpdatedBy: number,
        public lastUpdatedDate: Date,
        public company: string,
        public active: string,
        ) {
    }


}
