import { UserRole } from './userrole';

export class CognitoUser {
	constructor(public id: number,
		public email: string,
		public name: string,
		public customerId: number,
		public role: UserRole = UserRole.Patient) {
	}
}
