﻿export class TrialgroupAssociateSiteRequest {
    constructor(
        public siteId?: number,
        //public companyId?: number,
        public userId?: number

    ) {
    }
}
