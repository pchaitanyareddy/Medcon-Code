﻿export class PrivilegesRequest {
    constructor(
        //public moduleName: string,
        //public subModuleName: string,
        //public view: number,
        //public add: number,
        //public edit: number,
        //public deleteAction: number,
        //public roleName: string,
        //public roleId: number,
        //public createdBy: string,
        //public createdDate: Date,
        //public lastUpdatedBy: string,
        //public lastUpdatedDate: Date,
        //public active: boolean
        public jsonString:string
         ) {
    }
}
