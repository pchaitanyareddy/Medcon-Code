export class Regimen {
	constructor(public id: number,
		public name: string,
		public pillsPerDose: number,
		public dosesPerDay: number,
		public extraDoses: number,
		public totalDoses: number,
		public durationBetweenDoses: number,
		public adherenceThreshold: number,
		public inUse: boolean,
		public containersTotal: number,
		public dosageQuantity: number,
		public dosageAmount: number,
        public unitOfMeasure: string,
        public medicationPerDose: string,
        public schedule_type: string,
        public thresholdTime: number,
        public morningWindow: string,
        public noonWindow: string,
        public eveningWindow: string,
        public nightWindow: string,
        public days: number
    ) {
	}
}
