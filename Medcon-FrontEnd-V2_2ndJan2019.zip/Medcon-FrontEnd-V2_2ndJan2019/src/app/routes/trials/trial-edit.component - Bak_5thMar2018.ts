import { Component, HostListener, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import 'rxjs/add/operator/switchMap';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialService } from '../../services/trial.service';
import { PatientService } from '../../services/patient.service';
import { LabelService } from '../../services/label.service';
import { Trial } from '../../models/trial';
import { Drug } from '../../models/drug';
import { Regimen } from '../../models/regimen';
import { Customer } from '../../models/customer';
import { UserRole } from '../../models/userrole';
import { Site } from '../../models/site';
import { PairDrugRegimenRequest } from '../../requests/pair-drug-regimen-request';
import { TrialRequest } from '../../requests/trial-request';
import { TrialLabelsRequest } from '../../requests/trial-labels-request';
import { TrialContainersRequest } from '../../requests/trial-containers-request';
import { TrialOptionsRequest } from '../../requests/trial-options-request';
import { TrialGroupRequest } from '../../requests/trialgroup-request';
import { SiteRequest } from '../../requests/site-request';
import { TrialPatientAlertsRequest } from '../../requests/trial-patient-alerts-request';
import { Observable } from 'rxjs/Observable';
import { Patient } from '../../models/patient';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { TrialGroup } from '../../models/trialgroup';
import { SubscriptionRequest } from '../../requests/Subscription-request';
import {TrailGroupAssociateRequest} from '../../requests/trailgroupAssociate-request';
import {TrialgroupAddAssociateRequest} from '../../requests/trialgroupAddAssociate-request';
import {TrialgroupAssociateSiteRequest} from '../../requests/trialgroupAssociateSite-request';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { DisassociateSiteRequest } from '../../requests/disassociateSite-request';
import _ from 'lodash';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './trial-edit.component.html',
    styleUrls: ['./trial-edit.component.scss']
})

export class TrialEditComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('dataMatrixModal') public dataMatrixModal: ModalDirective;
    @ViewChild('trialMenu') public trialMenu: TabsetComponent;
    @ViewChild('viewTitrateModal') public viewTitrateModal: ModalDirective;
    @ViewChild('changeStatusModal') public changeStatusModal: ModalDirective;
    @ViewChild('disassociateModal') public disassociateModal: ModalDirective;
    @ViewChild('disassociateModal_Site') public disassociateModal_Site: ModalDirective;
    @ViewChild('titrateModal') public titrateModal: ModalDirective;
    @ViewChild('viewContainerDetailsModal') public viewContainerDetailsModal: ModalDirective;
    
    public deleteType: string;
    public disassociateType: string;
    public deleteObject: any;
    public trial: Trial;
    public drugs: Drug[];
    public regimens: Regimen[];
    public trialGroups: TrialGroup[];
    public sites: Site[];
    public containerLimit = 5;
    public activeContainer: Object;
    public form: FormGroup;
    public formPair: FormGroup;
    public subscribe_for_notificationForm: FormGroup;
    public formLabels: FormGroup;
    public formAssignContainers: FormGroup;
    public formAssociateTrialGroupform: FormGroup;
    public addTrialGroupform: FormGroup;
    public formAssociateSiteform: FormGroup;
    public addSiteform: FormGroup;
    public formTrialOptions: FormGroup;
    public patientAlertsForm: FormGroup;
    public dataMatrixCodes = [];
    public showErrors: boolean;
    public showErrors_FormAssociateTrialGroupform: boolean;
    public showErrors_addTrialGroupform: boolean;
    public showErrors_formAssociateSiteform: boolean;
    public showErrors_formTrialOptions: boolean;
    public showErrors_PatientAlertsForm: boolean;
    public error: any;
    public assignDrug: Drug;
    public assignTrialGroup: TrialGroup;
    public assignSite: Site;
    public assignRegimen: Regimen;
    public assignDrugRegimenError: String;
    public assignDrugRegimenSuccess: boolean;
    public drugRegimenPairs = [];
    public patientList = [];
    public customer: Customer;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    //public sites: Site[];
    public successMessage: string;
    public errorMessage: string;
    public durationError: boolean;
    public userId: number;
    public earlyDosingThreshholdError: boolean;
    public days = [];
    public hours = [];
    public minutes = [];
    public defaultDays: number;
    public defaultHours: number;
    public defaultMinutes: number;
    public selectedTrialGroupId: number;
    public SelectedsiteId: number;
    public selectedDrugRegimenPairId: number;
    public isTitrated: boolean;
    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public expiryDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public startDateDrugRegimenPairOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateDrugRegimenPairOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    usedContainersList: any;
    patientContainerList: any;
    patientTitrateList: any;
    patientToChangeStatus: Patient;
    associatedTrialGroupList: any;
    toggoleShowHide: string = "hidden"; 
    associatedSiteList: any;
    trialNotifications: any;
    customerId: number;
    companyId: number;
    patientAlertJsonString: string;
    containerDetailsList: any;
    constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
        private fb: FormBuilder,
        private trialService: TrialService,
        private patientService: PatientService,
        private labelService: LabelService,
        private cognitoUtil: CognitoUtil,
        private changeDetectorRef: ChangeDetectorRef) {

        // Days
        for (let i = 0; i < 31; i++) {
            this.days.push(i);
        }
        // Hours
        for (let i = 0; i < 24; i++) {
            this.hours.push(i);
        }
        // Minutes
        for (let i = 0; i < 60; i++) {
            this.minutes.push(i);
        }

        //this.defaultDays = 0;
        //this.defaultHours = 0;
        //this.defaultMinutes = 0;
    }

    public ngAfterViewInit(): void {

        if (this.trial.trialNotifications[0].isMissedDoseSelected == true) {
           // $('#txtMissedDose').removeAttr('disabled');
            $('#txtMissedDose_Occurances').removeAttr('disabled');
        }
        else {
            //$('#txtMissedDose').attr('disabled', 'disabled');
            $('#txtMissedDose_Occurances').attr('disabled', 'disabled');
        }

        if (this.trial.trialNotifications[0].isOverDoseSelected == true) {

            //$('#txtOverDose').prop('disabled', false);
            //$('#txtOverDose_Occurances').prop('disabled', false);
            //$('#txtOverDose').removeAttr('disabled');
            $('#txtOverDose_Occurances').removeAttr('disabled');
        }
        else {
            //$('#txtOverDose').prop('disabled', true);
            //$('#txtOverDose_Occurances').prop('disabled', true);
           // $('#txtOverDose').attr('disabled', 'disabled');
            $('#txtOverDose_Occurances').attr('disabled', 'disabled');
        }


        if (this.trial.trialNotifications[0].isLateDoseSelected == true) {

            //$('#txtLateDose').prop('disabled', false);

            //$('#txtLateDose_Occurances').prop('disabled', false);
            //$('#txtLateDose').removeAttr('disabled');
            $('#txtLateDose_Occurances').removeAttr('disabled');
        }
        else {
            // $('#txtLateDose').prop('disabled', true);
            //$('#txtLateDose').attr('disabled', 'disabled');
            $('#txtLateDose_Occurances').attr('disabled', 'disabled');
        }

        if (this.trial.trialNotifications[0].isUnderDoseSelected == true) {

            //$('#txtUnderDose').removeAttr('disabled', false);
            //$('#txtUnderDose_Occurances').prop('disabled', false);
            //$('#txtUnderDose').removeAttr('disabled');
            $('#txtUnderDose_Occurances').removeAttr('disabled');
        }
        else {
            //$('#txtUnderDose').attr('disabled', 'disabled');
            //$('#txtUnderDose_Occurances').prop('disabled', true);
            //$('#txtUnderDose').attr('disabled', 'disabled');
            $('#txtUnderDose_Occurances').attr('disabled', 'disabled');
        }

        if (this.trial.trialNotifications[0].isExcessiveManualDoseSelected == true) {

            //$('#txtExcesManualDose').prop('disabled', false);
            //$('#txtExcesManualDose_Occurances').prop('disabled', false);
            //$('#txtExcesManualDose').removeAttr('disabled');
            $('#txtExcesManualDose_Occurances').removeAttr('disabled');
        }
        else {
            //$('#txtUnderDose').prop('disabled', true);
            //$('#txtUnderDose_Occurances').prop('disabled', true);
            //$('#txtExcesManualDose').attr('disabled', 'disabled');
            $('#txtExcesManualDose_Occurances').attr('disabled', 'disabled');
        }




        //$('#datatable_drugRegimenPair').DataTable();
        //$('#datatable_TrialPatientsList').DataTable();
        //$('#datatable_TitrateDetails').DataTable();
        //$('#datatable_associatedTrialGroupList').DataTable();


        //$('#datatable_drugRegimenPair').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        //$('#datatable_TrialPatientsList').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        $('#datatable_TitrateDetails').DataTable({
            dom: 'lBfrtip',
            buttons: [
                'csv', 'print'
            ]
        });

        //$('#datatable_associatedTrialGroupList').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});


        //$('#datatable_UsedContainers').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});


        this.loadDrugRegimenPairList();

        this.loadAssociateTrialGroupList();

        this.loadTrialContainers();

        this.loadSiteList();

        this.loadTrialPatientList();

    }

    public ngOnInit(): void {
        this.currentUserRole = this.route.snapshot.data['role'];
        this.trial = this.route.snapshot.data['trial'];
        this.customer = this.route.snapshot.data['customer'];
        this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
        this.customerId = this.userId;
        //this.userId = this.route.snapshot.params['customer_id'];
        this.companyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        //alert(this.trial.id);
        //alert(this.customer.id);
        //this.drugs = this.route.snapshot.data['drugs'];
        //this.regimens = this.route.snapshot.data['regimens'];
        //this.sites = this.route.snapshot.data['sites'];
        //this.trial.labels = this.route.snapshot.data['labels'];
        //this.trial.containers = this.route.snapshot.data['containers'];
        this.trial.associatedTrialGroups = this.route.snapshot.data['associatedTrialGroups']; 
        this.trial.associatedSites = this.route.snapshot.data['associatedSites'];
        //this.trial.trialNotifications = this.route.snapshot.data['trialNotifications'];  enable this line when API is available
        this.trial.trialNotifications = [
            { id: 1, isMissedDoseSelected: true, missedDoseContent: 'Test missedDoseContent', missedDoseOccurances: '1', isOverDoseSelected: true, overDoseContent: 'Test content', overDoseOccurances: '1', isLateDoseSelected: false, lateDoseContent: 'Test content', lateDoseOccurances: '1', isUnderDoseSelected: false, underDoseContent: 'Test content', underDoseOccurances: '1', isExcessiveManualDoseSelected: false, excessiveManualDoseContent: 'Test content', excessiveManualDoseOccurances: '1', isnotificationTypeEmailSelected: true, isnotificationTypeSMSSelected: false},

        ]
  


            
        //this.trialGroups = this.route.snapshot.data['trialGroups']; enable this line when API is available
        //this.trialGroups = [
        //    { "trialGroupId": 1, "trialGroupName": "TestGroup51", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //    { "trialGroupId": 2, "trialGroupName": "TestGroup52", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //    { "trialGroupId": 3, "trialGroupName": "TestGroup53", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //    { "trialGroupId": 4, "trialGroupName": "TestGroup54", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //    { "trialGroupId": 5, "trialGroupName": "TestGroup55", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //    { "trialGroupId": 6, "trialGroupName": "TestGroup56", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //    { "trialGroupId": 7, "trialGroupName": "TestGroup57", "createdBy": "Jhon", "createdDate": "10/24/2017", "trialCount": 1 },
        //]

        this.trialService.getAllTrialGroups(this.trial.id, this.companyId).subscribe(
            (response) => {
                this.trialGroups = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        //this.sites = [
        //    { id: 1, name: 'Site25', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 1, stateId: 1, cityName: 'sdasd', zipCode:'45345' },
        //    { id: 2, name: 'Site26', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 2, stateId: 2, cityName: 'sdasd', zipCode: '45345' },
        //    { id: 3, name: 'Site27', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 3, stateId: 3, cityName: 'sdasd', zipCode: '45345'},
        //    { id: 4, name: 'Site28', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 4, stateId: 4, cityName: 'sdasd', zipCode: '45345'},
        //    { id: 5, name: 'Site29', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 5, stateId: 5, cityName: 'sdasd', zipCode: '45345'},
        //    { id: 6, name: 'Site30', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 6, stateId: 6, cityName: 'sdasd', zipCode: '45345' },
        //    { id: 7, name: 'Site31', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 7, stateId: 7, cityName: 'sdasd', zipCode: '45345'},
        //    { id: 8, name: 'Site32', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phoneNumber: '12123123', countryId: 8, stateId: 8, cityName: 'sdasd', zipCode: '45345'},
            
        //]

        this.trialService.getAllSites(this.trial.id, this.companyId).subscribe(
            (response) => {
                this.sites = response;

            },
            (err) => {
                this.errorMessage = err;

            });
           
        this.usedContainersList = [
            { id: 1, containerNumber: 'Container1', doseType: 'Tablet', remainingDoses: '8', remainingDoseUnits: '16', startDate: '08/03/2017 |8:40 am', endDate: '10/24/2017 |9:53 am', status: 'Active' },
            { id: 2, containerNumber: 'Container2', doseType: 'Capsule', remainingDoses: '5', remainingDoseUnits: '15', startDate: '08/03/2017 |8:49 am', endDate: '10/24/2017 |8:49 am', status: 'Inactive' },
            { id: 3, containerNumber: 'Container3', doseType: 'Caplet', remainingDoses: '3', remainingDoseUnits: '6', startDate: '08/03/2017 |8:40 am', endDate: '10/24/2017 |10:00 am', status: 'Active' },
            { id: 4, containerNumber: 'Container4', doseType: 'Liquid', remainingDoses: '2', remainingDoseUnits: '4', startDate: '08/03/2017 |8:40 am', endDate: '10/24/2017 |10:00 am', status: 'Active' },

        ]

        this.patientContainerList = [
            { id: 1, containerNumber: 'Container1' },
            { id: 2, containerNumber: 'Container2' },
            { id: 3, containerNumber: 'Container3' },
        ]
        //service call to get patientContainerList
        //uncomment code once API service is available
        //this.trialService
        //    .getPatientContainerList(this.trial.id, this.customer.id, 3)
        //    .subscribe((patientContainerList) => this.trial.containers = patientContainerList);

        //service call to get patientTitrateList
        //uncomment code once API service is available
        //this.patientService
        //    .getPatientTitrateList(this.trial.id, this.customer.id, 3)
        //    .subscribe((patientContainerList) => this.trial.titrateList = patientTitrateList);

        //service call to get associatedTrialGroups
        //uncomment code once API service is available
        //this.trialService
        //    .getAssociatedTrialGroupList(this.trial.id, this.customer.id)
        //    .subscribe((associatedTrialGroups) => this.trial.associatedTrialGroups = associatedTrialGroups);

        //service call to get associatedSites
        //uncomment code once API service is available
        //this.trialService
        //    .getAssociatedSiteList(this.trial.id, this.customer.id)
        //    .subscribe((associatedSites) => this.trial.associatedSites = associatedSites);

        this.patientTitrateList = [
            { id: 1, drug: 'Drug 1', regimen: 'Once a Day', startDate: '10/20/2017', endDate: '11/19/2017', patientConfirmedDate: '10/22/2017' },
            { id: 1, drug: 'Drug 2', regimen: 'Twice a Day', startDate: '09/08/2017', endDate: '10/09/2017', patientConfirmedDate: '09/10/2017' },
            { id: 1, drug: 'Drug 3', regimen: 'Once a Day', startDate: '08/20/2017', endDate: '10/21/2017', patientConfirmedDate: '10/19/2017' },
        ]

        
        //this.trial.associatedTrialGroups = [
        //    { trialGroupId: 1, trialGroupName: 'TestGroup1', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 12 },
        //    { trialGroupId: 2, trialGroupName: 'TestGroup2', createdBy: 'Jane', createdDate: '10/24/2017', trialCount: 5 },
        //    { trialGroupId: 3, trialGroupName: 'TestGroup3', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 4, trialGroupName: 'TestGroup4', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 5, trialGroupName: 'TestGroup5', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 6, trialGroupName: 'TestGroup6', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 12 },
        //    { trialGroupId: 7, trialGroupName: 'TestGroup7', createdBy: 'Jane', createdDate: '10/24/2017', trialCount: 5 },
        //    { trialGroupId: 8, trialGroupName: 'TestGroup8', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 9, trialGroupName: 'TestGroup9', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 10, trialGroupName: 'TestGroup10', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 11, trialGroupName: 'TestGroup11', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 12 },
        //    { trialGroupId: 12, trialGroupName: 'TestGroup12', createdBy: 'Jane', createdDate: '10/24/2017', trialCount: 5 },
        //    { trialGroupId: 13, trialGroupName: 'TestGroup13', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 14, trialGroupName: 'TestGroup14', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 15, trialGroupName: 'TestGroup15', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 16, trialGroupName: 'TestGroup16', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 12 },
        //    { trialGroupId: 17, trialGroupName: 'TestGroup17', createdBy: 'Jane', createdDate: '10/24/2017', trialCount: 5 },
        //    { trialGroupId: 18, trialGroupName: 'TestGroup18', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 19, trialGroupName: 'TestGroup19', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 20, trialGroupName: 'TestGroup20', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 21, trialGroupName: 'TestGroup21', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 12 },
        //    { trialGroupId: 22, trialGroupName: 'TestGroup22', createdBy: 'Jane', createdDate: '10/24/2017', trialCount: 5 },
        //    { trialGroupId: 23, trialGroupName: 'TestGroup23', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 24, trialGroupName: 'TestGroup24', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 25, trialGroupName: 'TestGroup25', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 26, trialGroupName: 'TestGroup26', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 12 },
        //    { trialGroupId: 27, trialGroupName: 'TestGroup27', createdBy: 'Jane', createdDate: '10/24/2017', trialCount: 5 },
        //    { trialGroupId: 28, trialGroupName: 'TestGroup28', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 29, trialGroupName: 'TestGroup29', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },
        //    { trialGroupId: 30, trialGroupName: 'TestGroup30', createdBy: 'Jhon', createdDate: '10/24/2017', trialCount: 10 },

        //]

        this.trial.associatedSites = [
            { id: 1, name: 'Site1', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU',phone:'12123123' },
            { id: 2, name: 'Site2', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 3, name: 'Site3', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 4, name: 'Site4', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 5, name: 'Site5', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 6, name: 'Site6', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 7, name: 'Site7', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 8, name: 'Site8', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 9, name: 'Site9', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 10, name: 'Site10', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 11, name: 'Site11', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 12, name: 'Site12', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 13, name: 'Site13', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 14, name: 'Site14', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 15, name: 'Site15', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 16, name: 'Site16', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 17, name: 'Site17', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 18, name: 'Site18', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 19, name: 'Site19', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 20, name: 'Site20', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 21, name: 'Site21', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 22, name: 'Site22', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 23, name: 'Site23', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },
            { id: 24, name: 'Site24', addressLine1: 'test address1', addressLine2: 'test address2', countryName: 'AU', phone: '12123123' },

        ]

        //12th Feb 2018
        //To get the list of drugs
        this.trialService.getAllDrugs(this.companyId).subscribe(
            (response) => {
                this.drugs = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        //To get the list of regimens
        this.trialService.getAllRegimens(this.companyId).subscribe(
            (response) => {
                this.regimens = response;

            },
            (err) => {
                this.errorMessage = err;

            });


        //20th Dec 2017
        this.trial.patients = this.route.snapshot.data['patients'];

        //this.setDrugRegimenPairs();

        this.form = this.fb.group({
            //site: [this.trial.site.id, Validators.required],
            name: [this.trial.name, Validators.required],
            startDate: [this.dateForView(this.trial.startDate), Validators.required],
            endDate: [this.dateForView(this.trial.end_date), Validators.required],
            //adherenceTarget: [this.trial.adherenceTarget,
            //Validators.pattern(/^(\d{0,2}(\.\d{1,2})?|100(\.00?)?)$/)],
            //enrolmentTarget: [this.trial.enrolmentTarget],
            //earlyDosingThresholdTime: [this.trial.earlyDosingThresholdTime, Validators.required],
            status: [this.trial.status, Validators.required]
        });
        //Added by ramesh on 20th Oct 2017
        let expiryDateTime1 = new Date();
        let day = expiryDateTime1.getDate();
        let month = expiryDateTime1.getMonth() + 1;
        //let year = expiryDateTime1.getFullYear();
        //let today = year + '-' + month + '-' + day;
        //End
        this.formPair = this.fb.group({
            drug: ['', Validators.required],
            regimen: ['', Validators.required],
            //expiryDate: [this.dateForView(today), Validators.required],
            startDateDrugRegimenPair: ['', Validators.required],
            endDateDrugRegimenPair: ['', Validators.required],
            chkMissedDose: [this.trial.trialNotifications[0].isMissedDoseSelected],
            txtMissedDose: [this.trial.trialNotifications[0].missedDoseContent],
            txtMissedDose_Occurances: [this.trial.trialNotifications[0].missedDoseOccurances],
            chkOverDose: [this.trial.trialNotifications[0].isOverDoseSelected],
            txtOverDose: [this.trial.trialNotifications[0].overDoseContent],
            txtOverDose_Occurances: [this.trial.trialNotifications[0].overDoseOccurances],
            chkLateDose: [this.trial.trialNotifications[0].isLateDoseSelected],
            txtLateDose: [this.trial.trialNotifications[0].lateDoseContent],
            txtLateDose_Occurances: [this.trial.trialNotifications[0].lateDoseOccurances],
            chkUnderDose: [this.trial.trialNotifications[0].isUnderDoseSelected],
            txtUnderDose: [this.trial.trialNotifications[0].underDoseContent],
            txtUnderDose_Occurances: [this.trial.trialNotifications[0].underDoseOccurances],
            chkExcesManualDose: [this.trial.trialNotifications[0].isExcessiveManualDoseSelected],
            txtExcesManualDose: [this.trial.trialNotifications[0].excessiveManualDoseContent],
            txtExcesManualDose_Occurances: [this.trial.trialNotifications[0].excessiveManualDoseOccurances],
            //NotificationTypeEmail: [this.trialNotifications[0].notificationType],
            chkNotificationTypeEmail: [this.trial.trialNotifications[0].isnotificationTypeEmailSelected],
            chkNotificationTypeSMS: [this.trial.trialNotifications[0].isnotificationTypeSMSSelected],
            
        });

       
        

        //this.subscribe_for_notificationForm = this.fb.group({
        //    chkMissedDose: [this.trial.trialNotifications[0].isMissedDoseSelected],
        //    txtMissedDose: [this.trial.trialNotifications[0].missedDoseContent],
        //    txtMissedDose_Occurances: [this.trial.trialNotifications[0].missedDoseOccurances],
        //    chkOverDose: [this.trial.trialNotifications[0].isOverDoseSelected],
        //    txtOverDose: [this.trial.trialNotifications[0].overDoseContent],
        //    txtOverDose_Occurances: [this.trial.trialNotifications[0].overDoseOccurances],
        //    chkLateDose: [this.trial.trialNotifications[0].isLateDoseSelected],
        //    txtLateDose: [this.trial.trialNotifications[0].lateDoseContent],
        //    txtLateDose_Occurances: [this.trial.trialNotifications[0].lateDoseOccurances],
        //    chkUnderDose: [this.trial.trialNotifications[0].isLateDoseSelected],
        //    txtUnderDose: [this.trial.trialNotifications[0].underDoseContent],
        //    txtUnderDose_Occurances: [this.trial.trialNotifications[0].underDoseOccurances],
        //    chkExcesManualDose: [this.trial.trialNotifications[0].isExcessiveManualDoseSelected],
        //    txtExcesManualDose: [this.trial.trialNotifications[0].excessiveManualDoseContent],
        //    txtExcesManualDose_Occurances: [this.trial.trialNotifications[0].excessiveManualDoseOccurances],
        //    chkEmailNotificationType: [''],
        //    chkSMSNotificationType:['']
        //});

        this.formLabels = this.fb.group({
            additionalLabels: ['', Validators.pattern('[0-9]+')]
        });

        this.formAssignContainers = this.fb.group({
           // pair: [this.drugRegimenPairs[0].id, Validators.required],
            containerNumbers: [''],
            containerNumbersFile: ['']
        });

        this.formAssociateTrialGroupform = this.fb.group({
            trialGroupName: ['', Validators.required]

        });

        this.addTrialGroupform = this.fb.group({
            trialGroupName: ['', Validators.required]

        });

        this.formAssociateSiteform = this.fb.group({
            siteName: ['', Validators.required]

        });

        this.addSiteform = this.fb.group({
            siteName: ['', Validators.required]

        });
        
        
        //Added by ramesh on 29th Dec 2017
        this.formTrialOptions = this.fb.group({
            trialAdherenceTarget: ['', [Validators.required, Validators.pattern('[0-9]+')]],
            minPatientAdherenceTarget: ['', [Validators.required, Validators.pattern('[0-9]+')]],
            patientEnrollmentTarget: ['', [Validators.required, Validators.pattern('[0-9]+')]],
            turnOffManualDosing: ['', Validators.required],

        });

        this.patientAlertsForm = this.fb.group({
            preDoseAlert: ['', Validators.required],
            onTimeDoseAlert: ['', Validators.required],
            thresholdDueAlert: ['', Validators.required],
            thresholdWindow: ['', Validators.required],
            preDoseAlertDays: [0],
            preDoseAlertHours: [0],
            preDoseAlertMinutes: [15],
            thresholdDueAlertDays: [0],
            thresholdDueAlertHours: [0],
            thresholdDueAlertMinutes: [15],
            thresholdWindowAlertDays: [0],
            thresholdWindowAlertHours: [0],
            thresholdWindowAlertMinutes: [15],
        });
        
        
        setTimeout(() => {
            if (this.route.snapshot.queryParams['tab'] === 'patients') {
                let index = (this.currentUserRole === this.UserRole.MedConAdmin) ? 0 : 2;
                this.trialMenu.tabs[index].active = true;
            }
        });

        // Disable start date if trial has scans logged against it
        //if (this.trial.labels.used > 0) {
        //    let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        //    copy.componentDisabled = true;
        //    this.startDateOptions = copy;
        //}

        // Make sure start date can't come after end date
        this.setStartDateDisableSince(this.form.value.endDate.date);

        // Make sure end date can't be set earlier than start date
        this.setEndDateDisableUntil(this.form.value.startDate.date);
    }

    public moreContainers(): void {
        this.containerLimit = 6;
    }

    public cancelForm(): void {
        this.form.markAsPristine();
        this.router.navigate([this.customer.id, 'trials']);
    }

    public populateContainerPopover(patient): void {
        //this.activeContainer = container;
        this.patientContainerList = [
            { id: 1, containerNumber: 'Container1' },
            { id: 2, containerNumber: 'Container2' },
            { id: 3, containerNumber: 'Container5' },
        ]
    }

    public onSubmit() {
        if (this.form.invalid) {
            this.showErrors = true;
        } else {
            let request = new TrialRequest(
                this.form.value.name,
                this.convertDate(this.form.value.startDate.date),
                this.convertDate(this.form.value.endDate.date),
                Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'))
            );

            this.trialService
                .updateTrial(this.trial.id, request)
                .subscribe(
                (response) => {
                    this.form.markAsPristine();
                    this.successMessage = 'Trial has been successfully updated';
                },
                (err) => {
                    this.errorMessage = err;
                }
                );
        }
    }

    

    public submitAddLabels() {
        if (this.formLabels.invalid) {
            this.showErrors = true;
        } else {
            let request = new TrialLabelsRequest(
                this.formLabels.value.additionalLabels
            );

            this.trialService.addLabels(this.trial.id, this.route.snapshot.params['customer_id'], request)
                .subscribe(
                (response) => {
                    this.successMessage = 'Additional labels have been successfully added';
                    this.labelService
                        .getOverview(this.trial.id, this.customer.id)
                        .subscribe((labels) => this.trial.labels = labels);
                },
                (err) => {
                    this.errorMessage = err;
                }
                );
        }
    }



    public assignDrugRegimen(): void {

        let notificationType = (this.formPair.value.chkNotificationTypeEmail) ? this.formPair.value.chkNotificationTypeEmail : this.formPair.value.chkNotificationTypeSMS;

        if (this.formPair.invalid) {
            this.assignDrugRegimenError = 'Please choose both a drug and a regimen';
        } else {

           

            if (this.isTitrated) {
                //alert('titrate action');
               // alert(this.selectedDrugRegimenPairId);
                let request = new PairDrugRegimenRequest(
                    this.assignDrug.id,
                    this.assignRegimen.id,
                    this.convertDate(this.formPair.value.startDateDrugRegimenPair.date),
                    this.convertDate(this.formPair.value.endDateDrugRegimenPair.date),
                    Number(this.userId),
                    Number(this.companyId),
                    Number(this.selectedDrugRegimenPairId)
                );
                this.trialService.titrateDrugRegimenPair(this.trial.id, request).subscribe(
                    (response) => {
                        //this.assignDrugRegimenSuccess = true;
                        //this.formPair.controls['drug'].setValue('');
                        //this.formPair.controls['regimen'].setValue('');
                        //this.assignDrugRegimenError = null;
                        //this.assignDrug = null;
                        //this.assignRegimen = null;

                    },
                    (err) => {
                        this.errorMessage = err;
                    });
            }
            else {
                let request = new PairDrugRegimenRequest(
                    this.assignDrug.id,
                    this.assignRegimen.id,
                    this.convertDate(this.formPair.value.startDateDrugRegimenPair.date),
                    this.convertDate(this.formPair.value.endDateDrugRegimenPair.date),
                    Number(this.userId),
                    Number(this.companyId)
                );
               
                //assign new regimen
                this.trialService.pairDrugRegimen(this.trial.id, request).subscribe(
                    (response) => {
                        this.assignDrugRegimenSuccess = true;
                        this.formPair.controls['drug'].setValue('');
                        this.formPair.controls['regimen'].setValue('');
                        this.assignDrugRegimenError = null;
                        this.assignDrug = null;
                        this.assignRegimen = null;

                        // Update assigned drug/regimens list
                        this.trialService.getTrial(this.trial.id).subscribe((trial) => {
                            this.drugRegimenPairs = [];
                            this.trial.drPairs = trial.drPairs;
                            this.setDrugRegimenPairs();
                        });
                    },
                    (err) => {
                        this.errorMessage = err;
                    });
                // code for Notification subscription
                let request1 = new SubscriptionRequest(

                    this.formPair.value.chkMissedDose,
                    this.formPair.value.txtMissedDose_Occurances,
                    this.formPair.value.chkOverDose,
                    this.formPair.value.txtOverDose_Occurances,
                    this.formPair.value.chkLateDose,
                    this.formPair.value.txtLateDose_Occurances,
                    this.formPair.value.chkUnderDose,
                    this.formPair.value.txtUnderDose_Occurances,
                    this.formPair.value.chkExcesManualDose,
                    this.formPair.value.txtExcesManualDose_Occurances,
                    notificationType,

                    this.userId
                );
                this.trialService.createNotifications(this.trial.id, request1).subscribe(
                    (response) => {
                        this.formPair.markAsPristine();

                        this.successMessage = "successfully Added ";
                        //this.notification.reset();

                    },
                    (err) => {
                        this.errorMessage = err;
                    });

            }

        }

    }

    public submitAssignContainers() {
        if (this.formAssignContainers.invalid) {
            this.showErrors = true;
        } else {
            let containerNumbers = this.formAssignContainers.value.containerNumbers
                .replace(/[,;]+/g, '').split('\n').filter((e) => /\S/.test(e));
            if (containerNumbers.length <= 0) {
                this.errorMessage = 'Please enter at least 1 container number';
                return;
            }
            let request = new TrialContainersRequest(
                containerNumbers,
                this.formAssignContainers.value.pair,
                !!(this.error && this.error.error === 'duplicates'),
            );

            this.alertClosed();

            this.trialService.createContainers(this.trial.id, request, this.customer.id)
                .subscribe(
                (response) => {
                    this.successMessage = 'Containers successfully uploaded';
                    // Update containers list
                    this.trialService.getContainers(this.trial.id, this.customer.id)
                        .subscribe((containers) => {
                            let diff = _.difference(_.map(containers.unused, 'id'), _.map(this.trial.containers.unused, 'id'));
                            let newContainers = _.filter(containers.unused, (obj) => {
                                return diff.indexOf(obj['id']) >= 0;
                            });
                            this.trial.containers = containers;
                            // Reset containers input field
                            this.formAssignContainers.controls['containerNumbers'].setValue('');
                            this.formAssignContainers.controls['containerNumbersFile'].setValue('');
                            // Populate data matrix modal
                            this.dataMatrixCodes = [];
                            for (let code of newContainers) {
                                code['code'] = response.prefix + '/' + code['id'];
                                this.dataMatrixCodes.push(code);
                            }
                            this.dataMatrixModal.show();
                        });
                },
                (err) => {
                    // Duplicates error
                    if (err.error === 'duplicates') {
                        this.errorMessage = err.message;
                        this.error = err;
                    } else {
                        // Generic error
                        this.errorMessage = err;
                    }
                }
                );
        }
    }
    //Code added by ramesh on 21st Oct 2017
    public submitTrialOptions() {
        if (this.formTrialOptions.invalid) {
            this.showErrors_formTrialOptions = true;
        } else {
            let request = new TrialOptionsRequest(
                Number(this.formTrialOptions.value.patientEnrollmentTarget),
                Number(this.formTrialOptions.value.trialAdherenceTarget),
                Number(this.formTrialOptions.value.minPatientAdherenceTarget),
                Number(this.formTrialOptions.value.turnOffManualDosing),
                Number(this.userId)
            );
            this.trialService
                .updateTrialOptions(this.trial.id, request)
                .subscribe(
                (response) => {
                    this.formTrialOptions.markAsPristine();
                    this.successMessage = 'Trial options  has been successfully updated';
                },
                (err) => {
                    this.errorMessage = err;
                }
                );
        }
    }

    public drugSelected(drug): void {
        this.assignDrug = drug.item;
    }

    public trialGroupSelected(trialGroup): void {
        //this.assignTrialGroup = trialGroup.item;
        this.selectedTrialGroupId = trialGroup.item.id;

    }

    public siteSelected(sites): void {
        //this.assignSite = site.item;
        this.SelectedsiteId = sites.item.id;

    }

    public regimenSelected(regimen): void {
        this.assignRegimen = regimen.item;
    }

    public deleteItem(deleteType, deleteObject, index?): void {
        deleteObject.index = index;
        this.deleteType = deleteType;
        this.deleteObject = deleteObject;
        this.deleteModal.show();
    }

    public hideDeleteModal(): void {
        this.deleteType = null;
        this.deleteObject = null;
        this.deleteModal.hide();
    }

    public hideTitrateModal(): void {
        this.deleteType = null;
        this.deleteObject = null;
        this.titrateModal.hide();
    }

    public hideDataMatrixModal(): void {
        this.dataMatrixModal.hide();
    }

 

    public titrateConfirmed(): void {

        this.successMessage = 'Please assign the drug regimen pair once again';
        this.hideTitrateModal();

        //this.trialService.titrateDrugRegimenPair(Number(this.selectedDrugRegimenPairId)).subscribe(
        //    (response) => {
        //        //this.drugRegimenPairs.splice(deleteObject.index, 1);
        //        this.successMessage = 'Drug/Regimen pair successfully removed';
        //        this.hideTitrateModal();
        //        this.loadDrugRegimenPairList();
        //    },
        //    (err) => {
        //        this.errorMessage = err;
        //    }
        //);


    }

    public deleteConfirmedForDrugRegimenPair(): void {
        let jsonString = "{\n\"userId\" :" + this.userId + "\n}";
        this.trialService.deleteDrugRegimenPair(Number(this.selectedDrugRegimenPairId), jsonString).subscribe(
            (response) => {
                //this.drugRegimenPairs.splice(deleteObject.index, 1);
                this.successMessage = 'Drug/Regimen pair successfully removed';
                this.hideDeleteModal();
                $("#datatable_drugRegimenPair").dataTable().fnDestroy();
                this.loadDrugRegimenPairList();
            },
            (err) => {
                this.errorMessage = err;
            }
        );

    }

    public deleteConfirmed(deleteObject): void {
        if (this.deleteType === 'drug/regimen pair') {

            //if (!deleteObject.inUse) {
            this.trialService.deleteDrugRegimenPair(Number(this.selectedDrugRegimenPairId)).subscribe(
                    (response) => {
                        //this.drugRegimenPairs.splice(deleteObject.index, 1);
                        this.successMessage = 'Drug/Regimen pair successfully removed';
                        this.hideDeleteModal();
                    },
                    (err) => {
                        this.errorMessage = err;
                    }
                );
            //} else {
            //    this.errorMessage = 'Cannot delete drug/regimen pair that has doses logged against it.';
            //}
        }
        else if (this.deleteType === 'titrate') {

            //if (!deleteObject.inUse) {
            this.trialService.titrateDrugRegimenPair(Number(this.selectedDrugRegimenPairId)).subscribe(
                (response) => {
                    //this.drugRegimenPairs.splice(deleteObject.index, 1);
                    this.successMessage = 'Drug/Regimen pair successfully removed';
                    this.hideTitrateModal();
                },
                (err) => {
                    this.errorMessage = err;
                }
            );
            //} else {
            //    this.errorMessage = 'Cannot delete drug/regimen pair that has doses logged against it.';
            //}
        }
        else if (this.deleteType === 'patient') {
            this.patientService.deletePatient(deleteObject.id, this.customer.id).subscribe(
                (response) => {
                    this.trialService.getPatients(this.trial.id, this.customer.id).subscribe((patients) => {
                        this.trial.patients = patients;
                        this.successMessage = 'Patient ' + deleteObject.patientNumber + ' has been successfully deleted';
                    });
                },
                (err) => {
                    this.errorMessage = err;
                }
            );
        } else if (this.deleteType === 'container') {
            this.trialService.deleteContainer(deleteObject.id, this.customer.id).subscribe(
                (response) => {
                    this.trialService.getContainers(this.trial.id, this.customer.id)
                        .subscribe(
                        (containers) => {
                            this.trial.containers = containers;
                            this.successMessage = 'Container successfully deleted';
                        }
                        );
                },
                (err) => {
                    this.errorMessage = err;
                }
            );
        }
        this.hideDeleteModal();
    }

    public getAge(date) {
        return this.patientService.getAge(date);
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
        this.assignDrugRegimenSuccess = false;
        this.assignDrugRegimenError = null;
        this.error = null;
    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            } else if (field === 'end') {
                this.setStartDateDisableSince(date.date);
            }
        }
    }

    public fileChange(input) {
        this.processContainersFile(input.target.files);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.form.dirty;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    private setDrugRegimenPairs(): void {
        this.trial.drPairs.forEach((pair) => {
            this.drugRegimenPairs.push({
                id: pair.id,
                drug: pair.drug,
                regimen: { id: pair.regimen.id, name: pair.regimen.name },
                inUse: pair.inUse
            });
        });
    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {
            return (value < 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    private processContainersFile(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                this.formAssignContainers.controls['containerNumbers'].setValue(result);
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

    private readFile(file, reader, callback) {
        let invalidFileMessage = 'Container numbers file must be a CSV';

        if (
            file.type &&
            file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel' && file.type !== 'application/csv'
        ) {
            return this.errorMessage = invalidFileMessage;
        }

        if (file.name.split('.').pop().toLowerCase() !== 'csv') {
            return this.errorMessage = invalidFileMessage;
        }

        reader.onload = () => {
            callback(reader.result.replace(/\r\n|\n/, '\n').replace(/[,;]+/g, ''));
        };

        reader.readAsText(file);
    }

    public viewTitrateDetails(patient): void {
        this.trialService
            .getPatientTitrateList(this.trial.id, this.customer.id, patient.id)
            .subscribe((patientContainerList) => this.trial.titrateList = this.patientTitrateList);
        this.viewTitrateModal.show();
    }

    public hideTitrateDetailsModal(): void {
        this.viewTitrateModal.hide();
    }

    public changePatientStatus(patient): void {
        this.patientToChangeStatus = patient;
        this.changeStatusModal.show();
    }

    public hideChangePatientStatusModal(): void {
        this.changeStatusModal.hide();
    }


    //Code added by ramesh on 19th Dec 2017
    public confirmChangeStatusConfirmation(): void {
        let patient = this.patientToChangeStatus;
        this.trialService
            .updatePatientStatus(this.trial.id, this.customer.id, patient.id)
            .subscribe(
            (response) => {
                this.trialService.getPatients(this.trial.id, this.customer.id)
                    .subscribe((patients) => {
                        this.trial.patients = patients;
                        this.successMessage = patient.id + ' has been changed status successfully';
                        this.hideChangePatientStatusModal();
                    }
                    );
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    

    //Code added by ramesh on 4th Jan 2017
    public disassociateSite(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.SelectedsiteId = id;
        this.disassociateModal_Site.show();

    }

    public confirmDisassociateTrialGroup(trialGroup)
    {

        let trialId = this.trial.id;
        let userId=Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'))
        let jsonString = "{\r\n     \"trailGroupTrailId\":" + this.selectedTrialGroupId + ",\r\n     \"userId\":" + userId +"\r\n}"
        //Uncomment when API is available
            this.trialService
                .disassociateTrialGroup(trialId, jsonString)
            .subscribe(
            (response) => {
                        //this.trialService.getAssociatedTrialGroupList(this.trial.id)
                        //.subscribe((associatedTrialGroups) => {
                        //    this.trial.associatedTrialGroups = associatedTrialGroups;
                        //    this.successMessage = 'TrialGroup has been disassociated to trial successfully';
                        //    this.hideChangePatientStatusModal();
                        //}
                        //);

                $("#datatable_associatedTrialGroupList").dataTable().fnDestroy();
                this.loadAssociateTrialGroupList();
                       
                
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
        );

        this.successMessage = 'TrialGroup has been disassociated to trial successfully';
        this.hideDisassociateModal();
    }


    public confirmDisassociate_Site(site) {

        let request = new DisassociateSiteRequest(

            Number(this.SelectedsiteId),
            Number(this.userId)
        );

        this.trialService
            .disassociateSite(this.SelectedsiteId, request)
            .subscribe(
            (response) => {
                //this.trialService.getAssociatedSiteList(this.trial.id)
                //        .subscribe((associatedSites) => {
                //            this.trial.associatedSites = associatedSites;
                //            this.successMessage = 'Site has been disassociated from Associated List successfully';
                //            this.hideChangePatientStatusModal();
                //        }
                //        );

                $("#datatable_associatedSiteList").dataTable().fnDestroy();
                this.loadSiteList();


            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );

        this.successMessage = 'Site has been disassociated  successfully';
        this.hideDisassociateModal_Site();
    }


    
    public hideDisassociateModal(): void {
        //this.deleteType = null;
        //this.deleteObject = null;
        this.disassociateModal.hide();
    }

    public hideDisassociateModal_Site(): void {
        //this.deleteType = null;
        //this.deleteObject = null;
        this.disassociateModal_Site.hide();
    }

    public enableAddTrialGroupSection(): void {
        
        this.toggoleShowHide="visible"; 
    }

    public enableAddSiteSection(): void {

        this.toggoleShowHide = "visible";
    }
    

    //28th Dec 2017
    public associateTrialGroup()
    {
        if (this.formAssociateTrialGroupform.invalid) {
            this.showErrors_FormAssociateTrialGroupform = true;
        } else {

            let request = new TrailGroupAssociateRequest(
                Number(this.selectedTrialGroupId),
                Number(this.userId)
            );
            //un comment these lines when API is available
            this.trialService
                .associateTrialGroup(this.trial.id,  request)
                .subscribe(
                (response) => {
                    this.trialService.getAssociatedTrialGroupList(this.trial.id)
                        .subscribe((associatedTrialGroups) => {
                            this.trial.associatedTrialGroups = associatedTrialGroups;
                            this.successMessage = 'TrialGroup has been successfully associated to trial';
                            this.hideChangePatientStatusModal();
                        }
                        );
                    this.successMessage = 'TrialGroup has been successfully associated to trial';
                    
                },
                (err) => {
                    this.errorMessage = err;
                }
                );
            //this.successMessage = 'Trial Group  has been successfully associated to trial';
        }

    }

    public addTrialGroupAndAssociateTrialGroup() {

        if (this.addTrialGroupform.invalid) {
            this.showErrors_addTrialGroupform = true;
        } else {
            let request = new TrialgroupAddAssociateRequest(
                this.addTrialGroupform.value.trialGroupName,
                Number(this.companyId),
                Number(this.userId)
                
               
            );

            //Uncomment this code when API is avialable
            this.trialService
                .addTrialGroupAndAssociateTrialGroup(this.trial.id, request)
                .subscribe(
                (response) => {
                    //this.form.markAsPristine();
                    this.trialService.getAssociatedTrialGroupList(this.trial.id, this.customer.id)
                        .subscribe((associatedTrialGroups) => {
                            this.trial.associatedTrialGroups = associatedTrialGroups;
                            this.successMessage = 'Trial Group has been successfully added and associated to a trial';
                            this.hideChangePatientStatusModal();
                        }
                        ); 
                },
                (err) => {
                    this.errorMessage = err;
                }
                );

            //this.successMessage = 'Trial Group has been successfully added and associated to a trial';
        }

    }


    public onSubmit_ForAssociateSite()
    {

        if (this.formAssociateSiteform.invalid) {
            this.showErrors_formAssociateSiteform = true;
        } else {
            let request = new TrialgroupAssociateSiteRequest(

                //this.addTrialGroupform.value.trialGroupName,

                Number(this.SelectedsiteId),
                Number(this.userId)


            );

            //Uncomment this code when API is avialable
            this.trialService
                .associateSite(this.trial.id, request)
                .subscribe(
                (response) => {
                    this.form.markAsPristine();
                    this.successMessage = 'Site has been successfully associated to a trial';
                },
                (err) => {
                    this.errorMessage = err;
                }
                );

            //this.successMessage = 'Site has been successfully associated to a trial';
        }

    }

    public onSubmit_PatientAlertsForm() {
        let preDoseAlertDurationDays = ((Number(this.patientAlertsForm.value.preDoseAlertDays * 24)) * 60);
        let preDoseAlertdurationHours = (Number(this.patientAlertsForm.value.preDoseAlertHours * 60));
        let preDoseAlertdurationMinutes = Number(this.patientAlertsForm.value.preDoseAlertMinutes);
        let preDoseAlertTime = preDoseAlertDurationDays + preDoseAlertdurationHours + preDoseAlertdurationMinutes;
        let thresholdDueAlertDurationDays = ((Number(this.patientAlertsForm.value.thresholdDueAlertDays * 24)) * 60);
        let thresholdDueAlertdurationHours = (Number(this.patientAlertsForm.value.thresholdDueAlertHours * 60));
        let thresholdDueAlertdurationMinutes = Number(this.patientAlertsForm.value.thresholdDueAlertMinutes);
        let thresholdDueAlertTime = thresholdDueAlertDurationDays + thresholdDueAlertdurationHours + thresholdDueAlertdurationMinutes;
        let thresholdWindowAlertDurationDays = ((Number(this.patientAlertsForm.value.thresholdWindowAlertDays * 24)) * 60);
        let thresholdWindowAlertdurationHours = (Number(this.patientAlertsForm.value.thresholdWindowAlertHours * 60));
        let thresholdWindowAlertdurationMinutes = (Number(this.patientAlertsForm.value.thresholdWindowAlertMinutes));
        let thresholdWindowAlertTime = thresholdWindowAlertDurationDays + thresholdWindowAlertdurationHours + thresholdWindowAlertdurationMinutes;



        if (this.patientAlertsForm.invalid) {
            this.showErrors_PatientAlertsForm = true;
        } else {
            let request = new TrialPatientAlertsRequest(
                this.patientAlertsForm.value.preDoseAlert,
                preDoseAlertTime,
                this.patientAlertsForm.value.onTimeDoseAlert,
                this.patientAlertsForm.value.thresholdDueAlert,
                thresholdDueAlertTime,
                this.patientAlertsForm.value.thresholdWindow,
                thresholdWindowAlertTime,
                Number(this.userId)

            );
            this.preparePatientAlertsJsonString(
                this.patientAlertsForm.value.preDoseAlert,
                preDoseAlertTime,
                this.patientAlertsForm.value.onTimeDoseAlert,
                this.patientAlertsForm.value.thresholdDueAlert,
                thresholdDueAlertTime,
                this.patientAlertsForm.value.thresholdWindow,
                thresholdWindowAlertTime,
                Number(this.userId));
            //Uncomment this when API is available
            this.trialService
                .saveTrialPatientAlerts(this.trial.id, this.patientAlertJsonString)
                .subscribe(
                (response) => {
                    this.form.markAsPristine();
                    this.successMessage = 'Trial patient alerts have been successfully Saved';
                },
                (err) => {
                    this.errorMessage = err;
                }
                );

            //this.successMessage = 'Trial patient alerts have been successfully Saa';
        }
    }

    public enablePanel(chkType,textBox1Id, textBox2Id)
    {
        
        let flag = (<HTMLInputElement>document.getElementById(chkType)).checked;
        let checkBoxId = chkType
        if (flag==true) {
            
            //$('#' + textBox1Id).prop('disabled', false);
           
            $('#' + textBox1Id).removeAttr('disabled');
            $('#' + textBox2Id).prop('disabled', false);
            //(<HTMLInputElement>document.getElementById(textBox1Id)).disabled = false;
            //(<HTMLInputElement>document.getElementById(textBox2Id)).disabled = false;
        }
        else {
            //$('#' + textBox1Id).prop('disabled', true);
            $('#' + textBox1Id).attr('disabled', 'disabled');
            $('#' + textBox2Id).prop('disabled', true);
            //(<HTMLInputElement>document.getElementById(textBox1Id)).disabled = true;
            //(<HTMLInputElement>document.getElementById(textBox2Id)).disabled = false;
            

        }
        
    }

    public preparePatientAlertsJsonString(preDoseAlertText, preDoseAlertTime, onTimeDoseAlert, thresholdDueAlert, thresholdDueAlertTime, thresholdWindow, thresholdWindowAlertTime, userId) {

        this.patientAlertJsonString = "{\r\n  \"preDoseAlertText\":\"" + preDoseAlertText + "\",\r\n    \"preDoseAlertTime\":" + preDoseAlertTime + ",\r\n    \"ontimeDoseAlertText\":\"" + onTimeDoseAlert + "\",\r\n    \"thresholdDueAlertText\":\"" + thresholdDueAlert + "\",\r\n    \"thresholdDueAlertTime\":" + thresholdDueAlertTime + ",\r\n    \"thresholdWindowAlertText\":\"" + thresholdWindow + "\",\r\n    \"thresholdWindowAlertTime\":\"" + thresholdWindowAlertTime + "\",\r\n    \"userId\":" + userId + "\r\n}";
    }


    public loadDrugRegimenPairList(): void {
        var self = this;
        let trialId = this.trial.id;
        //alert(trialId);
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_drugRegimenPair').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/pair/' + trialId ,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        'csv', 'print'

                    ],
                    "columns": [
                        { "data": "drugName" },
                        { "data": "RegimenName" },
                        { "data": "medicationType"},
                        { "data": "doseAmount" },
                        { "data": "measureDose" },
                        { "data": "doseStrength" },
                        { "data": "startDate" },
                        { "data": "endDate" },
                        { "data": "status" },
                        { "data": "drugregimenId"}
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                return "<div class=\"btn-action\"><button  id=\"" + full.drugregimenId + "_delete" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button><button   id=\"" + full.drugregimenId+ "_titrate" + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Titrate</button>  </div>";
                            }
                        }

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [9],
                            "visible": false
                        },
                        //{
                        //    "targets": [8],
                        //    "visible": false
                        //},
                        {
                            "targets": [8],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                    ]
                });
            }
        });


        $('#datatable_drugRegimenPair tbody').on('click', 'td button', function () {
            //alert('hello');
            //alert($(this).attr('id'));
            //alert($('button').text());
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            
            if (buttonName == "delete")
                self.deleteDrugRegimenPair(buttonId);
            if (buttonName == "titrate") {

                self.titrateDrugRegimenPair(buttonId);

            }


        });


    }

    public deleteDrugRegimenPair(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.deleteType === 'drug/regimen pair';
        this.selectedDrugRegimenPairId = id;
        this.deleteModal.show();
    }

    public titrateDrugRegimenPair(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.deleteType == 'titrate';
        //this.deleteModal.show();
        this.titrateModal.show();
        this.selectedDrugRegimenPairId = id;
        this.isTitrated=true;
    }


    public loadTrialPatientList(): void {


        var self = this;
        let trialId = this.trial.id;
        //alert(trialId);
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert("Testing Load patient");
                $('#datatable_TrialPatientsList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "rowId": "Id",
                    'ajax': {

                        'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        'csv', 'print'

                    ],
                    "columns": [
                        { "data": "PatientID" },
                        { "data": "age" },
                        { "data": "Sex" },
                        { "data": "Race" },
                        { "data": "FirstScan" },
                        { "data": "LastScan" },
                        { "data": "Containers" },
                        { "data": "titrate" },
                        { "data": "status" },
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                return "<div class=\"btn-action\"><a href=\"#/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><button  id=\"" + full.Id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){  localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div></div>";
                            }
                        }


                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [8],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                    ]
                });
            }
        });


        $('#datatable_TrialPatientsList tbody').on("click", 'tr td:eq(7)', function () {
            //var data = $('#datatable').row(this).data();
            //alert(data.firstName);
            var attId = $(this).attr('id');
            //alert(attId);
            self.loadTrialTitrateDetails($(this).attr('id'));
        });

        $('#datatable_TrialPatientsList tbody').on("click", 'tr td:eq(6)', function () {
            //var data = $('#datatable').row(this).data();
            //alert(data.firstName);
            var attId = $(this).attr('id');
            //alert(attId);
            self.loadTrailPatientContainer($(this).attr('id'));
        });



    }


    public loadTrailPatientContainer(id): void {
        let trialId = this.trial.id;
        let patientId = 'Pat456688';

        this.trialService.getTrailPatientContainerDetails(trialId, patientId).subscribe(
            (response) => {
                //this.patientTitrateList = response;
                this.containerDetailsList = response;
                this.viewContainerDetailsModal.show();
                // this.viewTitrateModal.show();
            },
            (err) => {
                this.errorMessage = err;

            });

    }


    public loadTrialTitrateDetails(id): void {


        //alert(iD);
        //alert("LoadLabelData Entered");
        let trialId = this.trial.id;
        let patientId = 'Pat456688';

        this.trialService.getTitrateDetails(trialId, patientId).subscribe(
            (response) => {
                this.patientTitrateList = response;
                this.viewTitrateModal.show();
            },
            (err) => {
                this.errorMessage = err;

            });


    }

    public loadTrialContainers(): void {

        //NoAPI
        let trialId = this.trial.id;
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_UsedContainers').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/containers/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    //dom: 'lBfrtip',
                    //buttons: [
                    //    'csv', 'print'

                    //],
                    "columns": [
                        { "data": "containerId" },
                        { "data": "doseType" },
                        { "data": "remainingDoses" },
                        { "data": "remainingDoseUnits" },
                        { "data": "FirstScan" },
                        { "data": "LastScan" },
                        { "data": "status" }
                      
                    ]
                    ,
                    "columnDefs": [

                       
                        {
                            "targets": [6],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }


                    ]
                });
            }
        });

       

    }

    public loadAssociateTrialGroupList(): void{

        //API 
        let trialId = this.trial.id;
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup/{id}

        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_associatedTrialGroupList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        'csv', 'print'

                    ],
                    "columns": [
                        { "data": "trialGroupName" },
                        { "data": "createdBy" },
                        { "data": "createdDate" },
                        { "data": "id" }
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                return "<div class=\"btn-action\"><button  id=\"" + full.id + "_disassociate" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Disasscociate</button> </div>";
                            }
                        }
                        

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [3],
                            "visible": false
                        }

                    ]
                });
            }
        });

        $('#datatable_associatedTrialGroupList tbody').on('click', 'td button', function () {
           
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];

            if (buttonName == "disassociate")
                self.disassociateTrialGroup(buttonId);
            


        });
    }

    //Code added by ramesh on 27th Dec 2017
    public disassociateTrialGroup(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.selectedTrialGroupId = id;
        this.disassociateModal.show();
    }

    public loadSiteList(): void {
        let trialId = this.trial.id;
        var self = this;
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/site/{id} localStorage.getItem('GLOBAL_COMPANY_ID')

        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_associatedSiteList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/site/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        'csv', 'print'

                    ],
                    "columns": [

                        { "data": "siteName" },
                        { "data": "siteAdress" },
                        { "data": "countryName" },
                        { "data": "phoneNumber" },
                        { "data": "id" }
                        //{ "data": "female" },
                        //{ "data": "containers" },
                        //{ "data": "status" },
                        //{ "data": "Id" }
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                return "<div class=\"btn-action\"><button  id=\"" + full.id + "_disassociate" + "\" class=\"btn btn-danger btn-xs\" ><i class=\"fa fa-trash-o\" > </i> Disasscociate</button> </div>";

                            }
                        }

                    ],
                    "columnDefs": [

                        {
                            "targets": [4],
                            "visible": false
                        },
                        //{
                        //    "targets": [7],
                        //    render: function (data, type, row) {
                        //        return data == '1' ? 'Active' : 'Inactive'
                        //    }
                        //}
                    ]
                });
            }
        });
        $('#datatable_associatedSiteList tbody').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            if (buttonName == "disassociate")
                self.disassociateSite(buttonId);



        });

    }




    
}
