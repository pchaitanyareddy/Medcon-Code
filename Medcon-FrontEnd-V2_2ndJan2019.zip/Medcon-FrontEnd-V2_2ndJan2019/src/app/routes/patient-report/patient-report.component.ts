﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { PatientReportService } from '../../services/patient-report.service';
import { PatientReport } from '../../models/patientreport';
import { PatientInformation } from '../../models/PatientInformation';
import { PatientDosageDetails } from '../../models/PatientDosageDetails';
import { PatientSummaryGrid } from '../../models/PatientSummaryGrid';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from '../../services/commonService';
import { SiteService } from '../../services/site.service';
import { TrialService } from '../../services/trial.service';
import { ReportService } from '../../services/report.service';
import { NotificationsService } from '../../services/notifications.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
//require('datatables.net-buttons-bs')(window, $);
//require('style-loader!datatables.net/jquery.dataTables.min.css');
@Component({
    templateUrl: './patient-report.component.html?v=${new Date().getTime()}',
    styleUrls: ['./custom.css?v=${new Date().getTime()}']
})

export class PatientReportComponent implements OnInit {
    @ViewChild('viewSummaryModal') public viewSummaryModal: ModalDirective;
    @ViewChild('viewDetailModal') public viewDetailModal: ModalDirective;
    public patientReport: Pagination<PatientReport>;
    patientReportList: any;
    patientList_Summary: any;
    public patientInformation: any;
    patient_Details: any;
    isLoading: boolean;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    //public userToDelete: User;
    public countryList: any;
    public countryListFiltered: any;
    public maxSize: number = 5;
    public currentPage: number = 1;
    public patientReportForm: FormGroup;
    public allTrialGroupList: any;
    public selectedTrialGroupId: number;
    public selectedTrialGroupName: string;
    public allTrailsList: any;
    public selectedTrialId: any = 'all';
    public selectedTrial: any;
    public allPatientList: any;
    public allPatientList1: any;
    public selectedPatientId: any;
    public selectedPatient: any;
    public allTrailsListFiltered: any;
    public allLocationList: any;
    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public selectedCountryCode: number;
    public selectCountry: string;
    public selectedCompanyId: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private patientReportService: PatientReportService,
        private cognitoUtil: CognitoUtil,
        private fb: FormBuilder,
        private siteService: SiteService,
        private trialService: TrialService,
        private reportService: ReportService,
        private notificationsService: NotificationsService,
        private url: LocationStrategy) {
    }

    public ngOnInit(): void {
        this.currentUserRole = this.route.snapshot.data['role'];
        this.patientReport = this.route.snapshot.data['PatientReport'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }


        this.patientReportForm = this.fb.group({

            patientID: ['', Validators.required],
            startDate: ['', Validators.required],
            trialName: ['', Validators.required],
            endDate: ['', Validators.required],
            location: ['', [Validators.required]],
            ddlStatusType: ['', [Validators.required]],
            trialGroup: ['', [Validators.required]],
        });


        //this.siteService.getCountries().subscribe(
        //    (response) => {
        //        this.countryList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });

        this.loadAllDropdowns();

       

    }

    loadAllDropdowns()
    {



        this.trialService.getAllTrialGroupsDropDown(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrialGroupList = response.trailgroups;
                if ($('#trialGroup').val() != 'Select' && $('#trialGroup').val()!=null) 
                {
                    this.notificationsService.getSelectedTrailsFromTrialGroup(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number($('#trialGroup').val())).subscribe(
                        (response) => {
                            //alert(this.selectedTrialGroupId);
                            this.allTrailsList = response;
                            this.isLoading = false;
                        },
                        (err) => {
                            this.errorMessage = err;
                            this.isLoading = false;
                        });
                }
                else {
                    this.allTrailsList = response.trailname;
                    this.isLoading = false;
                }
                if ($('#trialName').val() != 'Select' && $('#trialName').val() != null) {

                    this.notificationsService.getSelectedLocationFromTrail(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number($('#trialName').val())).subscribe(
                        (response) => {
                            //alert(this.selectedTrialGroupId);
                            this.allLocationList = response;
                            this.isLoading = false;
                        },
                        (err) => {
                            this.errorMessage = err;
                            this.isLoading = false;
                        });
                }
                else {
                    this.allLocationList = response.country;
                }
                this.allPatientList = response.patientname;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });
    }

    public ngAfterViewInit(): void {


        this.loadPatientInfo('PageLoad');


        
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        //this.patientReportService.getPatientReportData(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((PatientReport) => {
        //this.patientReport = PatientReport;
        //});
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    
    public showModal(): void {
        this.viewSummaryModal.show();
    }

    public hideViewSummaryModal(): void {
        this.viewSummaryModal.hide();
    }

    public viewSummary(patient): void {
        //alert(patient.firstName);
        //alert(patient.lastName);
        //this.userToDelete = user;
        this.viewSummaryModal.show();
    }

    public viewDetails(patient): void {
        //this.userToDelete = user;
        this.viewDetailModal.show();
    }


    public showViewDetailModal(): void {
        this.viewDetailModal.show();
    }

    public hideViewDetailModal(): void {
        this.viewDetailModal.hide();
    }

    public viewLabelDetails(companyId): void {
       // alert('jjj');
        //this.labelDetailsModal.show();
    }

    public ShowSummaryModalPopup(): void {

        //alert('showing');
    }

    public LoadPatientSummaryDetailsByUserId(): void {

        //iterate through the every record
        this.isLoading = true;
        $('#pnlViewSummaryModal').on('shown.bs.modal', function () {
            //alert('show event fired!');
        });
    }

    public ClearFieldValues(): void {
        $("#date").text("");
        $("#ActiveFlag").text("");
        $("#Name").text("");
        $("#ActiveTrial").text("");
        $("#Age").text("");
        $("#Country").text("");
        $("#Gender").text("");
        $("#State").text("");
        $("#EmailAddress").text("");
        $("#City").text("");
        $("#Mobile").text("");
        $("#Zipcode").text("");
        $("#Race").text("");
        $("#City").text("");
    }

    public LoadPatientSummaryDetails(patientId, trialStartDate): void {

        //alert(userId);
        this.ClearFieldValues();
        this.isLoading = true;
        //$('#pnlViewSummaryModal').on('shown.bs.modal', function () {
        //    alert('show event fired!');
        //});
        ///let userId = localStorage.getItem('UserId');
        this.patientReportService.getPatientInformation(patientId).subscribe(
            (response) => {
                //this.patientInformation = response;
                //this.viewSummaryModal.show();
                //alert(response.firstName);
                this.isLoading = false;
                let status = (response.status==1) ? "Active" : "Inactive";
                $("#date").text(trialStartDate);
                $("#ActiveFlag").text(status);
                $("#PatientIds").text(patientId);
                $("#Name").text(response.firstName + response.lastName);
                //$("#ActiveTrial").text(response.activetrial);
                $("#Age").text(response.age);
                $("#Country").text(response.country);
                $("#Gender").text(response.gender);
                $("#State").text(response.state);
                $("#EmailAddress").text(response.emailAddress);
                $("#City").text(response.location);
                $("#Mobile").text(response.phoneNumber);
                $("#Zipcode").text(response.zipcode);
                $("#Race").text(response.race);
                $("#City").text(response.city);
                $("#firstScan").text(response.Firstscan);
                $("#lastScan").text(response.lasttscan);
                this.viewSummaryModal.show();
                //$('#pnlViewSummaryModal').modal('show'); 
            },
            (err) => {
                this.errorMessage = err;

            });

        //Get dosage details
        this.LoadDosageData(patientId);
        //Get Patient summary list
        //$("#datatable_PatientSummary").dataTable().fnDestroy();
        //this.loadPatientSummarList(userId);

        //alert(this.patientInformation.firstName + this.patientInformation[0].lastName);
        
        
        //$('#pnlViewSummaryModal').modal({
        //    //remote: url,
        //    refresh: true
        //});
    }

    public test(userid): void {
        //alert(userid);
        //this.userToDelete = user;
        this.viewSummaryModal.show();
    }

    public test_org(userId): void  {
       
    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    public loadPatientInfo(submitType): void {
        var self = this; // store here
        //var table = $('#datatable').DataTable();
        let url = '';
        let patientIds = '';
        let startDate = '';
        let endDate = '';
        let location = '';
        let trialName = '';
        let status = '';
        var arrLocationIds;
        let locationIds = '';
        let trialGroupIds = '';
        let trialIds = '';
        let pageLength = 0;
        let companyIdGobalID = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        if (submitType == 'PageLoad') {
            //url = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/patientsummarylist';
            url = CommonService.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST + 'user/patient/patientsummarylist?companyIds=' + companyIdGobalID;
        }
        else if (submitType == 'buttonClick')
        {
            
            //pageLength = Number($("select[name='datatable_length'] option:selected").text());
            pageLength = $("select[name='datatable_length'] option:selected").text();
            pageLength = ($("select[name='datatable_length'] option:selected").text() == 'All' ? -1 : Number($("select[name='datatable_length'] option:selected").text()));
           
            $("#datatable").dataTable().fnDestroy();
            //patientIds = this.patientReportForm.value.patientID;    
            trialIds = ($("#trialName").val() == null || $("#trialName").val()=='Select') ? '' : $("#trialName").val();//this.selectedTrialId;
            patientIds = ($("#patientID option:selected").text() == undefined || $("#patientID option:selected").text()=='Select')?'':$("#patientID option:selected").text();//this.selectedPatient;
            startDate = this.convertDate(this.patientReportForm.value.startDate.date);
            endDate = this.convertDate(this.patientReportForm.value.endDate.date);
            location = $("#location option:selected").val(); //String(this.selectedCountryCode);// this.patientReportForm.value.location;
            locationIds = location;
            locationIds = (locationIds == undefined || locationIds == 'Select') ? '' : locationIds;
            //trialName = ($("#trialName").val()==null)?'':$("#trialName").val();//this.selectedTrial;
            var selectedTrials;
            var startDate1 = new Date(startDate);
            var endDate1 = new Date(endDate);
            var todayDate = new Date();
            if (startDate1 > endDate1) {

                this.errorMessage = "Start Date should be Less than End Date";

            }
            if (startDate != '' && endDate == '') {
                this.errorMessage = "Please Select End Date"
            }
            else if (startDate == '' && endDate != '') {
                this.errorMessage = "Please Select Start Date"
            }
            //alert(trialIds);
            //alert(locationIds);
            let trialGroupIds = $("#trialGroup").val();//String(this.selectedTrialGroupId);
            if(patientIds == null || patientIds == 'NaN')
                patientIds = '';
            //if(trialIds == null || trialIds == 'NaN')
            //    trialIds = '';
            if (String(trialIds) == 'NaN') {
                trialIds = '';
                //alert(trialIds);
            }
            if (trialGroupIds == null || trialGroupIds == 'NaN' || trialGroupIds == 'Select') trialGroupIds = '';
            if (this.patientReportForm.value.ddlStatusType != undefined && this.patientReportForm.value.ddlStatusType != '' && this.patientReportForm.value.ddlStatusType != null && this.patientReportForm.value.ddlStatusType!='Select')  
                status = (this.patientReportForm.value.ddlStatusType == 'Active') ? '1' : '0'; 
           
            

            //if (startDate == '' && endDate == '' && (this.patientReportForm.value.trialGroup == 'Select' || this.patientReportForm.value.trialGroup.replace('NaN', '') == '')
            //    && (this.patientReportForm.value.trialName == 'Select' || String(this.patientReportForm.value.trialName).replace('NaN', '') == '') && (this.patientReportForm.value.location == 'Select' || this.patientReportForm.value.location.replace('NaN', '') == '')
            //    && (this.patientReportForm.value.patientID == 'Select' || String(this.patientReportForm.value.patientID).replace('NaN', '') == '') && (this.patientReportForm.value.ddlStatusType == 'Select' || String(this.patientReportForm.value.ddlStatusType).replace('NaN', '') == ''))
            if (startDate == '' && endDate == '' && ($("#trialGroup").val() == null || $("#trialGroup").val() == 'Select')
                && ($("#trialName").val() == null || $("#trialName").val() == 'Select')
                && ($("#location").val() == null || $("#location").val() == 'Select')
                && ($("#patientID").val() == null || $("#patientID").val() == 'Select')
                && ($("#ddlStatusType").val() == null || $("#ddlStatusType").val() == 'Select') )
            {

                url = CommonService.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST + 'user/patient/patientsummarylist?companyIds=' + companyIdGobalID;
            }
            else {
                //url = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/patientsummarylist?patientNumbers="' + patientIds + '"&locationIds=' + location + '&status=' + status + '&startdate=' + startDate + '&enddate=' + endDate;
                //url = CommonService.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST +'user/patient/patientsummarylist?patientNumbers="' + patientIds + '"&locationIds=' + location + '&status=' + status + '&startdate=' + startDate + '&enddate=' + endDate;
                url = CommonService.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST + 'user/patient/patientsummarylist?patientNumbers=' + patientIds + '&locationIds=' + locationIds + '&status=' + status + '&startdate=' + startDate + '&enddate=' + endDate + '&trialGroupIds=' + trialGroupIds + '&companyIds=' + companyIdGobalID + '&trialIds=' + trialIds;

            }
        }
        

        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "rowId": "userId",
                    'ajax': {
                        //'url': 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/patientlist',
                        //'url':'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/patientsummarylist?patientNumbers ="ABC223456" &locationIds="101,44" &  status = 1 &  startdate = "2018-01-01" & enddate="2018-03-31"',
                        'url':url,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        complete: function () {

                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1,3, 4, 5,6]
                            },
                            action: function () {
                                //let apiUrl = CommonService.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST + 'user/patient/patientsummarylist?companyIds=' + Number(localStorage.getItem('GLOBAL_COMPANY_ID'))+'&draw=4&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=trialName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=TrialGroups&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Company&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=startDate&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=endDate&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false&_=15'
                                let apiUrl = url + '&draw=4&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=trialName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=TrialGroups&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Company&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=startDate&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=endDate&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=15'
                                self.reportService.ExportAll(apiUrl,'Patient Report');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 3, 4, 5, 6]
                            } }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "PatientID" },
                        { "data": "trialName" },
                        { "data": "TrialGroups" },
                        { "data": "Company" },
                        { "data": "startDate" },
                        { "data": "endDate" },
                        //{ "data": "date" },
                        //{
                        //    "data": "date", "render": function (data) {
                        //        var date = new Date(data);
                        //        var month = date.getMonth() + 1;
                        //        return (month.length > 1 ? month : "0" + month) + "/" + date.getDate() + "/" + date.getFullYear();
                        //    }
                        //} 
                        //,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                localStorage.setItem('firstName', full.firstName);
                                localStorage.setItem('lastName', full.lastName);
                                localStorage.setItem('country', full.country);
                                //return "<div class=\"btn-action\"><button onclick=\"test(" + full.userId + ")\" id=\"" + full.userId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Summary</button><button onclick=\"DetailsFn(" + full.userId + ")\" id=\"" + full.userId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Details</button> <script> function test(userId){ localStorage.setItem('UserId', String(userId)); $('#pnlViewSummaryModal').modal('show');" + self.LoadPatientSummaryDetails(full.userId, full.country) + " } $('#btnCloseModalPopup').click(function () { $('#pnlViewSummaryModal').modal('hide');}); function DetailsFn(userId){  localStorage.setItem('UserId', String(userId)); $('#pnlViewDetailModal').modal('show');" + self.loadPatientDetailsWindow(full.userId, full.firstName, full.lastName, full.lastName,full.country,full.country) + "  } $('#btnCloseModalPopup_Details').click(function () { $('#pnlViewDetailModal').modal('hide');});</script> </div>";
                                //return "<div class=\"btn-action\"><button onclick=\"" + test("" + full.userId + "") + "\" id=\"" + full.userId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Summary</button><button onclick=\"DetailsFn(" + full.userId + ")\" id=\"" + full.userId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Details</button> <script> function  $('#btnCloseModalPopup').click(function () { $('#pnlViewSummaryModal').modal('hide');}); function DetailsFn(userId){  localStorage.setItem('UserId', String(userId)); $('#pnlViewDetailModal').modal('show');" + self.loadPatientDetailsWindow(full.userId, full.firstName, full.lastName, full.lastName, full.country, full.country) + "  } $('#btnCloseModalPopup_Details').click(function () { $('#pnlViewDetailModal').modal('hide');});</script> </div>";
                                //return "<div class=\"btn-action\"><button onclick\"" + test("" + full.userId + "") + "\" id=\"" + full.userId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Summary</button><button onclick=\"DetailsFn(" + full.userId + ")\" id=\"" + full.userId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Details</button> <script>   $('#btnCloseModalPopup').click(function () { $('#pnlViewSummaryModal').modal('hide');}); $('#btnCloseModalPopup_Details').click(function () { $('#pnlViewDetailModal').modal('hide');});</script> </div>";
                                return "<div class=\"btn-action\"><button  id=\"" + full.PatientID + "^summary" + "^" + full.startDate + "^" + full.lastName + "^" + full.country + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Summary</button><button  id=\"" + full.PatientID + "^details" + "^" + full.firstName + "^" + full.lastName + "^" + full.country +  "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Details</button>  </div>";
                            }
                        }

                    ],
                    "columnDefs": [

                        //{
                        //    "targets": [0],
                        //    "visible": false
                        //},
                        //{
                        //    "targets": [1],
                        //    "visible": false
                        //},
                        //{
                        //    "targets": [2],
                        //    "visible": false
                        //},
                        //{
                        //    "targets": [6],
                        //    "visible": false
                        //}
                        //,
                        //{
                        //    "targets": [5],
                        //    render: function (data, type, row) {
                        //        return data == '1' ? 'Active' : 'Inactive'
                        //    }
                        //    ,
                        //    "visible": false
                        //}
                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    "pageLength": pageLength
                    ,
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }

                });
            }
        });

        $('#datatable tbody').on('click', 'td button', function () {
            //alert('hello');
            //alert($(this).attr('id'));
            //alert($('button').text());
            
            var attId = $(this).attr('id');
            var buttonName = attId.split("^")[1];
            var buttonId = attId.split("^")[0];
            var trialStartDate = attId.split("^")[2];
            var lastName = attId.split("^")[3];
            var country = attId.split("^")[4];
            //alert(attId);
            if (buttonName=="summary")
                self.LoadPatientSummaryDetails(buttonId, trialStartDate);
            if (buttonName == "details") {

                self.loadPatientDetailsWindow(buttonId, trialStartDate, lastName, "", country,country);

            }

            
        });

        $('#datatable tbody').on("click", 'tr', function () {
            //var data = $('#datatable').row(this).data();
            //alert(data.firstName);
            var attId = $(this).attr('id');
            //alert(attId);
        });

    }

    public ClearDosageDetails(): void {

                $("#spnDosageTaken").text("");
                $("#spnManualDosages").text("");
                $("#spnMissedDosages").text("");
                $("#spnOverdose").text("");
                $("#spnScannedDosages").text("");
                $("#spnUnderDose").text("");
                $("#spnOntime").text("");
                $("#spnLateDose").text("");
                $("#spnPatientId").text("");
                $("#spnTrialName").text("");

    }

    public LoadDosageData(patientId): void {

        //alert(patientId);
        this.ClearDosageDetails();
        this.isLoading = true;
        this.patientReportService.getPatientDosageDetails(patientId).subscribe(
            (response) => {
                this.isLoading = false;
                //this.patientInformation = response;
                //this.viewSummaryModal.show();
               // alert(response.firstName);
                //let status = (response.status) ? "Active" : "Inactive";
                $("#spnDosageTaken").text(response.Taken);
                $("#spnManualDosages").text(response.Manual);
                $("#spnMissedDosages").text(response.Missed);
                $("#spnOverdose").text(response.Overdose);
                $("#spnScannedDosages").text(response.Scanned);
                $("#spnPatientId").text(patientId);
                $("#spnTrialName").text(response.TrailName);
                $("#ActiveTrial").text(response.TrailName);
                $("#spnUnderDose").text(response.Underdose);
                $("#spnOntime").text(response.ontime);
                $("#spnLateDose").text(response.late);

            },
            (err) => {
                this.errorMessage = err;

            });

    }

    public loadPatientSummarList(patientId): void {
        //alert('summary list');
        this.ClearDosageDetails();
        var self = this; // store here
        
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_PatientSummary').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "rowId": "PatientID",
                    'ajax': {
                        //'url': 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/patientsummarylist?patientId=' + patientId,
                        'url': CommonService.API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST +'user/patient/patientsummarylist?patientId=' + patientId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        complete: function () {

                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        //'csv', 'print'
                        {
                            extend: 'csv', text: 'Export'
                        },
                        {
                            extend: 'print', text: 'Print'
                        }
                    ],
                    "columns": [
                        { "data": "PatientID" },
                        { "data": "trialID" },
                        { "data": "TrialGroups" },
                        { "data": "Company" },
                        { "data": "Start Date" },
                        { "data": "End Date" }
                        //,
                        //{
                        //    sortable: false,
                        //    "render": function (data, type, full, meta) {

                        //        return "<div class=\"btn-action\"><button id=\"" + full.PatientID + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Dosage Details</button>  </div>";

                        //    }
                        //}
                    ],
                    
                    "columnDefs": [

                        {
                            "targets": [0],
                            render: function (data, type, row) {
                                return '<a href=\"javascript:void(0)\"><u>' + data + '</u></a>';
                            }
                        }
                    ],
                    
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    },
                    "initComplete": function (settings, json) {
                        //alert('DataTables has finished its initialisation.');
                        //alert(json.data[0].PatientID);

                        if (json.data[0]!=undefined)
                        self.LoadDosageData(json.data[0].PatientID);
                    }
                });
            }
        });

        $('#datatable_PatientSummary tbody').on("click", 'tr', function () {
            //var data = $('#datatable').row(this).data();
            //alert(data.firstName);
            //var attId = $(this).attr('id');
            //alert(attId);
             //alert($(this).attr('id'));
            self.LoadDosageData($(this).attr('id'));

        });

        //$('#datatable_PatientSummary tbody').on('click', 'td button', function () {
        //    //alert('hello');
        //    //alert($(this).attr('id'));

        //    self.LoadDosageData($(this).attr('id'));

        //});

    }

    public loadPatientDetailsWindow(patientId, firstName, lastName, emailAddress, state, country): void {
        //alert(firstName);
        let location = state + "," + country;
        $("#spnFirstName").text(firstName);
        $("#spnLastName").text(lastName);
        $("#spnEmailAddress").text(emailAddress);
        //$("#spnLocation").text(location);
        $("#datatable_PatientDetail").dataTable().fnDestroy();
        this.loadPatientDosageList(patientId);
        this.viewDetailModal.show();
    }
    public loadPatientDosageList(patientId): void {
        //alert('summary list');
        var self = this; // store here


        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_PatientDetail').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        //'url': 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/patientdosagedetailslist?patientNumber=' + patientId,
                        'url': CommonService.API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_LIST +'user/patient/patientdosagedetailslist?patientNumber=' + patientId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        complete: function () {

                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        //'csv', 'print'
                        {
                            extend: 'csv', text: 'Export',
                            action: function () {
                                var searchTextBoxVal = ($('#datatable_PatientDetail_filter input[type="search"]').val().toLowerCase() == 'on-time' ) ? 'normal' : $('#datatable_PatientDetail_filter input[type="search"]').val();
                                let apiUrl = CommonService.API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_LIST + 'user/patient/patientdosagedetailslist?patientNumber=' + patientId + '&draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=patientId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=Container&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=dose&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=type&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=extraDose&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=doseWindow&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=entry&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=location&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B10%5D%5Bdata%5D=timeTaken&columns%5B10%5D%5Bname%5D=&columns%5B10%5D%5Bsearchable%5D=true&columns%5B10%5D%5Borderable%5D=true&columns%5B10%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B10%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B11%5D%5Bdata%5D=timeTaken&columns%5B11%5D%5Bname%5D=&columns%5B11%5D%5Bsearchable%5D=true&columns%5B11%5D%5Borderable%5D=true&columns%5B11%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B11%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=asc&start=0&length=-1&search%5Bvalue%5D=' + searchTextBoxVal +'&search%5Bregex%5D=false&_=1523950744748'
                                self.reportService.ExportAll(apiUrl,'Patient Details');
                            },
                        },
                        {
                            extend: 'print', text: 'Print'
                        }
                    ],
                    "columns": [
                        //{ "data": "trialName" },
                        //{ "data": "patientId" },
                        //{ "data": "Container" },
                        //{ "data": "dose" },
                        //{ "data": "doseAmount" },
                        //{ "data": "type" },
                        //{ "data": "extraDose" },
                        //{ "data": "doseWindow" },
                        //{ "data": "entry" },
                        //{ "data": "location" },
                        //{ "data": "timeTaken" },
                        //{ "data": "timeTaken" }
                        { "data": "trialName" },
                        { "data": "patientId" },
                        { "data": "Container" },
                        { "data": "drugname" },
                        { "data": "dosetype" },
                        { "data": "doseAmount" },
                        { "data": "type" },
                        { "data": "doseWindow" },
                        { "data": "entry" },
                        { "data": "location" },
                        { "data": "timeZone" },
                        { "data": "timeTaken" },
                        { "data": "timeTaken" },

                    ]
                    ,
                    "columnDefs": [
                        {
                            "targets": [2],
                            render: function (data, type, row) {
                                
                                return data.split('_')[3];
                            }
                        },
                        {
                            "targets": [6],
                            render: function (data, type, row) {
                                if (data == 'normal')
                                    return 'On-Time'
                                else
                                return data && data.charAt(0).toUpperCase() + data.slice(1);
                            }
                        },
                        {
                            "targets": [7],
                            render: function (data, type, row) {
                                return data && data.charAt(0).toUpperCase() + data.slice(1);
                            }
                        }
                        ,
                        {
                            "targets": [8],
                            render: function (data, type, row) {
                                if (data == 1) {
                                    return 'Manual'
                                }
                                else if (data == 2) {
                                    return '-'
                                }
                                else if (data == 0) {
                                    return 'Scan'
                                }
                            }
                        },
                        //{
                        //    "targets": [6],
                        //    render: function (data, type, row) {
                        //        return data == '0' ? 'No' : data
                        //    }
                        //},
                         {
                            "targets": [12],
                            render: function (data, type, row) {
                                return data.split('|')[1];
                            }
                        }
                        ,
                         {
                             "targets": [11],
                             render: function (data, type, row) {
                                 return data.split('|')[0];
                             }
                         }
                        ,
                         {
                             "targets": [10],
                             render: function (data, type, row) {
                                 if (data != null) {
                                     let num = data.split(' ')[1];
                                     let GmtSec = num.split(':')[2];
                                     let GmtMin = num.split(':')[1];
                                     let Gmthr = num.split(':')[0];
                                     GmtSec = Math.round(GmtSec);

                                     if (GmtSec == 60) {
                                         GmtMin = Number(GmtMin) + 1;
                                         GmtSec = '00';
                                     }
                                     let finalGmt = Gmthr + ':' + GmtMin + ':' + GmtSec
                                     //alert(finalGmt)
                                     return data.split(' ')[0] + ' ' + finalGmt;
                                 }
                                 else
                                     return '-'
                                 //return data == null ? '-' :finalGmt
                             }
                         }


                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    },
                    "createdRow": function (row, data, index) {
                        $("#spnLocation").text($('td', row).eq(9).text());
                        //if (data[5].replace(/[\$,]/g, '') * 1 > 150000) {
                        //    $('td', row).eq(5).addClass('highlight');
                        //}
                        //alert($('td', row).eq(5).text()); 
                        if ($('td', row).eq(6).text() == 'Normal' || $('td', row).eq(6).text() == 'On-Time')
                        {
                            $('td', row).eq(6).css('color', 'green');
                           
                        }
                        else if ($('td', row).eq(6).text() == 'Missed') {
                            $('td', row).eq(6).css('color', '#c81b18');
                            $('td', row).eq(0).css('background-color', '#ffcdd2');
                            $('td', row).eq(1).css('background-color', '#ffcdd2');
                            $('td', row).eq(2).css('background-color', '#ffcdd2');
                            $('td', row).eq(3).css('background-color', '#ffcdd2');
                            $('td', row).eq(4).css('background-color', '#ffcdd2');
                            $('td', row).eq(5).css('background-color', '#ffcdd2');
                            $('td', row).eq(6).css('background-color', '#ffcdd2');
                            $('td', row).eq(7).css('background-color', '#ffcdd2');
                            $('td', row).eq(8).css('background-color', '#ffcdd2');
                            $('td', row).eq(9).css('background-color', '#ffcdd2');
                            $('td', row).eq(10).css('background-color', '#ffcdd2');
                            $('td', row).eq(11).css('background-color', '#ffcdd2');
                            $('td', row).eq(12).css('background-color', '#ffcdd2');
                        }

                        //if ($('td', row).eq(6).text() == '0')
                        //{
                        //    $('td', row).eq(6).css('align', 'right');

                        //}
                        //else
                        //{
                        //    $('td', row).eq(6).css('align', 'right');
                        //}

                    }
                });
            }
        });

        $('#datatable_PatientDetail').on('search.dt', function () {

            if ($('#datatable_PatientDetail').DataTable().search().toLowerCase() == 'on-time') {
                // alert($('#datatable').DataTable().search());
                //this.loadDataReportList('PageLoad');
                //$('#datatable').DataTable()
                //    .columns(6)
                //    .search('normal')
                //    .draw();
                $('#datatable_PatientDetail').DataTable().search('normal').draw();
            }

        });
        

    }

    //public onDateChange(event: IMyInputFieldChanged, field): void {
    //    let d = event.value.split('/');
    //    let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

    //    if (event.valid) {
    //        if (field === 'start') {
    //            this.setEndDateDisableUntil(date.date);
    //        } else if (field === 'end') {
    //            this.setStartDateDisableSince(date.date);
    //        }
    //    }
    //}

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let day = Number(d[1]) - 1;
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + day);
        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            }
            //else if (field === 'end') {
            //    this.setStartDateDisableSince(date.date);
            //}
        }
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    private dateForView(date: string): any {
        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2].replace('0', '') } };
        } else {
            return '';
        }
    }


    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }


    onChangeTrialGroip(selectedValue) {
        this.isLoading = true;
        this.selectedTrialGroupId = Number(selectedValue);
        this.selectedTrialGroupName = null;
        this.allTrailsList = [];
        this.allPatientList = [];
        this.allLocationList = [];


        //To get selected role name
        if (this.allTrialGroupList != null) {
            for (var i = 0; i < this.allTrialGroupList.length; i++) {
                if (this.allTrialGroupList[i].id == this.selectedTrialGroupId) {
                    this.selectedTrialGroupName = this.allTrialGroupList[i].name;
                }
            }

        }
        //alert(selectedValue);
        if (selectedValue != 'Select') {
            this.notificationsService.getSelectedTrailsFromTrialGroup(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialGroupId)).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allTrailsList = response;
                    this.isLoading = false;
                    this.loadAllDropdowns();
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else
        {
            
            this.loadAllDropdowns();
        }

    }
    onChange_Trial1(selectedValue) {
        this.isLoading = true;
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;
        this.allPatientList = [];
        this.allLocationList = [];

        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }

        if (String(this.selectedTrialId) != 'NaN')
            {
            this.notificationsService.getSelectedLocationFromTrail(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialId)).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allLocationList = response;
                    this.isLoading = false;
                    this.loadAllDropdowns();
                },
                (err) => {
                    this.errorMessage = err;

                });
        }
        else if (selectedValue =='Select')
        {
           
            this.loadAllDropdowns();

        }

    }
    onChange_Patient(selectedValue) {

        this.selectedPatientId = Number(selectedValue);
        this.selectedPatient = null;
        //this.allLocationList = [];

        if (this.allPatientList != null) {
            for (var i = 0; i < this.allPatientList.length; i++) {
                if (this.allPatientList[i].id == this.selectedPatientId) {
                    this.selectedPatient = this.allPatientList[i].patient_number;
                }
            }
            
        }

    }

    onChange(selectedValue) {
        this.isLoading = true;
        this.selectedCountryCode = selectedValue;
        this.selectCountry = null;
        if (this.allLocationList != null) {
            for (var i = 0; i < this.allLocationList.length; i++) {
                if (this.allLocationList[i].id == this.selectedCountryCode) {
                    this.selectCountry = this.allLocationList[i].name;
                }
            }

        }
        if (String(this.selectedCountryCode) != 'Select')
        {
                this.notificationsService.getSelectedPatientsFromLocation(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), this.selectedCountryCode, Number(this.selectedTrialId)).subscribe(
                    (response) => {
                        //alert(this.selectedTrialGroupId);
                        this.allPatientList = response;
                        this.isLoading = false;
                    },
                    (err) => {
                        this.errorMessage = err;
                        this.isLoading = false;
                    });
        }
        else
        {

            this.loadAllDropdowns();
            $('#patientID').val('Select');
        }
    }

}