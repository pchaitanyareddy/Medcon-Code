import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { SiteService } from '../../services/site.service';
import { Customer } from '../../models/customer';
import { Site } from '../../models/site';
import { SiteRequest } from '../../requests/site-request';
import { Observable } from 'rxjs/Observable';
//import { CompanyService } from '../../services/company.service';
@Component({
    templateUrl: './site-edit.component.html?v=${new Date().getTime()}'
})

export class SiteEditComponent implements OnInit {
	public form: FormGroup;
	public showErrors: boolean;
	public successMessage: string;
	public errorMessage: string;
	public customer: Customer;
    public site: Site;
    isLoading: boolean;
	public states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
		'Delaware', 'District of Columbia', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana',
		'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan',
		'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
		'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma',
		'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas',
		'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];
    selectedStateId: number;
    selectedCountryId: number;
    selectedCountry: string;
    selectedState: string;
    selectedPhoneCode: number;
    stateList: any;
    countryList: any;
    userId: number;
    zipCode: number;
	constructor(public templateService: TemplateService,
		private router: Router,
		private route: ActivatedRoute,
		private fb: FormBuilder,
        private siteService: SiteService
        //,
        //private companyService: CompanyService
    ) {
	}

    public ngOnInit(): void {
        this.isLoading = true;
		this.customer = this.route.snapshot.data['customer'];
		this.site = this.route.snapshot.data['site'];

		this.form = this.fb.group({
			//name: [this.site.name, [Validators.required]],
            //address_line_1: [this.site.addressLine1, [Validators.required]],
			//address_line_2: [this.site.address.line2],
			//address_line_3: [this.site.address.line3],
            //city: [this.site.cityName, Validators.required],
            //zip_code: [this.site.zipCode, Validators.required],
            state: [this.site.State, Validators.required],
           //phone: [this.site.phoneNumber, Validators.required],
            name: [this.site.name, Validators.required],
            address_line_1: [this.site.address, [Validators.required]],
            city: [this.site.cityName, Validators.required],
            zip_code: [this.site.zipcode, Validators.required],
           //state: ["Telanagana", Validators.required],
            phone: [this.site.phoneNumber, Validators.required],
            country: [this.site.country, Validators.required],
        });

        this.selectedStateId = this.site.stateId;
        this.selectedCountryId = this.site.countryId;

        this.siteService.getCountries().subscribe(
            (response) => {
                this.countryList = response;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });
	}

    public onSubmit(): void {
        this.userId = Number(this.route.snapshot.params['customer_id']);
        this.zipCode = Number(this.form.value.zip_code);
        //alert(this.selectedStateId);
       // alert(this.form.value.state);
		if (this.form.invalid) {
			this.showErrors = true;
        }
        else if (String(this.selectedCountryId) == 'NaN' || this.selectedCountryId == undefined) {
            this.showErrors = true;
            this.errorMessage = "Please Select Country"
        }
        else if (String(this.selectedStateId) == 'NaN' || this.selectedStateId == undefined || this.selectedStateId == 0) {
            this.showErrors = true;
            this.errorMessage="Please Select State"
        }
        else {
            this.isLoading = true;
            
			// TODO: NEED TO ADD COUNTRY SELECTOR TO THE VIEW
            //let request = new SiteRequest(
            //    this.form.value.name,
            //    this.route.snapshot.params['customer_id'],
            //    this.form.value.address_line_1,
            //    this.selectedCountryId,//country id//this.form.value.city,
            //    this.selectedStateId,//state_id this.form.value.zip_code,
            //    this.form.value.city,
            //    this.form.value.zipcode,
            //    this.form.value.phone
            //);
            let request = new SiteRequest(
                this.userId,
                this.form.value.name,
                this.form.value.address_line_1,
                this.selectedCountryId,//country id//this.form.value.city,
                this.selectedStateId,//state_id this.form.value.zip_code,
                this.form.value.city,
                this.zipCode,
                this.form.value.phone
            );

			this.siteService.updateSite(this.site.id, request).subscribe(
                (response) => {
                    this.isLoading = false;
					this.form.markAsPristine();
                    this.successMessage = 'Site successfully updated';
                    $(window).scrollTop(5);
                    this.goBack();
				},
                (err) => {
                    this.isLoading = false;
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

    public goBack(): void {
        this.isLoading = true;
        this.form.markAsPristine();
        //this.router.navigate([this.customer.id, 'sites']);
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'sites']);
    }

    onChange(selectedValue) {
        this.isLoading = true;
        //alert(selectedValue);
        let countryId = Number(selectedValue);
        if (this.selectedCountryId != Number(selectedValue))
            this.selectedStateId = 0;
        //Call API when country is selected, then retrieve data for state drop down list
        this.siteService.getStatesByCountry(countryId).subscribe(
            (response) => {
                this.stateList = response;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

        this.selectedCountryId = Number(selectedValue);
        this.selectedCountry = null;
        this.selectedPhoneCode = null;
       
        //To get selected role name
        if (this.countryList != null) {
            for (var i = 0; i < this.countryList.length; i++) {
                if (this.countryList[i].id == this.selectedCountryId) {
                    this.selectedCountry = this.countryList[i].name;
                    this.selectedPhoneCode = this.countryList[i].phonecode;
                    $('#phone').val("+" + this.selectedPhoneCode + "-");  
                   
                }
            }

        }

    }



    onChange_State(selectedValue) {
       
        this.selectedStateId = Number(selectedValue);
        //this.selectedState = null;
        //To get selected role name
        if (this.stateList != null) {
            for (var i = 0; i < this.stateList.length; i++) {
                if (this.stateList[i].id == this.selectedStateId) {
                    this.selectedState = this.stateList[i].name;
                }
            }

        }

    }

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}
}
