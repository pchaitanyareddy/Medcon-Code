﻿import { PrivilegesRequest } from '../../requests/privileges-request';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { PrivilegesService } from '../../services/privileges.service';
import { Observable } from 'rxjs/Observable';
import { Pagination } from '../../models/pagination';
import { FormsModule } from '@angular/forms';
import { Privileges } from '../../models/privileges';
import { UserRole } from '../../models/userrole';
import { CurrentUserService } from '../../services/currentuser.service';
import { UserService } from '../../services/user.service';
import { LocationStrategy } from '@angular/common';
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}


@Component({
    templateUrl: './privileges-list.component.html?v=${new Date().getTime()}'
})

export class PrivilegesComponent implements OnInit {
    public privileges: Pagination<Privileges>;
    public privilegesForm: FormGroup;
    public showErrors: boolean;
    public errorMessage: string;
    public successMessage: string;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    defaultRole;
    privilegesList: any;
    allRoleList: any;
    selectedAll: any;
    selectedCheckboxes: Array<any> = [];
    selectedRow: string;
    selectedRows: string;
    selectedRowCount: number;
    public customerId: number;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public roleId: number;
    loggedInUserRole: string;
    selectedRoleId: number;
    selectedRoleName: string;
    rowLevelCheckboxSelected: boolean;
    isLoading: boolean;
    constructor(public templateService: TemplateService,
        public router: Router,
        public privilegesService: PrivilegesService,
        public currentUserService: CurrentUserService,
        public userService: UserService,
        private fb: FormBuilder,
        private url: LocationStrategy,
        private route: ActivatedRoute) {
        //this.privilegesList = [
        //    { id: 1, moduleName: 'Patient', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 2, moduleName: 'Data Reports', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 3, moduleName: 'Trials', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
        //    { id: 4, moduleName: 'Trial Group', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 5, moduleName: 'Pharmaceutical Company', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 6, moduleName: 'Label Manufacturer', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 7, moduleName: 'Drugs', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 8, moduleName: 'Regimen', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 9, moduleName: 'Alerts', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 10, moduleName: 'Import', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 11, moduleName: 'Notifications', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //    { id: 12, moduleName: 'Users', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
        //]

        //this.allRoleList = [
        //    { id: 1, roleName: 'Medcon Admin' },
        //    { id: 2, roleName: 'Customer Admin' },
        //    { id: 4, roleName: 'Label User' },
        //    { id: 5, roleName: 'Customer User' },
        //    { id: 6, roleName: 'Patient' },
        //]
        //this.privilegesList = this.privilegesService
        //    .getPrivileges(this.roleId,route.queryParams['page'], route.queryParams['perPage'],null,null);

        //this.privilegesService
        //    .getPrivileges(this.customerId, null, null)
        //    .subscribe((privileges) => this.privileges = privileges);

        this.currentUserService.getRole().subscribe((role) => {
            if (role === UserRole.MedConAdmin) {
                this.roleId = UserRole.MedConAdmin;
                this.loggedInUserRole = "MedConAdmin";
            }
            
        }, (err) => {
            //if (err.message === 'Token is null') {
            //    this.userService.logout();
            //}
        });
        //alert(this.roleId);
        this.selectedRoleId = 1;
        
    }


    public ngOnInit() {
        this.isLoading = false;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.privileges = this.route.snapshot.data['privileges'];
        this.customerId = this.route.snapshot.params['customer_id'];
        this.privilegesForm = this.fb.group({
            
            role: ['CustomerUser', [Validators.required]]
        });

        var x = Roles;
        var options = Object.keys(Roles);
        this.options = options.slice(options.length / 2);
        //this.defaultRole = this.allRoleList[0].id;//this.options[0];

        //this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
        //    (response) => {
        //        this.privilegesList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });
        this.privilegesList = this.privileges;
        this.userService.getAllRoles().subscribe(
            (response) => {
                this.allRoleList = response;

            },
            (err) => {
                this.errorMessage = err;

            });
        
    }

    public resetPrivileges()
    {
        //this.privilegesList = this.privileges;
        //this.onRefresh(this.route.snapshot.params['customer_id'], 'privileges');
        location.reload();
    }

    public onSubmit() {
        let jsonHeader= '[';
        let jsonFooter= ']';
        //alert(this.privilegesForm.value.role);
         //Loop through array and create string for every row
        //and then concatenate every row by seperating from pipe symbol |
        this.selectedRow = "";
        this.selectedCheckboxes = [];
        this.selectedRows = "";
        this.selectedRowCount = 0;
        for (let i = 0; i < this.privilegesList.length; i++) {
            //if ((<HTMLInputElement>document.getElementsByClassName("chkSelected")[i]).checked)
            //{
                //alert($('checkbox[id*="chkViewPermission"]')[i].innerText);
                //alert((<HTMLInputElement>document.getElementsByName("chkViewPermission")[i]).value);
                let status = (<HTMLInputElement>document.getElementsByClassName("chkSelected")[i]).checked;
                //let view = (this.privilegesList[i].view) ? "1" : "0";
                //let add = (this.privilegesList[i].add) ? "1" : "0";
                //let edit = (this.privilegesList[i].edit) ? "1" : "0";
                //let deleteAction = (this.privilegesList[i].deleteAction) ? "1" : "0";
                let view = ((<HTMLInputElement>document.getElementsByClassName("chkView")[i]).checked) ? "1" : "0";
                let add = ((<HTMLInputElement>document.getElementsByClassName("chkAdd")[i]).checked) ? "1" : "0";
                let edit = ((<HTMLInputElement>document.getElementsByClassName("chkEdit")[i]).checked) ? "1" : "0";
                let deleteAction = ((<HTMLInputElement>document.getElementsByClassName("chkDelete")[i]).checked) ? "1" : "0";
                let roleName = this.privilegesForm.value.role;
                if (view == "0" && add == "0" && edit == "0" && deleteAction == "0")
                    status = false;
                //this.selectedRow = this.privilegesList[i].id + "," + this.privilegesList[i].moduleName + "," + view + "," + add + "," + edit + "," + deleteAction + "," + roleName;
                this.selectedRow = "{\"status\":" + status + "," + "\"moduleName\":" + "\""+this.privilegesList[i].moduleName + "\""+"," + "\"edit\":" + edit + "," + "\"add\":" + add + "," + "\"view\":" + view + "," + "\"id\":" + this.privilegesList[i].id + "," +"\"delete\":" + deleteAction+"}";
                if (this.selectedRows.length > 0) {

                    this.selectedRows = this.selectedRows + "," + this.selectedRow;
                }
                else {
                    this.selectedRows = this.selectedRow;
                }

                this.selectedRowCount++;
            //}
            //(<HTMLInputElement>document.getElementsByClassName("chkSelected")[i]).checked = true;
            
            //this.selectedCheckboxes.push(this.privilegesList[i].id);
            //alert(this.privilegesList[i].id);
        }
        //alert(this.selectedRows);
        if (this.selectedRowCount == 0)
        {
            alert('Please select module.')

        }
        
        
        //To get the selected role name
        //alert(this.privilegesForm.value.role);
        //var e = (document.getElementById("ddlRole")) as HTMLSelectElement;
        //var sel = e.selectedIndex;
        //var opt = e.options[sel];
        //alert(sel);
        //var CurValue = (<HTMLSelectElement>opt).value;
        //var CurText = (<HTMLSelectElement>opt).text;

        let finalJsonString = jsonHeader + this.selectedRows + jsonFooter;
        //alert(finalJsonString);
        this.route.params.subscribe((params) => {
            let request = new PrivilegesRequest(
                finalJsonString
            );

            //alert(this.selectedRoleId);
            //alert(finalJsonString);
            this.isLoading = true;
            this.privilegesService.updatePrivileges(finalJsonString, this.selectedRoleId).subscribe(
                (response) => {
                    this.isLoading = false;
                    //this.user.markAsPristine();
                    this.privilegesForm.markAsPristine();
                    this.successMessage = 'Privileges has been successfully updated';
                    //alert(this.successMessage);
                    $(window).scrollTop(5);
                    //this.goBack();
                    location.reload();
                    //this.onRefresh(this.route.snapshot.params['customer_id'], 'privileges');
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                });
        });
        
    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        this.privilegesForm.markAsPristine();
        //this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
        //    (response) => {
        //        this.privilegesList = response;
        //        this.url.pushState(null, null, '/' + this.route.snapshot.params['customer_id'] + '/privileges', '');
        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });
        //this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'privileges']);
        this.router.navigate(['/', 'dashboard']);
    }

    selectAll() {
        
        for (var i = 0; i < this.privilegesList.length; i++) {
            this.privilegesList[i].status = this.selectedAll;
            this.privilegesList[i].view = this.selectedAll;
            this.privilegesList[i].add = this.selectedAll;
            this.privilegesList[i].edit = this.selectedAll;
            this.privilegesList[i].deleteAction = this.selectedAll;

            this.alterFewPermissions(i, this.selectedAll);
        }
    }
    checkIfAllSelected(rowIndex, selectedValue) {
        this.selectedAll = this.privilegesList.every(function (item: any) {
            return item.status == true;
        })

        this.alterFewPermissions(rowIndex, selectedValue);

    }

    alterFewPermissions(rowIndex, selectedValue)
    {
        if (this.selectedRoleId == 5 && this.privilegesList[rowIndex].moduleName != 'Privileges') { //customer user, add edit delete always zero due to  customer user has only readonly access except privileges
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = 0;
            this.privilegesList[rowIndex].delete = 0;
        }
        //else if (this.selectedRoleId == 5 && this.privilegesList[rowIndex].moduleName == 'Import Patient') { //customer user, remove import patient access
        //    this.privilegesList[rowIndex].view = 0;
        //    this.privilegesList[rowIndex].add = 0;
        //    this.privilegesList[rowIndex].edit = 0;
        //    this.privilegesList[rowIndex].delete = 0;
        //}
        else if ((this.selectedRoleId != 1 && this.privilegesList[rowIndex].moduleName == 'Privileges') || (this.selectedRoleId == 5 && this.privilegesList[rowIndex].moduleName == 'Import Patient')) { //other than medcon admin, for privileges module name, all permissions are zero
            //alert('second else' + this.privilegesList[rowIndex].moduleName);
            this.privilegesList[rowIndex].view = 0;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = 0;
            this.privilegesList[rowIndex].delete = 0;
        }
        else if (this.selectedRoleId == 1 && this.privilegesList[rowIndex].moduleName == 'Trials') { //For Medcon admin, restirct privileges to AddTrial
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = selectedValue;
            this.privilegesList[rowIndex].delete = selectedValue;
        }
        else if (this.selectedRoleId == 4 && this.privilegesList[rowIndex].moduleName != 'Import Patient' && this.privilegesList[rowIndex].moduleName != 'Export') { //label user
            this.privilegesList[rowIndex].view = 0;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = 0;
            this.privilegesList[rowIndex].delete = 0;
        }
        else if (this.privilegesList[rowIndex].moduleName == 'Broadcast Messages' ) { //for all user roles
            
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = selectedValue;
            this.privilegesList[rowIndex].edit = selectedValue;
            this.privilegesList[rowIndex].delete = 0;
        }
        else {
            //alert('else');
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = selectedValue;
            this.privilegesList[rowIndex].edit = selectedValue;
            this.privilegesList[rowIndex].delete = selectedValue;
        }

    }

    changeStatusCheckbox(id, permissionType, selectedValue, rowIndex) {
       
        //let id = rowIndex;
        //alert(id);
        //this.privilegesList[rowIndex].status = selectedValue;
        if (permissionType == 'View') {
            this.privilegesList[rowIndex].view = selectedValue;
            
        }
        else if (permissionType == 'Add') {
           
            this.privilegesList[rowIndex].add = selectedValue;
           
        }
        else if (permissionType == 'Edit') {
           
            this.privilegesList[rowIndex].edit = selectedValue;
           
        }
        else if (permissionType == 'Delete') {
           
            this.privilegesList[rowIndex].delete = selectedValue;
        }
        //alert('selectedValue' + selectedValue);
        //alert('view' + $('#chkViewPermission_' + id).is(":checked"));
        //alert('add' + $('#chkAddPermission_' + id).is(":checked"));
        //alert('edit' + $('#chkEditPermission_' + id).is(":checked"));
        //alert('delete' + $('#chkDeletePermission_' + id).is(":checked"));
        if (selectedValue == false && ($('#chkViewPermission_' + id).is(":checked") || $('#chkAddPermission_' + id).is(":checked") || $('#chkEditPermission_' + id).is(":checked") || $('#chkDeletePermission_' + id).is(":checked")))
        {
            this.privilegesList[rowIndex].status = true; //if any one of the checkbox(either add, view, edit , delete) selected, then flag is true

        }
        else
            this.privilegesList[rowIndex].status = selectedValue;

        if ((this.selectedRoleId == 5 && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Dashboard' && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Reports' && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Export' && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Import Patient' && permissionType == 'Add' && selectedValue == false)
        )
        {
            this.privilegesList[rowIndex].status = false;

        }

    }

    onChange(selectedValue) {
       
        this.selectedRoleId = Number(selectedValue);
        //alert(this.selectedRoleId);
        this.selectedRoleName = null;
        //To get selected role name
        if (this.allRoleList != null) {
            for (var i = 0; i < this.allRoleList.length; i++) {
                if (this.allRoleList[i].roleId == this.selectedRoleId) {
                    this.selectedRoleName = this.allRoleList[i].roleName;
                }
            }

        }


        //alert(selectedValue);
        this.selectedAll = false;
        if (selectedValue == 4) //"Label User"
        {

            //this.privilegesList=this.getPrivilegesByRoleId(Number(selectedValue));
            //this.privilegesList = [
            //    { id: 1, moduleName: 'Patient', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 2, moduleName: 'Data Reports', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 3, moduleName: 'Trials', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 4, moduleName: 'Trial Group', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 5, moduleName: 'Pharmaceutical Company', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 6, moduleName: 'Label Manufacturer', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 7, moduleName: 'Drugs', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 8, moduleName: 'Regimen', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 9, moduleName: 'Alerts', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 10, moduleName: 'Import', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 11, moduleName: 'Notifications', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 12, moduleName: 'Users', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //]
            this.isLoading = true;
            this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
                (response) => {
                    this.privilegesList = response;
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });

        }
        //else if ((selectedValue == "Customer Admin") || (selectedValue == "Trial Admin") || (selectedValue == "Customer User"))
        else if ((selectedValue == "2") || (selectedValue == "3") || (selectedValue == "5"))
        {
            //this.privilegesList=this.getPrivilegesByRoleId(Number(selectedValue));
            //this.privilegesList = [
            //    { id: 1, moduleName: 'Patient', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 2, moduleName: 'Data Reports', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 3, moduleName: 'Trials', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 4, moduleName: 'Trial Group', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 5, moduleName: 'Pharmaceutical Company', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 6, moduleName: 'Label Manufacturer', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 7, moduleName: 'Drugs', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 8, moduleName: 'Regimen', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 9, moduleName: 'Alerts', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 10, moduleName: 'Import', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 11, moduleName: 'Notifications', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 12, moduleName: 'Users', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //]
            this.isLoading = true;
            this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
                (response) => {
                    this.privilegesList = response;
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });

        
        }
        else if (selectedValue == "1") {  //Medcon Admin

            //this.privilegesList=this.getPrivilegesByRoleId(Number(selectedValue));

            //this.privilegesList = [
            //    { id: 1, moduleName: 'Patient', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 2, moduleName: 'Data Reports', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 3, moduleName: 'Trials', view: 1, add: 0, edit: 0, deleteAction: 0, selected: false },
            //    { id: 4, moduleName: 'Trial Group', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 5, moduleName: 'Pharmaceutical Company', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 6, moduleName: 'Label Manufacturer', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 7, moduleName: 'Drugs', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 8, moduleName: 'Regimen', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 9, moduleName: 'Alerts', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 10, moduleName: 'Import', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 11, moduleName: 'Notifications', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //    { id: 12, moduleName: 'Users', view: 1, add: 1, edit: 1, deleteAction: 1, selected: false },
            //]

            //this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
            //    (response) => {
            //        this.privilegesList = response;

            //    },
            //    (err) => {
            //        this.errorMessage = err;

            //    });

            this.privilegesList = this.privileges;

        }
    }

    public getPrivilegesByRoleId(roleId)
    {
        let privilegesListReturnJson: any;

        this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
            (response) => {
                privilegesListReturnJson = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        return privilegesListReturnJson;

    }

    public prepareJsonString()
    {
        [
            {
                "status": true,
                "moduleName": "Patient",
                "edit": 0,
                "add": 1,
                "view": 1,
                "id": 1,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Data Reports",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 2,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Trials",
                "edit": 0,
                "add": 0,
                "view": 1,
                "id": 3,
                "delete": 0
            },
            {
                "status": true,
                "moduleName": "Trial Group",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 4,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Pharmaceutical Company",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 5,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Label Manufacturer",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 6,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Drugs",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 7,
                "delete": 112
            },
            {
                "status": true,
                "moduleName": "Regimen",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 8,
                "delete": 111
            },
            {
                "status": true,
                "moduleName": "Alerts",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 9,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Schedules",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 10,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Import",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 11,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Notifications",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 12,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Users",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 13,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Customers",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 14,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Manage Customer Users",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 15,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "MCC Settings",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 16,
                "delete": 1
            }
        ]



    }

    onRefresh(companyId, viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId != '')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }
}
