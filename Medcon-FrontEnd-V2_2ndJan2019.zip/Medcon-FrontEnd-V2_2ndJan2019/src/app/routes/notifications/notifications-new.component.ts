﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { NotificationsService } from '../../services/notifications.service';
import { Notifications } from '../../models/notifications';
import { NotificationsRequest } from '../../requests/notifications-request';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
import { Privileges } from '../../models/privileges';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './notifications-new.component.html?v=${new Date().getTime()}',
    styleUrls: ['./trial-edit.component.scss?v=${new Date().getTime()}']
})

export class NotificationsNewComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('patientAlertsHelpModal') public patientAlertsHelpModal: ModalDirective;
    public Notifications: Pagination<Notifications>;
    public notificationToDelete: Notifications;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public showErrors: boolean;
    public selectedCustomerId: number;
    public successMessage: string;
    public trailList: any;
    public allTrailsList: any;
    public errorMessage: string;
    public notification: FormGroup;
    public trial: Notifications;
    public userId: number;
    privilegesByModule: any;
    privilegesList: any;
    selectedTrialId: number;
    selectedNotificationID: number;
    selectedNotificationIDToDelete: number;
    public selectedTrial: any;
    public trailId: number;
    //public trialGroupToDelete: BroadcastMessages;
    isNewForm: boolean;
    isEditForm: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    notificationsList: any;
    trialNotifications: any[];
    isLoading: boolean;
    loggedInUserId: number;
    public privileges: Privileges;
    selectedCompanyId: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        public router: Router,
        private reportService: ReportService,
        private NotificationsService: NotificationsService,
        private fb: FormBuilder,
        private cognitoUtil: CognitoUtil,
        private url: LocationStrategy) {

    }
    public goBack(): void {
        this.addNewEditCheckOptions();
        this.loadDefaultValues();

        $('#pnlNotificationTypeEmail').removeClass("btn-group selected").addClass("btn-group");
        $('#pnlNotificationTypeSMS').removeClass("btn-group selected").addClass("btn-group");
    }
    public addNewEditCheckOptions(): void {
        $('#missedDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlMissedDose').removeClass("btn-group selected").addClass("btn-group");
        $('#overDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlOverDose').removeClass("btn-group selected").addClass("btn-group");
        $('#lateDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlLateDose').removeClass("btn-group selected").addClass("btn-group");
        $('#underDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlUnderDose').removeClass("btn-group selected").addClass("btn-group");
        $('#excessiveManualDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlExcessiveManualDose').removeClass("btn-group selected").addClass("btn-group");


    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.Notifications = this.route.snapshot.data['Notifications'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.userId = this.route.snapshot.params['customer_id'];
        this.trailId = Number(this.route.snapshot.params['id'])
        this.trialNotifications = this.route.snapshot.data['notifications'];
        //alert(this.currentUserRole);
        //this.trialNotifications = [
        //    { id: 1, isMissedDoseSelected: false, missedDoseContent: 'Test missedDoseContent', missedDoseOccurances: '1', isOverDoseSelected: false, overDoseContent: 'Test content', overDoseOccurances: '1', isLateDoseSelected: false, lateDoseContent: 'Test content', lateDoseOccurances: '1', isUnderDoseSelected: false, underDoseContent: 'Test content', underDoseOccurances: '1', isExcessiveManualDoseSelected: false, excessiveManualDoseContent: 'Test content', excessiveManualDoseOccurances: '1' },

        //]
        this.loadDefaultValues();
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Notification')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }


        // this.selectedTrialId = 1;


        //if (this.currentUserRole === UserRole.MedConAdmin) {
        //    this.NotificationsService.getNotificationsList(this.selectedCustomerId)
        //        .subscribe((Notifications) => {
        //            this.Notifications = Notifications;

        //        }
        //        );
        //}

        this.notificationsList = [
            //{ notificationId: 1, userName: 'priya', email: 'welcome@smartims.com', trailName: 'TestGroup1', name: 'priya', numberOfSubscriptions: '90', NotificationType: 'Titrate' },
            //{ notificationId: 2, userName: 'Robort', email: 'world@world.com', trailName: 'TestGroup1', name: 'Robort', numberOfSubscriptions: '45', NotificationType: 'Broadcast' },
            //{ notificationId: 3, userName: 'Sachin', email: 'abc123@gmail.com ', trailName: 'TestGroup2', name: 'Sachin', numberOfSubscriptions: '10', NotificationType: 'Broadcast' },
            //{ notificationId: 4, userName: 'Jinga', email: 'happiness@h24s.com', trailName: 'TestGroup3', name: 'Jinga', numberOfSubscriptions: '65', NotificationType: 'Broadcast' },
        ]

        this.loggedInUserId = Number(localStorage.getItem("GLOBAL_LOGGED_IN_USER_ID"));
        this.selectedCompanyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));
    }



    public ngAfterViewInit(): void {
        //$('#datatable').DataTable();

        this.NotificationsService.getAllTrails(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrailsList = response;

            },
            (err) => {
                this.errorMessage = err;

            });




        this.addNewEditCheckOptions();
        this.newAndPopulateFormValues('');
    }

    public onSubmit(): void {
        this.showErrors = false;
        this.errorMessage = "";
        //alert(this.isNewForm);
        let notificationType;
        if (this.notification.value.chkNotificationTypeEmail && this.notification.value.chkNotificationTypeSMS) {
            notificationType = 3;
        }
        else if (this.notification.value.chkNotificationTypeSMS) {
            notificationType = 2;
        }
        else if (this.notification.value.chkNotificationTypeEmail) {
            notificationType = 1;
        }

        //Code added on 24th July 2018 to validate occurances value, if it is zero, then display validation error
        let isValid;
        isValid = true;
        let missedDoseChkValue = Number(this.notification.value.missedDose);
        let missedDoseOccurrence = Number(this.notification.value.missedDoseOccurrence);
        let overDoseChkValue = Number(this.notification.value.overDose);
        let overDoseOccurrence = Number(this.notification.value.overDoseOccurrence);
        let lateDoseChkValue = Number(this.notification.value.lateDose);
        let lateDoseOccurrence = Number(this.notification.value.lateDoseOccurrence);
        let underDoseChkValue = Number(this.notification.value.underDose);
        let underDoseOccurrence = Number(this.notification.value.underDoseOccurrence);
        let excessiveManualDoseChkValue = Number(this.notification.value.excessiveManualDose);
        let excessiveManualDoseOccurrence = Number(this.notification.value.excessiveManualDoseOccurrence);
        if ((missedDoseChkValue == 1 && missedDoseOccurrence == 0) || (overDoseChkValue == 1 && overDoseOccurrence == 0)
            || (lateDoseChkValue == 1 && lateDoseOccurrence == 0) || (underDoseChkValue == 1 && underDoseOccurrence == 0)
            || (excessiveManualDoseChkValue == 1 && excessiveManualDoseOccurrence == 0)) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please enter Occurrences value higher than zero";
            this.isLoading = false;
            $(window).scrollTop(5);
        }

        if (missedDoseChkValue == 0 && overDoseChkValue == 0
            && lateDoseChkValue == 0 && underDoseChkValue == 0
            && excessiveManualDoseChkValue == 0) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please select atleast one subscription";
            this.isLoading = false;
            $(window).scrollTop(5);
        }


        //End 24th July 2018


        if (this.notification.invalid) {
            this.showErrors = true;
            this.errorMessage = "Errors While Adding new Notifications";
        }
        else if (String(this.selectedTrialId) == 'NaN' || this.selectedTrialId == undefined) {

            this.showErrors = true;
            this.errorMessage = "Please Select Trial"
        }
        //else if ((this.isNewForm == false || this.isNewForm == undefined) && (this.isEditForm == false || this.isEditForm==undefined )) {

        //    this.showErrors = true;
        //    this.errorMessage = "Please Click on ADD New Notification button"
        //}
        

            //else {
            // TODO: NEED TO ADD COUNTRY SELECTOR TO THE VIEW
            //alert("New Notification");
            if (isValid) {
                //alert(this.isNewForm);
                //alert(Number(this.notification.value.overDose));
                this.isLoading = true;
                let request = new NotificationsRequest(
                    //this.route.snapshot.params['customer_id'],
                    this.notification.value.listOfTrails,
                    Number(this.notification.value.missedDose),
                    Number(this.notification.value.missedDoseOccurrence),
                    Number(this.notification.value.overDose),
                    Number(this.notification.value.overDoseOccurrence),
                    Number(this.notification.value.lateDose),
                    Number(this.notification.value.lateDoseOccurrence),
                    Number(this.notification.value.underDose),
                    Number(this.notification.value.underDoseOccurrence),
                    Number(this.notification.value.excessiveManualDose),
                    Number(this.notification.value.excessiveManualDoseOccurrence),
                    notificationType
                    // Number(this.userId)
                );
                this.NotificationsService.createNotifications(this.selectedTrialId, request).subscribe(
                    (response) => {
                        this.notification.markAsPristine();
                        this.isLoading = false;
                        this.successMessage = "Successfully Added ";
                        //this.notification.reset();
                        //location.reload();
                        //$("#datatable").dataTable().fnDestroy();
                       // this.loadNotificationList();
                        this.notification.reset();
                        this.clearDataCSS();
                        this.addNewEditCheckOptions();
                        this.back();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });

            }


       

        
    }




    

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public newAndPopulateFormValues(notificationObject) {

        this.isNewForm = true;

        this.loadDefaultValues();
        this.addNewEditCheckOptions();
        $('#pnlNotificationTypeEmail').removeClass("btn-group selected").addClass("btn-group");
        $('#pnlNotificationTypeSMS').removeClass("btn-group selected").addClass("btn-group");

    }

   

    public enablePanel(chkType, textBox1Id, divId) {
        //alert(chkType);
        let flag = (<HTMLInputElement>document.getElementById(chkType)).checked;
        let checkBoxId = chkType
        if (flag == true) {

            //$('#' + textBox1Id).prop('disabled', false);

            $('#' + textBox1Id).removeAttr('disabled');
            // $('#' + textBox2Id).prop('disabled', false);
            $('#' + divId).removeClass("btn-group").addClass("btn-group selected");

        }
        else {
            //$('#' + textBox1Id).prop('disabled', true);
            $('#' + textBox1Id).attr('disabled', 'disabled');
            //$('#' + textBox2Id).prop('disabled', true);
            $('#' + divId).removeClass("btn-group selected").addClass("btn-group");

        }



    }
    public deleteItem(id): void {
        this.selectedNotificationIDToDelete = id;
        this.deleteModal.show();
    }

    public hideDeleteModal(): void {
        this.notificationToDelete = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        let recordId = Number(localStorage.getItem('RECORD_ID'));
        this.NotificationsService
            .deleteNotifications(this.selectedNotificationIDToDelete, recordId)
            .subscribe(
            (response) => {

                this.successMessage = "successfully deleted";
                this.hideDeleteModal();
                location.reload();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }
    onChange_State(selectedValue) {
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;

        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }

    }

    
    public clearDataCSS() {
        $("#pnlMissedDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlOverDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlUnderDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlLateDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlExcessiveManualDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
    }



  

    enableAndDisableCSS(controlId, selectedValue) {
        //alert(selectedValue);
        if (selectedValue == false)
            $("#" + controlId).removeClass("btn-group selected").addClass("btn-group");
        else
            $("#" + controlId).removeClass("btn-group").addClass("btn-group selected");
    }
    public viewHelpSection(): void {

        this.patientAlertsHelpModal.show();
    }

    public hideHelpSection(): void {

        this.patientAlertsHelpModal.hide();
    }

    public loadDefaultValues(): void {

        this.notification = this.fb.group({

            listOfTrails: [''],
            missedDose: [''],
            txtMissedDose: [this.trialNotifications[0].message],
            missedDoseOccurrence: [''],
            overDose: [''],
            txtOverDose: [this.trialNotifications[1].message],
            overDoseOccurrence: [''],
            lateDose: [''],
            txtLateDose: [this.trialNotifications[2].message],
            lateDoseOccurrence: [''],
            underDose: [''],
            txtUnderDose: [this.trialNotifications[3].message],
            underDoseOccurrence: [''],
            excessiveManualDose: [''],
            txtExcesManualDose: [this.trialNotifications[4].message],
            excessiveManualDoseOccurrence: [''],
            chkNotificationTypeEmail: [''],
            chkNotificationTypeSMS: ['']
        });

    }

    public back(): void {
        this.isLoading = true;
        //this.form.markAsPristine();
        this.router.navigate(['/', this.selectedCompanyId, 'notifications']);
    }
}
