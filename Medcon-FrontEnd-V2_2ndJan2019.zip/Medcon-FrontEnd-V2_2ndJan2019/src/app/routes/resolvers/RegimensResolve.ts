import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RegimenService } from '../../services/regimen.service';
import { Pagination } from '../../models/pagination';
import { Regimen } from '../../models/regimen';

@Injectable()
export class RegimensResolve implements Resolve<(Pagination<Regimen>)> {
	constructor(private regimenService: RegimenService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(Pagination<Regimen>)>
		| Promise<(Pagination<Regimen>)>
		| (Pagination<Regimen>) {
		return this.regimenService
			.getRegimens(route.params['customer_id'], route.queryParams['page'], route.queryParams['perPage']);
	}
}
