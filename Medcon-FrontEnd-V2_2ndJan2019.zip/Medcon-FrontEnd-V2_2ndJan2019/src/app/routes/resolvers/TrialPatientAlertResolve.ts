﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialService } from '../../services/trial.service';
import { Trial } from '../../models/trial';
import { Pagination } from '../../models/pagination';
@Injectable()
export class TrialPatientAlertResolve implements Resolve<(Pagination<Trial>)> {
    constructor(private TrialService: TrialService) {
    }



    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<Trial>
        | Promise<(Pagination<TrialGroup>)>
        | Trial {
        return this.TrialService.getPatientAlerts(route.params['id'], Number(localStorage.getItem('GLOBAL_COMPANY_ID')));
    }



}
