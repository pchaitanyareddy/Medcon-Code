import { Component, HostListener, OnInit, ViewChild} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { ActivatedRoute, Router} from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { SettingsRequest } from '../../requests/settings-request';
import { SettingsService } from '../../services/settings.service';
import { CustomerService } from '../../services/customer.service';
import { Observable } from 'rxjs/Observable';
import { UserRole } from '../../models/userrole';
import { Settings } from '../../models/settings';
import { Pagination } from '../../models/pagination';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { LocationStrategy } from '@angular/common';
import { URLSearchParams } from '@angular/http';
import { NotificationsmsgsRequest } from '../../requests/notificationmsgs-request';
import { SettingsAlertMsgsRequest } from '../../requests/settingsAlertMsgs-request';
import { Customer } from '../../models/customer';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';

@Component({
    templateUrl: './settings-list.component.html?v=${new Date().getTime()}',
    styleUrls: ['./trial-edit.component.scss?v=${new Date().getTime()}']
})

export class SettingsListComponent implements OnInit {
    @ViewChild('settingsMenu') public settingsMenu: TabsetComponent;
    @ViewChild('patientAlertsHelpModal') public patientAlertsHelpModal: ModalDirective;
    public notification: FormGroup;
    public notificationTimezone: FormGroup;
    public customer: Customer;
    public notificationmsgs: FormGroup;
    public showErrors: boolean;
    public showErrors_TimeZone: boolean;
    public showErrors_AlertMsgs: boolean;
    public showErrors_NotificationMsgsTxt: boolean;
	public successMessage: string;
    public errorMessage: string;
    public days = [];
    public hours = [];
    public minutes = [];
    public currentPage: number = 1;
    public allTimeZone: any;
    isLoading: boolean;
    //public industryAdherenceBenchmark: number;
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public settings: Pagination<Settings>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    //public customers: Customer[];
    public selectedCustomerId: number;
    public notificationAlert: FormGroup;
    public notificationmsgstxt: FormGroup;
    public selectedTimeZone: string;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    alertMsgJsonString: string;
    notificationJsonString: string;
    userId: number;
    dosageWindowsJsonString: string;
    notificationList: any;
    alertsList: any;
    dosageList: any;
    meridiemList: any;
    timezoneList: any;
    selectedMeridiemValue: any;
    selectedTimeZoneValue: number;
    preDoseDays: number;
    preDoseHours: number;
    preDoseMinutes: number;
    thresholdDueAlertDays: number;
    thresholdDueAlertHours: number;
    thresholdDueAlertMinutes: number;
	constructor(public templateService: TemplateService,
		private fb: FormBuilder,
        private location: Location,
        private route: ActivatedRoute,
        private SettingsService: SettingsService,
        private router: Router,
       
     private url: LocationStrategy) {
        for (let i = 0; i < 31; i++) {
            this.days.push(i);
        }
        // Hours
        for (let i = 1; i <= 12; i++) {
            if (i < 10)
                this.hours.push('0' + String(i));
            else
                this.hours.push(i);
        }
        // Minutes
        for (let i = 0; i < 60; i++) {
            if (i < 10)
                this.minutes.push('0'+String(i));
            else
                this.minutes.push(i);
        }
    }

    public ngAfterViewInit(): void {


        this.isLoading = false;

    }


    public ngOnInit() {
        this.isLoading = false;
        //this.selectedTimeZoneValue = this.timezoneList.time;
        this.notificationList = this.route.snapshot.data['notifications'];
        this.privileges = this.route.snapshot.data['privileges'];
        this.alertsList = this.route.snapshot.data['alerts'];
        this.dosageList = this.route.snapshot.data['dosageWindow'];
        this.timezoneList = this.route.snapshot.data['timezone'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.settings = this.route.snapshot.data['settings'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        $(window).scrollTop(5);
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        
        this.meridiemList = [
            { meridiemId: 1, meridiemValue: 'AM' },
            { meridiemId: 2, meridiemValue: 'PM' }
        ]

        
        this.SettingsService.getTimeZone().subscribe(
            (response) => {
                this.allTimeZone = response;
                this.isLoading = false; //26th june 2018 to display progress bar

            },
            (err) => {
                this.errorMessage = err;

            });
      //alert(this.timezoneList[1].time);
        //alert(this.timezoneList.id);
        this.dosageWindow();
        this.InitializeAndResetTimeZone();
        //this.notificationTimezone = this.fb.group({

        //    timeZone: [this.timezoneList.time],
        //});


        this.InitializeAndResetAlerts();
        this.InitializeAndResetNotifications(); 
       
        this.notificationmsgs = this.fb.group({
            spnMissedDoseText: [this.notificationList[0].message],
        });

        //this.allTimeZone = this.SettingsService.getTimeZone();
        //this.selectedTimeZone = '(GMT-12:00) International Date Line West';

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Settings')

        if (Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID')) != null)
            this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));

       // alert(this.dosageList[0].to[0] + this.dosageList[0].to[1]);


        //28th Aug 2018

        setTimeout(() => {
            
            if (localStorage.getItem("selectedTab") === 'Dosage Window' || localStorage.getItem("selectedTab")===undefined) {
               
                this.settingsMenu.tabs[0].active = true;
            }
            else if (localStorage.getItem("selectedTab") === 'TimeZone') {

                this.settingsMenu.tabs[1].active = true;
            }
            else if (localStorage.getItem("selectedTab") === 'Alert') {

                this.settingsMenu.tabs[2].active = true;
            }
            else if (localStorage.getItem("selectedTab") === 'Notification') {

                this.settingsMenu.tabs[3].active = true;
            }
        });

        //End 28th Aug 2018
    }
    public dosageWindow() {
        let morningToSplit = this.dosageList[0].to;
        let toHours_Morning = morningToSplit.split(".")[0];
        let toMinutes_Morning = morningToSplit.split(".")[1].split(" ")[0];
        let toMeridiemValue_morning = morningToSplit.split(" ")[1];

        let morningFromSplit = this.dosageList[0].from;
        let fromHours_Morning = morningFromSplit.split(".")[0];
        let fromMinutes_Morning = morningFromSplit.split(".")[1].split(" ")[0];
        let fromMeridiemValue_morning = morningFromSplit.split(" ")[1];

        let afternoonFromSplit = this.dosageList[1].from;
        let fromHours_Afternoon = afternoonFromSplit.split(".")[0];
        let fromMinutes_Afternoon = afternoonFromSplit.split(".")[1].split(" ")[0];
        let fromMeridiemValue_Afternoon = afternoonFromSplit.split(" ")[1];

        let afternoonToSplit = this.dosageList[1].to;
        let toHours_Afternoon = afternoonToSplit.split(".")[0];
        let toMinutes_Afternoon = afternoonToSplit.split(".")[1].split(" ")[0];
        let toMeridiemValue_Afternoon = afternoonToSplit.split(" ")[1];

        let eveningFromSplit = this.dosageList[2].from;
        let fromHours_Evening = eveningFromSplit.split(".")[0];
        let fromMinutes_Evening = eveningFromSplit.split(".")[1].split(" ")[0];
        let fromMeridiemValue_Evening = eveningFromSplit.split(" ")[1];

        let eveningToSplit = this.dosageList[2].to;
        let toHours_Evening = eveningToSplit.split(".")[0];
        let toMinutes_Evening = eveningToSplit.split(".")[1].split(" ")[0];
        let toMeridiemValue_Evening = eveningToSplit.split(" ")[1];


        let bedtimeFromSplit = this.dosageList[3].from;
        let fromHours_Bedtime = bedtimeFromSplit.split(".")[0];
        let fromMinutes_Bedtime = bedtimeFromSplit.split(".")[1].split(" ")[0];
        let fromMeridiemValue_Bedtime = bedtimeFromSplit.split(" ")[1];

        let bedtimeToSplit = this.dosageList[3].to;
        let toHours_Bedtime = bedtimeToSplit.split(".")[0];
        let toMinutes_Bedtime = bedtimeToSplit.split(".")[1].split(" ")[0];
        let toMeridiemValue_Bedtime = bedtimeToSplit.split(" ")[1];
        //this.selectedTimeZoneValue = this.timezoneList.id;

        this.notification = this.fb.group({
            adherenceHours_Morning: [fromHours_Morning, Validators.required],
            adherenceMinutes_Morning: [fromMinutes_Morning],
            adherence_Morning: [fromMeridiemValue_morning],
            toAdherenceHours_Morning: [toHours_Morning],
            toAdherenceMinutes_Morning: [toMinutes_Morning],
            toAdherence_Morning: [toMeridiemValue_morning],
            adherenceHours_Afternoon: [fromHours_Afternoon, Validators.required],
            adherenceMinutes_Afternoon: [fromMinutes_Afternoon],
            adherence_Afternoon: [fromMeridiemValue_Afternoon],
            toAdherenceHours_Afternoon: [toHours_Afternoon],
            toAdherenceMinutes_Afternoon: [toMinutes_Afternoon],
            toAdherence_Afternoon: [toMeridiemValue_Afternoon],
            adherenceHours_Evening: [fromHours_Evening, Validators.required],
            adherenceMinutes_Evening: [fromMinutes_Evening],
            adherence_Evening: [fromMeridiemValue_Evening],
            toAdherenceHours_Evening: [toHours_Evening],
            toAdherenceMinutes_Evening: [toMinutes_Evening],
            toAdherence_Evening: [toMeridiemValue_Evening],
            adherenceHours_BedTime: [fromHours_Bedtime, Validators.required],
            adherenceMinutes_BedTime: [fromMinutes_Bedtime],
            adherence_BedTime: [fromMeridiemValue_Bedtime],
            toAdherenceHours_BedTime: [toHours_Bedtime],
            toAdherenceMinutes_BedTime: [toMinutes_Bedtime],
            toAdherence_BedTime: [toMeridiemValue_Bedtime],
        });

    }

    public submitTimeZone()
    {

        this.isLoading = true;
        let jsonString = '{\r\n   \"key\":\"timezone\",\r\n   \"value\":' + this.selectedTimeZoneValue+'\r\n}';
     
        this.SettingsService.updateTimeZone(jsonString).subscribe(
            (response) => {
                this.isLoading = false;
                this.notificationAlert.markAsPristine();
                this.successMessage = 'Settings Alerts Message have been successfully updated';
                $(window).scrollTop(5);
            },
            (err) => {
	        this.isLoading = false;
                this.errorMessage = err;
            });

    }

    public onSubmit() {
        let adherenceHours = (Number(this.notification.value.adherenceHours * 60));
        let adherenceMinutes = Number(this.notification.value.adherenceMinutes);
        if (this.notification.invalid) {
            this.showErrors = true;

        }
        else
        {
           
        }

    }


	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public goBack(): void {
        this.notification.markAsPristine();
        this.router.navigate(['/', 'dashboard']);
    }

    public isValidDosageWindowTimings(): boolean
    {
        this.isLoading = true;
            this.errorMessage = '';

            let fromMorningHrs = Number(this.notification.value.adherenceHours_Morning * 60);
            let fromMorningMins = Number(this.notification.value.adherenceMinutes_Morning);
            let fromAfternoonHrs = Number(this.notification.value.adherenceHours_Afternoon * 60);
            let fromAfternoonMins = Number(this.notification.value.adherenceMinutes_Afternoon);
            let totalFromAfternoonDuration = fromAfternoonHrs + fromAfternoonMins;

            let toMorningHrs = Number(this.notification.value.toAdherenceHours_Morning * 60);
            let toMorningMins = Number(this.notification.value.toAdherenceMinutes_Morning);
            let totalToMorningDuration = toMorningHrs + toMorningMins;
            
            

        

            let fromEveningHrs = Number(this.notification.value.adherenceHours_Evening * 60);
            let fromEveningMins = Number(this.notification.value.adherenceMinutes_Evening);
            let totalFromEveningDuration = fromEveningHrs + fromEveningMins;

            let toAfternoonHrs = Number(this.notification.value.toAdherenceHours_Afternoon * 60);
            let toAfternoonMins = Number(this.notification.value.toAdherenceMinutes_Afternoon);
            let totalToAfternoonDuration = toAfternoonHrs + toAfternoonMins;
        
            let fromBedTimeHrs = Number(this.notification.value.adherenceHours_BedTime * 60);
            let fromBedTimeMins = Number(this.notification.value.adherenceMinutes_BedTime);
            let totalFromBedTimeDuration = fromBedTimeHrs + fromBedTimeMins;

            let toEveningHrs = Number(this.notification.value.toAdherenceHours_Evening * 60);
            let toEveningMins = Number(this.notification.value.toAdherenceMinutes_Evening);
            let totalToEveningDuration = toEveningHrs + toEveningMins;

            if (totalFromAfternoonDuration < totalToMorningDuration) {
                this.isLoading = false;
                this.errorMessage = "Please select From Afternoon Time higher than To Morning Time";
                $(window).scrollTop(5);

            }
            else if (totalFromEveningDuration < totalToAfternoonDuration) {
                this.isLoading = false;
                this.errorMessage = "Please select From Evening Time higher than To Afternoon Time";
                $(window).scrollTop(5);

            }
            else if (totalFromBedTimeDuration < totalToEveningDuration) {
                this.isLoading = false;
                this.errorMessage = "Please select From Bed Time higher than To Afternoon Time";
                $(window).scrollTop(5);

            }

            //alert(String(fromAfternoonHrs));
            if (String(fromAfternoonHrs) == '0' && String(fromAfternoonMins) == '0' && String(toMorningHrs) == '0'
                && String(toMorningMins) == '0' && String(fromEveningHrs) == '0' && String(fromEveningMins) == '0'
                && String(toAfternoonHrs) == '0' && String(toAfternoonMins) == '0' && String(fromBedTimeHrs) =='0'
                && String(fromBedTimeMins) == '0' && String(toEveningHrs) == '0' && String(toEveningMins) == '0'
                && String(fromMorningHrs) == '0' && String(fromMorningMins) =='0'
            )
            {
                this.isLoading = false;
                this.errorMessage = "Please select proper timings";
                $(window).scrollTop(5);

            }

            if (this.errorMessage == undefined || this.errorMessage == '')
                return true
            else
                return false;
       
    }

    public submitTreshold(): void {
        if (this.notification.invalid) {
            
			this.showErrors = true;
        }
        else {
            this.isLoading = true;
            if (this.isValidDosageWindowTimings())
            {
                let fromMorning = this.notification.value.adherenceHours_Morning + '.' + this.notification.value.adherenceMinutes_Morning + ' ' + this.notification.value.adherence_Morning;
                let toMorning = this.notification.value.toAdherenceHours_Morning + '.' + this.notification.value.toAdherenceMinutes_Morning + ' ' + this.notification.value.toAdherence_Morning;
                let fromAfternoon = this.notification.value.adherenceHours_Afternoon + '.' + this.notification.value.adherenceMinutes_Afternoon + ' ' + this.notification.value.adherence_Afternoon;
                let toAfternoon = this.notification.value.toAdherenceHours_Afternoon + '.' + this.notification.value.toAdherenceMinutes_Afternoon + ' ' + this.notification.value.toAdherence_Afternoon;
                let fromEvening = this.notification.value.adherenceHours_Evening + '.' + this.notification.value.adherenceMinutes_Evening + ' ' + this.notification.value.adherence_Evening;
                let toEvening = this.notification.value.toAdherenceHours_Evening + '.' + this.notification.value.toAdherenceMinutes_Evening + ' ' + this.notification.value.toAdherence_Evening;
                let fromBedTime = this.notification.value.adherenceHours_BedTime + '.' + this.notification.value.adherenceMinutes_BedTime + ' ' + this.notification.value.adherence_BedTime;
                let toBedTime = this.notification.value.toAdherenceHours_BedTime + '.' + this.notification.value.toAdherenceMinutes_BedTime + ' ' + this.notification.value.toAdherence_BedTime;

                this.prepareDosageWindowJsonString(fromMorning, toMorning, fromAfternoon, toAfternoon, fromEvening, toEvening, fromBedTime, toBedTime);
                //alert(toMorning);
                this.SettingsService.updateDosageWindows(this.dosageWindowsJsonString).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.notification.markAsPristine();
                        this.successMessage = 'Settings for dosage window have been successfully updated';
                        $(window).scrollTop(5);
                    },
                    (err) => {
                        this.errorMessage = err;
                    });

            }
            

        }

    }

    //public prepareJsonString(preDoseTextContent, preDoseAlertTime,  onTimeDoseAlertTime,thresholdAlertTextContent, thresholdAlertTime,userId): void {

    //    this.alertMsgJsonString = "{\r\n   \"alertmessages\":[\r\n      {\r\n         \"type\":\"Pre Dose\",\r\n         \"message\":\"" + preDoseTextContent + "\",\r\n         \"alertTime\":\"" + preDoseAlertTime + "\"\r\n      },\r\n      {\r\n         \"type\":\"On Time Dose\",\r\n                 \"alertTime\":\"" + onTimeDoseAlertTime + "\"\r\n      },\r\n  {\r\n         \"type\":\"Threshold\",\r\n         \"message\":\"" + thresholdAlertTextContent + "\",\r\n         \"alertTime\":\"" + thresholdAlertTime + "\"\r\n      }\r\n   ],\r\n   \"userId\":"+userId+"\r\n}";

    //}
    public prepareJsonString(preDoseTextContent, preDoseAlertTime, onTimeDoseTextContent, onTimeDoseAlertTime, thresholdAlertTextContent, thresholdAlertTime, userId): void {

        this.alertMsgJsonString = "{\r\n   \"alertmessages\":[\r\n      {\r\n         \"type\":\"Pre Dose\",\r\n         \"message\":\"" + preDoseTextContent + "\",\r\n         \"alertTime\":\"" + preDoseAlertTime + "\"\r\n      },\r\n      {\r\n         \"type\":\"On Time Dose\",\r\n         \"message\":\"" + onTimeDoseTextContent + "\",\r\n         \"alertTime\":\"" + onTimeDoseAlertTime + "\"\r\n      },\r\n  {\r\n         \"type\":\"Threshold\",\r\n         \"message\":\"" + thresholdAlertTextContent + "\",\r\n         \"alertTime\":\"" + thresholdAlertTime + "\"\r\n      }\r\n   ],\r\n   \"userId\":" + userId + "\r\n}";

    }

    public prepareNotificationJsonString(missedDoseText, overDoseText, lateDoseText, underDoseText, excessiveManualDoses,userId): void {

        this.notificationJsonString = "{\r\n   \"notifications\":[\r\n      {\r\n         \"type\":\"MISSED DOSE\",\r\n         \"message\":\"" + missedDoseText + " \"\r\n      },\r\n      {\r\n         \"type\":\"OVERDOSE\",\r\n         \"message\":\"" + overDoseText + "\"\r\n      },\r\n      {\r\n         \"type\":\"LATE DOSE\",\r\n         \"message\":\"" + lateDoseText + "\"\r\n      },\r\n      {\r\n         \"type\":\"UNDER DOSE\",\r\n         \"message\":\"" + underDoseText + "\"\r\n      },\r\n      {\r\n         \"type\":\"EXCESSIVE MANUAL DOSES\",\r\n         \"message\":\"" + excessiveManualDoses + "\"\r\n      }\r\n   ],\r\n   \"userId\":"+userId+"\r\n}";

    }

    public prepareDosageWindowJsonString(from_Morning, to_Morning, from_Afternoon, to_Afternoon, from_Evening, to_Evening, from_BedTime, to_BedTime) {


        this.dosageWindowsJsonString = "{\r\n   \"dosagewindow\":[\r\n      {\r\n         \"window\":\"Morning\",\r\n         \"from\":\"" + from_Morning + "\",\r\n         \"to\":\"" + to_Morning + "\"\r\n      },\r\n      {\r\n         \"window\":\"Afternoon\",\r\n         \"from\":\"" + from_Afternoon + "\",\r\n         \"to\":\"" + to_Afternoon + "\"\r\n      },\r\n      {\r\n         \"window\":\"Evening\",\r\n         \"from\":\"" + from_Evening + "\",\r\n         \"to\":\"" + to_Evening + "\"\r\n      },\r\n      {\r\n         \"window\":\"Bedtime\",\r\n         \"from\":\"" + from_BedTime + "\",\r\n         \"to\":\"" + to_BedTime + "\"\r\n      }\r\n   ],\r\n   \"userId\":" + this.userId+"\r\n} ";

    }

    public submitAlert(): void {

        let preDoseAlertDurationDays = ((Number(this.notificationAlert.value.preDoseAlertDays * 24)) * 60);
        let preDoseAlertdurationHours = (Number(this.notificationAlert.value.preDoseAlertHours * 60));
        let preDoseAlertdurationMinutes = Number(this.notificationAlert.value.preDoseAlertMinutes);
        let preDoseAlertTime = preDoseAlertDurationDays + preDoseAlertdurationHours + preDoseAlertdurationMinutes;
        let thresholdDueAlertDurationDays = ((Number(this.notificationAlert.value.thresholdDueAlertDays * 24)) * 60);
        let thresholdDueAlertdurationHours = (Number(this.notificationAlert.value.thresholdDueAlertHours * 60));
        let thresholdDueAlertdurationMinutes = Number(this.notificationAlert.value.thresholdDueAlertMinutes);
        let thresholdDueAlertTime = thresholdDueAlertDurationDays + thresholdDueAlertdurationHours + thresholdDueAlertdurationMinutes;
        //alert(thresholdDueAlertTime);
        //alert(preDoseAlertTime);
        let onTimeDoseTime = 0;

        
        if (this.notificationAlert.invalid) {
            this.showErrors_AlertMsgs = true;
        } else {
            this.isLoading = true;
            let request = new SettingsAlertMsgsRequest(
                this.notificationAlert.value.thresholdDueAlert,
                thresholdDueAlertTime,
                this.notificationAlert.value.onTimeDoseAlert,
                this.notificationAlert.value.preDoseAlert,
                preDoseAlertTime
            );

            this.prepareJsonString(this.notificationAlert.value.preDoseAlert, preDoseAlertTime, this.notificationAlert.value.onTimeDoseAlert, onTimeDoseTime, this.notificationAlert.value.thresholdDueAlert, thresholdDueAlertTime, this.userId);
            
            this.SettingsService.createSettingsAlert(this.alertMsgJsonString, Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.notificationAlert.markAsPristine();
                    this.successMessage = 'Settings Alerts Message have been successfully updated';
                    $(window).scrollTop(5);
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                    $(window).scrollTop(5);
                });
        }

    }

    public submitMessagestxt(): void {

        if (this.notificationmsgstxt.invalid) {
            this.showErrors_NotificationMsgsTxt = true;
        } else {
            this.isLoading = true;
            let request = new NotificationsmsgsRequest(
                this.notificationmsgstxt.value.txtMissedDose,
                this.notificationmsgstxt.value.txtOverDose,
                this.notificationmsgstxt.value.txtLateDose,
                this.notificationmsgstxt.value.txtUnderDose,
                this.notificationmsgstxt.value.txtExcessDose,
                this.notificationmsgstxt.value.txtthreshold
            );
           
            
            this.prepareNotificationJsonString(this.notificationmsgstxt.value.txtMissedDose, this.notificationmsgstxt.value.txtOverDose, this.notificationmsgstxt.value.txtLateDose, this.notificationmsgstxt.value.txtUnderDose, this.notificationmsgstxt.value.txtExcessDose, Number(this.userId))
            this.SettingsService.createSettingsNotificationMsgs(this.notificationJsonString).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.notificationmsgstxt.markAsPristine();
                    this.successMessage = 'Settings have been successfully updated';
                    $(window).scrollTop(5);
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                });
        }
    }


	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
        return !this.notification.dirty;
    }
    
    public customerChanged(): void {
        this.SettingsService.getSettingsList(this.selectedCustomerId).subscribe((setting) => {
            this.settings = setting;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/settings', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.SettingsService.getSettingsList(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((setting) => {
            this.settings = setting;
        });
    }
    

    onChange(selectedValue) {
        this.selectedTimeZoneValue = Number(selectedValue);
        
    }


    onChange_ToHrs(selectedValue,window) {
        //this.selectedTimeZoneValue = Number(selectedValue);
        if (window == 'Morning')
        {
            let fromMorningHrs = Number(this.notification.value.adherenceHours_Morning);

            if (Number(selectedValue) < fromMorningHrs)
            {
                this.errorMessage = "Please select To hours that should be higher than From hours";
                $(window).scrollTop(5);

            }
        } 
        else if (window == 'Afternoon') {

            let fromAfternoonHrs = Number(this.notification.value.adherenceHours_Afternoon);

            if (fromAfternoonHrs!=12 && Number(selectedValue) < fromAfternoonHrs) {
                this.errorMessage = "Please select To hours that should be higher than From hours";
                $(window).scrollTop(5);

            }

        } 
        else if (window == 'Evening') {

            let fromEveningHrs = Number(this.notification.value.adherenceHours_Evening);

            if (Number(selectedValue) < fromEveningHrs) {
                this.errorMessage = "Please select To hours that should be higher than From hours";
                $(window).scrollTop(5);

            }

        }
        else if (window == 'BedTime') {

            let fromBedtimeHrs = Number(this.notification.value.adherenceHours_BedTime);

            if (Number(selectedValue) < fromBedtimeHrs) {
                this.errorMessage = "Please select To hours that should be higher than From hours";
                $(window).scrollTop(5);

            }
        }

    }

    onChange_FromMins(selectedValue, window,dropDownType) {
        //this.selectedTimeZoneValue = Number(selectedValue);
        
         if (window == 'Afternoon') {

             let fromAfternoonHrs = (dropDownType == 'Hours') ? Number(selectedValue*60):Number(this.notification.value.adherenceHours_Afternoon * 60);
             let fromAfternoonMins = (dropDownType == 'Mins') ? Number(selectedValue) :Number(this.notification.value.adherenceMinutes_Afternoon);
             let totalFromAfternoonDuration = fromAfternoonHrs + fromAfternoonMins;

             let toMorningHrs = Number(this.notification.value.toAdherenceHours_Morning * 60);
             let toMorningMins = Number(this.notification.value.toAdherenceMinutes_Morning);
             let totalToMorningDuration = toMorningHrs + toMorningMins;
             //alert(selectedValue);
             //alert('totalFromAfternoonDuration' + totalFromAfternoonDuration);
             //alert('totalToMorningDuration' + totalToMorningDuration);
             if (totalFromAfternoonDuration < totalToMorningDuration) {
                this.errorMessage = "Please select From Afternoon Time higher than To Morning Time";
                $(window).scrollTop(5);

            }

        }
        else if (window == 'Evening') {

             let fromEveningHrs = (dropDownType == 'Hours') ? Number(selectedValue*60) :Number(this.notification.value.adherenceHours_Evening * 60);
             let fromEveningMins = (dropDownType == 'Mins') ? Number(selectedValue) :Number(this.notification.value.adherenceMinutes_Evening);
             let totalFromEveningDuration = fromEveningHrs + fromEveningMins;

             let toAfternoonHrs = Number(this.notification.value.toAdherenceHours_Afternoon * 60);
             let toAfternoonMins = Number(this.notification.value.toAdherenceMinutes_Afternoon);
             let totalToAfternoonDuration = toAfternoonHrs + toAfternoonMins;

             if (totalFromEveningDuration < totalToAfternoonDuration) {
                 this.errorMessage = "Please select From Evening Time higher than To Afternoon Time";
                 $(window).scrollTop(5);

             }

        }
        else if (window == 'BedTime') {

             let fromBedTimeHrs = (dropDownType == 'Hours') ? Number(selectedValue*60) :Number(this.notification.value.adherenceHours_BedTime * 60);
             let fromBedTimeMins = (dropDownType == 'Mins') ? Number(selectedValue) : Number(this.notification.value.adherenceMinutes_BedTime);
             let totalFromBedTimeDuration = fromBedTimeHrs + fromBedTimeMins;

             let toEveningHrs = Number(this.notification.value.toAdherenceHours_Evening * 60);
             let toEveningMins = Number(this.notification.value.toAdherenceMinutes_Evening);
             let totalToEveningDuration = toEveningHrs + toEveningMins;

             if (totalFromBedTimeDuration < totalToEveningDuration) {
                 this.errorMessage = "Please select From BedTime Time higher than To Evening Time";
                 $(window).scrollTop(5);

             }
        }

    }

    private convertMinutes(totalMinutes: number): any {
        let minsPerDay = 24 * 60;
        let minsPerHour = 60;
        let minutes = totalMinutes;
        let converted = { days: null, hours: null, minutes: null };

        let days = Math.floor(minutes / minsPerDay);
        converted.days = days;
        minutes = minutes - days * minsPerDay;
        let hours = Math.floor(minutes / minsPerHour);
        converted.hours = hours;
        minutes = minutes - hours * minsPerHour;
        converted.minutes = minutes;

        return converted;
    }
    public viewHelpSection(): void {

        this.patientAlertsHelpModal.show();
    }

    public hideHelpSection(): void {

        this.patientAlertsHelpModal.hide();
    }
    public clearDosageData() {

        this.notification.reset();
        this.errorMessage = '';
        this.dosageWindow();
        //this.ngOnInit();
    }

    public InitializeAndResetTimeZone()
    {
        this.notificationTimezone = this.fb.group({

            timeZone: [this.timezoneList.time],
        });
        this.selectedTimeZoneValue = this.timezoneList.id;
    }

    public InitializeAndResetAlerts()
    {
        let preDoseAlertDuration = this.convertMinutes(this.alertsList[1].time);
        let thresholdDueAlertTimeDuration = this.convertMinutes(this.alertsList[2].time);

        let preDoseDays = preDoseAlertDuration.days;
        let preDoseHours = preDoseAlertDuration.hours;
        let preDoseMinutes = preDoseAlertDuration.minutes;

        let thresholdDueAlertDays = thresholdDueAlertTimeDuration.days;
        let thresholdDueAlertHours = thresholdDueAlertTimeDuration.hours;
        let thresholdDueAlertMinutes = thresholdDueAlertTimeDuration.minutes;

        //19th July 2018

        this.preDoseDays = preDoseDays;
        this.preDoseHours = preDoseHours;
        this.preDoseMinutes = preDoseMinutes;

        this.thresholdDueAlertDays = thresholdDueAlertDays;
        this.thresholdDueAlertHours = thresholdDueAlertHours;
        this.thresholdDueAlertMinutes = thresholdDueAlertMinutes;
        //End

        //alert('predose' + this.alertsList[1].message);
        //alert('ontime' + this.alertsList[0].message);
        //alert('on time ' + this.alertsList[0].time);
        //alert('preDose time ' + this.alertsList[1].time);
        //alert('threshold time ' + this.alertsList[2].time);
        this.notificationAlert = this.fb.group({

            //thresholdAlert: [this.alertsList[2].time],
            //txtOntimeDose: [this.alertsList[1].message],
            //txtPreDose: [this.alertsList[0].message],
            //txtthreshold: [this.alertsList[2].message],
            //onTimeDoseAlert: [this.alertsList[1].time],
            //preDoseAlert: [this.alertsList[0].time],

            preDoseAlertDays: [preDoseDays],
            preDoseAlertHours: [preDoseHours],
            preDoseAlertMinutes: [preDoseMinutes],
            thresholdDueAlertDays: [thresholdDueAlertDays],
            thresholdDueAlertHours: [thresholdDueAlertHours],
            thresholdDueAlertMinutes: [thresholdDueAlertMinutes],
            preDoseAlert: [this.alertsList[1].message],
            onTimeDoseAlert: [this.alertsList[0].message],
            thresholdDueAlert: [this.alertsList[2].message]
        });

    }

    public InitializeAndResetNotifications()
    {
        this.notificationmsgstxt = this.fb.group({

            txtMissedDose: [this.notificationList[0].message],
            txtOverDose: [this.notificationList[1].message],
            txtLateDose: [this.notificationList[2].message],
            txtUnderDose: [this.notificationList[3].message],
            txtExcessDose: [this.notificationList[4].message],
            txtthreshold: [''],
        });

    }

    setSelectedTab(tab)
    {

        localStorage.setItem("selectedTab", tab);
    }
    
}
