import { Injectable } from '@angular/core';
import {
	Http,
	Headers,
	RequestOptionsArgs,
	Request,
	Response,
	ConnectionBackend,
	RequestOptions
} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { CognitoUtil } from './cognito/cognitoutil.service';

declare var AWS: any;

export interface HttpRequestData {
	url: string | Request;
	options?: RequestOptionsArgs;
	body?: any;
	cancelRequest?: boolean;
}
@Injectable()
export class HttpService extends Http {
	constructor(protected _backend: ConnectionBackend, protected _defaultOptions: RequestOptions,
		protected cognito: CognitoUtil) {
		super(_backend, _defaultOptions);
	}

    public request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
        
		const requestWithAuthorization = Observable.fromPromise(this.requestWithToken({ url, options }));

		const response = Observable.from(requestWithAuthorization).flatMap((data) => {
			return super.request(data.url, data.options);
		});
        
		return response;
	}

    private requestWithToken(data: HttpRequestData): Promise<HttpRequestData> {
        
		return new Promise((resolve) => {
			this.cognito.getIdToken({
				callback() {
					/* tslint:disable:no-empty */
				},
				callbackWithParam(token: any) {
					if (typeof data.url === 'string') {
						if (data.url.startsWith(API_PATH)) {
							if (!data.options) {
								data.options = { headers: new Headers() };
							}
							data.options.headers.set('Authorization', token);
                        }
                        data.options.headers.set('Authorization', token);
					} else {
						if (data.url.url.startsWith(API_PATH)) {
							// we have to add the token to the url object
							data.url.headers.set('Authorization', token);
                        }
                        data.url.headers.set('Authorization', token);
					}

					resolve(data);
				}
			});
		});
	}
}
