export class PairDrugRegimenRequest {
	constructor(public drugId: number,
        public regimenId: number,
        //public expiryDate: string,
        public startDateDrugRegimenPair: string,
        public endDateDrugRegimenPair: string,
        public userId: number,
        public companyId: number,
        public drugRegimenPairId?:number
    ) {
	}
}
