export class SiteRequest {
    constructor(public userId: number,
        public siteName: string,
        public address: string,
        public country_id: number,
        public state_id: number,
        public city_name: string,
        public zipcode: number,
        //public state: string,
        //public country: string,
        public phone_number: string) {
    }
}

