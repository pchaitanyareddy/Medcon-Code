export class UserPreferenceRequest {
	constructor(public metaKey: string,
		public metaValue: any) {
	}
}
