﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { BroadcastMessagesRequest } from '../../requests/broadcastMessages-request';
import { BroadcastMessagesEditRequest } from '../../requests/broadcastMessagesEdit-request';
import { BroadcastMessagesService } from '../../services/broadcastMessages.service';
import { BroadcastMessages } from '../../models/broadcastMessages';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './broadcast-Message-edit.component.html?v=${new Date().getTime()}'
})

export class BroadcastMessagesEditComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public Broadcastmsgs: Pagination<BroadcastMessages>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public showErrors: boolean;
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public allTrailsList: any;
    public broadcastmsgs: FormGroup;
    selectedTrialId: number;
    selectedBroadcastId: number;
    public selectedTrial: any;
    public trailId: number;
    //public trialGroupToDelete: BroadcastMessages;
    isEditForm: boolean;
    messageResponse: any;
    broadcastMessage: any;
    public maxSize: number = 5;
    public currentPage: number = 1;
    broadcastMessageList: any;
    privilegesByModule: any;
    privilegesList: any;
    selectedCompanyId: number;
    public privileges: Privileges;
    isLoading: boolean;
    constructor(
        public router: Router,
        private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private BroadcastMessagesService: BroadcastMessagesService,
        private reportService: ReportService,
        private fb: FormBuilder,
        private cognitoUtil: CognitoUtil,
        private url: LocationStrategy) {



    }
    
    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.Broadcastmsgs = this.route.snapshot.data['BroadcastMessages'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.trailId = Number(this.route.snapshot.params['id'])
        this.broadcastMessage = this.route.snapshot.data['broadcastMessage'];

        //alert(this.selectedTrialId);

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }
        this.selectedTrialId = this.broadcastMessage.trialId;
        this.broadcastmsgs = this.fb.group({
            messageTitle: [this.broadcastMessage.messageTitle, Validators.required],
            broadcastMessage: [this.broadcastMessage.broadcastMessage, Validators.required],
            listOfTrails: [this.selectedTrialId],
        });

        //alert(this.selectedTrialId);
        if (this.currentUserRole === UserRole.MedConAdmin) {
            this.BroadcastMessagesService.getBroadcastMessageList(this.selectedCustomerId)
                .subscribe((BroadcastMessages) => {
                    this.Broadcastmsgs = BroadcastMessages;

                }
                );
        }

        this.broadcastMessageList = [

        ]

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Broadcast Messages')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);

        this.BroadcastMessagesService.getAllTrails((localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrailsList = response;

            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;

            });
        this.selectedCompanyId = localStorage.getItem("GLOBAL_COMPANY_ID");
        

    }

    

    public onSubmit() {

        if (this.broadcastmsgs.invalid) {
            this.showErrors = true;

        }
        else if (String(this.selectedTrialId) == 'NaN' || this.selectedTrialId == undefined) {

            this.showErrors = true;
            this.errorMessage = "Please Select Trial Name"
        }
        else {
            this.isLoading = true;

            let request = new BroadcastMessagesRequest(
                this.selectedTrialId,
                this.broadcastmsgs.value.messageTitle,
                this.broadcastmsgs.value.broadcastMessage,
                Number((localStorage.getItem('GLOBAL_COMPANY_ID')))

            );

            $('#btnSubmit').attr('disabled', true);
            this.BroadcastMessagesService.createBroadcastMessages(request).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.broadcastmsgs.markAsPristine();

                    //this.broadcastMessageList = this.BroadcastMessagesService.getBroadcastMessages(1);
                    this.successMessage = "successfully Updated";
                    $(window).scrollTop(5);
                    this.broadcastmsgs.reset();
                    this.back();
                    $("#datatable").dataTable().fnDestroy();
                    // this.ngAfterViewInit();
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                });
        }
    }


    public customerChanged(): void {
        this.BroadcastMessagesService.getBroadcastMessageList(this.selectedCustomerId).subscribe((BroadcastMessages) => {
            this.Broadcastmsgs = BroadcastMessages;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/broadcast-Messages', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.BroadcastMessagesService.getBroadcastMessageList(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((BroadcastMessages) => {
            this.Broadcastmsgs = BroadcastMessages;
        });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
    
    onChange_State(selectedValue) {
        //alert(this.selectedTrialId);
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;
        //alert(this.selectedTrialId);

        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }

    }

    public back() {
        this.isLoading = true;
        this.router.navigate(['/', this.selectedCompanyId, 'broadcast-Messages']);
    }


    public goBack() {
        this.broadcastmsgs.reset();
        $('#btnSubmit').text('Submit');
        this.showErrors = false;
        this.errorMessage = '';
        $("#error_messageTitle").html("");
        $("#error_addcomment").html("");
        $('#btnSubmit').attr('disabled', false);
    }


}
