import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { PatientService } from '../../services/patient.service';
import { PatientRequest } from '../../requests/patient-request';
import { Patient } from '../../models/patient';
import { Race } from '../../models/race';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './patient-edit.component.html'
})

export class PatientEditComponent implements OnInit {
	public showErrors: boolean;
	public form: FormGroup;
	public races: Race[];
	public patient: Patient;
	public successMessage: string;
	public errorMessage: string;
	public disabled: boolean;
	public trialId: number;
	public myDatePickerOptions: IMyOptions = {
		dateFormat: 'mm/dd/yyyy',
	};

	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private router: Router,
		private fb: FormBuilder,
		private patientService: PatientService) {
	}

	public ngOnInit() {
		this.trialId = this.route.snapshot.queryParams['trial_id'];
		this.patient = this.route.snapshot.data['patient'];
		this.races = this.route.snapshot.data['races'];

		let race = (this.patient.race) ? this.patient.race.id : '';
		let dob: any = this.dateForView(this.patient.dob);

		// Disable fields if patient has scanned a container
		if (this.patient.firstScan !== null) {
			this.disabled = true;
		}

		this.form = this.fb.group({
			patientId: [this.patient.patientNumber, Validators.required],
			dob: [dob],
			race: [race],
			sex: [this.patient.sex, Validators.pattern('male|female')]
		});
	}

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
		} else {
			let request = new PatientRequest(
				(!this.disabled) ? this.form.value.patientId : null,
				null,
				this.form.value.sex,
				this.form.value.race,
				this.convertDate(this.form.value.dob.date)
			);

			this.patientService
				.updatePatient(this.patient.id, request, this.route.snapshot.params['customer_id'])
				.subscribe(
					(response) => {
						this.form.markAsPristine();
						this.successMessage = 'Patient has been successfully updated';
					},
					(err) => {
						this.errorMessage = err;
					}
				);
		}
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate([
			this.route.snapshot.params['customer_id'],
			'trials',
			this.trialId,
			'edit'
		], { queryParams: { tab: 'patients' } });
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

	private convertDate(date: any): string {
		return (date) ? date.year + '-' + date.month + '-' + date.day : '';
	}

	private dateForView(date: string): any {
		let stripZero = ((value) => {
			return (value < 9) ? value.replace('0', '') : value;
		});

		if (date) {
			let d = date.split('-');
			return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
		} else {
			return '';
		}
	}
}
