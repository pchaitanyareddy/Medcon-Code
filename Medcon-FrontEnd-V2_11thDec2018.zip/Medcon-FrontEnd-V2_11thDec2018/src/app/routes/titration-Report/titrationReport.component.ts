﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../../services/customer.service';
import { SiteService } from '../../services/site.service';
import { LabelReport } from '../../models/labelReport';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CompanyService } from '../../services/company.service';
import { TrialService } from '../../services/trial.service';
import { DrugService } from '../../services/drug.service';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
import { NotificationsService } from '../../services/notifications.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './titrationReport.component.html?v=${new Date().getTime()}'
})

export class TitrationReportComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public labelReport: Pagination<LabelReport>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public labelReportsForm: FormGroup;
    public companyList: any;
    public companyListFiltered: any;
    public drugList: any;
    public drugListFiltered: any;
    public regimenList: any;
    public regimenListFiltered: any;
    public maxSize: number = 5;
    public currentPage: number = 1;
    titrateReportsForm: any;
    privilegesByModule: any;
    privilegesList: any;
    selectedTrialGroupId: number;
    selectedTrialGroupName: string;
    allTrialGroupList: any;
    public allTrailsList: any;
    public allTrailsList1: any;
    public selectedTrialId: number;
    public selectedTrial: string;
    public allDrugList: any;
    public allRegimenList: any;
    public selectedRegimenId: number;
    public selectedRegimen: string;
    public selectedDrugId: number;
    public selectedDrug: string;
    public allTrailsListFiltered: any;
    public privileges: Privileges;

    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public selectedCompanyId: number;
    public isLoading: boolean;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private SiteService: SiteService,
        private cognitoUtil: CognitoUtil,
        private fb: FormBuilder,
        public companyService: CompanyService,
        public drugService: DrugService,
        public trialService: TrialService,
        public reportService: ReportService,
        private notificationsService: NotificationsService,
        private url: LocationStrategy) {


    }

    public ngOnInit(): void {
        //alert(GLOBAL_COMPANY_ID);
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];

        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        //this.companyService.getAllCompanies().subscribe(
        //    (response) => {
        //        this.companyList = response;
        //        //alert(this.loggedInUserRole);
        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });


        //this.drugService.getAllDrug(GLOBAL_COMPANY_ID).subscribe(
        //this.drugService.getAllDrug(localStorage.getItem('GLOBAL_COMPANY_ID')).subscribe(
        //    (response) => {
        //        this.drugList = response;
                
        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    }
        //);

        //this.trialService.getAllRegimens(localStorage.getItem('GLOBAL_COMPANY_ID')).subscribe(
        //    (response) => {
        //        this.regimenList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    }
        //);

        //this.notificationsService.getAllTrails(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
        //    (response) => {
        //        this.allTrailsList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });

        this.titrateReportsForm = this.fb.group({

            fromDate: ['', Validators.required],
            toDate: ['', Validators.required],
            trialName: ['', Validators.required],
            drug: ['', [Validators.required]],
            regimen: ['', [Validators.required]],
            doseType: ['', [Validators.required]],
            trialGroup: ['', [Validators.required]],
        });


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Data Reports')

        this.loadAllDropdowns();

        
    }

    loadAllDropdowns()
    {
        this.trialService.getAllTrialGroupsDropDownForTritration(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                if ($('#trialName').val() != 'Select' && $('#trialName').val()!=null) {
                    this.notificationsService.getSelectedDrugFromTrial(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number($('#trialName').val())).subscribe(
                        (response) => {
                            //alert(this.selectedTrialGroupId);

                            this.allDrugList = response;
                            this.isLoading = false;
                        },
                        (err) => {
                            this.errorMessage = err;
                            this.isLoading = false;
                        });
                }
                else {
                    this.allDrugList = response.drugname;
                    this.isLoading = false;
                }
                this.allRegimenList = response.regimen;
                this.allTrialGroupList = response.trialgroups;
                if ($('#trialGroup').val() != 'Select' && $('#trialGroup').val()!=null) {
                    this.notificationsService.getSelectedTrailsFromTrialGroupForTitrateReport(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number($('#trialGroup').val())).subscribe(
                        (response) => {
                            //alert(this.selectedTrialGroupId);
                            this.allTrailsList1 = response;
                            this.isLoading = false;
                        },
                        (err) => {
                            this.errorMessage = err;
                            this.isLoading = false;
                        });
                }
                else {
                    this.allTrailsList1 = response.trialname;
                    this.isLoading = false;
                }

            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

    }

    public loadTitrationReport(submitType): void {
        let isValid = true;
        let fromDate = '';
        let toDate = '';
        let company = '';
        let drug = '';
        let regimen = '';
        let doseType = '';
        let url = '';
        let companyIds = '';
        var arrCompanyIds;
        let drugIds = '';
        var arrDrugIds;
        var arrRegimenIds;
        let regimenIds = '';
        let companyIdGobalID = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        let trialName = '';
        let trialIds = '';
        var selectedTrials;
        let pageLength = 0;
        if (submitType == 'buttonClick') {
            //pageLength = Number($("select[name='datatable_length'] option:selected").text());
            pageLength = $("select[name='datatable_length'] option:selected").text();
            pageLength = ($("select[name='datatable_length'] option:selected").text() == 'All' ? -1 : Number($("select[name='datatable_length'] option:selected").text()));
            $("#datatable").dataTable().fnDestroy();
            fromDate = this.convertDate(this.titrateReportsForm.value.fromDate.date);
            toDate = this.convertDate(this.titrateReportsForm.value.toDate.date);
            trialIds = ($("#trialName").val() == null || $("#trialName").val() == 'Select') ? '' : $("#trialName").val(); // String(this.selectedTrialId);
            doseType = (this.titrateReportsForm.value.doseType == 'Select') ? '' : this.titrateReportsForm.value.doseType;           
            drugIds = ($("#drug").val() == null || $("#drug").val() == 'Select') ? '' : $("#drug").val();
            regimenIds = ($("#regimen").val() == null || $("#regimen").val() == 'Select') ? '' : $("#regimen").val();
            let trialGroupIds = $("#trialGroup").val();
            if (trialGroupIds == null || trialGroupIds == 'NaN') trialGroupIds = '';
            
            if (drugIds == null || drugIds == 'NaN') drugIds = '';
            if (regimenIds == null || regimenIds == 'NaN') regimenIds = '';
            if (trialIds == null || trialIds == 'NaN') trialIds = '';
            var startDate1 = new Date(fromDate);
            var endDate1 = new Date(toDate);
            var todayDate = new Date();
            if (startDate1 > endDate1) {

                this.errorMessage = "From Date should be Less than To Date";

            }
            if (fromDate != '' && toDate == '') {
                this.errorMessage = "Please Select To Date"
            }
            else if (fromDate == '' && toDate != '') {
                this.errorMessage = "Please Select From Date"
            }
            
                isValid = true;
                
                
                if (fromDate == '' && toDate == '' && ($("#trialGroup").val() == null || $("#trialGroup").val() == 'Select')
                    && ($("#trialName").val() == null || $("#trialName").val() == 'Select')
                    && ($("#drug").val() == null || $("#drug").val() == 'Select')
                    && ($("#regimen").val() == null || $("#regimen").val() == 'Select')
                    && ($("#doseType").val() == null || $("#doseType").val() == 'Select'))
                {       
                    url = CommonService.API_PATH_V2_TITRATE_REPORT + 'reports/titratereport?companyIds=' + companyIdGobalID;
                }
                else
                {

                    url = CommonService.API_PATH_V2_TITRATE_REPORT + 'reports/titratereport?companyIds=' + companyIdGobalID + '&drugIds=' + drugIds + '&regimenIds=' + regimenIds + '&doseType=' + doseType + '&startdate=' + fromDate + '&enddate=' + toDate + '&trialGroupIds=' + trialGroupIds + '&trialIds=' + trialIds;
                }

            }
       


            

        
        else {
            
            //url = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/reports/titratereport?companyIds=' + companyIdGobalID
            //url = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/reports/titratereport';
            url = CommonService.API_PATH_V2_TITRATE_REPORT + 'reports/titratereport?companyIds=' + companyIdGobalID;
        }
        if (isValid) {
            var self = this;
            this.cognitoUtil.getIdToken({
                callback() {
                    /* tslint:disable:no-empty */
                },
                callbackWithParam(token: any) {

                    this.authorizationToken = token;
                    //alert(this.authorizationToken);
                    $('#datatable').DataTable({
                        "processing": true,
                        "serverSide": true,
                        'ajax': {
                            'url': url,
                            'type': 'GET',
                            'beforeSend': function (request) {
                                request.setRequestHeader("Authorization", token);
                            }
                        },
                        dom: 'lBfrtip',
                        buttons: [
                            {
                                extend: 'csv', text: 'Export', exportOptions: {
                                    columns: [0, 1, 2, 3]
                                },
                                
                                    action: function () {
                                        //let apiUrl = CommonService.API_PATH_V2_TITRATE_REPORT + 'reports/titratereport?companyIds=' + companyIdGobalID+'&draw=2&columns%5B0%5D%5Bdata%5D=companyName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=false&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=drugName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=regimenName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=doseType&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=doseUnit&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=doseStrength&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=startDate&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=endDate&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=Status&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false&_=1523974787412'
                                        let apiUrl = url + '&draw=2&columns%5B0%5D%5Bdata%5D=companyName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=false&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=drugName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=regimenName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=doseType&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=doseUnit&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=doseStrength&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=startDate&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=endDate&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=Status&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1523974787412'
                                        self.reportService.ExportAll(apiUrl, 'Titration Report');
                                    },
                            },
                            {
                                extend: 'print', text: 'Print', exportOptions: {
                                    columns: [0, 1, 2, 3]
                                }
                            }

                        ],
                        "order": [[0, "desc"]],
                        "columns": [
                            { "data": "trialName" },
                            { "data": "drugName" },
                            { "data": "regimenName" },
                            { "data": "doseType" },
                            { "data": "doseAmount" },
                            {
                                "data": "doseUnit"
                                ,
                                "render": function (data, type, full, meta) {
                                    return full.doseUnit + " " + full.dosemeasure;

                                }

                            },
                            {
                                "data": "doseStrength"
                                ,
                                "render": function (data, type, full, meta) {
                                    return full.doseStrength + " " + full.dosemeasure;

                                }

                            },
                            { "data": "startDate" },
                            { "data": "endDate" },
                            { "data": "Status" },

                        ]
                        ,
                        "columnDefs": [

                            {
                                "targets": [9],
                                render: function (data, type, row) {
                                    return data == '1' ? 'Active' : 'Inactive'
                                }

                            }
                            ,
                            {
                                "render": (data, type, full) => {
                                    if (full.bucketKey != null)
                                    {
                                        //self.SetAndValidateImageUrl('https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + full.bucketKey, full.drugName.replace(/\s/g, ''));
                                        //return '<img id=\"' + full.drugName.replace(/\s/g, '') + '\" src=https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + full.bucketKey + ' onerror=\"imgError(this);\"></img><span>' + full.drugName + '</span>';
                                        return '<img id=\"' + full.drugName.replace(/\s/g, '') + '\" src=' + CommonService.MEDCON_V2_S3_BUCKET_URL + full.bucketKey + ' onerror=\"imgError(this);\"></img><span>' + full.drugName + '</span>';
                                    }
                                    else
                                        return '<img id=\"' + full.drugName.replace(/\s/g, '') +'\" src="../../../assets/images/medication-type-default.png"></img><span>' + full.drugName + '</span>';
                                },
                                "targets": [1],
                                'searchable': false,
                            }

                        ]
                        ,
                        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                        "pageLength": pageLength
                    });
                }
            });
        }
     
        
    }



    public ngAfterViewInit(): void {



        this.loadTitrationReport('PageLoad');

    }

    public deleteItem(id): void {

        this.deleteModal.show();
    }

    public hideDeleteModal(): void {

        this.deleteModal.hide();
    }

    //public onDateChange(event: IMyInputFieldChanged, field): void {
    //    let d = event.value.split('/');
    //    let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

    //    if (event.valid) {
    //        if (field === 'start') {
    //            this.setEndDateDisableUntil(date.date);
    //        } else if (field === 'end') {
    //            this.setStartDateDisableSince(date.date);
    //        }
    //    }
    //}

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let day = Number(d[1]) - 1;
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + day);
        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            }
            //else if (field === 'end') {
            //    this.setStartDateDisableSince(date.date);
            //}
        }
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    public customerChanged(): void {

    }


    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }
    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }
    private dateForView(date: string): any {
        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2].replace('0', '') } };
        } else {
            return '';
        }
    }

    onChangeTrialGroip(selectedValue) {
        this.isLoading = true;
        this.selectedTrialGroupId = Number(selectedValue);
        this.selectedTrialGroupName = null;
        this.allTrailsList1 = [];
        this.allDrugList = [];
        this.allRegimenList = [];
        //To get selected role name
        if (this.allTrialGroupList != null) {
            for (var i = 0; i < this.allTrialGroupList.length; i++) {
                if (this.allTrialGroupList[i].trial_group_id == this.selectedTrialGroupId) {
                    this.selectedTrialGroupName = this.allTrialGroupList[i].trial_group_name;
                }
            }

        }
        if (selectedValue != 'Select') {
            this.notificationsService.getSelectedTrailsFromTrialGroupForTitrateReport(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialGroupId)).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allTrailsList1 = response;
                    this.loadAllDropdowns();
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else
        {

            this.loadAllDropdowns();
        }

    }

    onChange_Trial(selectedValue) {
        this.isLoading = true;
        this.allDrugList = [];
        this.allRegimenList = [];
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;

        if (this.allTrailsList1 != null) {
            for (var i = 0; i < this.allTrailsList1.length; i++) {
                if (this.allTrailsList1[i].trail_id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList1[i].trial_name;
                }
            }

        }
        if (String(this.selectedTrialId) != 'NaN') {
            this.notificationsService.getSelectedDrugFromTrial(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialId)).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);

                    this.allDrugList = response;
                    this.isLoading = false;
                    this.loadAllDropdowns();
                   
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else if (selectedValue == 'Select') {

            this.loadAllDropdowns();
        }

    } 
    onChange_Drug(selectedValue) {
        this.isLoading = true;
        this.selectedDrugId = Number(selectedValue);
        this.selectedDrug = null;
        
        this.allRegimenList = [];
        if (this.allDrugList != null) {
            for (var i = 0; i < this.allDrugList.length; i++) {
                if (this.allDrugList[i].id == this.selectedDrugId) {
                    this.selectedDrug = this.allDrugList[i].name;
                }
            }

        }
        if (String(this.selectedDrugId) != 'NaN') {
            this.notificationsService.getSelectedRegimenFromDrug(Number(this.selectedTrialId), Number(this.selectedDrugId), Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allRegimenList = response;
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else if (selectedValue == 'Select') {

            this.loadAllDropdowns();
        }

    } 
    onChange_Regimen(selectedValue) {
        //alert(selectedValue);

        this.selectedRegimenId = Number(selectedValue);
        this.selectedRegimen = null;

        if (this.allRegimenList != null) {
            for (var i = 0; i < this.allRegimenList.length; i++) {
                if (this.allRegimenList[i].id == this.selectedRegimenId) {
                    this.selectedRegimen = this.allRegimenList[i].name;
                }
            }

        }
    }

    SetAndValidateImageUrl(url, imageId): void {
        //alert(url);
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            //alert(" Image Exists...!");
            //flag = true;
        }).on("error ", function () {
            //alert("ERROR");
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            //flag = false;

        });
        //return flag;

    }

}
