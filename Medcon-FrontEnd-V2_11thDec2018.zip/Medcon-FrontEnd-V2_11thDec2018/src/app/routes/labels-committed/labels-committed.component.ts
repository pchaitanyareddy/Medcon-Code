﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { LabelCommittedRequest } from '../../requests/label-committed-request';
import { LabelPurchasedRequest } from '../../requests/label-purchased-request';
//import { Component, HostListener, OnInit } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { UserService } from '../../services/user.service';
import { Observable } from 'rxjs/Observable';
import { UserRole } from '../../models/userrole';
import { CurrentUserService } from '../../services/currentuser.service';
import { CognitoUser } from '../../models/cognito-user';
import { LabelService } from '../../services/label.service';
import { Customer } from '../../models/customer';
import { Label } from '../../models/labels';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { CompanyService } from '../../services/company.service';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { TrialService } from '../../services/trial.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';

var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}

//enum Companies {

//    'ABC Pharmaticual',
//    'Test1',
//    'Test2'
//}

@Component({
    templateUrl: './labels-committed.component.html?v=${new Date().getTime()}'
})

export class LabelsCommittedComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('viewSummaryModal') public viewSummaryModal: ModalDirective;
    @ViewChild('labelDetailsModal') public labelDetailsModal: ModalDirective;
    public customer: Customer;
    public addPurchasedForm: FormGroup;
    public formLabelsCommitted: FormGroup;
    public showErrors: boolean;
    public showErrors_addPurchasedForm: boolean;
    public errorMessage: string;
    public successMessage: string;
    public labels: any;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    companyOptions: string[];
    //Companies: typeof Companies = Companies;
    defaultRole;
    defaultCompany;
    loggedInCompany;
    selectedCompany;
    isEditForm: boolean;
    selectedCompanyId: number;
    public UserRole: typeof UserRole = UserRole;
    public loggedInUserRole: string;
    public currentUserRole: UserRole;
    toggoleShowHide: string = "hidden";
    companyList: any;
    labelsCommittedList: any;
    public labelToDelete: Label;
    public selectedCustomerId: number;
    public yearList: any;
    public labelDetailsList: any;
    public defaultYear: any;
    selectedLabelId: number;
    selectedYear: number;
    //public loggedInUser: CognitoUser = new CognitoUser(-1, '', '', -1);
    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };

    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    isLoading: boolean;
    companyIdToDelete: number;
    yearToDelete: number;
    constructor(public templateService: TemplateService,
        public router: Router,
        public labelService: LabelService,
        public currentUserService: CurrentUserService,
        public companyService: CompanyService,
        private reportService: ReportService,
        private cognitoUtil: CognitoUtil,
        private fb: FormBuilder,
        private trialService: TrialService,
        private route: ActivatedRoute) {
    }

    public ngOnInit() {
        this.isLoading = false;
        this.isEditForm = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.customer = this.route.snapshot.data['customer'];
        this.currentUserRole = this.route.snapshot.data['role'];


        this.currentUserService.getRole().subscribe((role) => {
            if (role === UserRole.MedConAdmin) {

                this.loggedInUserRole = "MedConAdmin";
            }
            
        }, (err) => {
            //if (err.message === 'Token is null') {
            //    this.userService.logout();
            //}
        });

        this.formLabelsCommitted = this.fb.group({
            labelsCommitted: ['', [Validators.required]],
            currentYear: ['', [Validators.required]],
            company: ['']
        });

        this.addPurchasedForm = this.fb.group({
            labelPurchased: ['', [Validators.required]],
            company: ['']
        });

        //alert(this.currentUserRole);
        var x = Roles;
        var options = Object.keys(Roles);
        this.options = options.slice(options.length / 2);
        this.defaultRole = this.options[1];
        //var z = Companies;
        //var companyOptions = Object.keys(Companies);
        // this.companyOptions = companyOptions.slice(companyOptions.length / 2);
        //this.defaultCompany = this.companyOptions[0];
        //this.loggedInCompany = this.companyOptions[0];
        //this.loggedInUserRole = this.loggedInUser.role;
        //this.loggedInCompany = this.loggedInUser.name;
        //alert(this.loggedInUserRole);

        //this.companyList = [

        //    { companyId: 1, companyName: 'ABC Pharma Global' },
        //    { companyId: 2, companyName: 'Medcon Testing' },
        //]
        //Code added by ramesh on 29th Jan 2018 to get all companies json list to fill dropdown

        if (this.loggedInUserRole == "MedConAdmin") {
            this.companyService.getAllCompanies().subscribe(
                (response) => {
                    this.companyList = response;
                    //alert(this.loggedInUserRole);
                },
                (err) => {
                    this.errorMessage = err;

                });
        }
        else {
            //get current company name
            //this.companyList = [
            //    { companyId: 1, companyName: 'ABC Pharmaticual' },  
            //]
            this.companyService.getAllCompanies().subscribe(
                (response) => {
                    //this.companyList = response;
                    //alert(this.loggedInUserRole);
                    this.companyList = response.filter(company => company.companyId === Number(localStorage.getItem('GLOBAL_COMPANY_ID')));
                },
                (err) => {
                    this.errorMessage = err;

                });

        }

        //End code added by ramesh on 29th Jan 2018 to get all companies json list to fill dropdown

        this.labelsCommittedList = [

            //{ id: 1, company: 'Company1', committed: '2000', purchased: '2000', used: '1500', remaining: '500' },
            //{ id: 2, company: 'Company2', committed: '1000', purchased: '1000', used: '800', remaining: '200' },
            //{ id: 3, company: 'Company3', committed: '1000', purchased: '1000', used: '600', remaining: '400' },

        ]

        this.yearList = [
            { year: 2080 },
            { year: 2079 },
            { year: 2078 },
            { year: 2077 },
            { year: 2076 },
            { year: 2075 },
            { year: 2074 },
            { year: 2073 },
            { year: 2072 },
            { year: 2071 },
            { year: 2070 },
            { year: 2069 },
            { year: 2068 },
            { year: 2067 },
            { year: 2066 },
            { year: 2065 },
            { year: 2064 },
            { year: 2063 },
            { year: 2062 },
            { year: 2061 },
            { year: 2060 },
            { year: 2059 },
            { year: 2058 },
            { year: 2057 },
            { year: 2056 },
            { year: 2055 },
            { year: 2054 },
            { year: 2053 },
            { year: 2052 },
            { year: 2051 },
            { year: 2050 },
            { year: 2049 },
            { year: 2048 },
            { year: 2047 },
            { year: 2046 },
            { year: 2045 },
            { year: 2044 },
            { year: 2043 },
            { year: 2042 },
            { year: 2041 },
            { year: 2040 },
            { year: 2039 },
            { year: 2038 },
            { year: 2037 },
            { year: 2036 },
            { year: 2035 },
            { year: 2034 },
            { year: 2033 },
            { year: 2032 },
            { year: 2031 },
            { year: 2030 },
            { year: 2029 },
            { year: 2028 },
            { year: 2027 },
            { year: 2026 },
            { year: 2025 },
            { year: 2024 },
            { year: 2023 },
            { year: 2022 },
            { year: 2021 },
            { year: 2020 },
            { year: 2019 },
            { year: 2018 },
            { year: 2017 },
         
        ]

        //this.labelDetailsList = this.labelService.getLabelDetails(1);
        //alert(this.labelDetailsList[0].labelName);

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Labels')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
    }

    public yearChanged(selectedYear): void {
        this.selectedYear = selectedYear;
        //alert(obj);
        //this.labelsCommittedList = this.labelService.getLabelsByYear(this.selectedCustomerId, selectedYear);
        $("#datatable_labels").dataTable().fnDestroy();
        this.loadLabelsCommittedList(selectedYear);

    }

    public ngAfterViewInit() {
        //if (!this.isEditForm)
        //{

        //       this.selectedCompany = this.companyList[0].companyName;
        //}
        this.defaultYear = 0;//(new Date()).getFullYear();//'2018';
        this.selectedYear = this.defaultYear;
        //alert(this.defaultCompany);
        //this.loggedInCompany = (<HTMLInputElement>document.getElementById("companyName")).value;
        //alert(this.loggedInCompany);

        //$('#datatable_labels').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});
        $("#datatable_labels").dataTable().fnDestroy();
        this.loadLabelsCommittedList(this.defaultYear);

    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    public onSubmit() {
        if (this.formLabelsCommitted.invalid) {
            this.showErrors = true;
            return;
        }
        let userId = localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID');
        let companyId =  this.getCompanyIdCompanyName(this.formLabelsCommitted.value.company); //localStorage.getItem('GLOBAL_COMPANY_ID');
        let ID = localStorage.getItem('labelsCommittedID');
        if (!this.isEditForm) {
            
            if (companyId != 1) {
                let d = this.convertDate(this.formLabelsCommitted.value.currentYear.date).split('-');

                this.route.params.subscribe((params) => {
                    let request = new LabelCommittedRequest(
                        Number(this.formLabelsCommitted.value.labelsCommitted),
                        Number(userId),
                        //Number(d[0])
                        this.formLabelsCommitted.value.currentYear
                    );
                    this.isLoading = true;
                    this.labelService.updateCommitted(Number(companyId), request)
                        .subscribe(
                        (response) => {
                            this.isLoading = false;
                            this.formLabelsCommitted.markAsPristine();
                            this.successMessage = 'Label commitment has been successfully inserted.';
                            $("#datatable_labels").dataTable().fnDestroy();
                            this.loadLabelsCommittedList(this.defaultYear);
                            //this.formLabelsCommitted.reset();
                            //$("#datatable_labels").dataTable().ajax.reload();
                            //this.activeCommitment = [];
                            //this.control.controls.forEach((c) => {
                            //    this.activeCommitment.push(true);
                            //});
                            this.clearFields();
                        },
                        (err) => {
                            this.isLoading = false;
                            this.errorMessage = err;
                        }
                        );
                });
            }
            else {
                this.errorMessage = "Should not add Labels for Medcon Company"
            }

        }
        else if (this.isEditForm) {
            //alert("Edit Form")
            this.route.params.subscribe((params) => {
                let request = new LabelCommittedRequest(
                    Number(this.formLabelsCommitted.value.labelsCommitted),
                    Number(userId),
                    this.formLabelsCommitted.value.currentYear,
                    this.formLabelsCommitted.value.company,
                    companyId


                );
                //alert(this.formLabelsCommitted.value.labelsCommitted);
                //alert(userId);
                //alert(ID);
                this.isLoading = true;
                this.labelService.updateCommittedById(Number(ID), request)
                    .subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.formLabelsCommitted.markAsPristine();
                        this.successMessage = 'Label commitment has been successfully updated.';
                        $("#datatable_labels").dataTable().fnDestroy();
                        this.loadLabelsCommittedList(this.defaultYear);
                        //this.formLabelsCommitted.reset();
                        $('#company').removeAttr('disabled');
                        $('#currentYear').removeAttr('disabled');
                        
                        //$("#datatable_labels").dataTable().ajax.reload();
                        //this.activeCommitment = [];
                        //this.control.controls.forEach((c) => {
                        //    this.activeCommitment.push(true);
                        //});
                        this.clearFields();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    }
                    );
            });
        }
    }

    public addPurchased() {
        let userId = localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID');
        let companyId = this.getCompanyIdCompanyName(this.addPurchasedForm.value.company);//localStorage.getItem('GLOBAL_COMPANY_ID');

        if (this.addPurchasedForm.invalid) {
            this.showErrors_addPurchasedForm = true;
            return;
        }
        if (companyId!=1) {
            this.route.params.subscribe((params) => {
                let request = new LabelPurchasedRequest(
                    Number(this.addPurchasedForm.value.labelPurchased),
                    Number(userId)

                );

                this.labelService.addLabelPurchased(Number(companyId), request)
                    .subscribe(
                    (response) => {
                        this.addPurchasedForm.markAsPristine();
                        this.successMessage = 'Label purchased has been successfully updated.';
                        
                        $("#datatable_labels").dataTable().fnDestroy();
                        this.loadLabelsCommittedList(this.defaultYear);
                        this.addPurchasedForm.reset();
                        this.clearFields_AddPurchased();
                        // $("#datatable_labels").dataTable().ajax.reload();
                        //this.activeCommitment = [];
                        //this.control.controls.forEach((c) => {
                        //    this.activeCommitment.push(true);
                        //});
                    },
                    (err) => {
                        this.errorMessage = err;
                    }
                    );
            });
        }
        else {
            this.errorMessage="Should not Purchase Labels for Medcon"
        }

    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        //this.user.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'labels-committed']);
    }

    //@HostListener('window:beforeunload')
    //public canDeactivate(): Observable<boolean> | boolean {
    //    return !this.user.dirty;
    //}

    public enableAddPurchasedSection(): void {

        this.toggoleShowHide = "visible";
    }

    public disableAddPurchasedSection(): void {

        this.toggoleShowHide = "hidden";

    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            } else if (field === 'end') {
                this.setStartDateDisableSince(date.date);
            }
        }
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {
            return (value < 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    public deleteItem(id): void {
        //alert("Delete Entered");
        this.selectedLabelId = id;
        this.deleteModal.show();
        this.labelDetailsModal.hide();
    }


    public confirmDelete(): void {
                
        this.isLoading = true;
        //alert("Confirm Delete");
        this.labelService
            .deleteCommitment(this.selectedLabelId, this.companyIdToDelete, this.yearToDelete)
            .subscribe(
            (response) => {
                //this.labelService.getCommitted(this.selectedCustomerId)
                //    .subscribe((labels) => {
                //        this.labels = labels;
                //        this.successMessage = 'Label has been successfully deleted';
                //        this.hideDeleteModal();
                //    }
                //    );
                this.isLoading = false;
                this.hideDeleteModal();
                
                //alert(obj);
                //this.labelsCommittedList = this.labelService.getLabelsByYear(this.selectedCustomerId, selectedYear);
                $("#datatable_labels").dataTable().fnDestroy();
                this.loadLabelsCommittedList(this.selectedYear);
            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public hideDeleteModal(): void {
        this.labelToDelete = null;
        this.deleteModal.hide();
    }

    public viewLabelDetails(companyId): void {

        this.labelDetailsModal.show();
    }

    public hideLabelDetailsModal(): void {

        this.labelDetailsModal.hide();
    }



    public editAndPopulateFormValues(labelObject) {
        this.isEditForm = true;
        //Added by ramesh on 8th Oct 2017
        let createdDate = new Date();
        let day = createdDate.getDate();
        let month = createdDate.getMonth() + 1;
        let year = createdDate.getFullYear();
        let today = year + '-' + month + '-' + day;
        //End
        this.formLabelsCommitted = this.fb.group({
            labelsCommitted: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            currentYear: [this.dateForView(today), Validators.required],
            company: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]]
        });
        this.selectedCompany = this.companyList[1].companyName;//"ABC Pharma Global";//labelObject.companyName;
        //alert(this.selectedCompany);

    }

    onChange(selectedValue) {
        this.selectedCompanyId = Number(selectedValue);
        //this.selectedRoleName = null;
        //To get selected role name
        //if (this.companyList != null) {
        //    for (var i = 0; i < this.companyList.length; i++) {
        //        if (this.companyList[i].roleId == this.selectedRoleId) {
        //            this.selectedRoleName = this.allRoleList[i].roleName;
        //        }
        //    }

        //}

    }

    public EditLabel(buttonId,companyName, labelsCommitted, currentYear, createdDate): void {

        let date = this.trialService.convertDateToCalendarFormat(createdDate);
        localStorage.setItem('labelsCommittedID', buttonId);
        this.isEditForm = true;
        $('#labelsCommitted').val(labelsCommitted);
        $('#labelsCommitted').addClass("inputEdit");
        $('#company').val(companyName);
        $('#company').attr('disabled', 'disabled');
        $('#currentYear').attr('disabled', 'disabled');

        $('#btnSubmit').text('Update');
       // $('#currentYear').val('111');
        this.selectedCompany = companyName;
        //this.labelDetailsModal.hide();
        //let createdDate = new Date();
        //let day = createdDate.getDate();
        //let month = createdDate.getMonth() + 1;
        //let year = createdDate.getFullYear();
        //let today = year + '-' + month + '-' + day;

        this.formLabelsCommitted = this.fb.group({

            labelsCommitted: [labelsCommitted, Validators.required],
            currentYear: [createdDate, Validators.required],
            company: [companyName, Validators.required],

        });

    }

    public loadLabelsCommittedList(year): void {

        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_labels').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "rowId": "companyId",
                    'ajax': {

                        //'url': 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/commit/list/' + year + '/all',
                        'url': CommonService.API_PATH_V2_GET_LIST_LABEL_COMMITMENT + 'label/commit/list/' + year + '/all?companyIds='+localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3, 4]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_GET_LIST_LABEL_COMMITMENT + 'label/commit/list/' + year + '/all' + '?companyIds=' + localStorage.getItem('GLOBAL_COMPANY_ID') + '&draw=1&columns%5B0%5D%5Bdata%5D=companyName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=created&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=labelsCommitted&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=labelsPurchased&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=labelsUsed&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=labelsRemaining&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=iD&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=8&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=false&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1530012411063'
                                self.reportService.ExportAll(apiUrl, 'Labels Committed');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "companyName" },
                        { "data": "created" },
                        { "data": "labelsCommitted" },
                        { "data": "labelsPurchased" },
                        { "data": "labelsUsed" },
                        { "data": "labelsRemaining" },
                        //{ "data": "iD" },
                        { "data": "status" },
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                localStorage.setItem('companyName', full.companyName);
                                localStorage.setItem('labelsCommitted', full.labelsCommitted);
                                localStorage.setItem('labelsPurchased', full.labelsPurchased);
                               
                                //return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.iD + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){  localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>  </div>";
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Label As it is already deleted\" disabled  id=\"" + full.iD + "_editItem\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> <button title=\"Cannot Delete this Label As it is already deleted\" disabled id=\"" + full.iD + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                   
                                    else {
                                        return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.iD + "_deleteItem" +  "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created +"\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Label As it is already deleted\" disabled  id=\"" + full.iD + "_editItem\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> </div>";
                                    }
                                  
                                    else {
                                        return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"> <button title=\"Cannot Delete this Label As it is already deleted\" disabled id=\"" + full.iD + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                  
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.iD + "_deleteItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if ((self.currentUserRole == UserRole.CustomerUser) && Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0)
                                {
                                    return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</button></div>";

                                }
                                else {
                                    return "";
                                }
                            }
                        },
                        

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [3],
                            render: function (data, type, full, meta) {
                                return "<u  id=\"" + full.iD + "_purchaseClick" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "_" + full.companyId +"\" style=\"cursor: pointer;\">_" + data + " </u></div>";
                                //return "<a href=''>" + data + "</a>"
                                // return '<a href="//' + full[0] + '">' + data + '</a>';
                                //return '<a href=\"javascript:void(0)\"><u>' + data + '</u></a>';

                            }
                        }
                        ,
                        //{
                        //    "targets": [6],
                        //    "visible": false
                        //},
                        {
                            "targets": [6],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }

                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    //,
                    //"drawCallback": function (settings, json) {
                    
                    //    $("#datatable_labels td").each(function () {
                    //        var id = $(this).text();

                    //        if ($.isNumeric(id)) {
                    //            var num = id;

                    //            var commaNum = numberWithCommas(num);
                    //            $(this).text(commaNum);
                    //        }
                    //    });
                    //    function numberWithCommas(number) {
                    //        var parts = number.toString().split(".");
                    //        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    //        return parts.join(".");
                    //    }

                    //}
                });
            }
        });
        //$('#datatable_labels tbody').on("click", 'tr ', function (evt) {

        //    var attId = $(this).attr('id');
        //    // alert(attId);
        //    //alert("Row Click");
            

        //    //if (!$(evt.target).is("button")) {
        //    //    self.LoadLabelData($(this).attr('id'));
        //    //}

        //    localStorage.setItem('SELECTED_ROW_COMPANY_ID', $(this).attr('id'));

        //});
        $('#datatable_labels').on('click', 'td button', function () {
            
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            var companyName = attId.split("_")[2];
            var labelsCommitted = attId.split("_")[3];
            var labelsPurchased = attId.split("_")[4];
            var createdDate = attId.split("_")[5];
            
            this.selectedLabelId = buttonId;

            if (buttonName == "editItem") {

                self.EditLabel(buttonId,companyName, labelsCommitted, labelsPurchased, createdDate);

            }

            if (buttonName == "deleteItem") {
                //alert('companyName' + companyName);
                //alert('createdDate' + createdDate);
                self.companyIdToDelete = self.getCompanyIdCompanyName(companyName);
                self.yearToDelete = Number(createdDate);
                //alert(self.companyIdToDelete);
                //alert(self.yearToDelete);
                self.deleteItem(buttonId);
                
            }


            
        });
        $('#datatable_labels tbody').on('click', 'tr td u', function () {
           
            var attId = $(this).attr('id');
            //alert(attId);
            var createdDate = attId.split("_")[5];
            var selectedRowCompanyId = attId.split("_")[6];
            //localStorage.setItem('COMMITTED_YEAR', createdDate);

            //let selectedRowCompanyId = Number(localStorage.getItem('SELECTED_ROW_COMPANY_ID'));
            self.LoadLabelData(selectedRowCompanyId, createdDate);

        });




    }


    public LoadLabelData(companyId, committedYear): void {

        //alert(iD);
        //alert("LoadLabelData Entered");
        //let committedYear = Number(localStorage.getItem('COMMITTED_YEAR'));
        this.isLoading = true;
        this.labelService.getLabelDetails(companyId, committedYear).subscribe(
            (response) => {
                this.isLoading = false;
                //this.patientInformation = response;
                //this.viewSummaryModal.show();
                // alert(response.firstName);
                let status = (response.status) == 1 ? "Active" : "Inactive";
                $("#spnCompanyName").text(response.companyName);
                $("#spnStatus").text(status);
                $("#spnRemaining").text(response.remaining);
                $("#spnPurchased").text(response.purchased);
                $("#spnCommitted").text(response.committed);
                $("#spnUsed").text(response.used);
                //this.viewSummaryModal.show();
                this.LoadLabelPurchaseData(companyId, committedYear);
                this.labelDetailsModal.show();
                // alert(response.remaining);
            },
            (err) => {
                this.errorMessage = err;

            });

    }

    public LoadLabelPurchaseData(companyId,year): void {

        //alert(companyId);
        //alert("LoadLabelData Entered");

        this.isLoading = true;
        this.labelService.getLabelPurchase(companyId,year).subscribe(
            (response) => {
                this.isLoading = false;
                this.labelDetailsList = response



            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

    }


    getCompanyIdCompanyName(companyName):number
    {
        let companyId = 0;
        if (this.companyList != null) {
            for (var i = 0; i < this.companyList.length; i++) {
                if (this.companyList[i].companyName == companyName) {
                    companyId = this.companyList[i].companyId;
                }
            }

        }
        return companyId;
    }

    clearFields() {
        //this.selectedCompany = this.companyList[1].companyName;
        $('#labelsCommitted').removeClass("inputEdit");
        this.formLabelsCommitted = this.fb.group({

            labelsCommitted: ['', Validators.required],
            currentYear: ['', Validators.required],
            company: [localStorage.getItem('GLOBAL_COMPANY_NAME'), Validators.required],

        });

        $('#company').removeAttr('disabled');
        $('#currentYear').removeAttr('disabled');
        
        $('#btnSubmit').text('Submit');
        this.isEditForm = false;

    }

    clearFields_AddPurchased() {
        
        this.addPurchasedForm = this.fb.group({
            labelPurchased: ['', [Validators.required]],
            company: [localStorage.getItem('GLOBAL_COMPANY_NAME'), Validators.required],
        });

    }
    
}
