import { Component, OnInit, ViewChild, Compiler} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
//import { IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialService } from '../../services/trial.service';
import { CustomerService } from '../../services/customer.service';
import { Trial } from '../../models/trial';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { ReportService } from '../../services/report.service';
import { ReportScheduleRequest } from '../../requests/report-schedule-request';
import { ReportSchedule, ReportScheduleType } from '../../models/reportschedule';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { NotificationsService } from '../../services/notifications.service';
import {CommonService} from '../../services/commonService';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');

@Component({
    templateUrl: './data-reports.component.html?v=${new Date().getTime()}',
    styleUrls: ['./data-reports.component.scss']
})

export class DataReportsComponent implements OnInit {
    @ViewChild('scheduleModal') public deleteModal: ModalDirective;
    @ViewChild('reportMenu') public reportMenu: TabsetComponent;
    public trials: Trial[];
    public customers: Customer[];
    public showDatesTaken: boolean;
    public schedule: FormGroup;
    public days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    public dates = [];
    public hours = [];
    public minutes = [];
    public scheduleOptionToShow: string;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public allTrailsList: any;
    public allPatientList: any;
    public allTrailsListFiltered: any;
    public allTrialGroupList: any;
    public allTrialGroupListFiltered: any;
    public selectedTrialGroupId: number;
    public selectedTrialGroupName: string;
    public selectedTrial: any;
    public selectedPatientId: any;
    public selectedPatient: any;
    public allContainerList: any;
    public selectedContainerId: number;
    public selectedContainer: any;
    public selectedCompanyId: number;
    public myDatePickerOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public startDate: '';
    public endDate: '';
    public data: any;
    public selectedCustomerId: number;
    public selectedTrialId: any = 'all';
    public user: any;
    public ReportScheduleType: typeof ReportScheduleType = ReportScheduleType;
    public reportSchedules: ReportSchedule[];
    public successMessage: string;
    public errorMessage: string;
    public showErrors: boolean;
    public patientid: '';
    public dataReportsForm: FormGroup;
    public isLoading: boolean;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private fb: FormBuilder,
        private trialService: TrialService,
        private customerService: CustomerService,
        private cognitoUtil: CognitoUtil,
        private notificationsService: NotificationsService,
        private reportService: ReportService,
        private _compiler: Compiler
    ) {
    }

    public ngOnInit() {
        this._compiler.clearCache();
        // Dates
        for (let i = 1; i <= 28; i++) {
            this.dates.push(i);
        }
        for (let i = 0; i <= 23; i++) {
            this.hours.push(i);
        }
        for (let i = 0; i <= 59; i = i + 5) {
            this.minutes.push(i);
        }

        this.user = this.route.snapshot.data['user'];
        //this.reportSchedules = this.route.snapshot.data['report_schedules'];

        // If MedCon then populate list of customers, else, populate list of trials
        this.currentUserRole = this.route.snapshot.data['role'];
       

        this.schedule = this.fb.group({
            trial: ['', Validators.required],
            every: ['Day'],
            hour: [0],
            minute: [0],
            dayOfWeek: [0],
            dayOfMonth: ['1']
        });

        //$('#datatable_trials').DataTable();
        //$('#datatable_trials').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        this.dataReportsForm = this.fb.group({

            startDate: ['', Validators.required],
            endDate: ['', Validators.required],
            trialName: [''],
            patientId: ['', [Validators.required]],
            container: ['', [Validators.required]],
            ddlStatusType: ['', [Validators.required]],
            trialGroup: ['', [Validators.required]],
        });

        //this.notificationsService.getAllTrails(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
        //    (response) => {
        //        this.allTrailsList = response;

        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });
        //
    
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        this.loadAllDropdowns();
  
    }

    loadAllDropdowns()
    {  
        //this.isLoading = true;
        this.trialService.getAllTrialGroupsDropDown(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrialGroupList = response.trailgroups;
                if ($('#trialGroup').val() != 'Select' && $('#trialGroup').val()!=null) 
                {
                    this.notificationsService.getSelectedTrailsFromTrialGroup(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number($('#trialGroup').val())).subscribe(
                        (response) => {
                            //alert(this.selectedTrialGroupId);
                            this.allTrailsList = response;
                            this.isLoading = false;
                        },
                        (err) => {
                            this.errorMessage = err;
                            this.isLoading = false;
                        });
                }
                else {
                    this.allTrailsList = response.trailname;
                    this.isLoading = false;
                }
                if ($('#trialName').val() != 'Select' && $('#trialName').val()!=null) 
                {
                    this.notificationsService.getSelectedPatientsFromTrials(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialGroupId), Number($('#trialName').val())).subscribe(
                        (response) => {
                            //alert(this.selectedTrialGroupId);
                            this.allPatientList = response;
                            this.isLoading = false;
                        },
                        (err) => {
                            this.errorMessage = err;
                            this.isLoading = false;
                        });

                }
                else {
                    this.allPatientList = response.patientname;
                    this.isLoading = false;
                }
                this.allContainerList = response.containers;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });
    }

    public ngAfterViewInit(): void {

        this.loadDataReportList('PageLoad');
        //$('#datatable_reportSchedules').DataTable();
        //$('#datatable_trials').DataTable();
        //$('#datatable_reportSchedules').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        //$('#datatable_trials').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});
    }

    public customerChanged(): void {
        this.trialService.getTrialsAll(this.selectedCustomerId).subscribe((trials) => {
            this.trials = trials;
            // If customer has any trials, select the first one
            if (this.trials.length > 0) {
                this.selectedTrialId = this.trials[0].id;
            } else {
                this.selectedTrialId = 'all';
            }
        });
    }

    public filterReport(event): void {
        let trialId = (this.selectedTrialId === 'all') ? null : this.selectedTrialId;
        let customerId = (this.currentUserRole === UserRole.MedConAdmin) ?
            this.selectedCustomerId :
            this.user['custom:customer_id'];
        let filters = [
            {
                key: 'start_date',
                value: this.convertDate(event.start)
            },
            {
                key: 'end_date',
                value: this.convertDate(event.end)
            }
        ];

        this.reportService
            .getAdherenceReport(trialId, customerId, filters)
            .subscribe((report) => {
                this.data = report;
                setTimeout(() => {
                    // Check if it is set, MedCon won't have this tab index as they can only see doses tab
                    if (this.reportMenu.tabs[1]) {
                        this.reportMenu.tabs[1].active = true;
                    }
                });
            });

        //$('#datatable_trials').DataTable();
        //$('#datatable_trials').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});
    }

    public showModal(): void {
        this.deleteModal.show();
    }

    public hideModal(): void {
        this.deleteModal.hide();
    }

    public changeSchedule(): void {
        this.scheduleOptionToShow = this.schedule.value.every;
    }

    public deleteSchedule(id: string, index: number): void {
        this.reportService.deleteSchedule(id).subscribe(
            (response) => {
                this.reportSchedules.splice(index, 1);
                this.successMessage = 'Schedule successfully deleted';
            },
            (err) => {
                this.errorMessage = err;
            }
        );
    }

    //public createSchedule(): void {
    //    if (this.schedule.invalid) {
    //        this.showErrors = true;
    //        return;
    //    }

    //    let request = this.createReportScheduleRequest();

    //    this.reportService.createSchedule(request).subscribe(
    //        (response) => {
    //            this.successMessage = 'Successfully created report schedule';
    //            this.hideModal();
    //            this.reportService.getSchedules().subscribe((schedules) => this.reportSchedules = schedules);
    //        },
    //        (err) => {
    //            this.errorMessage = err;
    //        });
    //}

    public exportNow(): void {
        let trialId = (this.selectedTrialId === 'all') ? null : this.selectedTrialId;
        let customerId = (this.currentUserRole === UserRole.MedConAdmin) ?
            this.selectedCustomerId :
            this.user['custom:customer_id'];
        let filters = [
            {
                key: 'start_date',
                value: this.convertDate(this.startDate)
            },
            {
                key: 'end_date',
                value: this.convertDate(this.endDate)
            }
            ,
            {
                key: 'patientid',
                value: this.patientid
            }
        ];

        this.reportService
            .exportAdherenceReport(trialId, customerId, filters);
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    private createReportScheduleRequest(): ReportScheduleRequest {
        switch (this.schedule.value.every) {
            case 'Day':
                return new ReportScheduleRequest(
                    this.schedule.value.trial,
                    {
                        hour: this.schedule.value.hour,
                        minute: this.schedule.value.minute
                    }
                );
            case 'Week':
                return new ReportScheduleRequest(
                    this.schedule.value.trial,
                    {
                        dayOfWeek: this.schedule.value.dayOfWeek,
                        hour: this.schedule.value.hour,
                        minute: this.schedule.value.minute
                    }
                );
            case 'Month':
                return new ReportScheduleRequest(
                    this.schedule.value.trial,
                    {
                        day: this.schedule.value.dayOfMonth,
                        hour: this.schedule.value.hour,
                        minute: this.schedule.value.minute
                    }
                );
            default:
                throw new Error('Unhandled schedule');
        }
    }



    public loadDataReportList(submitType): void {
        let isValid = true;
        let startDate = '';
        let endDate = '';
        let trialName = '';
        let patientId = '';
        let container = '';
        let doseType = '';
        let companyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        let url = '';
        let trialIds = '';
        var selectedTrials;
        let trialGroupIds = '';
        let trialGroup = '';
        let pageLength = 0;
        var selectedTrialGroups;
        if (submitType == 'buttonClick') {
           
            //alert(Number($("select[name='datatable_length'] option:selected").text()));
            pageLength = $("select[name='datatable_length'] option:selected").text();
            pageLength = ($("select[name='datatable_length'] option:selected").text() == 'All' ? -1 : Number($("select[name='datatable_length'] option:selected").text()));
            $("#datatable").dataTable().fnDestroy();
            startDate = this.convertDate(this.dataReportsForm.value.startDate.date);
            endDate = this.convertDate(this.dataReportsForm.value.endDate.date);
            //trialName = this.dataReportsForm.value.trialName; //$('#trialName').val();
            //trialName = this.selectedTrial;
            //patientId = this.dataReportsForm.value.patientId; //$('#patientId').val();
            //container = this.dataReportsForm.value.container;//$('#container').val();
            //patientId = this.selectedPatient; //$('#patientId').val();
            patientId =($("#patientID option:selected").text() == undefined || $("#patientID option:selected").text() == 'Select') ? '' : $("#patientID option:selected").text();
            //container = this.selectedContainer;//$('#container').val();
            container = ($("#container option:selected").text() == null || $("#container option:selected").text() == 'Select') ? '' : $("#container option:selected").text();
            doseType = this.dataReportsForm.value.ddlStatusType;//$('#ddlStatusType').val();
            trialGroup = this.dataReportsForm.value.trialGroup;
            if (doseType == 'Select')
                doseType = '';
            else if (doseType == 'On-Time')
                doseType = 'normal'
            else if (doseType == 'Missed')
                doseType = 'missed'
            else if (doseType == 'Late')
                doseType = 'late'
            else if (doseType == 'Overdose')
                doseType = 'overdose'
            else if (doseType == 'Underdose')
                doseType = 'underdose'
            trialIds = ($("#trialName").val() == null || $("#trialName").val() == 'Select') ? '' : $("#trialName").val();
            
            trialGroupIds = ($("#trialGroup").val() == null || $("#trialGroup").val() == 'Select') ? '' : $("#trialGroup").val();
            
            var startDate1 = new Date(startDate);
            var endDate1 = new Date(endDate);
            var todayDate = new Date();
            if (startDate1 > endDate1) {

                this.errorMessage = "Start Date should be Less than End Date";

            }
            if (startDate != '' && endDate=='')
            {
                this.errorMessage ="Please Select End Date"
            }
            else if (startDate == '' && endDate != '') {
                this.errorMessage = "Please Select Start Date"
            }
            
            if (trialName != undefined && trialName != '') {
                selectedTrials = trialName.split(',');
                selectedTrials.forEach((item, index) => {

                    if (this.allTrailsList != undefined) {
                        this.allTrailsListFiltered = this.allTrailsList.filter(
                            trial => trial.name.toLowerCase() === item.toLowerCase())
                        if (trialIds == '') {
                            if (this.allTrailsListFiltered[0] != undefined) {
                                // alert(this.allTrailsList[0].id)
                                trialIds = this.allTrailsListFiltered[0].id;
                                //alert(trialIds);
                            }
                            else
                            {
                                trialIds = trialName;
                            }

                        }
                        else {
                            if (this.allTrailsListFiltered[0] != undefined) {
                                trialIds = trialIds + ',' + this.allTrailsListFiltered[0].id
                            }
                            else {
                                trialIds = trialName;
                            }

                        }

                    }
                });


            }
            //url = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/dosedata?companyId=' + companyId + '&trialIds=' + trialIds + '&patient=' + patientId + '&container=' + container + '&dosetype=' + doseType + '&extra=&entry=&startdate=' + startDate + '&enddate=' + endDate;
            if (patientId == null) patientId = '';
            if (trialIds == null) trialIds = '';
            if (trialGroupIds == null) trialGroupIds = '';
            if (container == null) container = '';

            if (startDate == '' && endDate == '' && ($("#trialGroup").val() == null || $("#trialGroup").val() == 'Select')
                && ($("#trialName").val() == null || $("#trialName").val() == 'Select')
                && ($("#patientID").val() == null || $("#patientID").val() == 'Select')
                && ($("#container").val() == null || $("#container").val() == 'Select')
                && ($("#ddlStatusType").val() == null || $("#ddlStatusType").val() == 'Select')) {
                url = CommonService.API_PATH_V2_DATA_REPORT + 'dose/dosedata?companyId=' + companyId;

                //}
            }
            else
            {
                url = CommonService.API_PATH_V2_DATA_REPORT + 'dose/dosedata?companyId=' + companyId + '&trialIds=' + trialIds + '&patient=' + patientId + '&container=' + container + '&dosetype=' + doseType + '&extra=&entry=&startdate=' + startDate + '&enddate=' + endDate + '&trialGroupIds=' + trialGroupIds;
            }
            
            
        }
        else
        {
            url = CommonService.API_PATH_V2_DATA_REPORT + 'dose/dosedata?companyId=' + companyId;
        }
        
      
        var self = this;
        //alert(Number($("select[name='datatable_length'] option:selected").text()));
        //alert($("select[name='datatable_length'] :selected").text());
        //alert($('select[name="datatable_length"] option:selected').val());
        //$("select[name='datatable_length']").change(function () {
        //    alert($(this).val());
        //}); 
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
               
                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,

                    'ajax': {
                        //'url': 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/dosedata?companyId=1&filter=trialId^' + '9,10|patient^ABC123457|container^1_9_21_2|dosetype^late|extra^0|entry^0|interval^2018-02-28 06:58:02#2018-03-06 18:25:02\'',
                        //'url': 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/dosedata?companyId=1&trialIds=9,10&patient=ABC123457&container=1_9_21_2&dosetype=late&extra=0&entry=0&startdate=2018-02-28&enddate=2018-03-06',
                        //'url': 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/dosedata?companyId=' + companyId + '&trialIds=' + trialName + '&patient=' + patientId + '&container=' + container + '&dosetype=' + doseType + '&extra=0&entry=0&startdate=' + startDate + '&enddate=' + endDate,
                        'url' : url,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6]
                            },
                            action: function () {
                                //let apiUrl = CommonService.API_PATH_V2_DATA_REPORT + 'dose/dosedata?companyId=' + companyId+'&draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=patientId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=Container&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=dose&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=type&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=extraDose&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=doseWindow&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=entry&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=location&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B10%5D%5Bdata%5D=timeTaken&columns%5B10%5D%5Bname%5D=&columns%5B10%5D%5Bsearchable%5D=true&columns%5B10%5D%5Borderable%5D=true&columns%5B10%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B10%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B11%5D%5Bdata%5D=timeTaken&columns%5B11%5D%5Bname%5D=&columns%5B11%5D%5Bsearchable%5D=true&columns%5B11%5D%5Borderable%5D=true&columns%5B11%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B11%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=asc&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false&_=1523950744748'
                                let apiUrl = url + '&draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=patientId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=Container&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=dose&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=doseAmount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=type&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=extraDose&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=doseWindow&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=entry&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=location&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=true&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B10%5D%5Bdata%5D=timeTaken&columns%5B10%5D%5Bname%5D=&columns%5B10%5D%5Bsearchable%5D=true&columns%5B10%5D%5Borderable%5D=true&columns%5B10%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B10%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B11%5D%5Bdata%5D=timeTaken&columns%5B11%5D%5Bname%5D=&columns%5B11%5D%5Bsearchable%5D=true&columns%5B11%5D%5Borderable%5D=true&columns%5B11%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B11%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1523950744748'
                                self.reportService.ExportAll(apiUrl, 'Data Reports');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6]
                            }
                        },


                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "trial" },
                        { "data": "Patient" },
                        { "data": "Container" },
                        { "data": "drugname" },
                        { "data": "dosetype" },
                        { "data": "doseAmount" },
                        { "data": "type" },
                        { "data": "doseWindow" },
                        { "data": "entry" },
                        { "data": "location" },
                        { "data": "timeZone" },
                        { "data": "timeTaken" },
                        { "data": "timeTaken" },


                    ],
                    "columnDefs": [
                        {
                            "targets": [2],
                            //"orderable": false,
                            render: function (data, type, row) {
                                return data.split('_')[3];
                            }
                        },
                        {
                            "targets": [8],
                            render: function (data, type, row) {
                                if (data == '0')
                                    return 'Scan'
                                else if (data == '1')
                                    return 'Manual'
                                else if (data == '2')
                                    return '-'
                                
                            }
                        },
                        {
                            "targets": [10],
                            render: function (data, type, row) {
                                if (data != null) {
                                    let num = data.split(' ')[1];
                                    let GmtSec = num.split(':')[2];
                                    let GmtMin = num.split(':')[1];
                                    let Gmthr = num.split(':')[0];
                                    GmtSec = Math.round(GmtSec);

                                    if (GmtSec == 60) {
                                        GmtMin = Number(GmtMin) + 1;
                                        GmtSec = '00';
                                    }
                                    let finalGmt = Gmthr + ':' + GmtMin + ':' + GmtSec
                                    //alert(finalGmt)
                                    return data.split(' ')[0] + ' ' + finalGmt;
                                }
                                else
                                    return '-'
                                //return data == null ? '-' : data
                            }
                        },
                        {
                            "targets": [6],
                            render: function (data, type, row) {
                                if (data == 'normal')
                                    return 'On-Time'
                                else
                                return data && data.charAt(0).toUpperCase() + data.slice(1);
                            }
                        },
                        {
                            "targets": [12],
                           // "orderable": false,
                            render: function (data, type, row) {
                                return data.split('|')[1];
                            }
                        },
                        
                        {
                            "targets": [11],
                            
                            render: function (data, type, row) {
                                return data.split('|')[0];
                            }
                        },

                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    "pageLength": pageLength
                   
                });

               
            }
        });
       
        
    }

    onChangeTrialGroip(selectedValue) {
        this.isLoading = true;
        this.selectedTrialGroupId = Number(selectedValue);
        this.selectedTrialGroupName = null;
        this.allTrailsList = [];
        this.allPatientList = [];
        this.allContainerList = [];
        //To get selected role name
        if (this.allTrialGroupList != null) {
            for (var i = 0; i < this.allTrialGroupList.length; i++) {
                if (this.allTrialGroupList[i].id == this.selectedTrialGroupId) {
                    this.selectedTrialGroupName = this.allTrialGroupList[i].name;
                }
            }

        }
        if (selectedValue != 'Select') {
            this.notificationsService.getSelectedTrailsFromTrialGroup(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialGroupId)).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allTrailsList = response;
                    this.isLoading = false;
                    this.loadAllDropdowns();
                    
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else
        {

            this.loadAllDropdowns();
        }


    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let day = Number(d[1]) - 1;
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + day);
        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            }
            //else if (field === 'end') {
            //    this.setStartDateDisableSince(date.date);
            //}
        }
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    private dateForView(date: string): any {
        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2].replace('0', '') } };
        } else {
            return '';
        }
    }


    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }
    onChange_Trial(selectedValue) {
        this.isLoading = true;
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;
        this.allPatientList = [];
        this.allContainerList = [];
        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }
        if (String(this.selectedTrialId) != 'NaN') {
            this.notificationsService.getSelectedPatientsFromTrials(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialGroupId), Number(this.selectedTrialId)).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allPatientList = response;
                    this.isLoading = false;
                    this.loadAllDropdowns();
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else if (selectedValue == 'Select') {

            this.loadAllDropdowns();
        }

    }
    onChange_Patient(selectedValue) {
        this.isLoading = true;
        this.selectedPatientId = Number(selectedValue);
        this.selectedPatient = null;
        this.allContainerList = [];
        if (this.allPatientList != null) {
            for (var i = 0; i < this.allPatientList.length; i++) {
                if (this.allPatientList[i].id == this.selectedPatientId) {
                    this.selectedPatient = this.allPatientList[i].patient_number;
                }
            }

        }
        if (String(this.selectedPatientId) != 'NaN') {
            this.notificationsService.getSelectedContainerFromPatients(Number(localStorage.getItem('GLOBAL_COMPANY_ID')), Number(this.selectedTrialGroupId), Number(this.selectedTrialId), this.selectedPatient).subscribe(
                (response) => {
                    //alert(this.selectedTrialGroupId);
                    this.allContainerList = response;
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });
        }
        else if (selectedValue == 'Select') {

            this.loadAllDropdowns();
        }
    }
    onChange_Container(selectedValue) {

        this.selectedContainerId = Number(selectedValue);
        this.selectedContainer = null;

        if (this.allContainerList != null) {
            for (var i = 0; i < this.allContainerList.length; i++) {
                if (this.allContainerList[i].id == this.selectedContainerId) {
                    this.selectedContainer = this.allContainerList[i].patient_container_id;
                }
            }

        }
    }
    
}
