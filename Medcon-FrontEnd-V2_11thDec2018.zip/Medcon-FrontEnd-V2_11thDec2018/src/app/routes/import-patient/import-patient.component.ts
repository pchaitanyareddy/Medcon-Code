﻿import { Component, HostListener, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { PatientService } from '../../services/patient.service';
import { Race } from '../../models/race';
import { PatientRequest } from '../../requests/patient-request';
import { PatientUploadRequest } from '../../requests/patient-upload-request';
import { Observable } from 'rxjs/Observable';
import { TabsetComponent } from 'ngx-bootstrap';
import { NotificationsService } from '../../services/notifications.service';
import { UserService } from '../../services/user.service';
import { TrialService } from '../../services/trial.service';
import { TrialOverview } from '../../models/trialoverview';
@Component({
    templateUrl: './import-patient.component.html?v=${new Date().getTime()}'
})

export class ImportPatientComponent implements OnInit {
    @ViewChild('patientMenu') public patientMenu: TabsetComponent;
    public showErrors: boolean;
    public showUploadErrors: boolean;
    public successMessage: string;
    public errorMessage: string;
    public form: FormGroup;
    public upload: FormGroup;
    public races: Race[];
    public trialId: number;
    public companyId: number;
    public error: any;
    public trialOverview: TrialOverview;
    selectedCompanyText;
    selectedCompanyValue;
    trialList: any;
    selectedTrialText;
    selectedTrialValue;
    companyList: any;
    userId: number;
    selectedCompanyId: number;
    selectedTrialId: number;
    selectedTrial: number;
    selectedCompany: string;
    isLoading: boolean;
    duplicatedPatients: any;
    public myDatePickerOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public patientStatus: any;

    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private router: Router,
        private fb: FormBuilder,
        private patientService: PatientService,
        private NotificationsService: NotificationsService,
        private userService: UserService,
        private trialService: TrialService,
        private changeDetectorRef: ChangeDetectorRef) {
    }

    public ngAfterViewInit(): void {
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
    }
    public ngOnInit() {
        this.duplicatedPatients = null;
        this.isLoading = false;
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        this.trialId = this.route.snapshot.queryParams['trial_id'];
        this.races = this.route.snapshot.data['races'];

        this.form = this.fb.group({
            trialList: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            company: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            race: [''],
            sex: ['', Validators.pattern('male|female')]
        });

        this.upload = this.fb.group({
            trialList: ['', Validators.required],
            companyList: [''],
            file: [''],
            patientNumbers: ['', Validators.required]
        });

        
        //this.trialList = [
        //    { id: 1, trialName: 'Test Trial one' },
        //    { id: 2, trialName: 'Test Trial two' },
        //    { id: 3, trialName: 'Test Trial three' }
        //]
        if (Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID')) != null)
            this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        else
            this.selectedCompanyId = Number(this.route.snapshot.params['customer_id']);
       // alert(this.selectedCompanyId);
        //this.selectedTrialId = 1;
        //alert(this.selectedCompanyId);
        this.NotificationsService.getAllTrails(Number(this.selectedCompanyId)).subscribe(
            (response) => {
                this.trialList = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        //this.companyList = [
        //    { id: 1, companyName: 'ABC Pharmaticual' },
        //    { id: 2, companyName: 'Test1' },
        //    { id: 3, companyName: 'Test2' }
        //]
        this.userService.getAllCompanies().subscribe(
            (response) => {
                this.companyList = response;
                //this.allCompanyList.filter(company => company.companyId === this.selectedCompanyId);
            },
            (err) => {
                this.errorMessage = err;

            });

        //this.selectedTrialText = this.trialList[0].trialName;
        //this.selectedTrialValue = this.trialList[0].id;
        //this.selectedCompanyText = this.companyList[0].companyName;
        //this.selectedCompanyValue = this.companyList[0].id;

       
    }

    public onSubmit() {
        if (this.form.invalid) {
            this.showErrors = true;
        } else {
            this.isLoading = true;
            let request = new PatientRequest(
                this.form.value.patientId,
                this.trialId,
                this.form.value.sex,
                this.form.value.race,
                this.convertDate(this.form.value.dob.date)
            );
            this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
            this.patientService.createPatient(this.route.snapshot.params['customer_id'], request).subscribe(
                (response) => {
                    this.form.markAsPristine();
                    this.goBack();
                },
                (err) => {
                    this.errorMessage = err;
                });
        }
    }

    public onUploadSubmit(ButtonId) {
        
        //Get trial id from drop down selected value
        //Get company id from company drop down selected value
        //alert(this.upload.value.company);
        //alert(this.upload.value.companyList);
        this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
        this.selectedCompanyId = this.getCompanyIdCompanyName(this.upload.value.companyList);
        if (this.upload.invalid) {
            this.showUploadErrors = true;
            //if (String(this.selectedTrialId) == 'NaN' || this.selectedTrialId == undefined)
            if ($("#trialList").val() == 'NaN' || $("#trialList").val() == undefined || $("#trialList").val() == '')
            {
                this.errorMessage = 'Please select trial';
                return;
            }
            if (this.upload.value.patientNumbers.length <= 0) {
                this.errorMessage = 'Please enter at least 1 patient number';
                return;
            }
            return;
        }
        else if (this.selectedCompanyId==1)  {

            this.errorMessage = 'Please select valid company other than medcon';
            return;
        }
        else if ($("#trialList").val() == 'NaN' || $("#trialList").val() == undefined || $("#trialList").val()=='') {
            this.errorMessage = 'Please select trial';
            return;
        }

        let patientNumbers = this.upload.value.patientNumbers
            .replace(/[,;]+/g, '').split('\n').filter((e) => /\S/.test(e));
        
        if (patientNumbers.length <= 0) {
            this.errorMessage = 'Please enter at least 1 patient number';
            return;
        }
        
            var arrDuplicatePatients = this.getDuplicatePatientIds(patientNumbers);
            this.duplicatedPatients = arrDuplicatePatients;
            if (arrDuplicatePatients.length > 0 && ButtonId != 'btnContinue') {

                ///this.errorMessage = 'Cannot upload any of the patient numbers as they are all duplicates';
                return;

            }
            else
                this.duplicatedPatients = null;
               
        this.isLoading = true;
        let request = new PatientUploadRequest(
            patientNumbers,
            this.selectedTrialId,
            
            !!(this.error && this.error.error === 'duplicates'),
            Number(this.userId),
            Number(this.selectedCompanyId)
        );
       
        this.patientService.uploadPatients(this.selectedTrialId, request)
            .subscribe(
            (response) => {
                this.isLoading = false;
                this.alertClosed();
                this.successMessage = 'Patients successfully uploaded';
                //this.patientMenu.tabs[2].active = true;
                //this.onRefresh(this.selectedCompanyId, 'import-patient');
                this.upload.controls['patientNumbers'].setValue('');
            },
            (err) => {
                this.isLoading = false;
                // Duplicates error
                if (err.error === 'duplicates') {
                    this.errorMessage = err.message;
                    this.error = err;
                    $('#errorPanel').addClass("disableDiv"); 
                    
                  
                } else {
                    // Generic error
                    this.errorMessage = err;
                    $('#errorPanel').removeClass("disableDiv"); 
                    
                }
            }
            );
    }


   
    onRefresh(companyId, viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId != '')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
        this.error = null;
    }

    public goBack(): void {
        this.form.markAsPristine();
        //this.router.navigate([
            //this.route.snapshot.params['customer_id'],
            //'trials',
            //this.trialId,
            //'edit'
        //], { queryParams: { tab: 'patients' } });
        this.router.navigate(['/', 'dashboard']);
    }
    public clearForm() {
      // alert('RESET');
        
      
        this.selectedTrialId = null;
        this.upload.reset();
        //alert(this.selectedCompanyId)
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        $('#companyList').val(this.selectedCompany)
        //alert(this.selectedCompany);
        
    }

    public fileChange(input) {
        this.processPatientsFile(input.target.files);
        this.duplicatedPatients = null;
    }

    public selectedStatusCheck() {
        this.checkPatientUploadStatus();
    }

    public removeFailedUploads() {
        this.patientService.removeFailedUploads(this.trialId, this.route.snapshot.params['customer_id']).subscribe(
            (response) => {
                this.successMessage = 'Failed patient uploads have been successfully removed';
                this.checkPatientUploadStatus();
            },
            (err) => {
                this.errorMessage = err;
            }
        );
    }

    public checkPatientUploadStatus() {
        this.patientStatus = null;

        this.patientService.getUploadStatus(this.trialId, this.route.snapshot.params['customer_id']).subscribe(
            (response) => {
                let stats = {
                    Pending: 0,
                    Failed: 0
                };
                for (let status of response) {
                    stats[status.status]++;
                }
                this.patientStatus = {
                    status: stats,
                    items: response
                };
            }
        );
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.form.dirty;
    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    private processPatientsFile(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                this.upload.controls['patientNumbers'].setValue(result);
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

    private readFile(file, reader, callback) {
        let invalidFileMessage = 'Patient numbers file must be a CSV';

        if (
            file.type &&
            file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel' && file.type !== 'application/csv'
        ) {
            return this.errorMessage = invalidFileMessage;
        }

        if (file.name.split('.').pop().toLowerCase() !== 'csv') {
            return this.errorMessage = invalidFileMessage;
        }

        reader.onload = () => {
            callback(reader.result.replace(/\r\n|\n/, '\n').replace(/[,;]+/g, ''));
        };

        reader.readAsText(file);
    }


    onChange_State(selectedValue) {
        //alert(this.selectedTrialId);
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;

        if (this.trialList != null) {
            for (var i = 0; i < this.trialList.length; i++) {
                if (this.trialList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.trialList[i].name;
                }
            }

        }
        //Added on 3rd June 2018, Todo: we can commentout these lines of code if not required
        //10th Dec 2018:No need this code line as trial options are created when trial is created
        //if (String(this.selectedTrialId) != 'NaN') {
            
        //    this.getTrialOptionsFromTrialOverView(this.selectedTrialId);

        //}

        //End

    }

    getCompanyIdCompanyName(companyName): number {
        let companyId = 0;
        if (this.companyList != null) {
            for (var i = 0; i < this.companyList.length; i++) {
                if (this.companyList[i].companyName == companyName) {
                    companyId = this.companyList[i].companyId;
                }
            }

        }
        return companyId;
    }

    onChange(selectedValue)
    {
        this.selectedCompanyId = this.getCompanyIdCompanyName(selectedValue);
        if (Number(this.selectedCompanyId) != 0) {
            this.NotificationsService.getAllTrails(Number(this.selectedCompanyId)).subscribe(
                (response) => {
                    this.trialList = response;

                },
                (err) => {
                    this.errorMessage = err;

                });
        }

    }

    getTrialOptionsFromTrialOverView(trialId)
    {
        
        this.trialService.getTrialOverview(trialId).subscribe(
            (response) => {
                this.trialOverview = response;
                if ((this.trialOverview.target.trialAdherenceTarget == null || this.trialOverview.target.trialAdherenceTarget == undefined || this.trialOverview.target.trialAdherenceTarget == 0)) {
                    //alert('trial overview11111111111');
                    $('#btnUpload').attr('disabled', 'disabled');
                    $('#btnUpload').attr('title', 'Please setup trial options first to Add Patient');
                }
                else {
                    $('#btnUpload').removeAttr('disabled');
                    $('#btnUpload').removeAttr('title');

                }
            },
            (err) => {
                this.errorMessage = err;

            });
       


    }

    //private hasDuplicates(array): string[] {
    //    var arrDuplicates = [];
    //    var valuesSoFar = Object.create(null);
    //    for (var i = 0; i < array.length; i++) {
    //        var value = array[i];
    //        if (value in valuesSoFar) {
    //            arrDuplicates.push(array[i]);
    //            //return true;
    //        }
    //        valuesSoFar[value] = true;
    //    }
    //    return arrDuplicates;

    //}

    private getDuplicatePatientIds(array): string[] {

        var arrDuplicates = [];
        var sorted_arr = array.sort();
        //var results = [];
        for (var i = 0; i < array.length - 1; i++) {
            //alert(sorted_arr[i]);
            //alert(sorted_arr[i + 1]);
            if (sorted_arr[i + 1].trim() == sorted_arr[i].trim()) {

                arrDuplicates.push(sorted_arr[i]);
            }
        }

        return arrDuplicates;

    }
}
