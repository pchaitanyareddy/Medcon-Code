﻿export class Measurement {
    constructor(
        public measurementId: number,
        public medicationType: string,
        public unitOfMeasure: string,
        public image: string) {
    }

}
