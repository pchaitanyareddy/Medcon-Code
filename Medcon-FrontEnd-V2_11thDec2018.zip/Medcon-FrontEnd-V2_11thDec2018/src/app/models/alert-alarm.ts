export class AlertAlarm {
	constructor(public id: number,
		public sequence: number,
		public title: string,
		public description: string,
		public message: string) {
	}
}
