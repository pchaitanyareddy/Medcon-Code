﻿export class Label {
    constructor(public id: number,
        public year: string,
        public total: string) {
    }
}
