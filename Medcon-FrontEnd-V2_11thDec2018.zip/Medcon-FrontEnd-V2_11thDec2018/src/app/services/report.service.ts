import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import { saveAs } from 'file-saver';
import { ReportScheduleRequest } from '../requests/report-schedule-request';
import { ReportSchedule } from '../models/reportschedule';

@Injectable()
export class ReportService {
	constructor(private http: Http) {
	}

	public getAdherenceReport(trialId?: number, customerId?: number, filters?: any): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('trial_id', String(trialId || ''));
		params.set('customer_id', String(customerId || ''));
		if (filters) {
			filters.forEach((filter) => {
				params.set(filter.key, String(filter.value || ''));
			});
		}

		return this.http.get(API_PATH + '/report/adherence', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public exportAdherenceReport(trialId?: number, customerId?: number, filters?: any): void {
		// Is supported
		try {
			let isFileSaverSupported = !!new Blob();
		} catch (e) {
			alert('Browser not supported');
			return;
		}

		let params: URLSearchParams = new URLSearchParams();
		params.set('trial_id', String(trialId || ''));
		params.set('customer_id', String(customerId || ''));
		if (filters) {
			filters.forEach((filter) => {
				params.set(filter.key, String(filter.value || ''));
			});
		}

		this.http.get(API_PATH + '/report/adherence/export', { search: params })
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'))
			.subscribe((response) => {
				let blob = new Blob([decodeURIComponent(encodeURI(response.text()))], {
					type: 'text/csv;charset=utf-8;'
				});

				let filename = 'medcon dose export.csv';
				saveAs(blob, filename);
			});
	}

	public createSchedule(request: ReportScheduleRequest): Observable<(any)> {
		return this.http.post(API_PATH + '/report/schedule', request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getSchedules(): Observable<ReportSchedule[]> {
		return this.http.get(API_PATH + '/report/schedule/list')
			.map((res: Response) => res.json().map((result) => {
				return new ReportSchedule(result.id, result.trial.id, result.trial.name, result.cron);
			}))
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public deleteSchedule(id: string): Observable<(any)> {
		return this.http.delete(API_PATH + '/report/schedule/' + id)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public convertToCSV(objArray,reportType): string {
        //alert(typeof objArray);
        var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
        var str = '';
        if (reportType == 'Patient Details')
            str = 'Trial Name, Patient Id,Container,Drug Name,Dose Type,Dose Amount,Type,Dose Window,Entry,Location,Dose Timezone,Date,Time \r\n';
        else if (reportType == 'Patient Report')
            str = 'Patient ID,Trial Name,Trial Group Count,Company,Start Date, End Date \r\n';
            //str = 'Start Date, End Date,Company, Patient ID,Trial Name,Trial Group Count\r\n';
        else if (reportType == 'TrialOverView-PatientList')
            str = 'Patient ID,Age,Sex,Race,First Scan,LastScan,Containers\r\n';
        else if (reportType == 'Drug Regimen Pair List')
            str = 'Drug Name,Regimen Name,Dose Type,Dose Amount,Dose Unit,Dose Strength, Start Date,End Date,Status\r\n';
        else if (reportType == 'Company List')
            str = 'Company Name,Company Type,Company Adh Target,Labels Committed,Labels Purchased,Labels Used\r\n';
            //str = 'Company Name,Company Adh Target, Labels Used,Labels Purchased,Labels Committed,Company Type\r\n';
        else if (reportType == 'Regimen List')
            str = 'Name,Medication Units Per Dose, Total Doses,Extra Doses,Duration Between Doses,Schedule Type\r\n';
            //str = 'Duration Between Doses,Extra Doses, Regimen Name,Units Per Dose,Total Doses,Schedule Type\r\n';
        else if (reportType == 'Data Reports')
            //str = 'Trial,Patient,Container,Dose,Type,Extra Dose,Entry,Location,Date,Time\r\n';
            //str = 'Trial,Patient ID,Container, Dose#,Type,Extra Dose,Entry,Location,Date,Time\r\n';
            str ='Trial Name, Patient Id,Container,Drug Name,Dose Type,Dose Amount,Type,Dose Window,Entry,Location,Dose Timezone,Date,Time \r\n';
        else if (reportType == 'Label Report')
            str = 'Company,Committed,Purchased,Used,Remaining,Year\r\n';
            //str = 'Company Name,Labels Used, Labels Purchased,Labels Remaining,Year,Labels Committed\r\n';
        else if (reportType == 'Titration Report')
            str = 'Trial,Drug,Regimen,Dose Type,Dose Amount ,Dose Unit,Dose Strength,Start Date, End Date,Status\r\n';
            //str = 'Dose Strength,Dose Unit,Status, End Date,Dose Amount ,Company Name,Dose Type,Regimen Name,Trial Name,Drug Name,Start Date\r\n';
        else if (reportType == 'Export Label')
            str = 'Company Name,Company Id,Trial Name,Trial Id,Drug Regimen Name,Drug Regimen Id\r\n';
        else if (reportType == 'Trialgroup List')
            str = 'Trial Group Name,Created By,Date Created,Trial Count\r\n';
        //else if (reportType == 'Trial Patient List')
        //    str = 'First Scan,status,Race,Titrate,Age,Last Scan,Patient ID,Containers,Sex\r\n';
        else if (reportType == 'Trial Patient List')
            str = 'Patient ID,Age,Gender,Race,First Scan,Last Scan,Containers,Titrate,Status\r\n';
        else if (reportType == 'Site List')
            str = 'Name,Address,Country,Phone\r\n';
        else if (reportType == 'Manage Drug List')
            str = 'Drug Name,Drug Alias,Medication Type,Medication Unit\r\n';
        else if (reportType == 'Broadcast Messages List')
            str = 'Message Title,Message Type,User Name,Email,Trial Name,Patient,Date/Time\r\n';
            //str = 'Message Title,Message Type,User Name,Email,Trial Name,Patient,Accepted,Date/Time\r\n';
        else if (reportType == 'Labels Committed')
            str = 'Company Name,Committed Year,Labels Committed,Labels purchased,Labels used,Labels Remaining,Status\r\n';
        else if (reportType == 'Notification List')
            str = 'Trail Name,User Name,Email,Number of Subscription,Notification Type\r\n';
        else if (reportType == 'Manage Users')
            str = 'First Name,Last Name,Email Address,Mobile,Role,Last Login,Status\r\n';
        else if (reportType == 'Measurment List')
            str = 'Medication Type,Unit of Measure,Status\r\n';
        else if (reportType == 'Trial Containers')
            str = 'Container #,Patient ID ,Dose Type,Remaining Doses,Remaining Medication Units,Start Date,End Date,Status\r\n';
	else if (reportType == 'Trial List')
            str = 'Trial Name,Start Date,End Date,Labels/Containers used,male,female,Drug/Regimen Pair,Status\r\n';
        else if (reportType == 'Associate Site')
            str = 'Site Name,Address,Country,Phone\r\n';
        else if (reportType == 'Associate Group List')
            str = 'Trial Group Name,Created By,Created Date\r\n';
        //alert(array.data);
        let columnCounter = 0;
        for (var i = 0; i < array.data.length; i++) {
            var line = '';
            columnCounter = 0;
            for (var index in array.data[i]) {
                //if (i == 0) {
                //    alert(columnCounter);
                //    alert(index);
                //}
                //alert(array.data[i][index]);
                //alert('i' + i);
                //alert('index' + index);
                if (reportType == 'Manage Drug List' && index == 'paircount' && line != '')
                {
                    //alert(i);
                    continue;
                   // line = line;
                }
                else if (reportType == 'Company List' && index == 'id' && line != '')
                {
                    continue;
                }
                else if (reportType == 'Label Report' && index == 'Date' && line != '') {
                    continue;
                }
                else if (reportType == 'Labels Committed' && index == 'companyId' && line != '') {
                    continue;
                }
                else if (reportType == 'Trial Patient List' && index == 'ptitrate')
                {
                    continue;
                }
                else if (reportType == 'Trial Patient List' && index == 'ttitrate') {
                    continue;
                }
                else if (reportType == 'Trial Patient List' && index == 'Id') {
                    continue;
                }
                else if (reportType == 'Patient Report' && index == 'Country')
                {
                    continue;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'ttitrate') {
                    continue;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'titrate') {
                    continue;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'Id') {
                    continue;
                }
                else if (reportType == 'Notification List' && index == 'notifId') {
                    continue;
                }
                else if (reportType == 'Notification List' && index == 'name') {
                    continue;
                } 
                else if (reportType == 'Notification List' && index == 'trialId') {
                    continue;
                }
                else if (reportType == 'Notification List' && index == 'status') {
                    continue;
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'measureUnit') {
                    continue;
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'drugregimenId') {
                    continue;
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'isTitrated') {
                    continue;
                }
                else if (reportType == 'Manage Users' && index == 'userId') {
                    continue;
                }
                else if (reportType == 'Manage Users' && index == 'email') {
                    continue;
                }
                else if (reportType == 'Measurment List' && index == 'drugCount') {
                    continue;
                }
                else if (reportType == 'Measurment List' && index == 'id') {
                    continue;
                }
                else if (reportType == 'Measurment List' && index == 'bucketKey') {
                    continue;
                }
                else if (reportType == 'Trial Containers' && index == 'start') {
                    continue;
                }
                else if (reportType == 'Trial Containers' && index == 'remainingDoses') {
                    continue;
                }
                else if (reportType == 'Trial Containers' && index == 'unit') {
                    continue;
                }
		else if (reportType == 'Trial List' && index == 'labelsUsed') {
                    continue;
                }
                else if (reportType == 'Trial List' && index == 'containers') {
                    continue;
                }
                else if (reportType == 'Titration Report' && index == 'trialName')
                {
                    continue;
                }
                else if (reportType == 'Titration Report' && index == 'drugName') {
                    continue;
                }
                else if (reportType == 'Titration Report' && index == 'bucketKey') {
                    continue;
                }
                else if (reportType == 'Associate Group List' && index == 'createdBy') {
                    continue;
                }
                else if (reportType == 'Associate Group List' && index == 'createdDate') {
                    continue;
                }
                else if (reportType == 'Patient Details' && index == 'type') {
                    continue;
                }
                else if (reportType == 'Patient Details' && index == 'extraDose') {
                    continue;
                }
               
                else if (reportType == 'Data Reports' && index == 'Patient') {
                    continue;
                }
                //else if (reportType == 'Data Reports' && index == 'timeZone') {
                //    continue;
                //}
                else if (reportType == 'Data Reports' && index == 'type') {
                    continue;
                }
                else if (reportType == 'Broadcast Messages List' && index == 'accepted') {
                    continue;
                }
                else if (reportType == 'Trial List' && index == 'labelsUsed') {
                    continue;
                }
                else if (line != '') line += ','
                if (reportType == 'Titration Report' && index == 'doseStrength')
                    line += array.data[i]['trialName'];
                else if (reportType == 'Titration Report' && index == 'doseUnit')
                    line += array.data[i]['drugName'];
                else if (reportType == 'Titration Report' && index == 'Status')
                    line += array.data[i]['regimenName'];
                else if (reportType == 'Titration Report' && index == 'endDate')
                    line += array.data[i]['doseType'];
                else if (reportType == 'Titration Report' && index == 'startDate')
                    line += array.data[i]['doseUnit'] + " " + array.data[i]['dosemeasure'];
                else if (reportType == 'Titration Report' && index == 'dosemeasure')
                    line += array.data[i]['doseStrength'] + " " + array.data[i]['dosemeasure'];
                else if (reportType == 'Titration Report' && index == 'doseType')
                    line += array.data[i]['startDate'];
                else if (reportType == 'Titration Report' && index == 'companyName')
                    line += array.data[i]['endDate'];
                else if (reportType == 'Titration Report' && index == 'regimenName')
                {
                    
                    let retVal;
                    if (array.data[i]['Status'] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'


                    line += retVal;
                }
                //if (reportType == 'Titration Report' && index == 'bucketKey')
                //    line += "";
                //else if (reportType == 'Titration Report' && index == 'doseStrength')
                //    line += array.data[i]['trialName'];
                //else if (reportType == 'Titration Report' && index == 'doseUnit')
                //    line += array.data[i]['drugName'];
                //else if (reportType == 'Titration Report' && index == 'Status')
                //    line += array.data[i]['regimenName'];
                //else if (reportType == 'Titration Report' && index == 'endDate')
                //    line += array.data[i]['doseType'];
                //else if (reportType == 'Titration Report' && index == 'companyName')
                //    line += array.data[i]['doseUnit'];
                //else if (reportType == 'Titration Report' && index == 'doseType')
                //    line += array.data[i]['doseStrength'];
                //else if (reportType == 'Titration Report' && index == 'regimenName')
                //    line += array.data[i]['startDate'];
                //else if (reportType == 'Titration Report' && index == 'trialName')
                //    line += array.data[i]['endDate'];
                //else if (reportType == 'Titration Report' && index == 'drugName')
                //{
                //    //line += array.data[i]['Status'];
                //    let retVal;
                //    if (array.data[i]['Status'] == '1')
                //        retVal = 'Active'
                //    else
                //        retVal = 'InActive'


                //    line += retVal;
                //}
                //else if (reportType == 'Titration Report' && index == 'startDate')
                //    line += "";
                //else if (reportType == 'Data Reports' && index == 'extraDose')
                //    line += (array.data[i][index] == '0') ? 'No' : array.data[i][index];
                else if (reportType == 'Patient Details' && index == 'doseWindow') {
                    line += array.data[i]['trialName'];
                }
                else if (reportType == 'Patient Details' && index == 'Container') {
                    line += array.data[i]['patientId'];
                }
                else if (reportType == 'Patient Details' && index == 'doseAmount') {
                    line += '="' + array.data[i]['Container'].split('_')[3] + '"'; 
                }
                else if (reportType == 'Patient Details' && index == 'dose') {
                    line += (array.data[i]['drugname'] == null) ? " " : array.data[i]['drugname'];
                }
                else if (reportType == 'Patient Details' && index == 'dosetype') {
                    line += (array.data[i][index]==null)?" ":array.data[i][index];
                }
                else if (reportType == 'Patient Details' && index == 'patientId') {
                    line += array.data[i]['doseAmount'];
                }
                else if (reportType == 'Patient Details' && index == 'timeTaken') {
                    let retVal;
                    if (array.data[i]['type'] == 'normal')
                        retVal = 'On-Time'
                    else
                        retVal = array.data[i]['type'] && array.data[i]['type'].charAt(0).toUpperCase() + array.data[i]['type'].slice(1);

                    line += retVal;
                }
                else if (reportType == 'Patient Details' && index == 'trialName') {
                    line += array.data[i]['doseWindow'];
                }
                
                else if (reportType == 'Patient Details' && index == 'location') {
                    let retVal;
                    if (array.data[i]['entry'] == '0')
                        retVal = 'Scan'
                    else if (array.data[i]['entry'] == '1')
                        retVal = 'Manual'
                    else if (array.data[i]['entry'] == '2')
                        retVal = '-'

                    line += retVal;
                }
                else if (reportType == 'Patient Details' && index == 'drugname') {
                    line += array.data[i]['location'];
                }

                else if ((reportType == 'Patient Details') && index == 'timeZone') {
                    //line += array.data[i][index];
                    if (array.data[i][index] != null) {
                        let num = array.data[i][index].split(' ')[1];
                        let GmtSec = num.split(':')[2];
                        let GmtMin = num.split(':')[1];
                        let Gmthr = num.split(':')[0];
                        GmtSec = Math.round(GmtSec);

                        if (GmtSec == 60) {
                            GmtMin = Number(GmtMin) + 1;
                            GmtSec = '00';
                        }
                        let finalGmt = Gmthr + ':' + GmtMin + ':' + GmtSec
                        //alert(finalGmt)
                        line += array.data[i][index].split(' ')[0] + ' ' + finalGmt;
                    }
                    else
                        line += "-";
                }
                else if (reportType == 'Patient Details' && index == 'entry') {
                    let date = array.data[i]['timeTaken'].split('|')[0];
                    let time = array.data[i]['timeTaken'].split('|')[1];
                    line += date + ',' + time
                }
               
                
                
                
               
                else if (reportType == 'Data Reports' && index == 'doseWindow') {
                    line += array.data[i]['trial'];
                }
                else if (reportType == 'Data Reports' && index == 'entry') {
                    line += array.data[i]['Patient'];
                }
                else if (reportType == 'Data Reports' && index == 'Container') {
                    let retval1 = '_'; //'="01"
                    let retval2 = array.data[i][index].split('_')[3]
                    line += '="'+retval2+ '"';
                    
                }
                
                else if (reportType == 'Data Reports' && index == 'doseAmount') {
                    line += (array.data[i]['drugname']==null)?" ":array.data[i]['drugname'];
                }
                else if (reportType == 'Data Reports' && index == 'dosetype') {
                    line += (array.data[i][index] == null) ? " " : array.data[i][index];
                }
                else if (reportType == 'Data Reports' && index == 'timeTaken') {
                    line += array.data[i]['doseAmount'];

                }

                else if (reportType == 'Data Reports' && index == 'dose') {
                    let retVal;
                    if (array.data[i]['type'] == 'normal')
                        retVal = 'On-Time'
                    else
                        retVal = array.data[i]['type'] && array.data[i]['type'].charAt(0).toUpperCase() + array.data[i]['type'].slice(1);

                    line += retVal;
                }
                else if (reportType == 'Data Reports' && index == 'trial') {
                    line += array.data[i]['doseWindow'];

                }
                else if (reportType == 'Data Reports' && index == 'extraDose') {
                    let retVal;
                    if (array.data[i]['entry'] == '0')
                        retVal = 'Scan'
                    else if (array.data[i]['entry'] == '1')
                        retVal = 'Manual'
                    else if (array.data[i]['entry'] == '2')
                        retVal = '-'

                    line += retVal;

                }
                else if (reportType == 'Data Reports' && index == 'location') {
                    line += array.data[i][index];
                } 
                
                //else if (reportType == 'Data Reports' && index == 'Patient') {
                //    line += array.data[i]['location'];
                //    //line += array.data[i]['timeTaken'].split('|')[0];
                //}
                else if (reportType == 'Data Reports' && index == 'drugname') {
                    //line += (array.data[i]['timeZone']==null)?"-":array.data[i]['timeZone'];
                    if (array.data[i]['timeZone'] != null) {
                        let num = array.data[i]['timeZone'].split(' ')[1];
                        let GmtSec = num.split(':')[2];
                        let GmtMin = num.split(':')[1];
                        let Gmthr = num.split(':')[0];
                        GmtSec = Math.round(GmtSec);

                        if (GmtSec == 60) {
                            GmtMin = Number(GmtMin) + 1;
                            GmtSec = '00';
                        }
                        let finalGmt = Gmthr + ':' + GmtMin + ':' + GmtSec
                        //alert(finalGmt)
                        line += array.data[i]['timeZone'].split(' ')[0] + ' ' + finalGmt;
                    }
                    else
                        line += "-";
                }
                

               
                
                else if (reportType == 'Data Reports' && index == 'timeZone') {
                    let date = array.data[i]['timeTaken'].split('|')[0];
                    let time = array.data[i]['timeTaken'].split('|')[1];
                    line += date+','+time
                }


                else if (reportType == 'Patient Report' && index == 'TrialGroups')
                {
                    line += array.data[i]['endDate'];
                }
                else if (reportType == 'Patient Report' && index == 'trialName') {
                    line += array.data[i]['startDate'];
                }
                else if (reportType == 'Patient Report' && index == 'startDate') {
                    line += array.data[i]['PatientID'];
                }
                else if (reportType == 'Patient Report' && index == 'endDate') {
                    line += array.data[i]['trialName'];
                }
                else if (reportType == 'Patient Report' && index == 'Company') {
                    line += array.data[i]['TrialGroups'];
                }
                else if (reportType == 'Patient Report' && index == 'PatientID') {
                    line += array.data[i]['Company'];
                }
                
                else if (reportType == 'Patient Details' && index == 'extraDose')
                    line += (array.data[i][index] == '0') ? 'No' : array.data[i][index];
                    //To Clear null in the export file.
                //else if (reportType == 'Company List' && index == 'labelsPurchased')
                //{
                //    let retVal;
                //    if (array.data[i][index] == '' || array.data[i][index]==null)
                //        retVal = '0'
                //    else
                //        retVal = array.data[i][index]


                //    line += retVal;
                //}
                //else if (reportType == 'Company List' && index == 'id')
                //    line += "";
                //else if (reportType == 'Company List' && index == 'labelsCommitted') {
                //    let retVal;
                //    if (array.data[i][index] == '' || array.data[i][index] == null)
                //        retVal = '0'
                //    else
                //        retVal = array.data[i][index]


                //    line += retVal;
                //}
                //Swapping column data for company list
                else if (reportType == 'Company List' && index == 'minPatientAdhTarget') { 
                    line += array.data[i]['companyType'];   //As per screen,2nd column-Company type
                }
                else if (reportType == 'Company List' && index == 'labelsUsed') { 
                    line += array.data[i]['minPatientAdhTarget']; //3rd column-Company Adh Target
                }
                else if (reportType == 'Company List' && index == 'labelsPurchased') { 
                    let retVal;
                    if (array.data[i]['labelsCommitted'] == '' || array.data[i]['labelsCommitted'] == null)
                        retVal = '0'
                    else
                        retVal = array.data[i]['labelsCommitted']


                    line += retVal; //4th column-Labels committed
                }
                else if (reportType == 'Company List' && index == 'labelsCommitted') {
                    let retVal;
                    if (array.data[i]['labelsPurchased'] == '' || array.data[i]['labelsPurchased'] == null)
                        retVal = '0'
                    else
                        retVal = array.data[i]['labelsPurchased']


                    line += retVal; //5th column-Labels purchased
                }
                else if (reportType == 'Company List' && index == 'companyType') {
                    line += array.data[i]['labelsUsed']; //6th column-Labels used
                }
                else if (reportType == 'Label Report' && index == 'iD')
                    line += "";
                else if (reportType == 'Label Report' && index == 'companyId')
                    line += "";
                else if (reportType == 'Label Report' && index == 'labelsUsed')
                    line += array.data[i]['labelsCommitted'];
                else if (reportType == 'Label Report' && index == 'labelsRemaining')
                    line += array.data[i]['labelsUsed'];
                else if (reportType == 'Label Report' && index == 'year')
                    line += array.data[i]['labelsRemaining'];
                else if (reportType == 'Label Report' && index == 'labelsCommitted')
                    line += array.data[i]['year'];
                else if (reportType == 'Company List' && index == 'status')
                    line += "";
                else if (reportType == 'Regimen List' && index == 'numPairs')
                    line += "";
                else if (reportType == 'Regimen List' && index == 'id')
                    line += "";
                else if (reportType == 'Regimen List' && index == 'status')
                    line += "";
               
                else if (reportType == 'Regimen List' && index == 'durationBetweenDoses')
                    line += array.data[i]['regimenName'];
                else if (reportType == 'Regimen List' && index == 'extraDoses')
                    line += array.data[i]['unitsPerDose'];
                else if (reportType == 'Regimen List' && index == 'regimenName')
                    line += array.data[i]['totalDoses'];
                else if (reportType == 'Regimen List' && index == 'unitsPerDose')
                    line += array.data[i]['extraDoses'];
                else if (reportType == 'Regimen List' && index == 'totalDoses')//swapping column data between totalDoses column and durationBetweenDoses, as API gives totalDoses column in 5th position, but screen displays "Duration between doses" column in 5th position, to make consistency between screen and export file, setting 5th position to "Duration between doses" column.
                {
                    
                    let minsPerDay = 24 * 60;
                    let minsPerHour = 60;
                    let minutes = array.data[i]['durationBetweenDoses'];
                    let converted = '';

                    let days = Math.floor(minutes / minsPerDay);

                    converted += (days < 10) ? '0' + days + 'D ' : days + 'D ';
                    minutes = minutes - days * minsPerDay;
                    let hours = Math.floor(minutes / minsPerHour);
                    converted += (hours < 10) ? '0' + hours + 'HRS ' : hours + 'HRS ';
                    minutes = minutes - hours * minsPerHour;
                    converted += (hours < 10) ? '0' + minutes + 'MINS' : minutes + 'MINS';

                    line += converted;
                }
                else if (reportType == 'Trialgroup List' && index == 'status')
                    line += "";
                else if (reportType == 'Trialgroup List' && index == 'id')
                    line += "";
                else if (reportType == 'Trialgroup List' && index == 'trailCount') //swap columns data between from trialCount and createdBy to change column order
                    line += array.data[i]['createdBy']; 
                else if (reportType == 'Trialgroup List' && index == 'createdBy') //swap columns data between from createdBy and createdDate to change column order
                    line += array.data[i]['createdDate'];
                else if (reportType == 'Trialgroup List' && index == 'createdDate') //swap columns data between from createdDate and trailCount to change column order
                    line += array.data[i]['trailCount'];
                else if (reportType == 'Trial Patient List' && index == 'status') {
                    line += array.data[i]['PatientID'];
                }
                else if (reportType == 'Trial Patient List' && index == 'LastScan') {
                    line += (array.data[i]['Sex'] == null) ? '-' : array.data[i]['Sex'];
                }
                else if (reportType == 'Trial Patient List' && index == 'PatientID') {
                    line += (array.data[i]['Race'] == null) ? '-' : array.data[i]['Race'];
                }
                else if (reportType == 'Trial Patient List' && index == 'Sex') {
                    let retVal;
                    if (array.data[i]['FirstScan'] == '' || array.data[i]['FirstScan'] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i]['FirstScan']


                    line += retVal;
                }
                else if (reportType == 'Trial Patient List' && index == 'FirstScan') {
                    let retVal;
                    if (array.data[i]['LastScan'] == '' || array.data[i]['LastScan'] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i]['LastScan']


                    line += retVal;
                }
                else if (reportType == 'Trial Patient List' && index == 'titrate') {
                    let titrateDetails = array.data[i][index];
                    let converted = '';
                    
                    let topValue = array.data[i][index].split('/')[0];
                    let bottomValue = array.data[i][index].split('/')[1];
                    if (topValue == 'None' && bottomValue == 'None') {
                        let nulltopValue = 0;
                        let nullbottomValue = 0;
                        converted = nulltopValue + '/' + nullbottomValue
                    }
                    else
                        converted = titrateDetails;
                    line += converted+'.';
                }
                else if (reportType == 'Trial Patient List' && index == 'Race') {
                    line += (array.data[i]['Containers'] == null)?'0':array.data[i]['Containers'];
                }
                else if (reportType == 'Trial Patient List' && index == 'Containers') {
                    let retVal;
                    if (array.data[i]['status'] == '1')
                        retVal = 'Active'
                    else if (array.data[i]['status'] == null) {
                        retVal= 'Pending'
                    }
                    else
                        retVal = 'InActive'


                    line += retVal;
                }
               
                else if (reportType == 'Trial Patient List' && index == 'age') {
                    let retVal;
                    if (array.data[i][index] == '' || array.data[i][index] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i][index]


                    line += retVal;
                }
                else if (reportType == 'Trial Patient List' && index == 'Id')
                    line += "";
               
                else if (reportType == 'Trial Patient List' && index == 'ttitrate')
                    line += "";
                else if (reportType == 'Trial Patient List' && index == 'status') {
                    let retVal;
                    if (array.data[i][index] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'


                    line += retVal;
                }
                else if (reportType == 'Site List' && index == 'status')
                    line += "";
                else if (reportType == 'Site List' && index == 'id')
                    line += "";
                else if (reportType == 'Site List' && index == 'numTrials')
                    line += "";

                else if (reportType == 'Site List' && index == 'siteAdress') {
                    let retVal;
                    if (array.data[i][index].indexOf(',') > -1 )
                        retVal = array.data[i][index].replace(',',' ')
                    else
                        retVal = array.data[i][index]


                    line += retVal;
                }
                else if (reportType == 'Site List' && index == 'phoneNumber') {
                    let retVal;
                    if (array.data[i][index].indexOf('-') > -1)
                        retVal = array.data[i][index].replace('-', ' ')
                    else
                        retVal = array.data[i][index]


                    line += retVal;
                }
                else if (reportType == 'Associate Site' && index == 'status')
                    line += "";
                else if (reportType == 'Associate Site' && index == 'id')
                    line += "";
                else if (reportType == 'Associate Site' && index == 'numTrials')
                    line += "";

                else if (reportType == 'Associate Site' && index == 'siteAdress') {
                    let retVal;
                    if (array.data[i][index].indexOf(',') > -1)
                        retVal = array.data[i][index].replace(',', ' ')
                    else
                        retVal = array.data[i][index]


                    line += retVal;
                }
                else if (reportType == 'Associate Site' && index == 'phoneNumber') {
                    let retVal;
                    if (array.data[i][index].indexOf('-') > -1)
                        retVal = array.data[i][index].replace('-', ' ')
                    else
                        retVal = array.data[i][index]


                    line += retVal;
                }
                else if (reportType == 'Manage Drug List' && index == 'bucketKey')
                    line += "";
                else if (reportType == 'Manage Drug List' && index == 'id')
                    line += "";
                else if (reportType == 'Manage Drug List' && index == 'status')
                    line += array.data[i]['drugName'];
                else if (reportType == 'Manage Drug List' && index == 'medication_unit')
                    line += array.data[i]['drugAlias'];
                else if (reportType == 'Manage Drug List' && index == 'drugName')
                {
                        line += array.data[i]['medicationType'];
                    
                }
                else if (reportType == 'Manage Drug List' && index == 'medicationType') //swap column data between drugalias and medication unit columns
                {
                    let amount = array.data[i]['medication_amount'];
                    let unit = array.data[i]['medication_unit']
                    line += amount + ' ' + unit;
                }
                //else if (reportType == 'Manage Drug List' && index == 'medication_amount')
                //    line += array.data[i]['medicationUnit'];
               
                //else if (reportType == 'Manage Drug List' && index == 'paircount')
                //    line += "";
                else if (reportType == 'Manage Drug List' && index == 'medication_amount')
                {
                    line += "";

                } 
                else if (reportType == 'Manage Drug List' && index == 'drugAlias') {
                    line += "";

                }
              
                else if (reportType == 'Broadcast Messages List' && index == 'iD')
                    line += "";
                else if (reportType == 'Broadcast Messages List' && index == 'userName') {
                    line += array.data[i]['title'];
                }
                else if (reportType == 'Broadcast Messages List' && index == 'title') {
                    let retVal;
                    if (array.data[i]['type'] == '1')
                        retVal = 'Broadcast'
                    else
                        retVal = 'Titrate'


                    line += retVal;
                }
                else if (reportType == 'Broadcast Messages List' && index == 'userMail') {
                    line += array.data[i]['userName'];
                }
                else if (reportType == 'Broadcast Messages List' && index == 'patients') {
                    line += array.data[i]['userMail'];
                }
                else if (reportType == 'Broadcast Messages List' && index == 'patients') {
                    line += array.data[i]['userMail'];
                }
                else if (reportType == 'Broadcast Messages List' && index == 'Createdtime') {
                    line += array.data[i]['patients'];
                }
                else if (reportType == 'Broadcast Messages List' && index == 'type') {
                    line += array.data[i]['Createdtime'];
                }
                else if (reportType == 'Labels Committed' && index == 'iD')
                    line += "";
                else if (reportType == 'Labels Committed' && index == 'companyId')
                    line += "";
              
                else if (reportType == 'Labels Committed' && index == 'status') {
                    line += array.data[i]['companyName'];
                }
                else if (reportType == 'Labels Committed' && index == 'companyName') {
                    line += array.data[i]['labelsCommitted'];
                }
                else if (reportType == 'Labels Committed' && index == 'labelsUsed') {
                    line += array.data[i]['labelsPurchased'];
                }
                else if (reportType == 'Labels Committed' && index == 'labelsPurchased') {
                    line += array.data[i]['labelsUsed'];
                }
                else if (reportType == 'Labels Committed' && index == 'labelsCommitted') {
                    let retVal;
                    if (array.data[i]['status'] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'


                    line += retVal;
                }
                else if (reportType == 'Export Label' && index == 'companyId') {
                    line += array.data[i]['companyName'];
                }
                else if (reportType == 'Export Label' && index == 'companyName') {
                    line += array.data[i]['companyId'];
                }
                else if (reportType == 'Export Label' && index == 'drugRegimenName') {
                    line += array.data[i]['trialName'];
                }
                else if (reportType == 'Export Label' && index == 'trialName') {
                    line += array.data[i]['trialId'];
                }
                else if (reportType == 'Export Label' && index == 'trialId') {
                    line += array.data[i]['drugRegimenName'];
                }
                else if (reportType == 'Export Label' && index == 'drugRegimenId') {
                    line += array.data[i][index];
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'status') {
                    continue;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'ptitrate') {
                    continue;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'age') {
                    line += array.data[i]['PatientID'];
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'LastScan') {
                    let retVal;
                    if (array.data[i]['age'] == '' || array.data[i]['age'] == null || array.data[i]['age'] == '0')
                        retVal = '-'
                    else
                        retVal = array.data[i]['age']


                    line += retVal;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'PatientID') {
                    //line += array.data[i]['Sex'];
                    let retVal;
                    if (array.data[i]['Sex'] == '' || array.data[i]['Sex'] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i]['Sex']


                    line += retVal;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'Sex') {
                    //line += array.data[i]['Race'];
                    let retVal;
                    if (array.data[i]['Race'] == '' || array.data[i]['Race'] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i]['Race']


                    line += retVal;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'Race') {
                    //line += array.data[i]['LastScan'];
                    let retVal;
                    if (array.data[i]['LastScan'] == '' || array.data[i]['LastScan'] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i]['LastScan']
                    line += retVal;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'Containers') {
                    //line += array.data[i][index];
                    let retVal;
                    if (array.data[i][index] == '' || array.data[i][index] == null)
                        retVal = '0'
                    else
                        retVal = array.data[i][index];
                    line += retVal;
                }
                else if (reportType == 'TrialOverView-PatientList' && index == 'FirstScan') {
                    //line += array.data[i][index];
                    let retVal;
                    if (array.data[i][index] == '' || array.data[i][index] == null)
                        retVal = '-'
                    else
                        retVal = array.data[i][index];
                    line += retVal;
                }
                else if (reportType == 'Notification List' && index == 'userName') {
                    line += array.data[i]['trialName'];
                }
                else if (reportType == 'Notification List' && index == 'email') {
                    let retVal;
                    if (array.data[i]['notificationType'] == '1')
                        retVal = 'Email'
                    else if (array.data[i]['notificationType'] == '2')
                        retVal = 'SMS'
                    else if (array.data[i]['notificationType'] == '3')
                        retVal = 'Email/SMS'


                    line += retVal;
                }
               
                else if (reportType == 'Notification List' && index == 'subscriptions') {
                    line += array.data[i]['userName'];
                }
                else if (reportType == 'Notification List' && index == 'notificationType') {
                    line += array.data[i]['email'];
                   
                }
                else if (reportType == 'Notification List' && index == 'trialName') {
                    line += array.data[i]['subscriptions'];                    
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'doseStrength') {
                    line += array.data[i]['drugName'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'endDate') {
                    line += array.data[i]['RegimenName'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'doseAmount') {
                    line += array.data[i]['medicationType'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'startDate') {
                    line += array.data[i]['doseAmount'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'RegimenName') {
                    line += array.data[i]['measureDose'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'measureDose') {
                    let doseStrength = array.data[i]['doseStrength'];
                    let doseMeasurewithUnit = array.data[i]['measureUnit'];
                    line += doseStrength + doseMeasurewithUnit;
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'status') {
                    line += array.data[i]['startDate'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'drugName') {
                    line += array.data[i]['endDate'];
                }
                else if (reportType == 'Drug Regimen Pair List' && index == 'medicationType') {
                    let retVal;
                    if (array.data[i]['status'] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'
                    line += retVal;
                }
                else if (reportType == 'Manage Users' && index =='status')
                {
                    line += array.data[i]['firstName'];
                }
                else if (reportType == 'Manage Users' && index == 'sub') {
                    line += array.data[i]['lastName'];
                }
                else if (reportType == 'Manage Users' && index == 'firstName') {
                    line += array.data[i]['email'];
                }
                else if (reportType == 'Manage Users' && index == 'lastName') {
                    line += array.data[i]['phoneNumber'];
                }
                else if (reportType == 'Manage Users' && index == 'logintime') {
                    line += array.data[i]['role'];
                }
                else if (reportType == 'Manage Users' && index == 'role') {
                    line += (array.data[i]['logintime'] == null) ? "" : array.data[i]['logintime'];
                }
                else if (reportType == 'Manage Users' && index == 'phoneNumber') {
                    let retVal = '';
                    if (array.data[i]['status'] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'
                    line += retVal;
                }
                else if (reportType == 'Measurment List' && index == 'status')
                {
                    line += array.data[i]['medicationType'];
                }
                else if (reportType == 'Measurment List' && index == 'medicationType') {
                    line += array.data[i]['medicationMeasure'];
                }
                else if (reportType == 'Measurment List' && index == 'medicationMeasure') {
                    let retVal = '';
                    if (array.data[i]['status'] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'
                    line += retVal;
                }
                else if (reportType == 'Trial Containers' && index == 'status')
                {
                    //line += array.data[i]['containerId'].split('_')[3];  
                    line += '="' + array.data[i]['containerId'].split('_')[3] + '"';
                }
                else if (reportType == 'Trial Containers' && index == 'LastScan') {
                    line += array.data[i]['patientId'];
                }
                else if (reportType == 'Trial Containers' && index == 'end') {
                    line += array.data[i]['doseType'];
                }
                else if (reportType == 'Trial Containers' && index == 'containerId') {
                    line += array.data[i]['remainingDoses'];
                }
                else if (reportType == 'Trial Containers' && index == 'remainingDoseUnits') {
                    line += array.data[i][index];
                }
                //else if (reportType == 'Trial Containers' && index == 'remainingDoseUnits') {
                //    line += (array.data[i]['start'] == null) ? "" : array.data[i]['start'];
                //}
                else if (reportType == 'Trial Containers' && index == 'doseType') {
                    //line += (array.data[i]['end'] == null) ? "" : array.data[i]['end'];
                    line += (array.data[i]['start'] == null) ? "" : array.data[i]['start'];
                }
                else if (reportType == 'Trial Containers' && index == 'patientId') {
                    line += (array.data[i]['end'] == null) ? "" : array.data[i]['end'];
                    //line += (array.data[i]['start'] == null) ? "" : array.data[i]['start'];
                }
                else if (reportType == 'Trial Containers' && index == 'FirstScan') {
                    let retVal = '';
                    if (array.data[i]['status'] == '1')
                        retVal = 'Active'
                    else
                        retVal = 'InActive'
                    line += retVal;
                }
		else if (reportType == 'Trial List' && index == 'status') {
                    line += array.data[i]['trialName'];
                }
                else if (reportType == 'Trial List' && index == 'startDate') {
                    line += array.data[i][index];
                }
                else if (reportType == 'Trial List' && index == 'females') {
                    line += array.data[i]['endDate'];
                }
                else if (reportType == 'Trial List' && index == 'males') {
                    line += array.data[i]['labelsUsed'];
                }
                else if (reportType == 'Trial List' && index == 'labelsUsed') {
                    line += "";
                }
                else if (reportType == 'Trial List' && index == 'trialName') {
                    
                    line += (array.data[i]['males'] == null) ? '' : array.data[i]['males'];
                }
                else if (reportType == 'Trial List' && index == 'endDate') {
                    line += (array.data[i]['females'] == null) ? '' : array.data[i]['females'];
                }
                else if (reportType == 'Trial List' && index == 'total') {
                    line += array.data[i]['containers'];
                }
                else if (reportType == 'Trial List' && index == 'Id') {
                    let retVal;
                    let startDate = new Date(array.data[i]['startDate']);
                    let endDate = new Date(array.data[i]['endDate']);
                    let todayDate = new Date();
                    if (startDate <= todayDate && todayDate <= endDate) {
                        retVal = 'A';
                    }
                    else if (todayDate > endDate) {
                        retVal = 'C';
                    }
                    else if (todayDate < endDate) {
                        retVal = 'P';
                    }
                    else if (reportType == 'Trial List' && index == 'containers') {
                        line += "";
                    }

                    line += retVal;
                }
                else if (reportType == 'Associate Group List' && index == 'status') {
                    line += array.data[i]['trialGroupName'];
                }
                else if (reportType == 'Associate Group List' && index == 'trialGroupName') {
                    line += array.data[i]['createdBy'];
                }
                else if (reportType == 'Associate Group List' && index == 'id') {
                    line += array.data[i]['createdDate'];
                }
                else
                    line += array.data[i][index];

                columnCounter++;
            }

            str += line + '\r\n';
        }


        return str;
    }

    public ExportAll(apiUrl,reportType): void {


        // Is supported
        try {
            let isFileSaverSupported = !!new Blob();
        } catch (e) {
            alert('Browser not supported');
            return;
        }

        let params: URLSearchParams = new URLSearchParams();
        //params.set('trial_id', String(trialId || ''));
        //params.set('customer_id', String(customerId || ''));
        //if (filters) {
        //    filters.forEach((filter) => {
        //        params.set(filter.key, String(filter.value || ''));
        //    });
        //}
        //let url = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/1?draw=2&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=startDate&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=endDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=labelsUsed&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=male&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=female&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=containers&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=Id&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false&_=1523902814864'
        let url = apiUrl;
        this.http.get(url, { search: params })
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'))
            .subscribe((response) => {

                var jsonData = response.text();
                //alert(jsonData.split("data")[1]);

                var csv = this.convertToCSV(jsonData, reportType);
                let blob = new Blob([decodeURIComponent(encodeURI(csv))], {
                    type: 'text/csv;charset=utf-8;'
                });

                let filename = reportType+'.csv';
                saveAs(blob, filename);
            });
    }
}
