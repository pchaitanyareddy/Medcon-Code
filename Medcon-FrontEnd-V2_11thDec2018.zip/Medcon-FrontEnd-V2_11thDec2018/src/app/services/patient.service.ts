import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Patient } from '../models/patient';
import { Race } from '../models/race';
import { PatientRequest } from '../requests/patient-request';
import { PatientUploadRequest } from '../requests/patient-upload-request';
import {CommonService} from '../services/commonService';

@Injectable()
export class PatientService {
	constructor(private http: Http) {
	}

	public getOverview(trialId?: number, customerId?: number): Observable<(any)> {
		//let params: URLSearchParams = new URLSearchParams();
		//params.set('trial_id', String(trialId || ''));
		//params.set('customer_id', String(customerId || ''));

		//return this.http.get(API_PATH + '/patient/overview', { search: params })
		//	.map((res: Response) => res.json())
  //          .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        
        //return this.http.get('https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/user/patient/overview?companyId=' + customerId)
        let apiUrl = '';
        if (trialId != 0)
            apiUrl = CommonService.API_PATH_V2_GET_PATIENT_OVERVIEW_DASHBOARD + 'user/patient/overview?companyId=' + customerId + '&trialId=' + trialId;
        else
            apiUrl = CommonService.API_PATH_V2_GET_PATIENT_OVERVIEW_DASHBOARD + 'user/patient/overview?companyId=' + customerId; 
        return this.http.get(apiUrl)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

        
	}

	public getPatient(id: number, customerId?: number): Observable<(Patient)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.get(API_PATH + '/patient/' + id, { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public createPatient(customerId: number, request: PatientRequest): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.post(API_PATH + '/patient', request, { search: params })
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updatePatient(id: number, request: PatientRequest, customerId?: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.put(API_PATH + '/patient/' + id, request, { search: params })
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public deletePatient(id: number, customerId: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.delete(API_PATH + '/patient/' + id, { search: params })
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getRaces(customerId?: number): Observable<(Race[])> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('customer_id', String(customerId || ''));

		return this.http.get(API_PATH + '/patient/races/all', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public uploadPatients(trialId: number, request: PatientUploadRequest): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		//params.set('customer_id', String(customerId));

		//return this.http.post(API_PATH + '/patient/upload', request, {search: params})
		//	.map((res: Response) => res.status === 200)
  //          .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //
        //return this.http.post('https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/update/' + trialId + '/importpatient', request)
        return this.http.post(CommonService.API_PATH_V2_IMPORT_PATIENTS+'trial/update/' + trialId + '/importpatient', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getAge(date) {
		if (date) {
			let dob = new Date(date);
			let ageDifMs = Date.now() - dob.getTime();
			let ageDate = new Date(ageDifMs);
			return Math.abs(ageDate.getUTCFullYear() - 1970);
		} else {
			return '-';
		}
	}

	public getUploadStatus(trialId?: number, customerId?: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('trial_id', String(trialId || ''));
		params.set('customer_id', String(customerId || ''));

		return this.http.get(API_PATH + '/patient/upload/list', { search: params })
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public removeFailedUploads(trialId?: number, customerId?: number): Observable<(any)> {
		let params: URLSearchParams = new URLSearchParams();
		params.set('trial_id', String(trialId || ''));
		params.set('customer_id', String(customerId || ''));

		return this.http.delete(API_PATH + '/patient/upload/remove-failed', {search: params})
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    
    

     
}
