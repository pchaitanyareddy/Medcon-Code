import { ChangeDetectorRef, Component, HostListener, OnInit, Compiler } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { DrugService } from '../../services/drug.service';
import { Drug } from '../../models/drug';
import { DrugRequest } from '../../requests/drug-request';
import { Observable } from 'rxjs/Observable';
import { CommonService } from '../../services/commonService';
@Component({
    templateUrl: './drug-edit.component.html?v=${new Date().getTime()}'
})

export class DrugEditComponent implements OnInit {
	public drug: Drug;
	public form: FormGroup;
	public showErrors: boolean;
	public successMessage: string;
	public errorMessage: string;
	public medicationAmount: number;
	public unitOfMeasure: string;
	public medicationTypes: any;
	public selectedMedicationTypeId: any = 'Tablet';
    private drugImage: string;
    public allmedicationTypeList: any;
    public selectedMedicationType: any;
    public drugImageBase64: string;
    userId: number;
    selectedUnitOfMeasure: string;
    allmedicationTypeFilteredList: any;
    isLoading: boolean;
	constructor(public templateService: TemplateService,
		private router: Router,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private drugService: DrugService,
        private changeDetectorRef: ChangeDetectorRef,
        private _compiler: Compiler
    ) {
	}

    public ngOnInit() {
        this._compiler.clearCache();
        this.isLoading = false;
		this.drug = this.route.snapshot.data['drug'];

		if (this.drug.inUse) {
			this.goBack();
		}

		this.form = this.fb.group({
			name: [this.drug.name, Validators.required],
			alias: [this.drug.alias, Validators.required],
            image: [''],
            medicationAmount: [this.drug.amount, Validators.required],
            unitOfMeasure: [this.drug.unit, Validators.required],
            medicationTypeId: [this.drug.medicationId, Validators.required]
        });
        //this.drugImage = 'https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + this.drug.bucketKey;
		//this.drugService.getAllMedicationTypes().subscribe((medicationTypes) => this.medicationTypes = medicationTypes);
        if (this.drug.bucketKey != null) {
            this.drugImage = CommonService.MEDCON_V2_S3_BUCKET_URL + this.drug.bucketKey; //'https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + this.drug.bucketKey;
            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.drug.bucketKey, "editDrugImageId");
            
        }
        else
            this.drugImage = '../../../assets/images/medication-type-default.png';
            

        this.selectedMedicationTypeId = this.drug.medicationId;
        this.selectedUnitOfMeasure = this.drug.unit;
        this.allmedicationTypeFilteredList = [this.drug.unit];
    }


    SetAndValidateImageUrl(url, imageId): void {
        //alert(url);
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            //alert(" Image Exists...!");
            //flag = true;
        }).on("error ", function () {
            //alert("ERROR");
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            //flag = false;

        });
        //return flag;

    }

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
        } else {
            this.isLoading = true;
            this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
			//let request = new DrugRequest(
			//	this.form.value.name,
			//	this.form.value.alias,
			//	this.drugImage,
			//	this.drug.value.medicationAmount,
			//	this.drug.value.unitOfMeasure,
			//	this.drug.value.medicationTypes
			//);
            //alert(this.drugImageBase64);
            if (this.drugImageBase64 == undefined)
                this.drugImageBase64 = "";
            let request = new DrugRequest(
                this.form.value.name,
                this.form.value.alias,
                this.drugImageBase64,
                Number(this.form.value.medicationAmount),
                //this.drug.value.unitOfMeasure,
                //this.drug.value.medicationTypeId
                Number(this.userId),
                Number(this.selectedMedicationTypeId)

            );

			this.drugService.updateDrug(this.drug.id, request).subscribe(
                (response) => {
                    this.isLoading = false;
					this.form.markAsPristine();
                    this.successMessage = 'Drug has been successfully updated';
                    $(window).scrollTop(5);
                    this.goBack();
				},
                (err) => {
                    this.isLoading = false;
					this.errorMessage = err;
				});
		}
	}

	public fileChange(input) {
		this.processImage(input.target.files);
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'drugs']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

    private processImage(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                // Create an img element and add the image file data to it
                let img = document.createElement('img');
                img.src = result;

                // Send this img to the resize function (and wait for callback)
                this.drugService.resizeImage(img, (croppedImage) => {

                    // This is the file you want to upload.
                    // Either as a base64 string or img.src = croppedImage if you prefer a file.
                    this.drugImage = croppedImage;
                    this.drugImageBase64 = croppedImage;
                });
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

	private readFile(file, reader, callback) {
		reader.onload = () => {
			callback(reader.result);
		};

		reader.readAsDataURL(file);
    }

    public ngAfterViewInit() {

        this.drugService.getAllMedicationType((localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allmedicationTypeList = response;
                //alert(this.allmedicationTypeList);

            },
            (err) => {
                this.errorMessage = err;

            });
    }

    onChange_MedicationType(selectedValue) {
        //alert("hi");
        //alert(this.selectedMedicationTypeId);
        this.selectedMedicationTypeId = Number(selectedValue);
        this.selectedMedicationType = null;
        let selectedImage = '';

        if (this.allmedicationTypeList != null) {
            for (var i = 0; i < this.allmedicationTypeList.length; i++) {
                if (this.allmedicationTypeList[i].id == this.selectedMedicationTypeId) {
                    this.selectedMedicationType = this.allmedicationTypeList[i].name;
                    this.selectedUnitOfMeasure = this.allmedicationTypeList[i].measure;
                    selectedImage = this.allmedicationTypeList[i].image;
                }
            }

            this.allmedicationTypeFilteredList = this.allmedicationTypeList.filter(
                medtypes => medtypes.measure === this.selectedUnitOfMeasure);

            var unique = {};
            var distinct = [];
            this.allmedicationTypeFilteredList.forEach(function (x) {
                if (!unique[x.measure]) {
                    distinct.push(x.measure);
                    unique[x.measure] = true;
                }
            });
            //alert(distinct[0]);
            this.allmedicationTypeFilteredList = distinct;
            this.loadDrugImage(selectedImage);
        }

        

    }

    clearData() {

        this.form.reset();
        $('#editDrugImageId').attr("src", 'assets/images/medication-type-default.png');
    }

    loadDrugImage(selectedImage) {
        //if (this.allmedicationTypeList != undefined) {

        if (selectedImage == null || selectedImage == '')
            this.drugImage = 'assets/images/medication-type-default.png';
        else {
            this.drugImage = CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage;
            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage, "newDrugImageId");
            this.drugImageBase64 = selectedImage;
        }
        //}

    }
}
