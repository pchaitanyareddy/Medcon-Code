import { Component, HostListener, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-monthly-track',
	templateUrl: './widget-monthly-track.component.html',
	styleUrls: ['../dashboard.component.scss']
})

export class WidgetMonthlyTrackComponent implements OnInit {
	public showMenu = false;
	public activeOption;
	public options = [
		{
			id: 'doses-logged',
            name: 'Doses Captured'
		},
		{
			id: 'patient-non-compliance',
			name: 'Patient Non-Compliance'
		},
		{
			id: 'adherence-info',
			name: 'Adherence Info'
		}
	];

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit() {
		this.dashboardService.viewState.subscribe((state) => {
			let savedOption = this.options.filter((option) => option.id === state.monthlyTrack);
            this.activeOption = (savedOption[0]) ? this.options[0] : this.options[0]; //savedOption[0] : this.options[2];
		});
	}

	public toggleMenuOption(optionID): void {
		this.showMenu = false;
		this.activeOption = this.options.filter((option) => option.id === optionID)[0];
		//this.dashboardService.setDashboardStateValue('monthlyTrack', this.activeOption.id);
	}

	public toggleMenu(): void {
		this.showMenu = !this.showMenu;
	}

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-menu-monthly') {
			this.showMenu = false;
		}
	}
}
