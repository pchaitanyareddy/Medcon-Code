﻿import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { MeasureService } from '../../services/measure.service';
import { Customer } from '../../models/customer';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Measurement } from '../../models/measurement';
import { UserRole } from '../../models/userrole';
import { Router} from '@angular/router';
import { Pagination } from '../../models/pagination';
import { Observable } from 'rxjs/Observable';
import { MeasureRequest } from '../../requests/measure-request';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
//import '../../../assets/js/Common/datatable/buttons.print.min.js';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './measure-edit.component.html',
    styleUrls: ['./drugs-list.component.scss']
})

export class MeasurementEditComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public Measurements: Pagination<Measurement>;
    public measure: FormGroup;
    public showErrors: boolean;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public successMessage: string;
    public errorMessage: string;
    public customerId: number;
    public customer: Customer;
    public sort = { field: 'name', order: 'desc' };
    public maxSize: number = 5;
    public currentPage: number = 1;
    measurementList: any;
    constructor(public templateService: TemplateService,
        private measureService: MeasureService,
        private route: ActivatedRoute,
        private url: LocationStrategy,
        private router: Router,
        private fb: FormBuilder) {
    }

    public ngOnInit(): void {
        this.currentUserRole = this.route.snapshot.data['role'];
        this.Measurements = this.route.snapshot.data['Measurements'];
        this.customerId = this.route.snapshot.params['customer_id'];



        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }



        this.measurementList = [
            { measurementId: 1, medicationType: 'Tablet', unitOfMeasure: 'MG', image: "../../../assets/images/tablet.png" },
            { measurementId: 2, medicationType: 'Capsule', unitOfMeasure: 'MG', image: "../../../assets/images/capsule.png" },
            { measurementId: 3, medicationType: 'Liquid', unitOfMeasure: 'OZ', image: "../../../assets/images/liquid.png" },
            { measurementId: 4, medicationType: 'Powder', unitOfMeasure: 'MG', image: "../../../assets/images/powder.png" },
            { measurementId: 5, medicationType: 'Injection', unitOfMeasure: 'OZ', image: "../../../assets/images/injection.png" },]
    }

    //public deleteItem(drug): void {
    //    this.drugToDelete = drug;
    //    this.deleteModal.show();
    //}

    //public hideDeleteModal(): void {
    //    this.drugToDelete = null;
    //    this.deleteModal.hide();
    //}

    public ngAfterViewInit(): void {

        //$('#datatable').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

    }

  

    public onSubmit(): void {
        if (this.measure.invalid) {
            this.showErrors = true;
        } 
        else {
            // TODO: NEED TO ADD COUNTRY SELECTOR TO THE VIEW
            let request = new MeasureRequest(
                this.route.snapshot.params['customer_id'],
                this.measure.value.Medication_Type,
                this.measure.value.UnitOfMeasure

            );
           

            this.measureService.createMeasure(request).subscribe(
                (response) => {
                    this.measure.markAsPristine();
                    this.successMessage = 'Meaurement added successfully';
                },
                (err) => {
                    this.errorMessage = err;
                });
        }
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.measureService
            .getMeasure(this.customerId, event.page, event.itemsPerPage)
            .subscribe((Measurements) => this.Measurements = Measurements);
    }

    public sortResults(field): void {
        let oppositeSort = (this.sort.order === 'asc') ? 'desc' : 'asc';
        let order = (this.sort.field === field) ? oppositeSort : 'asc';
        this.sort = { field, order };

        this.measureService.getMeasure(this.customerId, null, null, field, order)
            .subscribe((Measurements) => this.Measurements = Measurements);
    }
    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.measure.dirty;
    }
}
