﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ExportService } from '../../services/export.service';
import { Export } from '../../models/export';

@Injectable()
export class ExportResolve implements Resolve<Export> {
    constructor(private ExportService: ExportService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<Export> | Promise<Export> | Export {
        return this.ExportService.getExport(route.params['id']);
    }
}
