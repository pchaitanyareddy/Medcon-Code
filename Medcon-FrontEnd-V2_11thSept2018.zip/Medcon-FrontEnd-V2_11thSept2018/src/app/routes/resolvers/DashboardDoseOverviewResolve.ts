﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DoseService } from '../../services/dose.service';
import { DoseOverview } from '../../models/DoseOverview';

@Injectable()
export class DashboardDoseOverviewResolve implements Resolve<DoseOverview> {
    constructor(private doseService: DoseService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<DoseOverview> | Promise<DoseOverview> | DoseOverview {
        //alert(route.params['customer_id']);
        return this.doseService.getOverview(Number(route.params['customer_id']));
    }
}
