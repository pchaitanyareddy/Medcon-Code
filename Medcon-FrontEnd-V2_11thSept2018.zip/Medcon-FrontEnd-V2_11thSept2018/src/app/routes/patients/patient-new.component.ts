import { Component, HostListener, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { PatientService } from '../../services/patient.service';
import { Race } from '../../models/race';
import { PatientRequest } from '../../requests/patient-request';
import { PatientUploadRequest } from '../../requests/patient-upload-request';
import { Observable } from 'rxjs/Observable';
import { TabsetComponent } from 'ngx-bootstrap';
import { TrialService } from '../../services/trial.service';
@Component({
    templateUrl: './patient-new.component.html?v=${new Date().getTime()}',
    styleUrls: ['./patient-new.component.scss?v=${new Date().getTime()}']
})

export class PatientNewComponent implements OnInit {
	@ViewChild('patientMenu') public patientMenu: TabsetComponent;
	public showErrors: boolean;
	public showUploadErrors: boolean;
	public successMessage: string;
	public errorMessage: string;
	public form: FormGroup;
	public upload: FormGroup;
	public races: Race[];
	public trialId: number;
    public error: any;
    userId: number;
    selectedCompanyId: number;
    isLoading: boolean;
    duplicatedPatients: any;
	public myDatePickerOptions: IMyOptions = {
		dateFormat: 'mm/dd/yyyy',
	};
	public patientStatus: any;

	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private router: Router,
		private fb: FormBuilder,
        private patientService: PatientService,
        private trialService: TrialService,
		private changeDetectorRef: ChangeDetectorRef) {
	}

    public ngOnInit() {
        this.duplicatedPatients = null;
        this.isLoading = false;
        this.trialId = this.route.snapshot.queryParams['trial_id'];

		this.races = this.route.snapshot.data['races'];
        if (Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID')) != null)
            this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        else
            this.selectedCompanyId = Number(this.route.snapshot.params['customer_id']);
        this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));

        this.selectedCompanyId = Number(localStorage.getItem('TRIAL_LEVEL_COMPANY_ID'));

		this.form = this.fb.group({
			patientId: ['', Validators.required],
			dob: [''],
			race: [''],
			sex: ['', Validators.pattern('male|female')]
		});

		this.upload = this.fb.group({
			file: [''],
			patientNumbers: ['', Validators.required]
        });


        //this.trialService.getTrial(Number(this.trialId)).subscribe(
        //    (response) => {

        //        this.selectedCompanyId = response.companyId;
        //    },
        //    (err) => {
        //        this.errorMessage = err;

        //    });

	}

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
        } else {
            this.isLoading = true;
			let request = new PatientRequest(
				this.form.value.patientId,
				this.trialId,
				this.form.value.sex,
				this.form.value.race,
				this.convertDate(this.form.value.dob.date)
			);

			this.patientService.createPatient(this.route.snapshot.params['customer_id'], request).subscribe(
                (response) => {
                    this.isLoading = false;
					this.form.markAsPristine();
					this.goBack();
				},
                (err) => {
                    this.isLoading = false;
					this.errorMessage = err;
				});
		}
	}

    public onUploadSubmit(ButtonId) {
		if (this.upload.invalid) {
			this.showUploadErrors = true;
			return;
		}

		let patientNumbers = this.upload.value.patientNumbers
			.replace(/[,;]+/g, '').split('\n').filter((e) => /\S/.test(e));

		if (patientNumbers.length <= 0) {
			this.errorMessage = 'Please enter at least 1 patient number';
			return;
        }
        //alert(patientNumbers.length);
        //alert(patientNumbers);
        var arrDuplicatePatients = this.getDuplicatePatientIds(patientNumbers); // this.getDuplicatePatients(patientNumbers);
        this.duplicatedPatients = arrDuplicatePatients;
        if (arrDuplicatePatients.length > 0 && ButtonId != 'btnContinue') {

            ///this.errorMessage = 'Cannot upload any of the patient numbers as they are all duplicates';
            return;

        }
        else
            this.duplicatedPatients = null;
        this.isLoading = true;
		let request = new PatientUploadRequest(
			patientNumbers,
			this.trialId,
            !!(this.error && this.error.error === 'duplicates'),
            Number(this.userId),
            Number(this.selectedCompanyId)
		);

        this.patientService.uploadPatients(this.trialId, request)
			.subscribe(
            (response) => {
                    this.isLoading = false;
					this.alertClosed();
					this.successMessage = 'Patients successfully uploaded';
                    //this.patientMenu.tabs[2].active = true;
                    this.goBack();
                    this.isLoading = true;

				},
				(err) => {
					// Duplicates error
                    this.isLoading = false;
					if (err.error === 'duplicates') {
						this.errorMessage = err.message;
                        this.error = err;
                        $('#errorPanel').addClass("disableDiv"); 
					} else {
						// Generic error
                        this.errorMessage = err;
                        $('#errorPanel').removeClass("disableDiv");
					}
				}
			);
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
		this.error = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate([
			this.route.snapshot.params['customer_id'],
			'trials',
			this.trialId,
			'edit'
		], {queryParams: {tab: 'patients'}});
	}

	public fileChange(input) {
        this.processPatientsFile(input.target.files);
        this.duplicatedPatients = null;
	}

	public selectedStatusCheck() {
		this.checkPatientUploadStatus();
	}

	public removeFailedUploads() {
		this.patientService.removeFailedUploads(this.trialId, this.route.snapshot.params['customer_id']).subscribe(
			(response) => {
				this.successMessage = 'Failed patient uploads have been successfully removed';
				this.checkPatientUploadStatus();
			},
			(err) => {
				this.errorMessage = err;
			}
		);
	}

	public checkPatientUploadStatus() {
		this.patientStatus = null;

		this.patientService.getUploadStatus(this.trialId, this.route.snapshot.params['customer_id']).subscribe(
			(response) => {
				let stats = {
					Pending: 0,
					Failed: 0
				};
				for (let status of response) {
					stats[status.status]++;
				}
				this.patientStatus = {
					status: stats,
					items: response
				};
			}
		);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

	private convertDate(date: any): string {
		return (date) ? date.year + '-' + date.month + '-' + date.day : '';
	}

	private processPatientsFile(files, index = 0) {
		let reader = new FileReader();

		if (index in files) {
			this.readFile(files[index], reader, (result) => {
				this.upload.controls['patientNumbers'].setValue(result);
			});
		} else {
			// When all files are done this forces a change detection
			this.changeDetectorRef.detectChanges();
		}
	}

	private readFile(file, reader, callback) {
		let invalidFileMessage = 'Patient numbers file must be a CSV';

		if (
			file.type &&
			file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel' && file.type !== 'application/csv'
		) {
			return this.errorMessage = invalidFileMessage;
		}

		if (file.name.split('.').pop().toLowerCase() !== 'csv') {
			return this.errorMessage = invalidFileMessage;
		}

		reader.onload = () => {
			callback(reader.result.replace(/\r\n|\n/, '\n').replace(/[,;]+/g, ''));
		};

		reader.readAsText(file);
    }

    //private hasDuplicates(array) {
        
    //    var valuesSoFar = Object.create(null);
    //    for (var i = 0; i < array.length; ++i) {
    //        var value = array[i];
    //        if (value in valuesSoFar) {
    //            return true;
    //        }
    //        valuesSoFar[value] = true;
    //    }
    //    return false;
        
    //}

    private getDuplicatePatients(array): string[] {
        var arrDuplicates = [];
        var valuesSoFar = Object.create(null);
        alert('array lenth' + array.length);
        for (var i = 0; i < array.length; i++) {
            var value = array[i];
            //alert('value' + value);
            alert('valuesSoFar first value' + valuesSoFar[value])
            if (value in valuesSoFar) {
                //alert('valuesSoFar' + value);
                arrDuplicates.push(array[i]);
                //return true;
            }
            valuesSoFar[value] = true;
        }
        return arrDuplicates;

    }


    private getDuplicatePatientIds(array): string[] {

        var arrDuplicates = [];
        var sorted_arr = array.sort();
        //var results = [];
        for (var i = 0; i < array.length - 1; i++) {
            //alert(sorted_arr[i]);
            //alert(sorted_arr[i + 1]);
            if (sorted_arr[i + 1].trim() == sorted_arr[i].trim()) {
                
                arrDuplicates.push(sorted_arr[i]);
            }
        } 

        return arrDuplicates; 

    }
}
