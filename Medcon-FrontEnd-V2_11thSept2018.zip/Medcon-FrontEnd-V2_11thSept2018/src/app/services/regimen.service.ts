import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Regimen } from '../models/regimen';
import { Pagination } from '../models/pagination';
import { RegimenRequest } from '../requests/regimen-request';
import { CommonService }from '../services/commonService';

@Injectable()
export class RegimenService {
    constructor(private http: Http) {
    }

    public getRegimens(customerId: number, page?: number,
        perPage?: number): Observable<(Pagination<Regimen>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        return this.http.get(API_PATH + '/regimen/list', { search: params })
            .map((res: Response) => {
                let response = res.json();
                response.items = [];
                res.json().items.forEach((item) => {
                    this.getCheckDosesLogged(item.id, customerId)
                        .subscribe((r) => item.inUse = r.value);
                    response.items.push(item);
                });
                return response;
            })
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getRegimensAll(customerId: number): Observable<Regimen[]> {
        return this.http.get(API_PATH + '/regimen/list/' + customerId + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getRegimensUnusedList(customerId: number): Observable<Regimen[]> {
        return this.http.get(API_PATH + '/regimen/list/' + customerId + '/unused')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getRegimen(id: number): Observable<(Regimen)> {
        //let params: URLSearchParams = new URLSearchParams();
        //params.set('customer_id', String(customerId));

       // return this.http.get('https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/regimen/get/' + id)
             return this.http.get(CommonService.API_PATH_V2_GET_REGIMEN+'regimen/get/' + id)

            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getCheckDosesLogged(id: number, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/regimen/' + id + '/check/doses-logged', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createRegimen(jsonString: string, companyId: number): Observable<(any)> {

         //return this.http.post('https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/regimen/' + companyId, jsonString)
            return this.http.post(CommonService.API_PATH_V2_CREATE_REGIMEN+'regimen/' + companyId, jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateRegimen(id: number, jsonString: string): Observable<(any)> {

        //return this.http.put('https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/regimen/update/' + id, jsonString)
            return this.http.put(CommonService.API_PATH_V2_UPDATE_REGIMEN+'regimen/update/' + id, jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteRegimen(id: number): Observable<(any)> {

       // return this.http.delete('https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/regimen/delete/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_REGIMEN+'regimen/delete/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public convertMinutesToString(totalMinutes: number): string {
        let minsPerDay = 24 * 60;
        let minsPerHour = 60;
        let minutes = totalMinutes;
        let converted = '';

        let days = Math.floor(minutes / minsPerDay);
        
        converted += (days < 10) ? '0' + days + 'D ':days + 'D ';
        minutes = minutes - days * minsPerDay;
        let hours = Math.floor(minutes / minsPerHour);
        converted += (hours < 10) ? '0' + hours + 'HRS ':hours + 'HRS ';
        minutes = minutes - hours * minsPerHour;
        converted += (hours < 10) ? '0' + minutes + 'MINS':minutes + 'MINS';

        return converted;
    }

    public convertToDays(durationBetweenDoses, numberOfDaysSelected, totalDoses, morningWindowCount, afternoonWindowCount, eveningWindowCount, nightWindowCount, scheduleType, selectedDatesForYear?): number {
        let numberOfDays = 0;
        ////alert(durationBetweenDoses);
        ////alert(numberOfDaysSelected);
        ////alert(totalDoses);
        ////Ex: durationBetweenDoses : 2880
        ////numberOfDaysSelected:3,
        ////totalDoses:3
        //numberOfDays = Math.floor(durationBetweenDoses / (60 * 24)); 
        //numberOfDays = numberOfDays * numberOfDaysSelected * totalDoses;
        if (scheduleType =='Daily')
            numberOfDays = Math.round(totalDoses / (morningWindowCount + afternoonWindowCount + eveningWindowCount + nightWindowCount));
        if (scheduleType == 'Weekly') {
            
            let numberOfWeeksRequired = 0;
            let howManyTimesPerDay = 0;
            let howManyTimesPerWeek = 0;
            howManyTimesPerDay = morningWindowCount + afternoonWindowCount + eveningWindowCount + nightWindowCount;
            howManyTimesPerWeek = howManyTimesPerDay * numberOfDaysSelected;
            numberOfWeeksRequired = Math.round(totalDoses / howManyTimesPerWeek);
            numberOfDays = numberOfWeeksRequired * 7;
           
            
        }
        if (scheduleType == 'Monthly') {

            let numberOfMonthsRequired = 0;
            let howManyTimesPerDay = 0;
            let howManyTimesPerMonth = 0;
            howManyTimesPerDay = morningWindowCount + afternoonWindowCount + eveningWindowCount + nightWindowCount;
            howManyTimesPerMonth = howManyTimesPerDay * numberOfDaysSelected;
            numberOfMonthsRequired = Math.round(totalDoses / howManyTimesPerMonth);
            numberOfDays = numberOfMonthsRequired * 30;

        }
        if (scheduleType == 'Yearly') {

            let numberOfYearsRequired = 0;
            let howManyTimesPerDay = 0;
            let howManyMonthsSelectedPerYear = 0;
            let howManyDaysPerYear = 0;
            let howManyTimesPerYear = 0;
            
            howManyMonthsSelectedPerYear = selectedDatesForYear.split('|').length;
            var arrSelectedMonths = selectedDatesForYear.split('|');
            let strSelectedMonths = '';
            var arrSelectedDates;
            let strSelectedDates;
            var arrSelectedDates1;
            let finalSelectedDatesPerYear = ''; 
            arrSelectedMonths.forEach((item, index) => {
                strSelectedMonths = item;
                //alert(strSelectedMonths);
                arrSelectedDates = strSelectedMonths.split('^'); //Ex: March^1,2,3,4

                arrSelectedDates.forEach((item, index) => {
                    localStorage.setItem(item, arrSelectedDates[1]); //store dates for selected month
                   
                    if (index != 0) {
                        strSelectedDates = item;
                        arrSelectedDates1 = strSelectedDates.split(',');
                        arrSelectedDates1.forEach((item, index) => {
                            if (finalSelectedDatesPerYear == '')
                                finalSelectedDatesPerYear = arrSelectedDates[0];
                            else
                                finalSelectedDatesPerYear = finalSelectedDatesPerYear+"," + arrSelectedDates[0];
                            //$('#day' + item + 'Cell_' + arrSelectedDates[0]).addClass("selected");
                        });



                    }

                    //}

                });

            });
            howManyTimesPerDay = morningWindowCount + afternoonWindowCount + eveningWindowCount + nightWindowCount; //4 times
            howManyDaysPerYear = Number(finalSelectedDatesPerYear.split(',').length); //6 days
            howManyTimesPerYear = howManyTimesPerDay * howManyDaysPerYear; // 1day 4 times, 6 days * 4 times= 24 times
            numberOfYearsRequired = Math.round(totalDoses / howManyTimesPerYear); //60 / 24= 2.5 =3 years
            numberOfDays = numberOfYearsRequired * 365; //3*365
        }
        return numberOfDays;

    }

}
