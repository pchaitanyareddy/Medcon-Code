import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { PendingChangesGuard } from './guards/pending-changes.guard';
import { LoginComponent } from './routes/login/login.component';
import { DashboardComponent } from './routes/dashboard/dashboard.component';
import { DataReportsComponent } from './routes/reports/data-reports.component';
import { PrivilegesComponent } from './routes/privileges/privileges-list.component';
import { PatientReportComponent } from './routes/patient-report/patient-report.component';
import { ImportPatientComponent } from './routes/import-patient/import-patient.component';
import { TrialGroupListComponent } from './routes/trialgroup/trialgroup-list.component';
import { TrialGroupNewComponent } from './routes/trialgroup/trialgroup-new.component';
import { TrialGroupEditComponent } from './routes/trialgroup/trialgroup-edit.component';
import { CompanyListComponent } from './routes/company/company-list.component';
import { CompanyNewComponent } from './routes/company/company-new.component';
import { CompanyEditComponent } from './routes/company/company-edit.component';
import { LabelsCommittedComponent } from './routes/labels-committed/labels-committed.component';
import { MeasurementListComponent } from './routes/measurement/measure-list.component';
import { MeasurementEditComponent } from './routes/measurement/measure-edit.component';
import { BroadcastMessagesListComponent } from './routes/broadcast-Messages/broadcast-Messages-list.component';
import {
	CustomersListComponent,
	CustomerNewComponent,
	CustomerEditComponent,
	CustomerViewComponent
} from './routes/customers';
import { SiteNewComponent, SiteListComponent,SiteEditComponent } from './routes/sites';
import {
	TrialsListComponent,
	TrialNewComponent,
	TrialEditComponent,
	TrialViewComponent
} from './routes/trials';
import {
	UsersListComponent,
	UserEditComponent,
	UserNewComponent,
	MedConUsersListComponent,
	MedConUserNewComponent,
	MedConUserEditComponent
} from './routes/users';
import { PatientNewComponent, PatientEditComponent } from './routes/patients';
import { DrugsListComponent, DrugNewComponent, DrugEditComponent } from './routes/drugs';
import { RegimenListComponent, RegimenNewComponent, RegimenEditComponent } from './routes/regimen';
import { AlertsAlarmsComponent } from './routes/alerts-alarms/alerts-alarms-list.component';
import { SettingsComponent } from './routes/settings/settings.component';
import { PageNotFoundComponent } from './routes/errors/page-not-found.component';
import { UserRole } from './models/userrole';
import {
	DashboardStateResolve,
	CustomersResolve,
	CustomerResolve,
	SitesResolve,
	SiteResolve,
	TrialsResolve,
	TrialResolve,
	TrialLabelsResolve,
	TrialContainersResolve,
    TrialPatientsResolve,
    TrialAssociatedGroupListResolve,
	PatientResolve,
	RacesResolve,
	DrugsResolve,
	DrugsAllResolve,
	DrugResolve,
	RegimensResolve,
	RegimensAllResolve,
	RegimenResolve,
	AlertsAlarmsResolve,
	UsersResolve,
	UserResolve,
	MedConUsersResolve,
	CurrentUserRoleResolve,
	CurrentUserResolve,
    ReportSchedulesResolve,
    PrivilegesResolve,
    PatientReportResolve,
    TrialGroupListResolve,
    TrialAssociatedSiteListResolve,
    CompanyResolve
} from './routes/resolvers';

export const ROUTES: Routes = [
	{
		path: '',
		component: LoginComponent
	},
	{
		path: 'dashboard',
		component: DashboardComponent,
		canActivate: [AuthGuard],
		resolve: {
			role: CurrentUserRoleResolve,
			user: CurrentUserResolve,
            state: DashboardStateResolve,
            privileges: PrivilegesResolve,
		}
	},
	{
		path: 'reports',
		component: DataReportsComponent,
		canActivate: [AuthGuard],
		resolve: {
			role: CurrentUserRoleResolve,
			user: CurrentUserResolve,
			report_schedules: ReportSchedulesResolve,
		}
	},
	{
		path: 'customers',
		canActivate: [AuthGuard],
		children: [
			{
				path: '',
				component: CustomersListComponent,
				data: {roles: [UserRole.MedConAdmin]},
				resolve: {
					customers: CustomersResolve,
				},
			},
			{
				path: 'new',
				component: CustomerNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin]},
			},
			{
				path: ':customer_id/edit',
				component: CustomerEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
				resolve: {
					customer: CustomerResolve,
					sites: SitesResolve,
					role: CurrentUserRoleResolve,
				},
			},
			{
				path: ':customer_id/view',
				component: CustomerViewComponent,
				resolve: {
					customer: CustomerResolve,
					role: CurrentUserRoleResolve,
					drugs: DrugsAllResolve,
					regimens: RegimensAllResolve,
					sites: SitesResolve,
				}
			}
		]
	},
	{
		path: ':customer_id/sites',
		canActivate: [AuthGuard],
		resolve: {
			customer: CustomerResolve,
		},
        children: [
            {
                path: '',
                component: SiteListComponent,
                data: { roles: [UserRole.MedConAdmin, UserRole.CustomerUser, UserRole.CustomerAdmin] },
                resolve: {
                    site: SiteResolve,
                },
            },
			{
				path: 'new',
				component: SiteNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},

			},
			{
				path: ':id/edit',
				component: SiteEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
				resolve: {
					site: SiteResolve
				}
			}
		]
	},
	{
		path: ':customer_id/trials',
		canActivateChild: [AuthGuard],
		resolve: {
			customer: CustomerResolve,
			role: CurrentUserRoleResolve,
		},
		children: [
			{
				path: '',
				component: TrialsListComponent,
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerUser, UserRole.CustomerAdmin]},
				resolve: {
					trials: TrialsResolve,
				},
			},
			{
				path: 'new',
				component: TrialNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.CustomerAdmin]},
				resolve: {
					sites: SitesResolve,
				}
			},
			{
				path: ':id/edit',
				component: TrialEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
				resolve: {
					role: CurrentUserRoleResolve,
					trial: TrialResolve,
					drugs: DrugsAllResolve,
					regimens: RegimensAllResolve,
					sites: SitesResolve,
					labels: TrialLabelsResolve,
					containers: TrialContainersResolve,
                    patients: TrialPatientsResolve,
                    associatedTrialGroups: TrialAssociatedGroupListResolve,
                    associatedSites: TrialAssociatedSiteListResolve,
				},
			},
			{
				path: ':id/view',
				component: TrialViewComponent,
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerUser, UserRole.CustomerAdmin]},
				resolve: {
					trial: TrialResolve,
					labels: TrialLabelsResolve,
					containers: TrialContainersResolve,
					patients: TrialPatientsResolve,
				},
			},
		]
    },
    
    {
        path: ':customer_id/trialgroup',
        canActivateChild: [AuthGuard],
        resolve: {
            customer: CustomerResolve,
            role: CurrentUserRoleResolve,
        },
        children: [
            {
                path: '',
                component: TrialGroupListComponent,
                data: { roles: [UserRole.MedConAdmin, UserRole.CustomerUser, UserRole.CustomerAdmin] },
                resolve: {
                    trialgroup: TrialGroupListResolve,
                },
            }
            ,
            {
                path: 'new',
                component: TrialGroupNewComponent,
                canDeactivate: [PendingChangesGuard],
                data: { roles: [UserRole.CustomerAdmin] },
                resolve: {
                    trialgroup: TrialGroupListResolve,
                }
            },
            {
                path: ':id/edit',
                component: TrialGroupEditComponent,
                canDeactivate: [PendingChangesGuard],
                data: { roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin] },
                resolve: {
                    role: CurrentUserRoleResolve,
                    trial: TrialGroupListResolve,
                    //drugs: DrugsAllResolve,
                    //regimens: RegimensAllResolve,
                    //sites: SitesResolve,
                    //labels: TrialLabelsResolve,
                    //containers: TrialContainersResolve,
                    //patients: TrialPatientsResolve,
                },
            }
        ]
    },
	{
		path: ':customer_id/users',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: '', component: UsersListComponent,
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerUser, UserRole.CustomerAdmin]},
				resolve: {
					role: CurrentUserRoleResolve,
					users: UsersResolve,
				},
			},
			{
				path: 'new', component: UserNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
			},
			{
				path: ':id/edit', component: UserEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
				resolve: {
					user: UserResolve,
				},
			},
		]
	},
	{
		path: 'medcon-users',
		canActivateChild: [AuthGuard],
		data: {
			roles: [UserRole.MedConAdmin]
		}
		,
		children: [
			{
				path: '', component: MedConUsersListComponent,
				resolve: {
					users: MedConUsersResolve
				}
			},
			{
				path: 'new', component: MedConUserNewComponent,
				canDeactivate: [PendingChangesGuard],
			},
			{
				path: ':id/edit', component: MedConUserEditComponent,
				canDeactivate: [PendingChangesGuard],
				resolve: {
					user: UserResolve,
				},
			},
		]
	},
	{
		path: ':customer_id/patients',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: 'new',
				component: PatientNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
				resolve: {
					races: RacesResolve,
				},
			},
			{
				path: ':id/edit',
				component: PatientEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.MedConAdmin, UserRole.CustomerAdmin]},
				resolve: {
					patient: PatientResolve,
					races: RacesResolve,
				},
			},
		]
	},
	{
		path: ':customer_id/drugs',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: '',
				component: DrugsListComponent,
				data: {
					roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
				},
				resolve: {
					role: CurrentUserRoleResolve,
					drugs: DrugsResolve,
				},
			},
			{
				path: 'new',
				component: DrugNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.CustomerAdmin]},
			},
			{
				path: ':id/edit',
				component: DrugEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.CustomerAdmin]},
				resolve: {
					drug: DrugResolve,
				}
			},
		]
	},
	{
		path: ':customer_id/regimens',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: '',
				component: RegimenListComponent,
				data: {
					roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
				},
				resolve: {
					role: CurrentUserRoleResolve,
					regimens: RegimensResolve,
				},
			},
			{
				path: 'new',
				component: RegimenNewComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.CustomerAdmin]},
			},
			{
				path: ':id/edit',
				component: RegimenEditComponent,
				canDeactivate: [PendingChangesGuard],
				data: {roles: [UserRole.CustomerAdmin]},
				resolve: {
					regimen: RegimenResolve,
				}
			},
		]
	},
	{
		path: 'alerts-alarms',
		component: AlertsAlarmsComponent,
		canActivate: [AuthGuard],
		canDeactivate: [PendingChangesGuard],
		data: {
			roles: [UserRole.MedConAdmin, UserRole.CustomerUser, UserRole.CustomerAdmin],
		},
		resolve: {
			role: CurrentUserRoleResolve,
			alerts: AlertsAlarmsResolve,
		}
	},
	{
		path: 'settings',
		canActivateChild: [AuthGuard],
		children: [
			{
				path: 'mcc', component: SettingsComponent,
				data: {roles: [UserRole.MedConAdmin]},
				canDeactivate: [PendingChangesGuard],
			},
		]
    }
    ,
  //  {
		//path: 'privileges',
  //      component: PrivilegesComponent,
		//canActivate: [AuthGuard],
  //      resolve: {
  //          role: CurrentUserRoleResolve,
  //          user: CurrentUserResolve,
  //          privileges: PrivilegesResolve,
  //      }
  //  }, 
    {
        path: ':customer_id/privileges',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: PrivilegesComponent,
                data: {
                    roles: [UserRole.MedConAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    privileges: PrivilegesResolve,
                },
            }
            ,
        ]
    }

    ,
    {
        path: 'patient-report',
        //component: PatientReportComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: '',
                component: PatientReportComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //privileges: PatientResolve,
                },
            }
            ,
        ]
        //resolve: {
        //    role: CurrentUserRoleResolve,
        //    user: CurrentUserResolve,
        //    patientreport: PatientReportResolve,
        //}
    }
    ,
    {
        path: ':customer_id/import-patient',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: ImportPatientComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //privileges: PatientResolve,
                },
            }
            ,
        ]
    },

    {
        path: ':customer_id/company',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: CompanyListComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin, UserRole.MedConAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //companies: PrivilegesResolve,
                },
            }
            ,
            {
                path: 'new',
                component: CompanyNewComponent,
                canDeactivate: [PendingChangesGuard],
                data: { roles: [UserRole.CustomerAdmin, UserRole.MedConAdmin] },
            },
            {
                path: ':id/edit',
                component: CompanyEditComponent,
                canDeactivate: [PendingChangesGuard],
                data: { roles: [UserRole.CustomerAdmin, UserRole.MedConAdmin] },
                resolve: {
                    //companies: PrivilegesResolve,
                }
            },
        ]
    }
    ,

    {
        path: ':customer_id/labels-committed',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: LabelsCommittedComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin, UserRole.MedConAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //labels: PrivilegesResolve,
                },
            }
            ,
            //{
            //    path: 'new',
            //    component: CompanyNewComponent,
            //    canDeactivate: [PendingChangesGuard],
            //    data: { roles: [UserRole.CustomerAdmin, UserRole.MedConAdmin] },
            //},
            //{
            //    path: ':id/edit',
            //    component: CompanyEditComponent,
            //    canDeactivate: [PendingChangesGuard],
            //    data: { roles: [UserRole.CustomerAdmin, UserRole.MedConAdmin] },
            //    resolve: {
            //        companies: PrivilegesResolve,
            //    }
            //},
        ]
    }
    ,
    {
        path: ':customer_id/measurement',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: MeasurementListComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //privileges: PatientResolve,
                },

            },
            {
                path: 'id/edit',
                component: MeasurementEditComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //privileges: PatientResolve,
                },
            },


        ]
    }
    ,
    {
        path: ':customer_id/broadcast-Messages',
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: BroadcastMessagesListComponent,
                data: {
                    roles: [UserRole.CustomerUser, UserRole.CustomerAdmin]
                },
                resolve: {
                    role: CurrentUserRoleResolve,
                    //privileges: PatientResolve,

                },
            }
            ,
        ]
    }
    ,
	{
		path: '**',
		component: PageNotFoundComponent
	}
];
