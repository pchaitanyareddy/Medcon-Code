﻿export class Settings {
    constructor(
        public id: number) { }
      
   
}
