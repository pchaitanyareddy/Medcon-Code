export class TrialLabelsRequest {
	constructor(public additionalLabels: number) {
	}
}
