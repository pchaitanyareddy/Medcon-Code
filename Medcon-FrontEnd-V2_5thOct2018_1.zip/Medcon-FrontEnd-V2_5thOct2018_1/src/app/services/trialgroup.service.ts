﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Pagination } from '../models/pagination';
import { TrialGroup } from '../models/trialgroup';
import { MedConUser } from '../models/medconuser';
//import { UserMedConCreateRequest } from '../requests/user-medcon-create-request';
//import { UserPreferenceRequest } from '../requests/user-preference-request';
import { TrialGroupRequest } from '../requests/trialgroup-request';
import { CommonService }from '../services/commonService';
@Injectable()
export class TrialGroupService {
    constructor(private http: Http) {
    }

    
    //To get the all privileges list
    //public getTrialGroupList(customerId: number, roleId: number,
    //    page?: number, perPage?: number,
    //    sortField?: string,
    //    sortOrder?: string): Observable<(Pagination<TrialGroup>)> {
    //    let params: URLSearchParams = new URLSearchParams();
    //    params.set('sortField', sortField);
    //    params.set('sortOrder', sortOrder);
    //    if (page) {
    //        params.set('page', String(page));
    //    }
    //    if (perPage) {
    //        params.set('per_page', String(perPage));
    //    }
    //    //To fix the runtime errors, commented this code, once service is available then uncomment it
    //    //return this.http.get(API_PATH + '/trialgroup/lists', { search: params })
    //    //    .map((res: Response) => {
    //    //        let response = res.json();
    //    //        response.items = [];
    //    //        res.json().items.forEach((item) => {
    //    //            response.items.push(item);
    //    //        });

    //    //        return response;
    //    //    })
    //    //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    //    return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
    //        .map((res: Response) => res.json())
    //        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    //}


    public getTrialGroupList(customerId: number, page?: number, perPage?: number): Observable<(Pagination<TrialGroup>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        //Uncomment this when API service is ready
        //return this.http.get(API_PATH + '/trialgroup/list/' + customerId, { search: params })
        //    .map((res: Response) => res.json())
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
            return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteTrialGroup(id: number): Observable<(any)> {
        
        //return this.http.delete('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/delete/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_TRIAL_GROUP+'trialgroup/delete/' + id)  
          .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createTrialGroup(request: TrialGroupRequest, companyId:number): Observable<(any)> {
        
        //return this.http.post('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/' + companyId, request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_TRIAL_GROUP+'trialgroup/' + companyId, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));


    }

    public updateTrialGroup(trialGroupId: number, request: TrialGroupRequest): Observable<(any)> {
        //Uncomment this when API service is ready
        //return this.http.put(API_PATH + '/trialgroup/' + id, request)
        //    .map((res: Response) => res.status === 200)
        //    .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
        //https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/get/{trailGroupId}

        //return this.http.put('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/update/' + trialGroupId, request)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_TRIAL_GROUP+'trialgroup/update/' + trialGroupId, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    
    public getSelectedTrialGroup(id: string): Observable<(any)> {
        //return this.http.get('https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/trialgroup/get/' + id)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_TRIAL_GROUP+'trialgroup/get/' + id)
        
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

}
