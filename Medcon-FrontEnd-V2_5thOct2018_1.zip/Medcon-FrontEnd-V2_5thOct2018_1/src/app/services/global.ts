﻿'use strict';

export const GLOBAL_COMPANYID = 0;
export const API_URL_CREATE_MEDCON_USER_URL = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user';
