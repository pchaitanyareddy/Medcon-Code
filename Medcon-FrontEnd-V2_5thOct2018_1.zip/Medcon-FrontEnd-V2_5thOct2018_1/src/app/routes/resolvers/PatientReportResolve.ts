﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PatientReportService } from '../../services/patient-report.service';
import { PatientReport } from '../../models/patientreport';
import { Pagination } from '../../models/pagination';

@Injectable()
export class PatientReportResolve implements Resolve<(Pagination<PatientReport>)> {
    constructor(private patientReportService: PatientReportService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<(Pagination<PatientReport>)>
        | Promise<(Pagination<PatientReport>)>
        | (Pagination<PatientReport>) {
        return this.patientReportService
            .getPatientReportData(route.params['customer_id'],  route.queryParams['page'], route.queryParams['perPage']);
    }
}

