import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerService } from '../../services/customer.service';
import { Customer } from '../../models/customer';

@Injectable()
export class CustomerResolve implements Resolve<Customer> {
	constructor(private customerService: CustomerService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Customer> | Promise<Customer> | Customer {
		return this.customerService.getCustomer(route.params['customer_id']);
	}
}
