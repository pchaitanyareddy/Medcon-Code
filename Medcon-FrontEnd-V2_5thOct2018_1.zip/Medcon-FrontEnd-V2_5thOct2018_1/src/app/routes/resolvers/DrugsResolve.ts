import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DrugService } from '../../services/drug.service';
import { Pagination } from '../../models/pagination';
import { Drug } from '../../models/drug';

@Injectable()
export class DrugsResolve implements Resolve<(Pagination<Drug>)> {
	constructor(private drugService: DrugService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(Pagination<Drug>)>
		| Promise<(Pagination<Drug>)>
		| (Pagination<Drug>) {
		return this.drugService
			.getDrugs(route.params['customer_id'], route.queryParams['page'], route.queryParams['perPage']);
	}
}
