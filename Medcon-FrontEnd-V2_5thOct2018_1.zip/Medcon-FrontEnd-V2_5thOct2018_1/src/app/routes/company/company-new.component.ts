﻿import { UserCreateRequest } from '../../requests/user-create-request';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { CompanyService } from '../../services/company.service';
import { Observable } from 'rxjs/Observable';
import { CompanyRequest } from '../../requests/companyrequest';
import '../../../assets/js/Common/Generic.js';
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}

enum Companies {

    'ABC Pharmaticual',
    'Test1',
    'Test2'
}

@Component({
    templateUrl: './company-new.component.html?v=${new Date().getTime()}'
})

export class CompanyNewComponent implements OnInit {
    public company: FormGroup;
    public showErrors: boolean;
    public errorMessage: string;
    public successMessage: string;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    companyOptions: string[];
    Companies: typeof Companies = Companies;
    defaultRole;
    defaultCompany;
    companyTypeList: any;
    countryList: any;
    stateList: any
    defaultValue: string;
    selectedCompanyTypeId: number;
    selectedStateId: number;
    selectedCountryId: number;
    selectedCompanyType: string;
    selectedCountry: string;
    selectedState: string;
    selectedPhoneCode: number;
    isLoading: boolean;
    constructor(public templateService: TemplateService,
        public router: Router,
        public companyService: CompanyService,
        private fb: FormBuilder,
        private route: ActivatedRoute) {
        this.defaultValue = 'select'
    }

    public ngOnInit() {
        this.isLoading = false;
        this.company = this.fb.group({
            companyName: ['', [Validators.required]],
            companyType: ['', [Validators.required]],
            companyAdherenceTarget: [''],
            addressLine: ['', [Validators.required]],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            city: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            zipcode: ['', [Validators.required]],
            phone: [''],
            companyTypeId: []
        });

        //var x = Roles;
        //var options = Object.keys(Roles);
        //this.options = options.slice(options.length / 2);
        //this.defaultRole = this.options[1];
        //var z = Companies;
        //var companyOptions = Object.keys(Companies);
        //this.companyOptions = companyOptions.slice(companyOptions.length / 2);
        //this.defaultCompany = this.companyOptions[0];
        
        this.companyTypeList = [
           
            { companyTypeId: 1, companyType: 'Label Manufacturing' },
            { companyTypeId: 2, companyType: 'Pharmaceutical' },
            //{ companyTypeId: 4, companyType: 'Medcon' },
        ]

        //this.countryList = [
        //    { id: 1, name: 'United States' },
        //    { id: 2, name: 'India' },
        //    { id: 3, name: 'Singapore' },
        //]

        //this.stateList = [
        //    { id: 1, name: 'New york' },
        //    { id: 2, name: 'India' },
        //    { id: 3, name: 'Singapore' },
        //]

        this.companyService.getCountries().subscribe(
            (response) => {
                this.countryList = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        //Setting default values
        this.selectedCompanyTypeId = 1;
        //this.selectedCountryId = 231; //for united states
        this.companyService.getStatesByCountry(this.selectedCountryId).subscribe(
            (response) => {
                this.stateList = response;

            },
            (err) => {
                this.errorMessage = err;

            });
        //this.selectedStateId = 3919; //for Alabama
    }

    public onSubmit() {
        //alert(this.company.invalid);
        if (this.company.invalid) {
            this.showErrors = true;
            return;
        }
        else if (String(this.selectedCountryId) == 'NaN' || this.selectedCountryId == undefined || this.selectedCountryId == 0) {
            this.showErrors = true;
            this.errorMessage = "Please Select Country";
        }
        else if (String(this.selectedStateId) == 'NaN' || this.selectedStateId == undefined || this.selectedStateId == 0) {
            this.showErrors = true;
            this.errorMessage = "Please Select State";
        }
        else if (!this.isValidNumber(Number(this.company.value.companyAdherenceTarget))){
            this.showErrors = true;
            this.errorMessage = "Please enter Valid Range values(0 - 100) for Company Adherence Target";
        }
       
        else {
            this.route.params.subscribe((params) => {
                let request = new CompanyRequest(
                    //+params['customer_id'],
                    Number(localStorage.getItem("GLOBAL_LOGGED_IN_USER_ID")),
                    this.company.value.companyName,
                    Number(this.company.value.companyAdherenceTarget),
                    this.selectedCompanyType,//this.company.value.companyType,
                    this.company.value.addressLine,
                    this.selectedCountryId,//this.company.value.countryId,
                    this.selectedStateId,//this.company.value.stateId,
                    this.company.value.city,
                    Number(this.company.value.zipcode),
                    Number(this.company.value.phone),
                    //this.selectedCountry,
                    //this.selectedState


                );
                this.isLoading = true;
                this.companyService.createCompany(request).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.company.markAsPristine();
                        this.successMessage = "Company created successfully";
                        $(window).scrollTop(5);
                        this.goBack();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
            });
        }
    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        this.company.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'company']);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.company.dirty;
    }

    onChange(selectedValue) {
        let countryId = Number(selectedValue);
        this.selectedStateId = 0;
        //Call API when country is selected, then retrieve data for state drop down list
        //this.stateList=this.companyService.getStatesByCountry(countryId);
        this.companyService.getStatesByCountry(countryId).subscribe(
            (response) => {
                this.stateList = response;

            },
            (err) => {
                this.errorMessage = err;

            });
        this.selectedCountryId = Number(selectedValue);
        this.selectedCountry = null;
        //To get selected role name
        if (this.countryList != null) {
            for (var i = 0; i < this.countryList.length; i++) {
                if (this.countryList[i].id == this.selectedCountryId) {
                    this.selectedCountry = this.countryList[i].name;
                    this.selectedPhoneCode = this.countryList[i].phonecode;
                    $('#phone').val("+"+this.selectedPhoneCode);  
                }
            }

        }
        
    }

    onChange_CompanyType(selectedValue) {
        this.selectedCompanyTypeId = Number(selectedValue);
        this.selectedCompanyType = null;
        //To get selected role name
        if (this.companyTypeList != null) {
            for (var i = 0; i < this.companyTypeList.length; i++) {
                if (this.companyTypeList[i].companyTypeId == this.selectedCompanyTypeId) {
                    this.selectedCompanyType = this.companyTypeList[i].companyType;
                }
            }

        }

    }

    onChange_State(selectedValue) {
        this.selectedStateId = Number(selectedValue);
        this.selectedState = null;
        //To get selected role name
        if (this.stateList != null) {
            for (var i = 0; i < this.stateList.length; i++) {
                if (this.stateList[i].id == this.selectedStateId) {
                    this.selectedState = this.stateList[i].name;
                }
            }

        }

    }


    isValidNumber(val): boolean {

        if (val < 0)
            return false;
        else if (val > 100)
            return false;
        else
            return true;

    }
   
}
