﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { NotificationsService } from '../../services/notifications.service';
import { Notifications } from '../../models/notifications';
import { NotificationsRequest } from '../../requests/notifications-request';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
import { Privileges } from '../../models/privileges';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './notifications-list.component.html?v=${new Date().getTime()}',
    styleUrls: ['./trial-edit.component.scss?v=${new Date().getTime()}']
})

export class NotificationsListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('patientAlertsHelpModal') public patientAlertsHelpModal: ModalDirective;
    public Notifications: Pagination<Notifications>;
    public notificationToDelete: Notifications;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public showErrors: boolean;
    public selectedCustomerId: number;
    public successMessage: string;
    public trailList: any;
    public allTrailsList: any;
    public errorMessage: string;
    public notification: FormGroup;
    public trial: Notifications;
    public userId: number;
    privilegesByModule: any;
    privilegesList: any;
    selectedTrialId: number;
    selectedNotificationID: number;
    selectedNotificationIDToDelete: number;
    public selectedTrial: any;
    public trailId: number;
    //public trialGroupToDelete: BroadcastMessages;
    isNewForm: boolean;
    isEditForm: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    notificationsList: any;
    trialNotifications: any[];
    isLoading: boolean;
    loggedInUserId: number;
    public privileges: Privileges;
    selectedCompanyId: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private reportService: ReportService,
        private NotificationsService: NotificationsService,
        private fb: FormBuilder,
        private cognitoUtil: CognitoUtil,
        public router: Router,
        private url: LocationStrategy) {
        
    }
    public goBack(): void {
        this.addNewEditCheckOptions();
        this.loadDefaultValues();

        $('#pnlNotificationTypeEmail').removeClass("btn-group selected").addClass("btn-group");
        $('#pnlNotificationTypeSMS').removeClass("btn-group selected").addClass("btn-group");
    }
    public addNewEditCheckOptions(): void {
        $('#missedDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlMissedDose').removeClass("btn-group selected").addClass("btn-group");
        $('#overDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlOverDose').removeClass("btn-group selected").addClass("btn-group");
        $('#lateDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlLateDose').removeClass("btn-group selected").addClass("btn-group");
        $('#underDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlUnderDose').removeClass("btn-group selected").addClass("btn-group");
        $('#excessiveManualDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlExcessiveManualDose').removeClass("btn-group selected").addClass("btn-group");
       

    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.Notifications = this.route.snapshot.data['Notifications'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.userId = this.route.snapshot.params['customer_id'];
        this.trailId = Number(this.route.snapshot.params['id'])
        this.trialNotifications = this.route.snapshot.data['notifications'];
        //alert(this.currentUserRole);
        //this.trialNotifications = [
        //    { id: 1, isMissedDoseSelected: false, missedDoseContent: 'Test missedDoseContent', missedDoseOccurances: '1', isOverDoseSelected: false, overDoseContent: 'Test content', overDoseOccurances: '1', isLateDoseSelected: false, lateDoseContent: 'Test content', lateDoseOccurances: '1', isUnderDoseSelected: false, underDoseContent: 'Test content', underDoseOccurances: '1', isExcessiveManualDoseSelected: false, excessiveManualDoseContent: 'Test content', excessiveManualDoseOccurances: '1' },

        //]
        this.loadDefaultValues();
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Notification')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }


       // this.selectedTrialId = 1;
        

        if (this.currentUserRole === UserRole.MedConAdmin) {
            this.NotificationsService.getNotificationsList(this.selectedCustomerId)
                .subscribe((Notifications) => {
                    this.Notifications = Notifications;

                }
                );
        }

        this.notificationsList = [
            //{ notificationId: 1, userName: 'priya', email: 'welcome@smartims.com', trailName: 'TestGroup1', name: 'priya', numberOfSubscriptions: '90', NotificationType: 'Titrate' },
            //{ notificationId: 2, userName: 'Robort', email: 'world@world.com', trailName: 'TestGroup1', name: 'Robort', numberOfSubscriptions: '45', NotificationType: 'Broadcast' },
            //{ notificationId: 3, userName: 'Sachin', email: 'abc123@gmail.com ', trailName: 'TestGroup2', name: 'Sachin', numberOfSubscriptions: '10', NotificationType: 'Broadcast' },
            //{ notificationId: 4, userName: 'Jinga', email: 'happiness@h24s.com', trailName: 'TestGroup3', name: 'Jinga', numberOfSubscriptions: '65', NotificationType: 'Broadcast' },
        ]

        this.loggedInUserId = Number(localStorage.getItem("GLOBAL_LOGGED_IN_USER_ID"));
    }

    

    public ngAfterViewInit(): void {
        //$('#datatable').DataTable();

        this.NotificationsService.getAllTrails(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrailsList = response;

            },
            (err) => {
                this.errorMessage = err;

            });



        this.loadNotificationList();

        this.addNewEditCheckOptions();
        this.newAndPopulateFormValues('');

        this.selectedCompanyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));
    }

    public onSubmit(): void {
        this.showErrors = false;
        this.errorMessage = "";
        //alert(this.isNewForm);
        let notificationType;
        if (this.notification.value.chkNotificationTypeEmail && this.notification.value.chkNotificationTypeSMS) {
            notificationType = 3;
        }
        else if (this.notification.value.chkNotificationTypeSMS) {
            notificationType = 2;
        }
        else if (this.notification.value.chkNotificationTypeEmail) {
            notificationType = 1;
        }

        //Code added on 24th July 2018 to validate occurances value, if it is zero, then display validation error
        let isValid;
        isValid = true;
        let missedDoseChkValue = Number(this.notification.value.missedDose);
        let missedDoseOccurrence = Number(this.notification.value.missedDoseOccurrence);
        let overDoseChkValue = Number(this.notification.value.overDose);
        let overDoseOccurrence = Number(this.notification.value.overDoseOccurrence);
        let lateDoseChkValue = Number(this.notification.value.lateDose);
        let lateDoseOccurrence = Number(this.notification.value.lateDoseOccurrence);
        let underDoseChkValue = Number(this.notification.value.underDose);
        let underDoseOccurrence = Number(this.notification.value.underDoseOccurrence);
        let excessiveManualDoseChkValue = Number(this.notification.value.excessiveManualDose);
        let excessiveManualDoseOccurrence = Number(this.notification.value.excessiveManualDoseOccurrence);
        if ((missedDoseChkValue == 1 && missedDoseOccurrence == 0) || (overDoseChkValue == 1 && overDoseOccurrence == 0)
            || (lateDoseChkValue == 1 && lateDoseOccurrence == 0) || (underDoseChkValue == 1 && underDoseOccurrence == 0)
            || (excessiveManualDoseChkValue == 1 && excessiveManualDoseOccurrence == 0)) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please enter Occurrences value higher than zero";
            this.isLoading = false;
            $(window).scrollTop(5);
        }
        
        if (missedDoseChkValue == 0 && overDoseChkValue == 0
             && lateDoseChkValue == 0 && underDoseChkValue == 0 
            && excessiveManualDoseChkValue == 0) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please select atleast one subscription";
            this.isLoading = false;
            $(window).scrollTop(5);
        }


        //End 24th July 2018
        
         
        if (this.notification.invalid) {
            this.showErrors = true;
            this.errorMessage ="Errors While Adding new Notifications";
        }
        else if (String(this.selectedTrialId) == 'NaN' || this.selectedTrialId == undefined) {

            this.showErrors = true;
            this.errorMessage = "Please Select Trial"
        }
        //else if ((this.isNewForm == false || this.isNewForm == undefined) && (this.isEditForm == false || this.isEditForm==undefined )) {

        //    this.showErrors = true;
        //    this.errorMessage = "Please Click on ADD New Notification button"
        //}
        else if (this.isNewForm == true) {
            
            //else {
            // TODO: NEED TO ADD COUNTRY SELECTOR TO THE VIEW
            //alert("New Notification");
            if (isValid) {
                //alert(this.isNewForm);
                //alert(Number(this.notification.value.overDose));
                this.isLoading = true;
                let request = new NotificationsRequest(
                    //this.route.snapshot.params['customer_id'],
                    this.notification.value.listOfTrails,
                    Number(this.notification.value.missedDose),
                    Number(this.notification.value.missedDoseOccurrence),
                    Number(this.notification.value.overDose),
                    Number(this.notification.value.overDoseOccurrence),
                    Number(this.notification.value.lateDose),
                    Number(this.notification.value.lateDoseOccurrence),
                    Number(this.notification.value.underDose),
                    Number(this.notification.value.underDoseOccurrence),
                    Number(this.notification.value.excessiveManualDose),
                    Number(this.notification.value.excessiveManualDoseOccurrence),
                    notificationType
                    // Number(this.userId)
                );
                this.NotificationsService.createNotifications(this.selectedTrialId, request).subscribe(
                    (response) => {
                        this.notification.markAsPristine();
                        this.isLoading = false;
                        this.successMessage = "successfully Added ";
                        //this.notification.reset();
                        //location.reload();
                        $("#datatable").dataTable().fnDestroy();
                        this.loadNotificationList();
                        this.notification.reset();
                        this.clearDataCSS();
                        this.addNewEditCheckOptions();

                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });

            }


        }

        else {
            if (isValid) {
                this.isLoading = true;
                let request = new NotificationsRequest(
                    //this.route.snapshot.params['customer_id'],
                    this.notification.value.listOfTrails,
                    Number(this.notification.value.missedDose),
                    Number(this.notification.value.missedDoseOccurrence),
                    Number(this.notification.value.overDose),
                    Number(this.notification.value.overDoseOccurrence),
                    Number(this.notification.value.lateDose),
                    Number(this.notification.value.lateDoseOccurrence),
                    Number(this.notification.value.underDose),
                    Number(this.notification.value.underDoseOccurrence),
                    Number(this.notification.value.excessiveManualDose),
                    Number(this.notification.value.excessiveManualDoseOccurrence),
                    notificationType
                    // Number(this.userId)
                );
                let recordId = Number(localStorage.getItem('RECORD_ID'));
                this.NotificationsService.updateNotifications(this.selectedTrialId, request, recordId).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.notification.markAsPristine();

                        this.successMessage = "successfully Added ";
                        //this.notification.reset();
                        //location.reload();
                        $("#datatable").dataTable().fnDestroy();
                        this.loadNotificationList();
                        //this.notification.reset();
                        //this.clearDataCSS();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
            }


        }
    }




    public customerChanged(): void {
        this.NotificationsService.getNotificationsList(this.selectedCustomerId).subscribe((Notifications) => {
            this.Notifications = Notifications;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/notifications', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.NotificationsService.getNotificationsList(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((Notifications) => {
            this.Notifications = Notifications;
        });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public newAndPopulateFormValues(notificationObject) {

        this.isNewForm = true;

        this.loadDefaultValues();
        this.addNewEditCheckOptions();
        $('#pnlNotificationTypeEmail').removeClass("btn-group selected").addClass("btn-group");
        $('#pnlNotificationTypeSMS').removeClass("btn-group selected").addClass("btn-group");

    }
   
    public editAndPopulateFormValues(notificationObject) {
        
        this.isEditForm = true;
        this.trialNotifications = [
            { id: 1, isMissedDoseSelected: false, missedDoseContent: 'Test missedDoseContent', missedDoseOccurances: '1', isOverDoseSelected: true, overDoseContent: 'Test content', overDoseOccurances: '1', isLateDoseSelected: true, lateDoseContent: 'Test content', lateDoseOccurances: '1', isUnderDoseSelected: true, underDoseContent: 'Test content', underDoseOccurances: '1', isExcessiveManualDoseSelected: true, excessiveManualDoseContent: 'Test content', excessiveManualDoseOccurances: '1', isEmailNotificationChecked: false, isSMSNotificationChecked: false },

        ]
        this.notification = this.fb.group({
           
            listOfTrails: ['', Validators.required],
            missedDose: [this.trialNotifications[0].isMissedDoseSelected],
            txtMissedDose: [this.trialNotifications[0].missedDoseContent],
            missedDoseOccurrence: [this.trialNotifications[0].missedDoseOccurances],
            overDose: [this.trialNotifications[0].isOverDoseSelected],
            txtOverDose: [this.trialNotifications[0].overDoseContent],
            overDoseOccurrence: [this.trialNotifications[0].overDoseOccurances],
            lateDose: [this.trialNotifications[0].isLateDoseSelected],
            txtLateDose: [this.trialNotifications[0].lateDoseContent],
            lateDoseOccurrence: [this.trialNotifications[0].lateDoseOccurances],
            underDose: [this.trialNotifications[0].isUnderDoseSelected],
            txtUnderDose: [this.trialNotifications[0].underDoseContent],
            underDoseOccurrence: [this.trialNotifications[0].underDoseOccurances],
            excessiveManualDose: [this.trialNotifications[0].isExcessiveManualDoseSelected],
            txtExcesManualDose: [this.trialNotifications[0].excessiveManualDoseContent],
            excessiveManualDoseOccurrence: [this.trialNotifications[0].excessiveManualDoseOccurances],
            chkEmailNotificationType: [''],
            chkSMSNotificationType: ['']
        });
        this.addNewEditCheckOptions();
        
        

    }

    public enablePanel(chkType, textBox1Id, divId) {
        //alert(chkType);
        let flag = (<HTMLInputElement>document.getElementById(chkType)).checked;
        let checkBoxId = chkType
        if (flag == true) {

            //$('#' + textBox1Id).prop('disabled', false);

            $('#' + textBox1Id).removeAttr('disabled');
           // $('#' + textBox2Id).prop('disabled', false);
            $('#' + divId).removeClass("btn-group").addClass("btn-group selected");
            
        }
        else {
            //$('#' + textBox1Id).prop('disabled', true);
            $('#' + textBox1Id).attr('disabled', 'disabled');
            //$('#' + textBox2Id).prop('disabled', true);
            $('#' + divId).removeClass("btn-group selected").addClass("btn-group");

        }

       

    }
    public deleteItem(id): void {
        this.selectedNotificationIDToDelete = id;
        this.deleteModal.show();
        this.isLoading = false;
    }

    public hideDeleteModal(): void {
        this.notificationToDelete = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        let recordId = Number(localStorage.getItem('RECORD_ID'));
        this.NotificationsService
            .deleteNotifications(this.selectedNotificationIDToDelete, recordId)
            .subscribe(
            (response) => {
                
                this.successMessage = "successfully deleted";
                this.hideDeleteModal();
                location.reload();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }
    onChange_State(selectedValue) {
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;
       
        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }

    }

    public editNotification(id): void {
        if (id != 'undefined') {
            this.isLoading = true;
            this.router.navigate(['/', this.selectedCompanyId, 'notifications', id, 'edit']);
        }
        
        

    }
    public clearDataCSS() {
        $("#pnlMissedDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlOverDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlUnderDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlLateDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlExcessiveManualDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
    }



    public loadNotificationList(): void {
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {
                //alert(localStorage.getItem('GLOBAL_COMPANY_ID'));
                this.authorizationToken = token;
                //alert("Testing Load patient");
                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/notifications/all?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_GET_LIST_NOTIFICATION+'notifications/all?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                       
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2,3, 4, 5]
                            },
                             action: function () {
                                 let apiUrl = CommonService.API_PATH_V2_GET_LIST_NOTIFICATION + 'notifications/all?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID') + '&draw=1&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=userName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=email&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=subscriptions&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=notificationType&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=trialId&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=notifId&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=8&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=false&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=4&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1530788744083'
                                self.reportService.ExportAll(apiUrl, 'Notification List');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            }}

                    ],
                    "order": [[4, "desc"]],
                    "columns": [
                        { "data": "trialName" },
                        { "data": "userName" },
                        { "data": "email" },
                        //{ "data": "trialName" },
                        { "data": "subscriptions"},
                        { "data": "notificationType" },
                        { "data": "status" },
                        { "data": "trialId" },
                        { "data":"notifId"},
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                //localStorage.setItem('RECORD_ID', full.notifId)
                                //return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem" + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.trialId + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){  localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div></div>";
                            
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Notification Already Deleted\" disabled  id=\"" + full.trialId + "_edit_" + full.notifId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> <button title=\"Cannot Delete this Notification It is deleted already\" disabled id=\"" + full.trialId + "_deleteItem_" +  full.notifId +"\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem_" + full.notifId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.trialId + "_deleteItem_" + full.notifId+ "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Notification Already Deleted\" disabled  id=\"" + full.trialId + "_edit_" + full.notifId+ "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem_" + full.notifId+ "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"> <button title=\"Cannot Delete this Notification It is deleted already\" disabled id=\"" + full.trialId + "_deleteItem_" + full.notifId+ "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_deleteItem_" + full.notifId+ "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if ((self.currentUserRole == UserRole.CustomerUser) && Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0)
                                {
                                    return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem_" + full.notifId+ "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</button> </div>";
                                }
                                else {
                                    return "";
                                }
                                
                            }

                        }


                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [5],
                            "visible": false,
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        },
                        {
                            "targets": [4],
                            render: function (data, type, row) {
                                if (data == 1) {
                                    return 'Email'
                                }
                                else if (data == 2) {
                                    return 'SMS'
                                }
                                else {
                                    return 'Email, SMS'
                                }
                            }
                        },
                        {
                            "targets": [6],
                            "visible": false

                        },
                        {
                            "targets": [7],
                            "visible": false

                        }
                    ]
                });
            }
        });
        $('#datatable').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            var recordId = attId.split("_")[2];
            this.selectedNotificationIDToDelete = buttonId;
            localStorage.setItem('RECORD_ID', recordId);
            if (buttonName == "editItem")
            {
                self.editNotification(buttonId);
                self.isLoading = true;
            }
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });

        //$('#datatable tbody').on("click", 'tr', function (evt) {

        //    if ($(evt.target).is("button") && $(evt.target).is('[disabled]') == false) {
        //        self.isLoading = true;
        //    }

        //});


    }

    
    

    public loadDefaultValues(): void {

        this.notification = this.fb.group({

            listOfTrails: [''],
            missedDose: [''],
            txtMissedDose: [this.trialNotifications[0].message],
            missedDoseOccurrence: [''],
            overDose: [''],
            txtOverDose: [this.trialNotifications[1].message],
            overDoseOccurrence: [''],
            lateDose: [''],
            txtLateDose: [this.trialNotifications[2].message],
            lateDoseOccurrence: [''],
            underDose: [''],
            txtUnderDose: [this.trialNotifications[3].message],
            underDoseOccurrence: [''],
            excessiveManualDose: [''],
            txtExcesManualDose: [this.trialNotifications[4].message],
            excessiveManualDoseOccurrence: [''],
            chkNotificationTypeEmail: [''],
            chkNotificationTypeSMS: ['']
        });

    }
}
