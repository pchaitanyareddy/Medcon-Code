import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LocationStrategy } from '@angular/common';
import { URLSearchParams } from '@angular/http';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { UserService } from '../../services/user.service';
import { Pagination } from '../../models/pagination';
import { MedConUser } from '../../models/medconuser';

@Component({
	templateUrl: './medcon-users-list.component.html'
})

export class MedConUsersListComponent implements OnInit {
	@ViewChild('deleteModal') public deleteModal: ModalDirective;
	public users: Pagination<MedConUser>;
	public successMessage: string;
	public errorMessage: string;
	public userToDelete: MedConUser;

	public maxSize: number = 5;
	public currentPage: number = 1;

	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private userService: UserService,
		private url: LocationStrategy) {
	}

	public ngOnInit(): void {
		this.users = this.route.snapshot.data['users'];

		if (this.route.queryParams['page']) {
			this.currentPage = this.route.queryParams['page'];
		}
	}

	public deleteItem(user): void {
		this.userToDelete = user;
		this.deleteModal.show();
	}

	public hideDeleteModal(): void {
		this.userToDelete = null;
		this.deleteModal.hide();
	}

	public confirmDelete(): void {
		let user = this.userToDelete;
		this.userService
			.deleteMedConUser(user.id)
			.subscribe(
				(response) => {
					this.userService.getMedConUsers().subscribe((users) => {
						this.users = users;
						this.successMessage = user.givenName + ' ' + user.familyName + ' has been successfully deleted';
						this.hideDeleteModal();
					});
				},
				(err) => {
					this.errorMessage = err;
					this.hideDeleteModal();
				}
			);
	}

	public pageChanged(event: any): void {
		let queryParams = new URLSearchParams();
		queryParams.set('page', event.page);
		queryParams.set('per_page', event.itemsPerPage);

		this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
		this.userService.getMedConUsers(event.page, event.itemsPerPage).subscribe((users) => {
			this.users = users;
		});
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}
}
