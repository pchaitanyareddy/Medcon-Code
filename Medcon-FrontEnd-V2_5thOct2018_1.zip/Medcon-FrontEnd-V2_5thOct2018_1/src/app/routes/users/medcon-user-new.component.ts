import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { UserService } from '../../services/user.service';
import { UserMedConCreateRequest } from '../../requests/user-medcon-create-request';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './medcon-user-new.component.html'
})

export class MedConUserNewComponent implements OnInit {
	public form: FormGroup;
	public showErrors: boolean;
	public errorMessage: string;

	constructor(public templateService: TemplateService,
		public router: Router,
		private fb: FormBuilder,
		private userService: UserService) {
	}

	public ngOnInit() {
		this.form = this.fb.group({
			firstName: ['', Validators.required],
			lastName: ['', Validators.required],
			email: [
				'', [Validators.required,
					Validators.pattern('^[a-zA-Z0-9]+(\.[_a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,15})$')]
			]
		});
	}

	public onSubmit() {
		if (this.form.invalid) {
			this.showErrors = true;
			return;
		}

		let request = new UserMedConCreateRequest(
			this.form.value.firstName,
			this.form.value.lastName,
			this.form.value.email
		);

		this.userService.createMedConUser(request).subscribe(
			(response) => {
				this.form.markAsPristine();
				this.goBack();
			},
			(err) => {
				this.errorMessage = err;
			});
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate(['/medcon-users']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}
}
