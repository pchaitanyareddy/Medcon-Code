import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-weekly-pnc',
	templateUrl: './widget-pnc.component.html'
})

export class WidgetWeeklyPncComponent implements OnInit {
	public patients: any;

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit(): void {
		this.dashboardService.doseComplianceInfo.subscribe((value) => {
			if (value) {
				this.patients = value.weekly;
			}
		});
	}
}
