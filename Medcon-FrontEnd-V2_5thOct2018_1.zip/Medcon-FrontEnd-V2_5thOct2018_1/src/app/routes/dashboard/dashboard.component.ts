import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { DashboardService } from '../../services/dashboard.service';
import { CustomerService } from '../../services/customer.service';
import { TrialService } from '../../services/trial.service';
import { DoseService } from '../../services/dose.service';
import { LabelService } from '../../services/label.service';
import { PatientService } from '../../services/patient.service';
import { Trial } from '../../models/trial';
import { DoseOverview } from '../../models/DoseOverview';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { UserService } from '../../services/user.service';
import { NotificationsService } from '../../services/notifications.service';
//import '../../../assets/js/Common/translate.google.com_translate_a_element.js';
//import { } from '@types/googlemaps';
//declare var google: any;
@Component({
    templateUrl: './dashboard.component.html?v=${new Date().getTime()}',
    styleUrls: ['./dashboard.component.scss?v=${new Date().getTime()}']
})

export class DashboardComponent implements OnInit {
	public trials: Trial[];
	public customers: Customer[];
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public user: any;
	public trial: Trial;
	public labels: any;
	public customerId: number;
	public selectedCustomerId: number;
	public selectedTrialId: any = 'all';
	public doseOverview: any;
    public patientOverview: any;
    public allTrailsList: any;
    //public doseOverview: DoseOverview;
	constructor(private route: ActivatedRoute,
		public templateService: TemplateService,
		private dashboardService: DashboardService,
		private customerService: CustomerService,
		private trialService: TrialService,
		private doseService: DoseService,
		private labelService: LabelService,
        private patientService: PatientService,
        private notificationsService: NotificationsService,
        private router: Router,
    ) {
	}

    public ngOnInit(): void {
       
		this.currentUserRole = this.route.snapshot.data['role'];
		this.user = this.route.snapshot.data['user'];
        let dashboardState = this.route.snapshot.data['state'];
        this.doseOverview = this.route.snapshot.data['doseoverview'];
		//if (this.currentUserRole === UserRole.MedConAdmin) {
		//	//this.customerService.getCustomersAll().subscribe(
		//	//	(customers) => {
		//	//		this.customers = customers;
		//	//		this.selectedCustomerId = this.customers[0].id;
		//	//		this.viewChanged('customer');
		//	//	}
		//	//);
		//} else {
		//	this.customerId = this.user['custom:customer_id'];
		//	this.trialService.getTrialsAll().subscribe((trials) => {
		//		this.trials = trials;
		//		this.viewChanged('trial');
		//	});
		//}

		let viewState = null;
		if (dashboardState.meta_value) {
			viewState = JSON.parse(dashboardState.meta_value);
		} else {
			viewState = {
				dosageHistory: 'monthly',
				dosageAdherence: 'weekly',
				dailyTrack: 'doses-logged',
				weeklyTrack: 'patient-non-compliance',
				monthlyTrack: 'adherence-info',
			};
		}

        this.dashboardService.viewState.next(viewState);

        //Ramesh added on 26th Feb 2018

        let trialId = 0; //= (view === 'trial' && this.selectedTrialId !== 'all') ? this.selectedTrialId : null;
        //let customerId = (view === 'trial') ? null : this.selectedCustomerId;
        let companyId = localStorage.getItem('GLOBAL_COMPANY_ID');
        this.doseService
            .getOverview(trialId, Number(companyId))
            .subscribe((overview) => this.doseOverview = overview);
        this.doseService
            .getDosageHistory(Number(companyId), Number(trialId))
            .subscribe((history) => this.dashboardService.dosageHistory.next(history));
        this.doseService
            .getTrackLogged(Number(companyId), Number(trialId))
            .subscribe((logged) => this.dashboardService.trackDosesLogged(logged));
        this.doseService
            .getAdherenceInfo(Number(trialId), Number(companyId))
            .subscribe((adherence) => this.dashboardService.doseAdherenceInfo.next(adherence));
        //this.doseService
        //    .getDosageHistory(Number(companyId))
        //    .subscribe((adherence) => this.dashboardService.doseAdherenceInfo.next(adherence));
        this.doseService
            .getComplianceInfo(Number(trialId), Number(companyId))
            .subscribe((compliance) => this.dashboardService.doseComplianceInfo.next(compliance));
        //this.labelService
        //    .getOverview(trialId, Number(companyId))
        //    .subscribe((overview) => this.labels = overview);
        this.patientService
            .getOverview(Number(trialId), Number(companyId))
            .subscribe((overview) => this.patientOverview = overview);

        let currentYear = (new Date()).getFullYear();
        this.labelService
            .getLabelDetails(Number(companyId), Number(currentYear))
            .subscribe((labelDetails) => this.labels = labelDetails);

        //End

        this.notificationsService.getAllTrails(Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allTrailsList = response;

            },
            (err) => {
                //this.errorMessage = err;

            });
	}

    public viewChanged(view: string): void {
        
		let trialId = (view === 'trial' && this.selectedTrialId !== 'all') ? this.selectedTrialId : null;
		let customerId = (view === 'trial') ? null : this.selectedCustomerId;
        let companyId = localStorage.getItem('GLOBAL_COMPANY_ID'); 
        if (trialId == 'undefined') trialId = 0;
        if (view === 'trial' && trialId != null) {
            $("#anchOption_PatientMinimumAdherence").css("display", "block");
            //$('#spnGraphTitle').html('Patient Minimum Adherence');
        }
        else {
            $('#spnGraphTitle').html('Dosage Adherence');
            $("#anchOption_PatientMinimumAdherence").css("display", "none");

            this.onRefresh('', 'dashboard');
        }

		this.doseService
            .getOverview(Number(trialId), Number(companyId))
			.subscribe((overview) => this.doseOverview = overview);
		this.doseService
            .getDosageHistory(Number(companyId), Number(trialId))
			.subscribe((history) => this.dashboardService.dosageHistory.next(history));
		this.doseService
            .getTrackLogged(Number(companyId), Number(trialId))
			.subscribe((logged) => this.dashboardService.trackDosesLogged(logged));
		this.doseService
            .getAdherenceInfo(Number(trialId), Number(companyId))
			.subscribe((adherence) => this.dashboardService.doseAdherenceInfo.next(adherence));
		this.doseService
            .getComplianceInfo(Number(trialId), Number(companyId))
			.subscribe((compliance) => this.dashboardService.doseComplianceInfo.next(compliance));
		//this.labelService
  //          .getOverview(Number(trialId), Number(companyId), 2018)
		//	.subscribe((overview) => this.labels = overview);
        this.patientService
            .getOverview(Number(trialId), Number(companyId))
			.subscribe((overview) => this.patientOverview = overview);
    }

    public abbrNum(number, decPlaces):string {
        // 2 decimal places => 100, 3 => 1000, etc
        decPlaces = Math.pow(10, decPlaces);

        // Enumerate number abbreviations
        var abbrev = ["k", "m", "b", "t"];

        // Go through the array backwards, so we do the largest first
        for (var i = abbrev.length - 1; i >= 0; i--) {

            // Convert array index to "1000", "1000000", etc
            var size = Math.pow(10, (i + 1) * 3);

            // If the number is bigger or equal do the abbreviation
            if (size <= number) {
                // Here, we multiply by decPlaces, round, and then divide by decPlaces.
                // This gives us nice rounding to a particular decimal place.
                number = Math.round(number * decPlaces / size) / decPlaces;

                // Handle special case where we round up to the next abbreviation
                if ((number == 1000) && (i < abbrev.length - 1)) {
                    number = 1;
                    i++;
                }

                // Add the letter for the abbreviation
                number += abbrev[i];

                // We are done... stop
                break;
            }
        }

        return number;
    }

    onRefresh(companyId, viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId != '')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }
     
}
