export * from './patient-new.component';
export * from './patient-edit.component';
