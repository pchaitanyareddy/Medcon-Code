import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TabsetComponent } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { LabelService } from '../../services/label.service';
import { CustomerType } from '../../models/customertype';
import { CustomerService } from '../../services/customer.service';
import { Customer } from '../../models/customer';
import { Site } from '../../models/site';
import { UserRole } from '../../models/userrole';
import { LabelCommittedRequest } from '../../requests/label-committed-request';
import { CustomerRequest } from '../../requests/customerrequest';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './customer-edit.component.html'
})

export class CustomerEditComponent implements OnInit {
	@ViewChild('customerMenu') public customerMenu: TabsetComponent;
	public customer: Customer;
	public sites: Site[];
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public form: FormGroup;
	public formMeta: FormGroup;
	public formCustomer: FormGroup;
	public showErrors: boolean;
	public labelsCommitted = [];
	public activeCommitment = [];
	public successMessage: string;
	public errorMessage: string;
	public pageTitle: string;
	public control: FormArray;
	public types: CustomerType[];

	constructor(public templateService: TemplateService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		private labelService: LabelService,
		private customerService: CustomerService) {
	}

	public ngOnInit(): void {
		this.customer = this.route.snapshot.data['customer'];
		this.sites = this.route.snapshot.data['sites'];
		this.currentUserRole = this.route.snapshot.data['role'];
		this.formMeta = this.fb.group({
			name: [this.customer.name, [Validators.required, Validators.pattern('[A-Za-z ]{3,45}')]],
			type: [this.customer.typeId, Validators.required],
		});
		this.form = this.fb.group({
			labels_committed: this.fb.array([]),
		});
		this.pageTitle = (this.currentUserRole === UserRole.CustomerAdmin) ? 'Company' : 'Customer';
		this.pageTitle = 'Edit ' + this.pageTitle + ' - ' + this.customer.name;

		if (this.currentUserRole === UserRole.MedConAdmin) {
			this.labelService.getCommitted(this.customer.id).subscribe((committed) => {
				this.labelsCommitted = committed;
				if (committed) {
					committed.forEach((commitment) => {
						this.addLabelsCommitted(commitment.total, commitment.year);
						this.activeCommitment.push(true);
					});
				}
			});

			this.customerService.getCustomerTypesAll().subscribe((types) => this.types = types);
		}

		this.formCustomer = this.fb.group({
			dosageAdherenceBenchmark: [
				this.customer.dosageAdherenceBenchmark,
				Validators.pattern(/^(\d{0,2}(\.\d{1,2})?|100(\.00?)?)$/)],
		});

		setTimeout(() => {
			if (this.route.snapshot.queryParams['tab'] === 'sites') {
				let index = (this.currentUserRole === this.UserRole.MedConAdmin) ? 2 : 1;
				this.customerMenu.tabs[index].active = true;
			}
		});
	}

	public addLabelsCommitted(total?: number, year?: number) {
		this.control = <FormArray> this.form.controls['labels_committed'];
		let committedControl = this.fb.group({
			total: [total, Validators.pattern('[0-9]{1,12}')],
			year: [year, Validators.pattern('[0-9]{4}')],
		});

		this.control.push(committedControl);
	}

	public deleteCommitment(year: number, index: number, active: boolean): void {
		if (active) {
			this.labelService.deleteCommitment(this.customer.id, year)
				.subscribe(
					(response) => {
						this.control.removeAt(index);
						this.activeCommitment.splice(index, 1);
						this.successMessage = 'Label commitment has been successfully deleted.';
					},
					(err) => {
						this.errorMessage = err;
					}
				);
		} else {
			this.control.removeAt(index);
		}
	}

	public onSubmit(): void {
		if (this.formMeta.invalid) {
			this.showErrors = true;
		} else {
			let request = new CustomerRequest(
				this.formMeta.value.name,
				this.formMeta.value.type
			);

			this.customerService.updateCustomer(this.customer.id, request).subscribe(
				(response) => {
					this.formMeta.markAsPristine();
					this.successMessage = 'Customer successfully updated';
				},
				(err) => {
					this.errorMessage = err;
				});
		}
	}

	public submitLabelCommitment(): void {
		if (this.form.invalid) {
			this.showErrors = true;
		} else {
			let request = new LabelCommittedRequest(
				this.form.value.labels_committed
			);

			this.labelService.updateCommitted(this.customer.id, request)
				.subscribe(
					(response) => {
						this.form.markAsPristine();
						this.successMessage = 'Label commitment has been successfully updated.';
						this.activeCommitment = [];
						this.control.controls.forEach((c) => {
							this.activeCommitment.push(true);
						});
					},
					(err) => {
						this.errorMessage = err;
					}
				);
		}
	}

	public onSubmitCustomer(): void {
		if (this.formCustomer.invalid) {
			this.showErrors = true;
		} else {
			let request = {
				dosageAdherenceBenchmark: this.formCustomer.value.dosageAdherenceBenchmark
			};

			this.customerService.updateMyCompany(this.customer.id, request).subscribe(
				(response) => {
					this.formCustomer.markAsPristine();
					this.successMessage = 'Company successfully updated';
				},
				(err) => {
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.formMeta.markAsPristine();
		this.formCustomer.markAsPristine();
		let path = (this.currentUserRole === UserRole.MedConAdmin) ?
			['/customers'] :
			['/customers', this.customer.id, 'view'];

		this.router.navigate(path);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !(this.form.dirty || this.formCustomer.dirty || this.formMeta.dirty);
	}
}
