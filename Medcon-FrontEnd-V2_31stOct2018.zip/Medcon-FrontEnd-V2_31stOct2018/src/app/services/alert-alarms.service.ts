import { Injectable } from '@angular/core';
import { Response, Http } from '@angular/http';
import { Observable } from 'rxjs';
import { AlertAlarm } from '../models/alert-alarm';
import { AlertsAlarmsRequest } from '../requests/alerts-alarms-request';

@Injectable()
export class AlertAlarmService {
	constructor(private http: Http) {
	}

	public getAlertsAlarms(): Observable<AlertAlarm[]> {
		return this.http.get(API_PATH + '/alert-alarm/list')
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updateAlertsAlarms(updateType: string, request: AlertsAlarmsRequest): Observable<(any)> {
		return this.http.put(API_PATH + '/alert-alarm/update/' + updateType, request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}
}
