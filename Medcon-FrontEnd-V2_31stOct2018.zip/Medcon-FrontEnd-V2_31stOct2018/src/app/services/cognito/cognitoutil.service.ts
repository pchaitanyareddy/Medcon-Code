import { Injectable } from '@angular/core';
import { Callback } from './cognito.service';

/**
 * Created by Vladimir Budilov
 */

declare var AWS: any;
declare var AWSCognito: any;

@Injectable()
export class CognitoUtil {
	public static _REGION = 'us-east-1';

	public static _IDENTITY_POOL_ID = 'us-east-1:01bffbd4-574f-49ec-9693-4c37d7e49435';
	public static _USER_POOL_ID = 'us-east-1_bKRKFcMqA';
	public static _CLIENT_ID = '3d5e4fjm1icahcb0rp1rq06715';

	public static _POOL_DATA = {
		UserPoolId: CognitoUtil._USER_POOL_ID,
		ClientId: CognitoUtil._CLIENT_ID
	};

	public static getAwsCognito(): any {
		return AWSCognito;
	}

	public getUserPool() {
		return new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(CognitoUtil._POOL_DATA);
	}

	public getCurrentUser() {
		return this.getUserPool().getCurrentUser();
	}

	public getCognitoIdentity(): string {
		return AWS.config.credentials.identityId;
	}

	public getAccessToken(callback: Callback): void {
		if (callback == null) {
			throw('CognitoUtil: callback in getAccessToken is null...returning');
		}
		if (this.getCurrentUser() != null) {
			this.getCurrentUser().getSession((err, session) => {
				if (err) {
					console.log('CognitoUtil: Can\'t set the credentials:' + err);
					callback.callbackWithParam(null);
				} else {
					if (session.isValid()) {
						callback.callbackWithParam(session.getAccessToken().getJwtToken());
					}
				}
			});
		} else {
			callback.callbackWithParam(null);
		}
	}

	public getIdToken(callback: Callback): void {
		if (callback == null) {
			throw('CognitoUtil: callback in getIdToken is null...returning');
		}
		if (this.getCurrentUser() != null) {
			this.getCurrentUser().getSession((err, session) => {
				if (err) {
					console.log('CognitoUtil: Can\'t set the credentials:' + err);
					callback.callbackWithParam(null);
				} else {
					if (session.isValid()) {
						callback.callbackWithParam(session.getIdToken().getJwtToken());
					} else {
						console.log('CognitoUtil: Got the id token, but the session isn\'t valid');
						callback.callbackWithParam(null);
					}
				}
			});
		} else {
			callback.callbackWithParam(null);
		}
	}

	public getRefreshToken(callback: Callback): void {
		if (callback == null) {
			throw('CognitoUtil: callback in getRefreshToken is null...returning');
		}
		if (this.getCurrentUser() != null) {
			this.getCurrentUser().getSession((err, session) => {
				if (err) {
					console.log('CognitoUtil: Can\'t set the credentials:' + err);
					callback.callbackWithParam(null);
				} else {
					if (session.isValid()) {
						callback.callbackWithParam(session.getRefreshToken());
					}
				}
			});
		} else {
			callback.callbackWithParam(null);
		}
	}

	public refresh(): void {
		this.getCurrentUser().getSession((err, session) => {
			if (err) {
				console.log('CognitoUtil: Can\'t set the credentials:' + err);
			} else {
				if (session.isValid()) {
					console.log('CognitoUtil: refreshed successfully');
				} else {
					console.log('CognitoUtil: refreshed but session is still not valid');
				}
			}
		});
	}
}
