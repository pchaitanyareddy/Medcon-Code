﻿export class LabelDetails {
    constructor(public labelName: string,
        public companyName: string,
        public status: string,
        public committed: number,
        public purchased: number,
        public used: number,
        public remaining: number,
        public date:string,
    ) {
    }
}
