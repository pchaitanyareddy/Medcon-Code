﻿export class DoseOverview {
    constructor(
        public taken: any,
        public adherence: any,
        public nonCompliant: any,
        public captured: any,
        public distributed: any,
        

    ) {
    }
}
