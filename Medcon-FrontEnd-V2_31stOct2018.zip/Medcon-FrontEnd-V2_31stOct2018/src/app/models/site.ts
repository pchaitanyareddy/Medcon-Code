export class Site {
    //constructor(public id: number,
    //    public name: string,
    //    public addressLine1: any,
    //    //public addressLine2: any,
    //    public countryName: string,
    //    public phoneNumber: string,
    //    //public stateId: number,
    //    public stateName: String,
    //    public cityName: string,
    //    public zipCode: string,
    //    public siteId: number,
    //    public countryId?: number,
    //    public stateId?: number
    //    //public createdBy?: number,
    //    //public createdDate?: string,
    //    //public lastUpdatedBy?: string,
    //    //public lastUpdatedDate?: string,
    //    //public active?: string,
    //    //public allowToEdit?: number,
    //    //public allowToDelete?: number,
    //) {
    //}


    constructor(public id: number,
        public name: string,
        public address: any,
        public country: string,
        public phoneNumber: string,
        public State: String,
        public cityName: string,
        public zipcode: string,
        public siteId: number,
        public countryId?: number,
        public stateId?: number,
        public companyId?: number
        //public createdBy?: number,
        //public createdDate?: string,
        //public lastUpdatedBy?: string,
        //public lastUpdatedDate?: string,
        //public active?: string,
        //public allowToEdit?: number,
        //public allowToDelete?: number,
    ) {
    }
}
