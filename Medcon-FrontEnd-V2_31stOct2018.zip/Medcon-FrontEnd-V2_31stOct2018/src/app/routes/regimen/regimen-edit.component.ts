import { Component, HostListener, OnInit, ViewChild, Compiler} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { RegimenService } from '../../services/regimen.service';
import { Regimen } from '../../models/regimen';
import { RegimenRequest } from '../../requests/regimen-request';
import { Observable } from 'rxjs/Observable';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { ModalDirective } from 'ngx-bootstrap';
var $ = require('jquery');
@Component({
    templateUrl: './regimen-edit.component.html?v=${new Date().getTime()}'
})

export class RegimenEditComponent implements OnInit {
    @ViewChild('pnlRegimenYearlyCalendar_AllMonthsModal') public pnlRegimenYearlyCalendar_AllMonthsModal: ModalDirective;
    public selectedTimeCounter: number = 0;
    public selectedAfterNoonTimeCounter: number = 0;
    public selectedEveningTimeCounter: number = 0;
    public selectedBedTimeCounter: number = 0;
    public days = [];
    public hours = [];
    public minutes = [];
    public morningHours = [];
    public morningMinutes = [];
    public afternoonHours = [];
    public afternoonMinutes = [];
    public eveningHours = [];
    public eveningMinutes = [];
    public bedtimeHours = [];
    public bedtimeMinutes = [];
    public form: FormGroup;
    public regimen: Regimen;
    public showErrors: boolean;
    public durationError: boolean;
    public adherenceError: boolean;
    public successMessage: string;
    public errorMessage: string;
    public dosageQuantity: number;
    public dosageAmount: number;
    public unitOfMeasure: string;
    selectedTimeForMorning: string;
    selectedTimeForAfternoon: string;
    selectedTimeForEvening: string;
    selectedTimeForBedTime: string;
    regimenJsonString: string;
    scheduleTypeOptions: any;
    selectedDayOfWeek: string;
    selectedScheduleType: string;
    alreadySelectedMorningHours: number;
    alreadySelectedMorningMinutes: number;
    alreadySelectedAfternoonHours: number;
    alreadySelectedAfternoonMinutes: number;
    alreadySelectedEveningHours: number;
    alreadySelectedEveningMinutes: number;
    alreadySelectedBedTimeHours: number;
    alreadySelectedBedTimeMinutes: number;
    selectedTimeForMorning_PlainData: string;
    selectedTimeForAfternoon_PlainData: string;
    selectedTimeForEvening_PlainData: string;
    selectedTimeForBedTime_PlainData: string;
    selectedRegimenId: number;
    selectedDate: string;
    selectedDatesForMonthly: any;
    selectedDatesForYearly: any;
    selectedMonthForYearly: any;
    monthlyYearlySelectedDate: string;
    dayOfWeek: string;
    selectedDatesForYear: string;
    currentMonth: string;
    selectedMonthForYear: string;
    removedDates: string;
    morningFromMins: number;
    morningToMins: number;
    afternoonFromMins: number;
    afternoonToMins: number;
    eveninigFromMins: number;
    eveninigToMins: number;
    bedtimeFromMins: number;
    bedtimeToMins: number;
    morningAMPM: string;
    afternoonAMPM: string;
    eveningAMPM: string;
    bedTimeAMPM: string;
    isUserModifiedDate: boolean;
    removeDatesState: string;
    isRegimenEditPageLoad: boolean;
    isOnchangeEventTriggered: boolean;
    isLoading: boolean;
    numberOfDays: number;
    isFirstDateSelectedAndThenDeselectedDate: boolean;
    public startDateOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'yyyy-mm-dd',
        firstDayOfWeek: 'mo',
        sunHighlight: true,
        inline: true,
        disableUntil: { year: 2016, month: 8, day: 10 }
    };

    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    dosageWindowSettings: any;
    defaultMorningFromTime: string;
    defaultAfternoonFromTime: string;
    defaultEveningFromTime: string;
    defaultBedTimeFromTime: string;
    defaultMorningFromMins: string;
    defaultAfternoonFromMins: string;
    defaultEveningFromMins: string;
    defaultBedTimeFromMins: string;
    upperBoundaryForMorningHrs: string;
    upperBoundaryForAfternoonHrs: string;
    upperBoundaryForEveningHrs: string;
    upperBoundaryForBedTimeHrs: string;
    public monthDropdown: any;
    constructor(public templateService: TemplateService,
        private router: Router,
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private regimenService: RegimenService,
        private _compiler: Compiler
    ) {
        // Days
        for (let i = 0; i < 31; i++) {
            this.days.push(i);
        }
        // Hours
        for (let i = 0; i <= 23; i++) {
            this.hours.push(i);
        }
        // Minutes
        for (let i = 0; i < 60; i++) {
            this.minutes.push(i);
        }
    }

    public getAndDisplaySelectedDatesByMonth(selectedMonth) {

        var arrSelectedMonths;
        var arrSelectedDates;
        var arrSelectedDates1;
        let strSelectedMonths;
        let strSelectedDates;
        if (this.regimen.monthlyYearly != undefined) {
            arrSelectedMonths = this.regimen.monthlyYearly.split('|');
            arrSelectedMonths.forEach((item, index) => {
                strSelectedMonths = item;
                //alert(strSelectedMonths);
                arrSelectedDates = strSelectedMonths.split('^'); //Ex: March^1,2,3,4

                arrSelectedDates.forEach((item, index) => {
                    //$("#monthList option:'"+arrSelectedDates[0]+"'").css("background-color", "green");
                    if (arrSelectedDates[0] == selectedMonth) {
                        localStorage.setItem(selectedMonth, arrSelectedDates[1]); //store dates for selected month
                        //console.log(item); // 9, 2, 5
                        //console.log(index); // 0, 1, 2
                        if (index != 0) {
                            strSelectedDates = item;
                            arrSelectedDates1 = strSelectedDates.split(',');
                            arrSelectedDates1.forEach((item, index) => {
                                $('#day' + item + 'Cell').addClass("selected"); //displaying selected dates on the current month 
                            });



                        }

                    }

                });

            });

           
        }

        
    }

    public ngOnInit() {
        this.numberOfDays = 0;
        this._compiler.clearCache();
        this.isLoading = false;
        this.isRegimenEditPageLoad = true;
        this.isUserModifiedDate = false;
        this.clearLocalStorage();
        this.dosageWindowSettings = this.route.snapshot.data['dosageWindow'];
        this.regimen = this.route.snapshot.data['regimen'];
        this.route.params.subscribe(params => {
            this.selectedRegimenId = params['id'];

        });
        if (localStorage.getItem(String(this.selectedRegimenId)) != undefined) {
            let numPairsCount = localStorage.getItem(String(this.selectedRegimenId));
            $('#btnSubmit, #btnReset').css("display", "none");
            $('#title').text('View Regimen');
        }
        if (this.regimen.inUse) {
            this.goBack();
        }

        let duration = this.convertMinutes(this.regimen.durationBetweenDoses);
        let adherence = this.convertMinutes(this.regimen.thresholdTime);


        let days = duration.days;
        let hours = duration.hours;
        let minutes = duration.minutes;

        let thresholddays = adherence.days;
        let thresholdhours = adherence.hours;
        let thresholdminutes = adherence.minutes;
        //alert(adherence.hours);

        //Get morning window dosage window schedule from db and display here
        this.selectedScheduleType = this.regimen.schedule_type;
        //alert(this.selectedScheduleType);
        $("#lblDaily").addClass("btn btn-default buying-selling");

        if (this.selectedScheduleType == 'Daily') {

            $("#lblDaily").addClass("btn btn-default buying-selling active");
        }
        else if (this.selectedScheduleType == 'Weekly') {

            $("#lblWeekly").addClass("btn btn-default buying-selling active");
            $("#pnlDayOfWeek").css("display", "block");
            //this.dayOfWeek = this.regimen.dayOfWeek;
            var arrSelectedDays = this.regimen.dayOfWeek.split(',');
            this.selectedDayOfWeek = this.regimen.dayOfWeek;
            arrSelectedDays.forEach((item, index) => {

                if (item == 'Sun') {

                    $('#frm-test-elm-110-1').prop('checked', true);
                    $("#lblSun").addClass("btn btn-default active");
                }
                else if (item == 'Mon') {
                    $('#frm-test-elm-110-2').prop('checked', true);
                    $("#lblMon").addClass("btn btn-default active");
                }
                else if (item == 'Tue') {

                    $('#frm-test-elm-110-3').prop('checked', true);
                    $("#lblTue").addClass("btn btn-default active");
                }
                else if (item == 'Wed') {

                    $('#frm-test-elm-110-4').prop('checked', true);
                    $("#lblWed").addClass("btn btn-default active");
                }
                else if (item == 'Thu') {

                    $('#frm-test-elm-110-5').prop('checked', true);
                    $("#lblThu").addClass("btn btn-default active");
                }
                else if (item == 'Fri') {
                    $('#frm-test-elm-110-6').prop('checked', true);
                    $("#lblFri").addClass("btn btn-default active");

                }
                else if (item == 'Sat') {

                    $('#frm-test-elm-110-7').prop('checked', true);
                    $("#lblSat").addClass("btn btn-default active");
                }

            });
        }
        else if (this.selectedScheduleType == 'Monthly') {
            $('#pnlYearlyHeader').css("display", "none");
            $('#pnlMonthlyHeader').css("display", "table-row");
            $('#spnPrevMonth').css("display", "none");
            $('#spnNextMonth').css("display", "none");
            $("#lblMonthly").addClass("btn btn-default buying-selling active");
            //$("#pnlRegimenCalendar,#pnlSelectedDates").css("display", "block");
            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            $("#monthlyYearly").text(this.regimen.monthlyYearly);
            var arrSelectedDates = this.regimen.monthlyYearly.split(',');
            arrSelectedDates.forEach((item, index) => {

                //console.log(item); // 9, 2, 5
                //console.log(index); // 0, 1, 2
                $('#day' + item + 'Cell').addClass("selected");

            });

        }
        else if (this.selectedScheduleType == 'Yearly') {
            $('#pnlYearlyHeader').css("display", "table-row");
            $('#pnlMonthlyHeader').css("display", "none");
            $("#divCalendar").css("display", "block");
            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            //var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];;
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var date = new Date();

            //$('#spnMonth').text(months[date.getMonth()]);
            $('#spnPrevMonth').css("display", "block");
            $('#spnNextMonth').css("display", "block");

            $("#lblYearly").addClass("btn btn-default buying-selling active");
            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            $("#monthlyYearly").text(this.regimen.monthlyYearly);
            this.selectedMonthForYear = months[date.getMonth()];
            this.getAndDisplaySelectedDatesByMonth(this.selectedMonthForYear);
            this.displayAllMonthsWithSelectedDates();
            //alert(this.regimen.monthlyYearly);
            //March ^ 4, 4, 25 | April ^ 4, 4, 25, 10
            //var arrSelectedMonths;
            //var arrSelectedDates;
            //var arrSelectedDates1;
            //let strSelectedMonths;
            //let strSelectedDates;
            //if (this.regimen.monthlyYearly != undefined)
            //{
            //    arrSelectedMonths = this.regimen.monthlyYearly.split('|');
            //    arrSelectedMonths.forEach((item, index) => {
            //        strSelectedMonths = item;
            //        //alert(strSelectedMonths);
            //        arrSelectedDates = strSelectedMonths.split('^');
            //        arrSelectedDates.forEach((item, index) => {
            //            if (arrSelectedDates[0] == months[date.getMonth()]) {
            //                //console.log(item); // 9, 2, 5
            //                //console.log(index); // 0, 1, 2
            //                if (index != 0) {
            //                    strSelectedDates = item;
            //                    arrSelectedDates1 = strSelectedDates.split(',');
            //                    arrSelectedDates1.forEach((item, index) => {
            //                        $('#day' + item + 'Cell').addClass("selected"); //displaying selected dates on the current month 
            //                    });


            //                }

            //            }

            //        });

            //    });

            //}
        }
        else if (this.selectedScheduleType == 'Interval') {

            $("#lblInterval").addClass("btn btn-default buying-selling active");
        }
        else if (this.selectedScheduleType == 'Event') {

            $("#lblEvent").addClass("btn btn-default buying-selling active");
        }

        if (this.selectedScheduleType == 'Monthly' || this.selectedScheduleType == 'Yearly') {
            $("#divCalendar").css("display", "block");
            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            //var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];;
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var date = new Date();

            //$('#spnMonth').text(months[date.getMonth()]);

        }
        else {
            $("#divCalendar").css("display", "none");

        }

        if (this.selectedScheduleType == 'Monthly') {
            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];;
            //var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var date = new Date();

            //$('#spnMonth').text(months[date.getMonth()]);

        }

        if (this.regimen.morningWindow != "undefined" && this.regimen.morningWindow != "") {
            //alert(this.regimen.morningWindow);
            if (this.regimen.morningWindow != null) {
                if (this.regimen.morningWindow.indexOf(",") != -1) {

                    var arrAlreadySelectedMorning = this.regimen.morningWindow.split(',');

                    arrAlreadySelectedMorning.forEach((item, index) => {

                        //console.log(item); // 9, 2, 5
                        //console.log(index); // 0, 1, 2

                        if (this.selectedTimeForMorning == undefined) {
                            this.selectedTimeForMorning = "<div id=\"timeSlotPnl_" + index + "_MORNING\"class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_MORNING')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForMorning_PlainData = item;
                        }
                        else {
                            this.selectedTimeForMorning = this.selectedTimeForMorning + "<div id=\"timeSlotPnl_" + index + "_MORNING\"class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_MORNING')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForMorning_PlainData = this.selectedTimeForMorning_PlainData + "," + item;
                        }

                    });



                    //alert(this.selectedTimeForMorning);
                    $('#pnlSelectedTimeForMorning').html(this.selectedTimeForMorning);


                }
                else {
                    //only one morning time selected
                    if (this.selectedTimeForMorning == undefined) {
                        this.selectedTimeForMorning = "<div id=\"timeSlotPnl_" + 1 + "_MORNING\"class=\"schduleData\">" + this.regimen.morningWindow + "<button onclick=\"closeDiv1('btnClose_" + 1 + "\_" + this.regimen.morningWindow + "_MORNING')\" id=\"btnClose_" + 1 + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                        this.selectedTimeForMorning_PlainData = this.regimen.morningWindow;
                    }

                    $('#pnlSelectedTimeForMorning').html(this.selectedTimeForMorning);

                }
                //alert(this.selectedTimeForMorning_PlainData);
                localStorage.setItem("MORNING_DATA", this.selectedTimeForMorning_PlainData);
                //alert(localStorage.getItem("MORNING_DATA"));

            }


        }

        //Get afternoon window dosage window schedule from db and display here
        if (this.regimen.noonWindow != "undefined" && this.regimen.noonWindow != "") {
            if (this.regimen.noonWindow != null) {
                if (this.regimen.noonWindow.indexOf(",") != -1) {

                    var arrAlreadySelectedAfternoon = this.regimen.noonWindow.split(',');

                    arrAlreadySelectedAfternoon.forEach((item, index) => {

                        //console.log(item); // 9, 2, 5
                        //console.log(index); // 0, 1, 2

                        if (this.selectedTimeForAfternoon == undefined) {
                            this.selectedTimeForAfternoon = "<div id=\"timeSlotPnl_" + index + "_AFTERNOON\" class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_AFTERNOON')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForAfternoon_PlainData = item;
                        }
                        else {
                            this.selectedTimeForAfternoon = this.selectedTimeForAfternoon + "<div id=\"timeSlotPnl_" + index + "_AFTERNOON\" class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_AFTERNOON')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForAfternoon_PlainData = this.selectedTimeForAfternoon_PlainData + "," + item;
                        }

                    });



                    //alert(this.selectedTimeForMorning);
                    $('#pnlSelectedTimeForAfterNoon').html(this.selectedTimeForAfternoon);


                }
                else {
                    //only one afternoon time selected
                    if (this.selectedTimeForAfternoon == undefined) {
                        this.selectedTimeForAfternoon = "<div id=\"timeSlotPnl_" + 1 + "_AFTERNOON\" class=\"schduleData\">" + this.regimen.noonWindow + "<button onclick=\"closeDiv1('btnClose_" + 1 + "\_" + this.regimen.noonWindow + "_AFTERNOON')\" id=\"btnClose_" + 1 + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                        this.selectedTimeForAfternoon_PlainData = this.regimen.noonWindow;
                    }

                    $('#pnlSelectedTimeForAfterNoon').html(this.selectedTimeForAfternoon);

                }

                localStorage.setItem("AFTERNOON_DATA", this.selectedTimeForAfternoon_PlainData);
            }

        }


        //Get evening window dosage window schedule from db and display here
        if (this.regimen.eveningWindow != "undefined" && this.regimen.eveningWindow != "") {
            if (this.regimen.eveningWindow != null) {
                if (this.regimen.eveningWindow.indexOf(",") != -1) {

                    var arrAlreadySelectedEvening = this.regimen.eveningWindow.split(',');

                    arrAlreadySelectedEvening.forEach((item, index) => {

                        //console.log(item); // 9, 2, 5
                        //console.log(index); // 0, 1, 2

                        if (this.selectedTimeForEvening == undefined) {
                            this.selectedTimeForEvening = "<div id=\"timeSlotPnl_" + index + "_EVENING\" class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_EVENING')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForEvening_PlainData = item;
                        }
                        else {
                            this.selectedTimeForEvening = this.selectedTimeForEvening + "<div id=\"timeSlotPnl_" + index + "_EVENING\" class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_EVENING')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForEvening_PlainData = this.selectedTimeForEvening_PlainData + "," + item;
                        }

                    });



                    //alert(this.selectedTimeForMorning);


                    $('#pnlSelectedTimeForEvening').html(this.selectedTimeForEvening);
                }
                else {
                    //only one afternoon time selected
                    if (this.selectedTimeForEvening == undefined) {
                        this.selectedTimeForEvening = "<div id=\"timeSlotPnl_" + 1 + "_EVENING\" class=\"schduleData\">" + this.regimen.eveningWindow + "<button onclick=\"closeDiv1('btnClose_" + 1 + "\_" + this.regimen.eveningWindow + "_EVENING')\" id=\"btnClose_" + 1 + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                        this.selectedTimeForEvening_PlainData = this.regimen.eveningWindow;
                    }

                    $('#pnlSelectedTimeForEvening').html(this.selectedTimeForEvening);
                }

                localStorage.setItem("EVENING_DATA", this.selectedTimeForEvening_PlainData);

            }

        }


        //Get bedtime window dosage window schedule from db and display here
        if (this.regimen.nightWindow != "undefined" && this.regimen.nightWindow != "") {
            if (this.regimen.nightWindow != null) {

                if (this.regimen.nightWindow.indexOf(",") != -1) {

                    var arrAlreadySelectedBedTime = this.regimen.nightWindow.split(',');

                    arrAlreadySelectedBedTime.forEach((item, index) => {

                        //console.log(item); // 9, 2, 5
                        //console.log(index); // 0, 1, 2

                        if (this.selectedTimeForBedTime == undefined) {
                            this.selectedTimeForBedTime = "<div id=\"timeSlotPnl_" + index + "_BEDTIME\" class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_BEDTIME')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForBedTime_PlainData = item;
                        }
                        else {
                            this.selectedTimeForBedTime = this.selectedTimeForBedTime + "<div id=\"timeSlotPnl_" + index + "_BEDTIME\" class=\"schduleData\">" + item + "<button onclick=\"closeDiv1('btnClose_" + index + "\_" + item + "_BEDTIME')\" id=\"btnClose_" + index + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                            this.selectedTimeForBedTime_PlainData = this.selectedTimeForBedTime_PlainData + "," + item;
                        }

                    });



                    //alert(this.selectedTimeForMorning);


                    $('#pnlSelectedTimeForBedTime').html(this.selectedTimeForBedTime);
                }
                else {
                    //only one afternoon time selected

                    if (this.selectedTimeForBedTime == undefined) {
                        this.selectedTimeForBedTime = "<div id=\"timeSlotPnl_" + 1 + "_BEDTIME\" class=\"schduleData\">" + this.regimen.nightWindow + "<button onclick=\"closeDiv1('btnClose_" + 1 + "\_" + this.regimen.nightWindow + "_BEDTIME')\" id=\"btnClose_" + 1 + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                        this.selectedTimeForBedTime_PlainData = this.regimen.nightWindow;
                    }

                    $('#pnlSelectedTimeForBedTime').html(this.selectedTimeForBedTime);
                }

                localStorage.setItem("BEDTIME_DATA", this.selectedTimeForBedTime_PlainData);
            }

        }




        //let morningWindowDuration = this.convertMinutes(this.regimen.morningWindow);
        //let morningWindowDays = morningWindowDuration.days;
        //let morningWindowHours = morningWindowDuration.hours;
        //let morningWindowMinutes = morningWindowDuration.minutes;

        //let afterNoonWindowDuration = this.convertMinutes(this.regimen.noonWindow);
        //let afterNoonWindowDays = afterNoonWindowDuration.days;
        //let afterNoonWindowHours = afterNoonWindowDuration.hours;
        //let afterNoonWindowMinutes = afterNoonWindowDuration.minutes;

        //let eveningWindowDuration = this.convertMinutes(this.regimen.eveningWindow);
        //let eveningWindowDays = eveningWindowDuration.days;
        //let eveningWindowHours = eveningWindowDuration.hours;
        //let eveningWindowMinutes = eveningWindowDuration.minutes;


        //let nightWindowDuration = this.convertMinutes(this.regimen.nightWindow);
        //let nightWindowDays = nightWindowDuration.days;
        //let nightWindowHours = nightWindowDuration.hours;
        //let nightWindowMinutes = nightWindowDuration.minutes;

        this.form = this.fb.group({
            name: [this.regimen.name, Validators.required],
            medicationUnitsPerDose: [this.regimen.medicationPerDose, Validators.required],
            totalDoses: [this.regimen.totalDoses, Validators.required],
            extraDoses: [this.regimen.extraDoses, Validators.required],
            durationDays: [days],
            durationHours: [hours],
            durationMinutes: [minutes],
            adherenceDays: [thresholddays],
            adherenceHours: [thresholdhours],
            adherenceMinutes: [thresholdminutes],
            adherenceHours_Morning: [0],
            adherenceMinutes_Morning: [0],
            adherenceAMPM_Morning: ['AM'],
            adherenceHours_Afternoon: [0],
            adherenceMinutes_Afternoon: [0],
            adherenceAMPM_Afternoon: ['PM'],
            adherenceHours_Evening: [0],
            adherenceMinutes_Evening: [0],
            adherenceAMPM_Evening: ['PM'],
            adherenceHours_BedTime: [0],
            adherenceMinutes_BedTime: [0],
            adherenceAMPM_BedTime: ['PM'],
            weekly: [this.regimen.schedule_type],
            daily: [this.regimen.schedule_type],
            monthly: [this.regimen.schedule_type],
            yearly: [this.regimen.schedule_type],
            interval: [this.regimen.schedule_type],
            event: [this.regimen.schedule_type],
            scheduleTypeOptions1: [''],
            startDate: [''],
            monthList: ['']
            //,
            //dailyRadioButton: ['Daily'],
            //weeklyRadioButton: ['Weekly'],
            //monthlyRadioButton: ['Monthly'],
            //yearlyRadioButton: ['Yearly']
            //dosageQuantity: ['', Validators.required],
            //dosageAmount: ['', Validators.required],
            //unitOfMeasure: ['', Validators.required]
        });



        //Morning Window
        let morningWindow_FromTimeString = this.dosageWindowSettings[0].from;
        let morningWindow_ToTimeString = this.dosageWindowSettings[0].to;
        let morningFromHrs = morningWindow_FromTimeString.split('.')[0];
        this.morningFromMins = morningWindow_FromTimeString.split('.')[1].split(' ')[0];
        let morningToHrs = morningWindow_ToTimeString.split('.')[0];
        this.morningToMins = morningWindow_ToTimeString.split('.')[1].split(' ')[0];
        this.morningAMPM = morningWindow_ToTimeString.split('.')[1].split(' ')[1];
        // Hours
        for (let i = Number(morningFromHrs); i <= Number(morningToHrs); i++) {
            if (i < 10)
                this.morningHours.push('0' + String(i));
            else
                this.morningHours.push(i);
        }
        // Minutes
        for (let i = Number(this.morningFromMins); i <= Number(this.morningToMins); i++) {
            if (i < 10)
                this.morningMinutes.push('0' + String(i));
            else
                this.morningMinutes.push(i);
        }
        this.upperBoundaryForMorningHrs = morningToHrs;

        //Afternoon Window
        let afternoonWindow_FromTimeString = this.dosageWindowSettings[1].from;
        let afternoonWindow_ToTimeString = this.dosageWindowSettings[1].to;
        let afternoonFromHrs = afternoonWindow_FromTimeString.split('.')[0];
        this.afternoonFromMins = afternoonWindow_FromTimeString.split('.')[1].split(' ')[0];
        let afternoonToHrs = afternoonWindow_ToTimeString.split('.')[0];
        this.afternoonToMins = afternoonWindow_ToTimeString.split('.')[1].split(' ')[0];
        this.afternoonAMPM = afternoonWindow_ToTimeString.split('.')[1].split(' ')[1];
        //alert(afternoonFromHrs);
        //alert(afternoonFromMins);
        // Hours
        if (Number(afternoonFromHrs) > Number(afternoonToHrs)) { //12>4
            //get values say 12,1,2,3
            //alert('afternoon');
            this.afternoonHours.push(Number(afternoonFromHrs));
            for (let i = 1; i <= Number(afternoonToHrs); i++) {
                if (i < 10)
                    this.afternoonHours.push('0' + String(i));
                else
                    this.afternoonHours.push(i);
            }
        }
        else {
            for (let i = Number(afternoonFromHrs); i <= Number(afternoonToHrs); i++) {
                if (i < 10)
                    this.afternoonHours.push('0' + String(i));
                else
                    this.afternoonHours.push(i);
            }

        }
        // Minutes
        for (let i = Number(this.afternoonFromMins); i <= Number(this.afternoonToMins); i++) {
            if (i < 10)
                this.afternoonMinutes.push('0' + String(i));
            else
                this.afternoonMinutes.push(i);
        }

        //Evening Window
        let eveninigWindow_FromTimeString = this.dosageWindowSettings[2].from;
        let eveninigWindow_ToTimeString = this.dosageWindowSettings[2].to;
        let eveninigFromHrs = eveninigWindow_FromTimeString.split('.')[0];
        this.eveninigFromMins = eveninigWindow_FromTimeString.split('.')[1].split(' ')[0];
        let eveninigToHrs = eveninigWindow_ToTimeString.split('.')[0];
        this.eveninigToMins = eveninigWindow_ToTimeString.split('.')[1].split(' ')[0];
        this.eveningAMPM = eveninigWindow_ToTimeString.split('.')[1].split(' ')[1];
        // Hours
        for (let i = Number(eveninigFromHrs); i <= Number(eveninigToHrs); i++) {
            if (i < 10)
                this.eveningHours.push('0' + String(i));
            else
                this.eveningHours.push(i);
        }
        // Minutes
        for (let i = Number(this.eveninigFromMins); i <= Number(this.eveninigToMins); i++) {
            if (i < 10)
                this.eveningMinutes.push('0' + String(i));
            else
                this.eveningMinutes.push(i);
        }

        //BedTime Window
        let bedtimeWindow_FromTimeString = this.dosageWindowSettings[3].from;
        let bedtimeWindow_ToTimeString = this.dosageWindowSettings[3].to;
        let bedtimeFromHrs = bedtimeWindow_FromTimeString.split('.')[0];
        this.bedtimeFromMins = bedtimeWindow_FromTimeString.split('.')[1].split(' ')[0];
        let bedtimeToHrs = bedtimeWindow_ToTimeString.split('.')[0];
        this.bedtimeToMins = bedtimeWindow_ToTimeString.split('.')[1].split(' ')[0];
        this.bedTimeAMPM = bedtimeWindow_ToTimeString.split('.')[1].split(' ')[1];
        // Hours
        for (let i = Number(bedtimeFromHrs); i <= Number(bedtimeToHrs); i++) {
            if (i < 10)
                this.bedtimeHours.push('0' + String(i));
            else
                this.bedtimeHours.push(i);
        }
        // Minutes
        for (let i = Number(this.bedtimeFromMins); i <= Number(this.bedtimeToMins); i++) {
            if (i < 10)
                this.bedtimeMinutes.push('0' + String(i));
            else
                this.bedtimeMinutes.push(i);
        }

        this.defaultMorningFromTime = morningFromHrs;
        // alert(this.defaultMorningFromTime);
        this.defaultAfternoonFromTime = afternoonFromHrs;
        this.defaultEveningFromTime = eveninigFromHrs;
        this.defaultBedTimeFromTime = bedtimeFromHrs;
        this.defaultMorningFromMins = String(this.morningFromMins);
        this.defaultAfternoonFromMins = String(this.afternoonFromMins);
        this.defaultEveningFromMins = String(this.eveninigFromMins);
        this.defaultBedTimeFromMins = String(this.bedtimeFromMins);

        //var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];;
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var date = new Date();

        this.currentMonth = months[date.getMonth()];
        //alert(this.currentMonth);
        this.monthDropdown = [

            { id: 'Jan', monthName: 'January' },
            { id: 'Feb', monthName: 'February' },
            { id: 'Mar', monthName: 'March' },
            { id: 'Apr', monthName: 'April' },
            { id: 'May', monthName: 'May' },
            { id: 'Jun', monthName: 'June' },
            { id: 'July', monthName: 'July' },
            { id: 'Aug', monthName: 'August' },
            { id: 'Sep', monthName: 'September' },
            { id: 'Oct', monthName: 'October' },
            { id: 'Nov', monthName: 'November' },
            { id: 'Dec', monthName: 'December' }

        ]
    }

    public onSubmit() {
        //alert($("input[name='yearly']:checked").val());
        //alert(this.selectedScheduleType);
        this.errorMessage = '';
        this.showErrors = false;
        this.durationError = false;
        this.adherenceError = false;
        let durationDays = ((Number(this.form.value.durationDays * 24)) * 60);
        let durationHours = (Number(this.form.value.durationHours * 60));
        let durationMinutes = Number(this.form.value.durationMinutes);
        let durationBetweenDoses = durationDays + durationHours + durationMinutes;

        let adherenceDays = ((Number(this.form.value.adherenceDays * 24)) * 60);
        let adherenceHours = (Number(this.form.value.adherenceHours * 60));
        let adherenceMinutes = Number(this.form.value.adherenceMinutes);
        let adherenceThreshold = adherenceDays + adherenceHours + adherenceMinutes;

        let scheduleType = this.selectedScheduleType;
        let morningDosingWindowSchedule = '';
        let afternoonDosingWindowSchedule = '';
        let eveningDosingWindowSchedule = '';
        let bedtimeDosingWindowSchedule = '';
        let userId = localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID');
        let companyId = localStorage.getItem('GLOBAL_COMPANY_ID');
        let sunCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-1")).checked;
        let monCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-2")).checked;
        let tueCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-3")).checked;
        let webCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-4")).checked;
        let thuCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-5")).checked;
        let friCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-6")).checked;
        let satCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-7")).checked;
        if (scheduleType == 'Weekly') {
            if (!sunCheckBox && !monCheckBox && !tueCheckBox && !webCheckBox && !thuCheckBox && !friCheckBox && !satCheckBox) {
                this.showErrors = true;
                this.errorMessage = "Please select atleast one Day of week for weekly schedule type";
                $(window).scrollTop(5);
                return;

            }
        }

        if (this.form.invalid || durationBetweenDoses < 1 || adherenceThreshold < 1) {
            this.showErrors = true;
            this.durationError = (durationBetweenDoses < 1);
            this.adherenceError = (adherenceThreshold < 1);
        }
        else if (($("input[name='daily']:checked").val() == undefined && $("input[name='weekly']:checked").val() == undefined
            && $("input[name='monthly']:checked").val() == undefined && $("input[name='yearly']:checked").val() == undefined
            && $("input[name='interval']:checked").val() == undefined) &&( this.selectedScheduleType == undefined || this.selectedScheduleType == 'NaN' || this.selectedScheduleType=='')) {

            this.showErrors = true;
            this.errorMessage = "Please select atleast one schedule type";
            $(window).scrollTop(5);
        }
        else if (this.selectedScheduleType == '') {

            this.showErrors = true;
            this.errorMessage = "Please select atleast one schedule type";
            $(window).scrollTop(5);
           
        }
        else if (this.selectedScheduleType != 'Interval' && (this.selectedTimeForMorning_PlainData == undefined || this.selectedTimeForMorning_PlainData == '') && (this.selectedTimeForAfternoon_PlainData == undefined || this.selectedTimeForAfternoon_PlainData == '') && (this.selectedTimeForEvening_PlainData == undefined || this.selectedTimeForEvening_PlainData == '') && (this.selectedTimeForBedTime_PlainData == undefined || this.selectedTimeForBedTime_PlainData == ''))
        {
            this.showErrors = true;
            this.errorMessage = "Please select atleast one Dosage Window";
            $(window).scrollTop(5);
        }
        else if (this.selectedScheduleType != 'Interval' && ($('#pnlSelectedTimeForMorning').html() == '' || $('#pnlSelectedTimeForMorning').html() == 'SelectedTime') && ($('#pnlSelectedTimeForAfterNoon').html() == '' || $('#pnlSelectedTimeForAfterNoon').html() == 'SelectedTime') && ($('#pnlSelectedTimeForEvening').html() == '' || $('#pnlSelectedTimeForEvening').html() == 'SelectedTime') && ($('#pnlSelectedTimeForBedTime').html() == '' || $('#pnlSelectedTimeForBedTime').html() == 'SelectedTime')) {
            this.showErrors = true;
            this.errorMessage = "Please select atleast one Dosage Window";
            $(window).scrollTop(5);
        }
        else {
            
            this.isLoading = true;
            this.showErrors = false;
            
            let request = new RegimenRequest(
                this.form.value.name,
                this.form.value.medicationUnitsPerDose,
                this.form.value.totalDoses,
                this.form.value.extraDoses,
                durationBetweenDoses,
                adherenceThreshold,
                scheduleType,
                morningDosingWindowSchedule,
                afternoonDosingWindowSchedule,
                eveningDosingWindowSchedule,
                bedtimeDosingWindowSchedule,
                Number(userId)
            );
            //alert(this.selectedTimeForMorning_PlainData);
            if (scheduleType == "Monthly" || scheduleType == "Yearly")
                this.selectedDate = this.convertDate(this.form.value.startDate.date);

            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING") == 'Y') {
                this.selectedTimeForMorning = "";
                this.selectedTimeForMorning_PlainData = "";
                //alert('IS_CLOSED_EVENT_TRIGGERED_MORNING' + localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING"));
                this.selectedTimeForMorning = $('#pnlSelectedTimeForMorning').html();
                if (localStorage.getItem("MORNING_DATA") != undefined)
                    this.selectedTimeForMorning_PlainData = localStorage.getItem("MORNING_DATA");
                // alert(this.selectedTimeForMorning_PlainData);
                // alert(localStorage.getItem("MORNING_DATA"));
            }
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_AFTERNOON") == 'Y') {
                this.selectedTimeForAfternoon = "";
                this.selectedTimeForAfternoon_PlainData = "";
                this.selectedTimeForAfternoon = $('#pnlSelectedTimeForAfterNoon').html();
                if (localStorage.getItem("AFTERNOON_DATA") != undefined)
                    this.selectedTimeForAfternoon_PlainData = localStorage.getItem("AFTERNOON_DATA");
            }
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_EVENING") == 'Y') {
                this.selectedTimeForEvening = "";
                this.selectedTimeForEvening_PlainData = "";
                this.selectedTimeForEvening = $('#pnlSelectedTimeForEvening').html();
                if (localStorage.getItem("EVENING_DATA") != undefined)
                    this.selectedTimeForEvening_PlainData = localStorage.getItem("EVENING_DATA");
            }
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_BEDTIME") == 'Y') {
                this.selectedTimeForBedTime = "";
                this.selectedTimeForBedTime_PlainData = "";
                this.selectedTimeForBedTime = $('#pnlSelectedTimeForBedTime').html();
                if (localStorage.getItem("BEDTIME_DATA") != undefined)
                    this.selectedTimeForBedTime_PlainData = localStorage.getItem("BEDTIME_DATA");
            }

            if (scheduleType == "Monthly") {
               
                if (this.selectedDatesForMonthly != undefined)
                    this.monthlyYearlySelectedDate = this.selectedDatesForMonthly;
                else
                    this.monthlyYearlySelectedDate = this.regimen.monthlyYearly;
            }
            if (scheduleType == "Yearly") {
                let selectedDatesForYearFinal = '';
                
                if (this.selectedDatesForYear != undefined) {
                    //var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    months.forEach((item, index) => {
                        if (this.selectedDatesForYear.indexOf(item) == -1) {
                            if (localStorage.getItem(item) != undefined) {
                                this.selectedDatesForYear = this.selectedDatesForYear + "|" + item + "^" + localStorage.getItem(item);

                            }
                        }
                        
                        if (String(localStorage.getItem(item)) != 'null') {
                            
                            if (this.isFirstDateSelectedAndThenDeselectedDate == true && this.selectedDatesForYear.indexOf(item)!=-1) {
                                
                                if (selectedDatesForYearFinal != '') {


                                    selectedDatesForYearFinal = selectedDatesForYearFinal + '|' + item + '^' + localStorage.getItem(item);

                                }
                                else {
                                    selectedDatesForYearFinal = item + '^' + localStorage.getItem(item);
                                }


                            }
                        }
                    });
                    if (selectedDatesForYearFinal != '')
                        this.selectedDatesForYear = selectedDatesForYearFinal;

                    this.monthlyYearlySelectedDate = this.selectedDatesForYear;
                }
                else if (this.selectedDatesForYear == undefined) {
                    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    months.forEach((item, index) => {
                        if (localStorage.getItem(item) != undefined) {
                            if (this.selectedDatesForYear!=undefined)
                                this.selectedDatesForYear = this.selectedDatesForYear + "|" + item + "^" + localStorage.getItem(item);
                            else
                                this.selectedDatesForYear = item + "^" + localStorage.getItem(item);
                        }

                    });
                    this.monthlyYearlySelectedDate = this.selectedDatesForYear;
                    //alert('this.selectedDatesForYear' + this.selectedDatesForYear);
                    //alert('this.monthlyYearlySelectedDate' + this.monthlyYearlySelectedDate);
                }
                else
                {

                    this.monthlyYearlySelectedDate = this.regimen.monthlyYearly;
                }

                //alert(this.monthlyYearlySelectedDate);
            }

            if (this.monthlyYearlySelectedDate == undefined) {

                this.monthlyYearlySelectedDate = "";
            }
            if (this.selectedDayOfWeek == undefined) {

                this.selectedDayOfWeek = "";

            }
            //alert(this.monthlyYearlySelectedDate);
            //Number of days logic starts here
            let durationBetweenDosesFinalVal = (durationMinutes == 59) ? durationBetweenDoses + 1 : durationBetweenDoses
            let morningWindowCount = (this.selectedTimeForMorning_PlainData != undefined) ? this.selectedTimeForMorning_PlainData.split(',').length * Number(this.form.value.medicationUnitsPerDose) : 0;
            let afternoonWindowCount = (this.selectedTimeForAfternoon_PlainData != undefined) ? this.selectedTimeForAfternoon_PlainData.split(',').length * Number(this.form.value.medicationUnitsPerDose) : 0;
            let eveningWindowCount = (this.selectedTimeForEvening_PlainData != undefined) ? this.selectedTimeForEvening_PlainData.split(',').length * Number(this.form.value.medicationUnitsPerDose) : 0;
            let nightWindowCount = (this.selectedTimeForBedTime_PlainData != undefined) ? this.selectedTimeForBedTime_PlainData.split(',').length * Number(this.form.value.medicationUnitsPerDose) : 0;
            let totalDosesAndPills = (Number(this.form.value.medicationUnitsPerDose)) * (Number(this.form.value.totalDoses) + Number(this.form.value.extraDoses))
            if (scheduleType == 'Daily') {
               
                this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, 1, totalDosesAndPills, morningWindowCount, afternoonWindowCount, eveningWindowCount, nightWindowCount, scheduleType);
            }
            else if (scheduleType == 'Weekly') {
                //var arrSelectedDayOfWeek = this.selectedDayOfWeek.split(',');
                //this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, arrSelectedDayOfWeek.length, Number(this.form.value.totalDoses) + Number(this.form.value.extraDoses));
                
                this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, this.selectedDayOfWeek.split(',').length, totalDosesAndPills, morningWindowCount, afternoonWindowCount, eveningWindowCount, nightWindowCount, scheduleType);
            }
            else if (scheduleType == 'Monthly') {

                //this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, Number(this.selectedDatesForMonthly.split(',').length), Number(this.form.value.totalDoses) + Number(this.form.value.extraDoses));
                
                this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, Number(String(this.monthlyYearlySelectedDate).split(',').length), totalDosesAndPills, morningWindowCount, afternoonWindowCount, eveningWindowCount, nightWindowCount, scheduleType);
            }
            else if (scheduleType == 'Yearly') {

                //this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, Number(this.selectedDatesForMonthly.split(',').length), Number(this.form.value.totalDoses) + Number(this.form.value.extraDoses));
                //alert(this.selectedDatesForYear);
                //alert(Number(this.selectedDatesForYear.split(',').length));
                //alert(this.monthlyYearlySelectedDate);
                //alert(Number(this.monthlyYearlySelectedDate.split(',').length));
                this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, Number(this.selectedDatesForYear.split(',').length), totalDosesAndPills, morningWindowCount, afternoonWindowCount, eveningWindowCount, nightWindowCount, scheduleType, this.selectedDatesForYear);
            }
            //else if (scheduleType == 'Weekly') {
            //    var arrSelectedDayOfWeek = this.selectedDayOfWeek.split(',');
            //    this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, arrSelectedDayOfWeek.length, Number(this.form.value.totalDoses) + Number(this.form.value.extraDoses));
            //}
            //else if (scheduleType == 'Monthly') {
                
            //    this.numberOfDays = this.regimenService.convertToDays(durationBetweenDosesFinalVal, Number(this.monthlyYearlySelectedDate.split(',').length), Number(this.form.value.totalDoses) + Number(this.form.value.extraDoses));
            //}
            //end Number of days logic starts here
            this.prepareJsonStringForRegimen(this.form.value.name, this.form.value.medicationUnitsPerDose, this.form.value.totalDoses, this.form.value.extraDoses, durationBetweenDoses, adherenceThreshold, scheduleType, this.selectedTimeForMorning_PlainData, this.selectedTimeForAfternoon_PlainData, this.selectedTimeForEvening_PlainData, this.selectedTimeForBedTime_PlainData, Number(userId), this.monthlyYearlySelectedDate, this.selectedDayOfWeek, this.numberOfDays);
            this.regimenService.updateRegimen(Number(this.selectedRegimenId), this.regimenJsonString).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.form.markAsPristine();
                    this.successMessage = 'Regimen has been successfully updated';
                    $(window).scrollTop(5);
                    this.goBack();
                },
                (err) => {
		    this.isLoading = false;
                    this.errorMessage = err;
                });
        }
    }

    public clearLocalStorage() {

        localStorage.removeItem("IS_CLOSED_EVENT_TRIGGERED_MORNING");
        localStorage.removeItem("MORNING_DATA");
        localStorage.removeItem("IS_CLOSED_EVENT_TRIGGERED_AFTERNOON");
        localStorage.removeItem("AFTERNOON_DATA");
        localStorage.removeItem("IS_CLOSED_EVENT_TRIGGERED_EVENING");
        localStorage.removeItem("EVENING_DATA");
        localStorage.removeItem("IS_CLOSED_EVENT_TRIGGERED_BEDTIME");
        localStorage.removeItem("BEDTIME_DATA");
        localStorage.removeItem("Jan");
        localStorage.removeItem("Feb");
        localStorage.removeItem("Mar");
        localStorage.removeItem("Apr");
        localStorage.removeItem("May");
        localStorage.removeItem("Jun");
        localStorage.removeItem("July");
        localStorage.removeItem("Aug");
        localStorage.removeItem("Sep");
        localStorage.removeItem("Oct");
        localStorage.removeItem("Nov");
        localStorage.removeItem("Dec");
    }

    public selectMorningTime(): void {
        //let selectedTimeCounter;
        //this.selectedTimeCounter = 0;
        var self = this;
        let closedBtn = "";
        let isValid = true;
        let durationDays = ((Number(this.form.value.durationDays * 24)) * 60);
        let durationHours = (Number(this.form.value.durationHours * 60));
        let durationMinutes = Number(this.form.value.durationMinutes);
        let durationBetweenDoses = durationDays + durationHours + durationMinutes;

        let morningHours = (Number(this.form.value.adherenceHours_Morning * 60));
        let morningMinutes = Number(this.form.value.adherenceMinutes_Morning);
        let totalMorningDuration = morningHours + morningMinutes;
        //alert(this.selectedTimeForMorning);
        //alert(localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING"));
        if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING") == 'Y') {

            this.selectedTimeForMorning = $('#pnlSelectedTimeForMorning').html();
            if (localStorage.getItem("MORNING_DATA") != undefined)
                this.selectedTimeForMorning_PlainData = localStorage.getItem("MORNING_DATA");

            //alert(this.selectedTimeForMorning_PlainData.length);

        }
        if (this.selectedTimeForMorning != undefined && this.selectedTimeForMorning.length != 0 && this.selectedTimeForMorning_PlainData.length != 0) {

            //alert('inside');
            let tempAlreadySelectedMorningMinutes;
            if (this.selectedTimeForMorning_PlainData.indexOf(",") == -1) {
                this.alreadySelectedMorningHours = Number(this.selectedTimeForMorning_PlainData.split(':')[0]);
                tempAlreadySelectedMorningMinutes = this.selectedTimeForMorning_PlainData.split(':')[1];
            }
            else {
                let numOfCommas = (this.selectedTimeForMorning_PlainData.match(/,/g) || []).length;
                let selectedTimeForMorning_PlainData_Temp = this.selectedTimeForMorning_PlainData.split(',')[numOfCommas];
                this.alreadySelectedMorningHours = Number(selectedTimeForMorning_PlainData_Temp.split(':')[0]);
                tempAlreadySelectedMorningMinutes = selectedTimeForMorning_PlainData_Temp.split(':')[1];
            }
            this.alreadySelectedMorningMinutes = Number(tempAlreadySelectedMorningMinutes.split(' ')[0]);
            this.alreadySelectedMorningHours = (Number(Number(this.alreadySelectedMorningHours) * 60));
            let alreadySelectedMorningDuration = this.alreadySelectedMorningHours + this.alreadySelectedMorningMinutes;
            //alert(totalMorningDuration);
            //alert(alreadySelectedMorningDuration);
            //alert(this.alreadySelectedMorningHours);
            let diffBetweenTimeSlots = Number(totalMorningDuration) - Number(alreadySelectedMorningDuration);

            // alert(this.alreadySelectedMorningHours);
            //alert(this.alreadySelectedMorningMinutes);
            //alert("durationHours" + durationHours);
            //alert("diffBetweenTimeSlots" + diffBetweenTimeSlots);
            if (durationBetweenDoses > 0 && durationBetweenDoses > diffBetweenTimeSlots) {
                this.showErrors = true;
                this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                $(window).scrollTop(5);
                isValid = false;

            }

        }
        let fromMorning = this.form.value.adherenceHours_Morning + ':' + this.form.value.adherenceMinutes_Morning + ':' + this.form.value.adherenceAMPM_Morning;
        //let fromMorning = this.form.value.adherenceHours_Morning + ':' + this.form.value.adherenceMinutes_Morning;
        if (isValid) {

            //alert($('#pnlSelectedTimeForMorning').html());


            //alert('selectedTimeCounter' + this.selectedTimeCounter);
            if (this.selectedTimeForMorning == undefined) {
                this.selectedTimeCounter = 1;
                this.selectedTimeForMorning = "<div id=\"timeSlotPnl_" + this.selectedTimeCounter + "_MORNING\"class=\"schduleData\">" + fromMorning + "<button onclick=\"closeDiv1('btnClose_" + this.selectedTimeCounter + "\_" + fromMorning + "_MORNING')\" id=\"btnClose_" + this.selectedTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                this.selectedTimeForMorning_PlainData = fromMorning;

            }
            else {

                this.selectedTimeCounter = this.selectedTimeCounter + 1;
                //alert(this.selectedTimeCounter);
                this.selectedTimeForMorning = this.selectedTimeForMorning + "<div id=\"timeSlotPnl_" + this.selectedTimeCounter + "_MORNING\" class=\"schduleData\">" + fromMorning + "<button onclick=\"closeDiv1('btnClose_" + this.selectedTimeCounter + "\_" + fromMorning + "_MORNING')\" id=\"btnClose_" + this.selectedTimeCounter + "\" class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                if (this.selectedTimeForMorning_PlainData.length == 0) {
                    this.selectedTimeForMorning_PlainData = fromMorning;
                }
                else {
                    this.selectedTimeForMorning_PlainData = this.selectedTimeForMorning_PlainData + "," + fromMorning;
                }


            }
            localStorage.setItem("MORNING_DATA", this.selectedTimeForMorning_PlainData);
            //alert(this.selectedTimeForMorning);
            $('#pnlSelectedTimeForMorning').html(this.selectedTimeForMorning);

        }

        //var attId = $(this).attr('id');
        //$(attId).click(function (e) {

        //    alert(attId);
        //    var counterValue = attId.split("_")[1];
        //    alert('inside');
        //    //alert('#timeSlotPnl_'+Number(self.selectedTimeCounter));
        //    //alert($('#pnlSelectedTimeForMorning').html());
        //    $('#timeSlotPnl_' + counterValue).remove();
        //    //closedBtn = '#btnClose_' + this.selectedTimeCounter;

        //});


    }

    public selectAfterNoonTime(): void {
        //let selectedAfterNoonTimeCounter = 0; 
        let isValid = true;
        let durationDays = ((Number(this.form.value.durationDays * 24)) * 60);
        let durationHours = (Number(this.form.value.durationHours * 60));
        let durationMinutes = Number(this.form.value.durationMinutes);
        let durationBetweenDoses = durationDays + durationHours + durationMinutes;

        let afternoonHours = (Number(this.form.value.adherenceHours_Afternoon * 60));
        let afternoonMinutes = Number(this.form.value.adherenceMinutes_Afternoon);
        let totalAfternoonDuration = afternoonHours + afternoonMinutes;

        if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_AFTERNOON") == 'Y') {

            this.selectedTimeForAfternoon = $('#pnlSelectedTimeForAfterNoon').html();
            if (localStorage.getItem("AFTERNOON_DATA") != undefined)
                this.selectedTimeForAfternoon_PlainData = localStorage.getItem("AFTERNOON_DATA");

            //alert(this.selectedTimeForMorning_PlainData.length);

        }
        //alert(this.selectedTimeForMorning);
        if (this.selectedTimeForAfternoon != undefined && this.selectedTimeForAfternoon.length != 0 && this.selectedTimeForAfternoon_PlainData.length != 0) {
            //alert(this.selectedTimeForMorning);
            //alert('inside');
            let tempAlreadySelectedAfternoonMinutes = '';
            if (this.selectedTimeForAfternoon_PlainData.indexOf(",") == -1) {

                this.alreadySelectedAfternoonHours = Number(this.selectedTimeForAfternoon_PlainData.split(':')[0]);
                tempAlreadySelectedAfternoonMinutes = this.selectedTimeForAfternoon_PlainData.split(':')[1];
            }
            else {
                let numOfCommas = (this.selectedTimeForAfternoon_PlainData.match(/,/g) || []).length;
                let selectedTimeForAfternoon_PlainData_Temp = this.selectedTimeForAfternoon_PlainData.split(',')[numOfCommas];
                this.alreadySelectedAfternoonHours = Number(selectedTimeForAfternoon_PlainData_Temp.split(':')[0]);
                tempAlreadySelectedAfternoonMinutes = selectedTimeForAfternoon_PlainData_Temp.split(':')[1];
            }
            this.alreadySelectedAfternoonMinutes = Number(tempAlreadySelectedAfternoonMinutes.split(' ')[0]);
            this.alreadySelectedAfternoonHours = (Number(Number(this.alreadySelectedAfternoonHours) * 60));
            let alreadySelectedAfternoonDuration = this.alreadySelectedAfternoonHours + this.alreadySelectedAfternoonMinutes;
            let diffBetweenTimeSlots = 0;
            if (Number(this.alreadySelectedAfternoonHours) == 720)
                diffBetweenTimeSlots = Number(totalAfternoonDuration) + 720 - Number(alreadySelectedAfternoonDuration); //ex:comparing time difference between 12 PM and then 2PM
            else
                diffBetweenTimeSlots = Number(totalAfternoonDuration) - Number(alreadySelectedAfternoonDuration); //Ex: comparing time difference between 1 PM, 3 PM

            if (Number(totalAfternoonDuration) == Number(alreadySelectedAfternoonDuration)) //Ex: comparing time diff between 12PM and 12 PM
                diffBetweenTimeSlots = 0;

            // alert(this.alreadySelectedMorningHours);
            // alert(this.alreadySelectedMorningMinutes);
            //alert("durationHours" + durationHours);
            //alert('Number(totalAfternoonDuration)' + Number(totalAfternoonDuration));
            //alert('Number(alreadySelectedAfternoonDuration)' + Number(alreadySelectedAfternoonDuration));
            //alert("diffBetweenTimeSlots" + diffBetweenTimeSlots);
            if (durationBetweenDoses > 0 && durationBetweenDoses > diffBetweenTimeSlots) {
                this.showErrors = true;
                this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                $(window).scrollTop(5);
                isValid = false;

            }

        }
        else {
            //alert('esle part');
            let totalMorningDuration = 0;
            //let totalAfterNoonDuration = 0;
            //alert(this.selectedTimeForMorning_PlainData);
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING") == 'Y') {

                this.selectedTimeForMorning = $('#pnlSelectedTimeForMorning').html();
                if (localStorage.getItem("MORNING_DATA") != undefined)
                    this.selectedTimeForMorning_PlainData = localStorage.getItem("MORNING_DATA");

                //alert(this.selectedTimeForMorning_PlainData.length);

            }
            if (this.selectedTimeForMorning_PlainData != undefined && this.selectedTimeForMorning_PlainData != '') {
                //let arrAlreadySelectedMorning: string[] = Array();
                var arrAlreadySelectedMorning = this.selectedTimeForMorning_PlainData.split(',');
                //alert(arrAlreadySelectedMorning.length);
                let lastSelectedMorningTime = arrAlreadySelectedMorning[arrAlreadySelectedMorning.length - 1];
                //alert(lastSelectedMorningTime);
                this.alreadySelectedMorningHours = Number(lastSelectedMorningTime.split(':')[0]);
                let tempAlreadySelectedMorningMinutes = lastSelectedMorningTime.split(':')[1];
                this.alreadySelectedMorningMinutes = Number(tempAlreadySelectedMorningMinutes.split(' ')[0]);
                this.alreadySelectedMorningHours = (Number(Number(this.alreadySelectedMorningHours) * 60));
                totalMorningDuration = this.alreadySelectedMorningHours + this.alreadySelectedMorningMinutes;

                let sumDurHrsAndTotalMorningHrs = durationBetweenDoses + Number(totalMorningDuration);
                //alert(sumDurHrsAndTotalMorningHrs);
                //alert(totalAfternoonDuration);
                if (Number(this.form.value.adherenceHours_Afternoon) != 12)
                    totalAfternoonDuration = 720 + Number(totalAfternoonDuration); // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                else if (Number(this.form.value.adherenceHours_Afternoon) == 12)
                    totalAfternoonDuration = Number(totalAfternoonDuration);
                if (sumDurHrsAndTotalMorningHrs > 0 && totalAfternoonDuration > 0
                    && Number(sumDurHrsAndTotalMorningHrs) > Number(totalAfternoonDuration)) {
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);
                    isValid = false;

                }




            }


        }

        let fromAfternoon = this.form.value.adherenceHours_Afternoon + ':' + this.form.value.adherenceMinutes_Afternoon + ':' + this.form.value.adherenceAMPM_Afternoon;
        //let fromAfternoon = this.form.value.adherenceHours_Afternoon + ':' + this.form.value.adherenceMinutes_Afternoon;
        if (isValid) {

            if (this.selectedTimeForAfternoon == undefined) {
                this.selectedAfterNoonTimeCounter = 1;
                this.selectedTimeForAfternoon = "<div id=\"timeSlotPnl_" + this.selectedAfterNoonTimeCounter + "_AFTERNOON\" class=\"schduleData\">" + fromAfternoon + "<button onclick=\"closeDiv1('btnClose_" + this.selectedAfterNoonTimeCounter + "\_" + fromAfternoon + "_AFTERNOON')\" id=\"btnClose_" + this.selectedAfterNoonTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                this.selectedTimeForAfternoon_PlainData = fromAfternoon;
            }
            else {
                this.selectedAfterNoonTimeCounter = this.selectedAfterNoonTimeCounter + 1;
                this.selectedTimeForAfternoon = this.selectedTimeForAfternoon + "<div id=\"timeSlotPnl_" + this.selectedAfterNoonTimeCounter + "_AFTERNOON\" class=\"schduleData\">" + fromAfternoon + "<button  onclick=\"closeDiv1('btnClose_" + this.selectedAfterNoonTimeCounter + "\_" + fromAfternoon + "_AFTERNOON')\" id=\"btnClose_" + this.selectedAfterNoonTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                if (this.selectedTimeForAfternoon_PlainData.length == 0) {

                    this.selectedTimeForAfternoon_PlainData = fromAfternoon;
                }
                else {
                    this.selectedTimeForAfternoon_PlainData = this.selectedTimeForAfternoon_PlainData + "," + fromAfternoon;
                }
            }

            localStorage.setItem("AFTERNOON_DATA", this.selectedTimeForAfternoon_PlainData);
            $('#pnlSelectedTimeForAfterNoon').html(this.selectedTimeForAfternoon);

        }


        //$('#btnClose_' + selectedAfterNoonTimeCounter).click(function (e) {
        //    //alert(selectedTimeCounter);
        //    //alert($('#pnlSelectedTimeForMorning').html());
        //    $("#timeSlotPnl_" + selectedAfterNoonTimeCounter).remove();

        //    if ($('#pnlSelectedTimeForAfterNoon').html() != undefined) {
        //        //alert($('#pnlSelectedTimeForMorning').html().indexOf("timeSlotPnl_" + selectedTimeCounter));
        //        if ($('#pnlSelectedTimeForAfterNoon').html().indexOf("timeSlotPnl_" + selectedAfterNoonTimeCounter) != -1) {
        //            //alert('hhh');
        //            this.selectedTimeForAfternoon = $('#pnlSelectedTimeForAfterNoon').html().replace("< div id=\"timeSlotPnl_" + selectedAfterNoonTimeCounter + "\" class=\"schduleData\">" + fromAfternoon + "<button id=\"btnClose_" + selectedAfterNoonTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>", "");
        //            this.selectedTimeForAfternoon_PlainData = this.selectedTimeForAfternoon_PlainData.replace(fromAfternoon);
        //            $('#pnlSelectedTimeForMorning').html(this.selectedTimeForAfternoon)
        //        }
        //    }

        //    selectedAfterNoonTimeCounter = selectedAfterNoonTimeCounter - 1;
        //});
    }

    public selectEveningTime(): void {
        //let selectedEveningTimeCounter = 0;
        let isValid = true;
        let durationDays = ((Number(this.form.value.durationDays * 24)) * 60);
        let durationHours = (Number(this.form.value.durationHours * 60));
        let durationMinutes = Number(this.form.value.durationMinutes);
        let durationBetweenDoses = durationDays + durationHours + durationMinutes;

        let eveningHours = (Number(this.form.value.adherenceHours_Evening * 60));
        let eveningMinutes = Number(this.form.value.adherenceMinutes_Evening);
        let totalEveningDuration = eveningHours + eveningMinutes;
        if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_EVENING") == 'Y') {

            this.selectedTimeForEvening = $('#pnlSelectedTimeForEvening').html();
            if (localStorage.getItem("EVENING_DATA") != undefined)
                this.selectedTimeForEvening_PlainData = localStorage.getItem("EVENING_DATA");

            //alert(this.selectedTimeForMorning_PlainData.length);

        }
        if (this.selectedTimeForEvening != undefined && this.selectedTimeForEvening.length != 0 && this.selectedTimeForEvening_PlainData.length != 0) {
            //alert(this.selectedTimeForMorning);
            //alert('inside');
            let tempAlreadySelectedEveningMinutes;
            if (this.selectedTimeForEvening_PlainData.indexOf(",") == -1) {
                this.alreadySelectedEveningHours = Number(this.selectedTimeForEvening_PlainData.split(':')[0]);
                tempAlreadySelectedEveningMinutes = this.selectedTimeForEvening_PlainData.split(':')[1];

            }
            else {
                let numOfCommas = (this.selectedTimeForEvening_PlainData.match(/,/g) || []).length;
                let selectedTimeForEvening_PlainData_Temp = this.selectedTimeForEvening_PlainData.split(',')[numOfCommas];
                this.alreadySelectedEveningHours = Number(selectedTimeForEvening_PlainData_Temp.split(':')[0]);
                tempAlreadySelectedEveningMinutes = selectedTimeForEvening_PlainData_Temp.split(':')[1];
            }
            this.alreadySelectedEveningMinutes = Number(tempAlreadySelectedEveningMinutes.split(' ')[0]);
            this.alreadySelectedEveningHours = (Number(Number(this.alreadySelectedEveningHours) * 60));
            let alreadySelectedEveningDuration = this.alreadySelectedEveningHours + this.alreadySelectedEveningMinutes;

            //alert('totalEveningDuration' + totalEveningDuration);
            //alert('alreadySelectedEveningDuration' + alreadySelectedEveningDuration);
            let diffBetweenTimeSlots = Number(totalEveningDuration) - Number(alreadySelectedEveningDuration);

            // alert(this.alreadySelectedMorningHours);
            // alert(this.alreadySelectedMorningMinutes);
            //alert("durationHours" + durationHours);
            //alert("diffBetweenTimeSlots" + diffBetweenTimeSlots);
            if (durationBetweenDoses > 0 && durationBetweenDoses > diffBetweenTimeSlots) {
                this.showErrors = true;
                this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                $(window).scrollTop(5);
                isValid = false;

            }

        }
        else //check for default value selection of evening time against the afternoon time
        {
            //alert(this.selectedTimeForAfternoon_PlainData);
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_AFTERNOON") == 'Y') {

                this.selectedTimeForAfternoon = $('#pnlSelectedTimeForAfterNoon').html();
                if (localStorage.getItem("AFTERNOON_DATA") != undefined)
                    this.selectedTimeForAfternoon_PlainData = localStorage.getItem("AFTERNOON_DATA");

                //alert(this.selectedTimeForMorning_PlainData.length);

            }
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING") == 'Y') {

                this.selectedTimeForMorning = $('#pnlSelectedTimeForMorning').html();
                if (localStorage.getItem("MORNING_DATA") != undefined)
                    this.selectedTimeForMorning_PlainData = localStorage.getItem("MORNING_DATA");

                //alert(this.selectedTimeForMorning_PlainData.length);

            }
            //alert(this.selectedTimeForAfternoon_PlainData);
            if (this.selectedTimeForAfternoon_PlainData != undefined && this.selectedTimeForAfternoon_PlainData != '') {
                //let arrAlreadySelectedMorning: string[] = Array();
                var arrAlreadySelectedAfternoon = this.selectedTimeForAfternoon_PlainData.split(',');
                //alert(arrAlreadySelectedMorning.length);
                let lastSelectedAfternoonTime = arrAlreadySelectedAfternoon[arrAlreadySelectedAfternoon.length - 1];
                //alert(lastSelectedMorningTime);
                this.alreadySelectedAfternoonHours = Number(lastSelectedAfternoonTime.split(':')[0]);
                let tempAlreadySelectedAfternoonMinutes = lastSelectedAfternoonTime.split(':')[1];
                this.alreadySelectedAfternoonMinutes = Number(tempAlreadySelectedAfternoonMinutes.split(' ')[0]);
                this.alreadySelectedAfternoonHours = (Number(Number(this.alreadySelectedAfternoonHours) * 60));
                let totalAfterNoonDuration = this.alreadySelectedAfternoonHours + this.alreadySelectedAfternoonMinutes;
                //alert(totalAfterNoonDuration);
                //lastSelectedMorningTime = parseInt(lastSelectedMorningTime);



                let diffBetweenWindows = Number(totalEveningDuration) - Number(totalAfterNoonDuration);
                let sumDurHrsAndTotalAfterNoonHrs = durationBetweenDoses + Number(totalAfterNoonDuration);
                totalEveningDuration = (this.alreadySelectedAfternoonHours == 720) ? totalEveningDuration + 720 : totalEveningDuration; // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                //if (durationHours > 0 && durationHours > 0 && durationHours > diffBetweenWindows) {
                //alert('this.alreadySelectedAfternoonHours' + this.alreadySelectedAfternoonHours);
                //alert('sumDurHrsAndTotalAfterNoonHrs' + sumDurHrsAndTotalAfterNoonHrs);
                //alert('totalEveningDuration' + totalEveningDuration);
                if ((this.selectedTimeForEvening_PlainData == undefined || this.selectedTimeForEvening_PlainData == '') &&
                    Number(sumDurHrsAndTotalAfterNoonHrs) > 0 && Number(totalEveningDuration) > 0 &&
                    Number(sumDurHrsAndTotalAfterNoonHrs) > Number(totalEveningDuration)) {
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);
                    isValid = false;
                }

            }
            else if (this.selectedTimeForMorning_PlainData != undefined && this.selectedTimeForMorning_PlainData != '') {
                //let arrAlreadySelectedMorning: string[] = Array();
                var arrAlreadySelectedMorning = this.selectedTimeForMorning_PlainData.split(',');
                //alert(arrAlreadySelectedMorning.length);
                let lastSelectedMorningTime = arrAlreadySelectedMorning[arrAlreadySelectedMorning.length - 1];
                //alert(lastSelectedMorningTime);
                this.alreadySelectedMorningHours = Number(lastSelectedMorningTime.split(':')[0]);
                let tempAlreadySelectedMorningMinutes = lastSelectedMorningTime.split(':')[1];
                this.alreadySelectedMorningMinutes = Number(tempAlreadySelectedMorningMinutes.split(' ')[0]);
                this.alreadySelectedMorningHours = (Number(Number(this.alreadySelectedMorningHours) * 60));
                let totalMorningDuration = this.alreadySelectedMorningHours + this.alreadySelectedMorningMinutes;

                let sumDurHrsAndTotalMorningHrs = durationBetweenDoses + Number(totalMorningDuration);
                //alert(sumDurHrsAndTotalMorningHrs);
                //alert(totalAfternoonDuration);
                if (Number(this.form.value.adherenceHours_Morning) != 12)
                    totalEveningDuration = 720 + Number(totalEveningDuration); // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                //else if (Number(this.form.value.adherenceHours_Afternoon) == 12)
                //    totalBedTimeDuration = Number(totalAfternoonDuration);
                if (sumDurHrsAndTotalMorningHrs > 0 && totalMorningDuration > 0
                    && Number(sumDurHrsAndTotalMorningHrs) > Number(totalEveningDuration)) {
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);
                    isValid = false;

                }




            }
        }
        let fromEveninig = this.form.value.adherenceHours_Evening + ':' + this.form.value.adherenceMinutes_Evening + ':' + this.form.value.adherenceAMPM_Evening;
        //let fromEveninig = this.form.value.adherenceHours_Evening + ':' + this.form.value.adherenceMinutes_Evening;
        if (isValid) {

            if (this.selectedTimeForEvening == undefined) {
                this.selectedEveningTimeCounter = 1;
                this.selectedTimeForEvening = "<div id=\"timeSlotPnl_" + this.selectedEveningTimeCounter + "_EVENING\" class=\"schduleData\">" + fromEveninig + "<button onclick=\"closeDiv1('btnClose_" + this.selectedEveningTimeCounter + "\_" + fromEveninig + "_EVENING')\" id=\"btnClose_" + this.selectedEveningTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                this.selectedTimeForEvening_PlainData = fromEveninig;
            }
            else {
                this.selectedEveningTimeCounter = this.selectedEveningTimeCounter + 1;
                this.selectedTimeForEvening = this.selectedTimeForEvening + "<div id=\"timeSlotPnl_" + this.selectedEveningTimeCounter + "_EVENING\" class=\"schduleData\">" + fromEveninig + "<button onclick=\"closeDiv1('btnClose_" + this.selectedEveningTimeCounter + "\_" + fromEveninig + "_EVENING')\" id=\"btnClose_" + this.selectedEveningTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                if (this.selectedTimeForEvening_PlainData.length == 0) {
                    this.selectedTimeForEvening_PlainData = fromEveninig;
                }
                else {
                    this.selectedTimeForEvening_PlainData = this.selectedTimeForEvening_PlainData + "," + fromEveninig;

                }
            }

            localStorage.setItem("EVENING_DATA", this.selectedTimeForEvening_PlainData);
            $('#pnlSelectedTimeForEvening').html(this.selectedTimeForEvening);



        }


    }

    public selectBedTime(): void {
        //let selectedBedTimeCounter = 0;
        let isValid = true;
        let durationDays = ((Number(this.form.value.durationDays * 24)) * 60);
        let durationHours = (Number(this.form.value.durationHours * 60));
        let durationMinutes = Number(this.form.value.durationMinutes);
        let durationBetweenDoses = durationDays + durationHours + durationMinutes;

        let bedTimeHours = (Number(this.form.value.adherenceHours_BedTime * 60));
        let bedTimeMinutes = Number(this.form.value.adherenceMinutes_BedTime);
        let totalBedTimeDuration = bedTimeHours + bedTimeMinutes;
        if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_BEDTIME") == 'Y') {

            this.selectedTimeForBedTime = $('#pnlSelectedTimeForBedTime').html();
            if (localStorage.getItem("BEDTIME_DATA") != undefined)
                this.selectedTimeForBedTime_PlainData = localStorage.getItem("BEDTIME_DATA");

            //alert(this.selectedTimeForMorning_PlainData.length);

        }
        //alert(this.selectedTimeForBedTime);
        if (this.selectedTimeForBedTime != undefined && this.selectedTimeForBedTime.length != 0 && this.selectedTimeForBedTime_PlainData.length != 0) {
            //alert(this.selectedTimeForMorning);
            //alert('inside');
            let tempAlreadySelectedBedTimeMinutes;
            if (this.selectedTimeForBedTime_PlainData.indexOf(",") == -1) {
                this.alreadySelectedBedTimeHours = Number(this.selectedTimeForBedTime_PlainData.split(':')[0]);
                tempAlreadySelectedBedTimeMinutes = this.selectedTimeForBedTime_PlainData.split(':')[1];

            }
            else {
                let numOfCommas = (this.selectedTimeForBedTime_PlainData.match(/,/g) || []).length;
                let selectedTimeForBedTime_PlainData_Temp = this.selectedTimeForBedTime_PlainData.split(',')[numOfCommas];
                this.alreadySelectedBedTimeHours = Number(selectedTimeForBedTime_PlainData_Temp.split(':')[0]);
                tempAlreadySelectedBedTimeMinutes = selectedTimeForBedTime_PlainData_Temp.split(':')[1];


            }
            this.alreadySelectedBedTimeMinutes = Number(tempAlreadySelectedBedTimeMinutes.split(' ')[0]);
            this.alreadySelectedBedTimeHours = (Number(Number(this.alreadySelectedBedTimeHours) * 60));
            let alreadySelectedBedTimeDuration = this.alreadySelectedBedTimeHours + this.alreadySelectedBedTimeMinutes;
            let diffBetweenTimeSlots = Number(totalBedTimeDuration) - Number(alreadySelectedBedTimeDuration);

            // alert(this.alreadySelectedMorningHours);
            // alert(this.alreadySelectedMorningMinutes);
            //alert("durationHours" + durationHours);
            //alert("diffBetweenTimeSlots" + diffBetweenTimeSlots);
            if (durationBetweenDoses > 0 && durationBetweenDoses > diffBetweenTimeSlots) {
                this.showErrors = true;
                this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                $(window).scrollTop(5);
                isValid = false;

            }

        }
        else //check for default value selection of bed time against the evening time
        {
            //alert('else bedtime');
            //alert(this.selectedTimeForEvening_PlainData);
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_EVENING") == 'Y') {

                this.selectedTimeForEvening = $('#pnlSelectedTimeForEvening').html();
                if (localStorage.getItem("EVENING_DATA") != undefined)
                    this.selectedTimeForEvening_PlainData = localStorage.getItem("EVENING_DATA");

                //alert(this.selectedTimeForMorning_PlainData.length);

            }

            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_AFTERNOON") == 'Y') {

                this.selectedTimeForAfternoon = $('#pnlSelectedTimeForAfterNoon').html();
                if (localStorage.getItem("AFTERNOON_DATA") != undefined)
                    this.selectedTimeForAfternoon_PlainData = localStorage.getItem("AFTERNOON_DATA");

                //alert(this.selectedTimeForMorning_PlainData.length);

            }
            if (localStorage.getItem("IS_CLOSED_EVENT_TRIGGERED_MORNING") == 'Y') {

                this.selectedTimeForMorning = $('#pnlSelectedTimeForMorning').html();
                if (localStorage.getItem("MORNING_DATA") != undefined)
                    this.selectedTimeForMorning_PlainData = localStorage.getItem("MORNING_DATA");

                //alert(this.selectedTimeForMorning_PlainData.length);

            }
            if (this.selectedTimeForEvening_PlainData != undefined && this.selectedTimeForEvening_PlainData != '') {

                //let arrAlreadySelectedMorning: string[] = Array();
                var arrAlreadySelectedEvening = this.selectedTimeForEvening_PlainData.split(',');
                //alert(arrAlreadySelectedMorning.length);
                let lastSelectedEveningTime = arrAlreadySelectedEvening[arrAlreadySelectedEvening.length - 1];
                //alert(lastSelectedMorningTime);
                this.alreadySelectedEveningHours = Number(lastSelectedEveningTime.split(':')[0]);
                let tempAlreadySelectedEveningMinutes = lastSelectedEveningTime.split(':')[1];
                this.alreadySelectedEveningMinutes = Number(tempAlreadySelectedEveningMinutes.split(' ')[0]);
                this.alreadySelectedEveningHours = (Number(Number(this.alreadySelectedEveningHours) * 60));
                let totalEveningDuration = this.alreadySelectedEveningHours + this.alreadySelectedEveningMinutes;

                let diffBetweenWindows = Number(totalBedTimeDuration) - Number(totalEveningDuration);
                let sumDurHrsAndTotalEveningHrs = durationBetweenDoses + Number(totalEveningDuration);
                //totalBedTimeDuration = Number(totalEveningDuration); // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                //if (durationHours > 0 && durationHours > 0 && durationHours > diffBetweenWindows) {
                //alert('sumDurHrsAndTotalEveningHrs' + sumDurHrsAndTotalEveningHrs);
                //alert('totalBedTimeDuration' + totalBedTimeDuration);
                if ((this.selectedTimeForBedTime_PlainData == undefined || this.selectedTimeForBedTime_PlainData == '') &&  Number(sumDurHrsAndTotalEveningHrs) > 0 && Number(totalBedTimeDuration) > 0 &&
                    Number(sumDurHrsAndTotalEveningHrs) > Number(totalBedTimeDuration)) {
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);
                    isValid = false;

                }
            }
            else if (this.selectedTimeForAfternoon_PlainData != undefined && this.selectedTimeForAfternoon_PlainData != '') {
                //let arrAlreadySelectedMorning: string[] = Array();
                var arrAlreadySelectedAfternoon = this.selectedTimeForAfternoon_PlainData.split(',');
                //alert(arrAlreadySelectedMorning.length);
                let lastSelectedAfternoonTime = arrAlreadySelectedAfternoon[arrAlreadySelectedAfternoon.length - 1];
                //alert(lastSelectedMorningTime);
                this.alreadySelectedAfternoonHours = Number(lastSelectedAfternoonTime.split(':')[0]);
                let tempAlreadySelectedAfternoonMinutes = lastSelectedAfternoonTime.split(':')[1];
                this.alreadySelectedAfternoonMinutes = Number(tempAlreadySelectedAfternoonMinutes.split(' ')[0]);
                this.alreadySelectedAfternoonHours = (Number(Number(this.alreadySelectedAfternoonHours) * 60));
                let totalAfterNoonDuration = this.alreadySelectedAfternoonHours + this.alreadySelectedAfternoonMinutes;
                //alert(totalAfterNoonDuration);
                //lastSelectedMorningTime = parseInt(lastSelectedMorningTime);



                let diffBetweenWindows = Number(totalBedTimeDuration) - Number(totalAfterNoonDuration);
                let sumDurHrsAndTotalAfterNoonHrs = durationBetweenDoses + Number(totalAfterNoonDuration);
                totalBedTimeDuration = (this.alreadySelectedAfternoonHours == 720) ? totalBedTimeDuration + 720 : totalBedTimeDuration; // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                //if (durationHours > 0 && durationHours > 0 && durationHours > diffBetweenWindows) {
                //alert('this.alreadySelectedAfternoonHours' + this.alreadySelectedAfternoonHours);
                // alert('sumDurHrsAndTotalAfterNoonHrs' + sumDurHrsAndTotalAfterNoonHrs);
                //alert('totalEveningDuration' + totalEveningDuration);
                if ((this.selectedTimeForEvening_PlainData == undefined || this.selectedTimeForEvening_PlainData == '') &&
                    Number(sumDurHrsAndTotalAfterNoonHrs) > 0 && Number(totalBedTimeDuration) > 0 &&
                    Number(sumDurHrsAndTotalAfterNoonHrs) > Number(totalBedTimeDuration)) {
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);
                    isValid = false;
                }

            }
            else if (this.selectedTimeForMorning_PlainData != undefined && this.selectedTimeForMorning_PlainData != '') {
                //let arrAlreadySelectedMorning: string[] = Array();
                var arrAlreadySelectedMorning = this.selectedTimeForMorning_PlainData.split(',');
                //alert(arrAlreadySelectedMorning.length);
                let lastSelectedMorningTime = arrAlreadySelectedMorning[arrAlreadySelectedMorning.length - 1];
                //alert(lastSelectedMorningTime);
                this.alreadySelectedMorningHours = Number(lastSelectedMorningTime.split(':')[0]);
                let tempAlreadySelectedMorningMinutes = lastSelectedMorningTime.split(':')[1];
                this.alreadySelectedMorningMinutes = Number(tempAlreadySelectedMorningMinutes.split(' ')[0]);
                this.alreadySelectedMorningHours = (Number(Number(this.alreadySelectedMorningHours) * 60));
                let totalMorningDuration = this.alreadySelectedMorningHours + this.alreadySelectedMorningMinutes;

                let sumDurHrsAndTotalMorningHrs = durationBetweenDoses + Number(totalMorningDuration);
                //alert(sumDurHrsAndTotalMorningHrs);
                //alert(totalAfternoonDuration);
                //if (Number(this.form.value.adherenceHours_Morning) != 12)
                totalBedTimeDuration = 720 + Number(totalBedTimeDuration); // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                //else if (Number(this.form.value.adherenceHours_Afternoon) == 12)
                //    totalBedTimeDuration = Number(totalAfternoonDuration);
                if (sumDurHrsAndTotalMorningHrs > 0 && totalMorningDuration > 0
                    && Number(sumDurHrsAndTotalMorningHrs) > Number(totalBedTimeDuration)) {
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);
                    isValid = false;

                }




            }




        }
        let fromBedTime = this.form.value.adherenceHours_BedTime + ':' + this.form.value.adherenceMinutes_BedTime + ':' + this.form.value.adherenceAMPM_BedTime;
        //let fromBedTime = this.form.value.adherenceHours_BedTime + ':' + this.form.value.adherenceMinutes_BedTime;
        if (isValid) {


            if (this.selectedTimeForBedTime == undefined) {
                this.selectedBedTimeCounter = 1;
                this.selectedTimeForBedTime = "<div id=\"timeSlotPnl_" + this.selectedBedTimeCounter + "_BEDTIME\" class=\"schduleData\">" + fromBedTime + "<button onclick=\"closeDiv1('btnClose_" + this.selectedBedTimeCounter + "\_" + fromBedTime + "_BEDTIME')\" id=\"btnClose_" + this.selectedBedTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                this.selectedTimeForBedTime_PlainData = fromBedTime;
            }
            else {
                this.selectedBedTimeCounter = this.selectedBedTimeCounter + 1;
                this.selectedTimeForBedTime = this.selectedTimeForBedTime + "<div id=\"timeSlotPnl_" + this.selectedBedTimeCounter + "_BEDTIME\" class=\"schduleData\">" + fromBedTime + "<button onclick=\"closeDiv1('btnClose_" + this.selectedBedTimeCounter + "\_" + fromBedTime + "_BEDTIME')\" id=\"btnClose_" + this.selectedBedTimeCounter + "\"  class=\"btn-close\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></button></div>";
                if (this.selectedTimeForBedTime_PlainData.length == 0) {

                    this.selectedTimeForBedTime_PlainData = fromBedTime;
                }
                else {
                    this.selectedTimeForBedTime_PlainData = this.selectedTimeForBedTime_PlainData + "," + fromBedTime;
                }
            }
            localStorage.setItem("BEDTIME_DATA", this.selectedTimeForBedTime_PlainData);
            $('#pnlSelectedTimeForBedTime').html(this.selectedTimeForBedTime);



        }
    }

    //public prepareJsonStringForRegimen(name, medicationPerDose, totalDoses, extraDoses, durationBetweenDoses, thresholdTime, scheduleType, morningDosingWindowSchedule, afternoonDosingWindowSchedule, eveningDosingWindowSchedule, bedtimeDosingWindowSchedule, userId) {
    //    this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n   \"userId\":" + userId + " \r\n}";
    //}

    public prepareJsonStringForRegimen(name, medicationPerDose, totalDoses, extraDoses, durationBetweenDoses, thresholdTime, scheduleType, morningDosingWindowSchedule, afternoonDosingWindowSchedule, eveningDosingWindowSchedule, bedtimeDosingWindowSchedule, userId, monthlyYearlySelectedDate, dayOfWeek,days) {
        //this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n   \"userId\":" + userId+" \r\n}";
        if (scheduleType == 'Monthly' || scheduleType == 'Yearly') {
            this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n \"monthlyYearlySelectedDate\":\"" + monthlyYearlySelectedDate + "\",\r\n\"userId\":" + userId + " \r\n,\r\n\"days\":" + days + " \r\n}";
            //this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n   \"userId\":" + userId + ",\r\n   \"monthlyYearlySelectedDate\:\"" + monthlyYearlySelectedDate + "\",\r\n \"dayOfWeek\:\"" + dayOfWeek + " \r\n}";
        }
        else if (scheduleType == 'Weekly') {
            this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n \"dayOfWeek\":\"" + dayOfWeek + "\",\r\n\"userId\":" + userId + " \r\n,\r\n\"days\":" + days + " \r\n}";

        }
        else if (scheduleType == 'Daily') {
            this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n   \"userId\":" + userId + " \r\n,\r\n\"days\":" + days + " \r\n}";

        }
        else if (scheduleType == 'Interval' || scheduleType == 'Event') {
            this.regimenJsonString = "{\r\n   \"name\":\"" + name + "\",\r\n   \"medicationPerDose\":" + medicationPerDose + ",\r\n   \"totalDoses\":" + totalDoses + ",\r\n   \"extraDoses\":" + extraDoses + ",\r\n   \"durationBetweenDoses\":" + durationBetweenDoses + ",\r\n   \"thresholdTime\":" + thresholdTime + ",\r\n   \"scheduleType\":\"" + scheduleType + "\",\r\n   \"morningDosingWindowSchedule\":\"" + morningDosingWindowSchedule + "\",\r\n   \"afternoonDosingWindowSchedule\":\"" + afternoonDosingWindowSchedule + "\",\r\n   \"eveningDosingWindowSchedule\":\"" + eveningDosingWindowSchedule + "\",\r\n   \"bedtimeDosingWindowSchedule\":\"" + bedtimeDosingWindowSchedule + "\",\r\n   \"userId\":" + userId + " \r\n,\r\n\"days\":" + days + " \r\n}";

        }

    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public goBack(): void {
        this.isLoading = true;
        this.form.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'regimens']);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.form.dirty;
    }

    private convertMinutes(totalMinutes: number): any {
        let minsPerDay = 24 * 60;
        let minsPerHour = 60;
        let minutes = totalMinutes;
        let converted = { days: null, hours: null, minutes: null };

        let days = Math.floor(minutes / minsPerDay);
        converted.days = days;
        minutes = minutes - days * minsPerDay;
        let hours = Math.floor(minutes / minsPerHour);
        converted.hours = hours;
        minutes = minutes - hours * minsPerHour;
        converted.minutes = minutes;

        return converted;
    }


    getSelectedCheckBoxValue(selectedValue) {
        //alert(selectedValue);
        let sunCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-1")).checked;
        let monCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-2")).checked;
        let tueCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-3")).checked;
        let webCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-4")).checked;
        let thuCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-5")).checked;
        let friCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-6")).checked;
        let satCheckBox = (<HTMLInputElement>document.getElementById("frm-test-elm-110-7")).checked;
        //alert(satCheckBox);
        //alert(sunCheckBox);
        //this.selectedDayOfWeek = 'Sun';
        if (sunCheckBox && selectedValue == "Sun") {

            if (this.selectedDayOfWeek == undefined) {

                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue)==-1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }
            $("#lblSun").addClass("btn btn-default active");
        }
        else if (!sunCheckBox && selectedValue == "Sun") {
            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");

            $("#lblSun").removeClass("btn btn-default active").addClass("btn btn-default");
        }



        if (monCheckBox && selectedValue == "Mon") {

            if (this.selectedDayOfWeek == undefined) {
                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue) == -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }
            $("#lblMon").addClass("btn btn-default active");
        }
        else if (!monCheckBox && selectedValue == "Mon") {

            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");

            $("#lblMon").removeClass("btn btn-default active").addClass("btn btn-default");
        }

        if (tueCheckBox && selectedValue == "Tue") {

            if (this.selectedDayOfWeek == undefined) {
                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue) == -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }

            $("#lblTue").addClass("btn btn-default active");
        }
        else if (!tueCheckBox && selectedValue == "Tue") {
            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");
            $("#lblTue").removeClass("btn btn-default active").addClass("btn btn-default");
        }

        if (webCheckBox && selectedValue == "Wed") {

            if (this.selectedDayOfWeek == undefined) {
                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue) == -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }
            $("#lblWed").addClass("btn btn-default active");
        }
        else if (!webCheckBox && selectedValue == "Wed") {
            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");
            $("#lblWed").removeClass("btn btn-default active").addClass("btn btn-default");
        }

        if (thuCheckBox && selectedValue == "Thu") {

            if (this.selectedDayOfWeek == undefined) {
                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue) == -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }
            $("#lblThu").addClass("btn btn-default active");
        }
        else if (!thuCheckBox && selectedValue == "Thu") {

            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");
            $("#lblThu").removeClass("btn btn-default active").addClass("btn btn-default");
        }

        if (friCheckBox && selectedValue == "Fri") {

            if (this.selectedDayOfWeek == undefined) {
                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue) == -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }
            $("#lblFri").addClass("btn btn-default active");
        }
        else if (!friCheckBox && selectedValue == "Fri") {

            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");
            $("#lblFri").removeClass("btn btn-default active").addClass("btn btn-default");
        }


        if (satCheckBox && selectedValue == "Sat") {

            if (this.selectedDayOfWeek == undefined) {
                this.selectedDayOfWeek = selectedValue;

            }
            else {
                //if (this.selectedDayOfWeek.indexOf(selectedValue) == -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek + "," + selectedValue;
            }
            $("#lblSat").addClass("btn btn-default active");
        }
        else if (!satCheckBox && selectedValue == "Sat") {
            if (this.selectedDayOfWeek.indexOf(selectedValue) != -1)
                this.selectedDayOfWeek = this.selectedDayOfWeek.replace(selectedValue, "");
            $("#lblSat").removeClass("btn btn-default active").addClass("btn btn-default");

        }


        //alert(this.selectedDayOfWeek);
    }

    fnSelectedScheduleType(selectedValue) {
        this.selectedScheduleType = selectedValue;
        this.numberOfDays = 0;
        if (selectedValue == 'Weekly') {
            $("#pnlDayOfWeek").css("display", "block");


        }
        else {
            $("#pnlDayOfWeek").css("display", "none");

        }

        if (selectedValue == 'Monthly') {
            this.clearAllDateSelections();
            $('#spnPrevMonth').css("display", "none");
            $('#spnNextMonth').css("display", "none");
            $('#pnlYearlyHeader').css("display", "none");
            $('#pnlMonthlyHeader').css("display", "table-row");
        }
        else if (selectedValue == 'Yearly') {
            this.clearAllDateSelections();
            $('#spnPrevMonth').css("display", "block");
            $('#spnNextMonth').css("display", "block");
            $('#pnlYearlyHeader').css("display", "table-row");
            $('#pnlMonthlyHeader').css("display", "none");
        }
        if (selectedValue == 'Monthly' || selectedValue == 'Yearly') {


            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            //var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];;
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var date = new Date();

            //$('#spnMonth').text(months[date.getMonth()]);
        }
        else {
            $("#divCalendar,#pnlRegimenMonthlyCalendar").css("display", "none");
        }

        //if (selectedValue == 'Yearly') {
        //    $("#pnlRegimenMonthlyCalendar").css("display", "block");
        //    $("#pnlRegimenCalendar,#pnlSelectedDates").css("display", "block");
        //    $('.weekdaytitle').css("display", "none");
        //    //$('#spnSelectedDates').text("");

        //}
        //else {
        //    $("#pnlRegimenCalendar,#pnlSelectedDates").css("display", "none");

        //}

        if (selectedValue == 'Monthly' || selectedValue == 'Yearly') {
            $("#divCalendar").css("display", "block");

        }
        else {
            $("#divCalendar").css("display", "none");

        }


        if (selectedValue == 'Interval' || selectedValue == 'Event') {
            $('#pnlDosingSchdule').css("display", "none");

        }
        else {
            $('#pnlDosingSchdule').css("display", "block");
        }

        if (selectedValue == 'Monthly') {
            $("#pnlRegimenMonthlyCalendar").css("display", "block");
            var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];;
            //var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var date = new Date();

            // $('#spnMonth').text(months[date.getMonth()]);

        }

        if (selectedValue == 'Event')
        {
            this.selectedScheduleType = '';

        }

    }
    public clearAllDateSelections(): void {
        for (let i = 0; i < 31; i++) {
            $('#day' + i + 'Cell').removeClass("selected");
        }


    }
    onChange_Month(selectedValue) {
        //alert(selectedValue);

        if (this.selectedScheduleType == 'Yearly') {

            var arrSelectedDates;
            //alert(this.selectedDatesForYearly);
            this.clearAllDateSelections();
            this.selectedDatesForYearly = '';


            //this.selectedDatesForYearly = '';            
            //var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            let currentMonth = selectedValue;
            this.selectedMonthForYear = currentMonth;
            //$('#spnMonth').text(months[months.indexOf(currentMonth) - 1]);

            if (localStorage.getItem(selectedValue) != undefined) {
                let selectedDates = localStorage.getItem(selectedValue);
                //alert(selectedDates);
                var arrSelectedDates1 = selectedDates.split(',');
                arrSelectedDates1.forEach((item, index) => {
                    //alert(index);
                    //console.log(item); // 9, 2, 5
                    //console.log(index); // 0, 1, 2
                    $('#day' + item + 'Cell').addClass("selected");
                    //newly added
                    if (this.selectedDatesForYearly == '')
                        this.selectedDatesForYearly = item;
                    else
                        this.selectedDatesForYearly = this.selectedDatesForYearly + ',' + item;
                    //end newly added
                });

            }
            else {
                this.getAndDisplaySelectedDatesByMonth(selectedValue);

            }

        }

    }

    onChange(selectedValue, dosageWindow, isEventTriggered) {
        this.showErrors = false;
        this.errorMessage = "";
        //this.isOnChangeEventTriggered = true;
        //alert(this.isOnChangeEventTriggered);
        //alert(this.defaultMorningFromTime);
        //alert(selectedValue);
        //alert(this.upperBoundaryForMorningHrs);
        //alert(isEventTriggered);
        //if (this.isRegimenEditPageLoad != true) {
            if (this.defaultMorningFromTime != selectedValue && this.upperBoundaryForMorningHrs != selectedValue && dosageWindow == 'Morning') {
                //$('#adherenceMinutes_Morning').empty();
                this.morningMinutes = [];
                //display all the minutes
                for (let i = 0; i < 60; i++) {
                    if (i < 10)
                        this.morningMinutes.push('0' + String(i));
                    else
                        this.morningMinutes.push(i);
                }

                //this.defaultMorningFromMins = '0';
            }
            else {
                this.morningMinutes = [];
                //display all the minutes
                for (let i = Number(this.morningFromMins); i <= Number(this.morningToMins); i++) {
                    if (i < 10)
                        this.morningMinutes.push('0' + String(i));
                    else
                        this.morningMinutes.push(i);
                }

            }

            if (this.defaultAfternoonFromTime != selectedValue && dosageWindow == 'Afternoon') {
                //$('#adherenceMinutes_Morning').empty();
                this.afternoonMinutes = [];
                //display all the minutes
                for (let i = 0; i < 60; i++) {
                    if (i < 10)
                        this.afternoonMinutes.push('0' + String(i));
                    else
                        this.afternoonMinutes.push(i);
                }

            }
            else {

                this.afternoonMinutes = [];
                //display all the minutes
                for (let i = Number(this.afternoonFromMins); i <= Number(this.afternoonToMins); i++) {
                    if (i < 10)
                        this.afternoonMinutes.push('0' + String(i));
                    else
                        this.afternoonMinutes.push(i);
                }
            }

            if (this.defaultEveningFromTime != selectedValue && dosageWindow == 'Evening') {
                //$('#adherenceMinutes_Morning').empty();
                this.eveningMinutes = [];
                //display all the minutes
                for (let i = 0; i < 60; i++) {
                    if (i < 10)
                        this.eveningMinutes.push('0' + String(i));
                    else
                        this.eveningMinutes.push(i);
                }

            }
            else {

                this.eveningMinutes = [];
                //display all the minutes
                for (let i = Number(this.eveninigFromMins); i <= Number(this.eveninigToMins); i++) {
                    if (i < 10)
                        this.eveningMinutes.push('0' + String(i));
                    else
                        this.eveningMinutes.push(i);
                }
            }

            if (this.defaultBedTimeFromTime != selectedValue && dosageWindow == 'Bedtime') {
                //$('#adherenceMinutes_Morning').empty();
                this.bedtimeMinutes = [];
                //display all the minutes
                for (let i = 0; i < 60; i++) {
                    if (i < 10)
                        this.bedtimeMinutes.push('0' + String(i));
                    else
                        this.bedtimeMinutes.push(i);
                }

            }
            else {

                this.bedtimeMinutes = [];
                //display all the minutes
                for (let i = Number(this.bedtimeFromMins); i <= Number(this.bedtimeToMins); i++) {
                    if (i < 10)
                        this.bedtimeMinutes.push('0' + String(i));
                    else
                        this.bedtimeMinutes.push(i);
                }
            }

            //alert(selectedValue.value);
            //alert(dosageWindow);
            let durationDays = ((Number(this.form.value.durationDays * 24)) * 60);
            let durationHours = (Number(this.form.value.durationHours * 60));
            let durationMinutes = Number(this.form.value.durationMinutes);
            let durationBetweenDoses = durationDays + durationHours + durationMinutes;
            let totalMorningDuration = 0;
        
            //let durationHours = Number(this.form.value.durationHours);
            //alert(afternoonHours);

            if (dosageWindow == 'Morning') {
                if (this.selectedTimeForMorning_PlainData != undefined && $('#pnlSelectedTimeForMorning').text() != '') {
                    //let arrAlreadySelectedMorning: string[] = Array();
                    var arrAlreadySelectedMorning = this.selectedTimeForMorning_PlainData.split(',');
                    //alert(arrAlreadySelectedMorning.length);
                    let lastSelectedMorningTime = arrAlreadySelectedMorning[arrAlreadySelectedMorning.length - 1];
                    //alert('lastSelectedMorningTime' + lastSelectedMorningTime);
                    this.alreadySelectedMorningHours = Number(lastSelectedMorningTime.split(':')[0]);
                    let tempAlreadySelectedMorningMinutes = lastSelectedMorningTime.split(':')[1];
                    this.alreadySelectedMorningMinutes = Number(tempAlreadySelectedMorningMinutes.split(' ')[0]);
                    this.alreadySelectedMorningHours = (Number(Number(this.alreadySelectedMorningHours) * 60));
                    totalMorningDuration = this.alreadySelectedMorningHours + this.alreadySelectedMorningMinutes;

                    //lastSelectedMorningTime = parseInt(lastSelectedMorningTime);

                    //let diffBetweenMorningTimeslots = Number(this.alreadySelectedMorningHours) - Number(selectedValue);
                    selectedValue = (Number(selectedValue * 60));
                    //alert('selectedValue' + selectedValue);
                    //alert('nnnn' + this.form.value.durationHours);
                    //alert('ss' + Number(this.alreadySelectedMorningHours));
                    let diffBetweenTimeSlots = Number(selectedValue) - Number(this.alreadySelectedMorningHours);
                    //alert(durationHours);
                    //alert(diffBetweenTimeSlots);
                    //alert(totalMorningDuration);
                    //alert('durationHours' + durationHours);
                    //alert('diffBetweenTimeSlots' + diffBetweenTimeSlots);
                    //alert('onchange morning');
                    if (String(diffBetweenTimeSlots) != 'NaN' && durationBetweenDoses > 0 && totalMorningDuration > 0 && durationBetweenDoses > 0 && durationBetweenDoses > diffBetweenTimeSlots && diffBetweenTimeSlots > 0) { //ex: 3 hrs> 2 hrs(diff between 6 AM and 7 AM)
                        this.showErrors = true;
                        //alert('onchange morning');
                        this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                        $(window).scrollTop(5);

                    }
                //if (selectedValue < Number(this.alreadySelectedMorningHours)) {
                //    this.showErrors = true;
                //    this.errorMessage = "Please select hours higher than the already selected time";
                //    $(window).scrollTop(5);

                //}
                }

                

            }

            if (dosageWindow == 'Afternoon') {
                let afternoonHours = (Number(selectedValue * 60)); //(Number(this.form.value.adherenceHours_Afternoon * 60));
                let afternoonMinutes = Number(this.form.value.adherenceMinutes_Afternoon);
                let totalAfterNoonDuration = afternoonHours + afternoonMinutes;
                //alert('afternoonHours' + Number(afternoonHours));
                //alert('morning hrs' + Number(morningHours));


                //alert(diffBetweenWindows);
                //alert(durationHours);
                //alert(this.selectedTimeForMorning_PlainData);
                if (this.selectedTimeForMorning_PlainData != undefined) {
                    //let arrAlreadySelectedMorning: string[] = Array();
                    var arrAlreadySelectedMorning = this.selectedTimeForMorning_PlainData.split(',');
                    //alert(arrAlreadySelectedMorning.length);
                    let lastSelectedMorningTime = arrAlreadySelectedMorning[arrAlreadySelectedMorning.length - 1];
                    //alert(lastSelectedMorningTime);
                    this.alreadySelectedMorningHours = Number(lastSelectedMorningTime.split(':')[0]);
                    let tempAlreadySelectedMorningMinutes = lastSelectedMorningTime.split(':')[1];
                    this.alreadySelectedMorningMinutes = Number(tempAlreadySelectedMorningMinutes.split(' ')[0]);
                    this.alreadySelectedMorningHours = (Number(Number(this.alreadySelectedMorningHours) * 60));
                    totalMorningDuration = this.alreadySelectedMorningHours + this.alreadySelectedMorningMinutes;

                    //lastSelectedMorningTime = parseInt(lastSelectedMorningTime);
                }
                else {
                    let morningHours = (Number(this.form.value.adherenceHours_Morning * 60));
                    let morningMinutes = Number(this.form.value.adherenceMinutes_Morning);
                    totalMorningDuration = morningHours + morningMinutes;


                }
                let diffBetweenWindows = Number(totalAfterNoonDuration) - Number(totalMorningDuration);
                let sumDurHrsAndTotalMorningHrs = durationBetweenDoses + Number(totalMorningDuration);
                totalAfterNoonDuration = 720 + Number(totalAfterNoonDuration); // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
               
                //alert(durationHours);
                //alert(diffBetweenWindows);
                //if (durationHours > 0 && durationHours > 0 && durationHours > diffBetweenWindows) {
                // alert('onchange afternoon');
                if (Number(sumDurHrsAndTotalMorningHrs) > 0 && Number(totalAfterNoonDuration) > 0 &&
                    Number(sumDurHrsAndTotalMorningHrs) > Number(totalAfterNoonDuration)) {
                    //alert('onchange afternoon');
                    this.showErrors = true;
                    this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                    $(window).scrollTop(5);

                }



            }
            else if (dosageWindow == 'Evening') {
                let totalAfterNoonDuration = 0;
                let eveningHours = (Number(selectedValue * 60)); //(Number(this.form.value.adherenceHours_Evening * 60));
                let eveningMinutes = Number(this.form.value.adherenceMinutes_Evening);
                let totalEveningDuration = eveningHours + eveningMinutes;
                if (this.selectedTimeForAfternoon_PlainData != undefined && this.selectedTimeForAfternoon_PlainData != '') {
                    //let arrAlreadySelectedMorning: string[] = Array();
                    var arrAlreadySelectedAfternoon = this.selectedTimeForAfternoon_PlainData.split(',');
                    //alert(arrAlreadySelectedMorning.length);
                    let lastSelectedAfternoonTime = arrAlreadySelectedAfternoon[arrAlreadySelectedAfternoon.length - 1];
                    //alert(lastSelectedMorningTime);
                    this.alreadySelectedAfternoonHours = Number(lastSelectedAfternoonTime.split(':')[0]);
                    let tempAlreadySelectedAfternoonMinutes = lastSelectedAfternoonTime.split(':')[1];
                    this.alreadySelectedAfternoonMinutes = Number(tempAlreadySelectedAfternoonMinutes.split(' ')[0]);
                    this.alreadySelectedAfternoonHours = (Number(Number(this.alreadySelectedAfternoonHours) * 60));
                    let totalAfterNoonDuration = this.alreadySelectedAfternoonHours + this.alreadySelectedAfternoonMinutes;
                    //alert(totalAfterNoonDuration);
                    //lastSelectedMorningTime = parseInt(lastSelectedMorningTime);

                    let diffBetweenWindows = Number(totalEveningDuration) - Number(totalAfterNoonDuration);
                    let sumDurHrsAndTotalAfterNoonHrs = durationBetweenDoses + Number(totalAfterNoonDuration);
                    //if (this.alreadySelectedAfternoonHours != undefined)
                    totalEveningDuration = (this.alreadySelectedAfternoonHours == 720) ? totalEveningDuration + 720 : totalEveningDuration;//Ex: Already selected afternoon time is 12 PM(720 hrs), selected eventime: 4PM, this should allow by user
                    

                    if (this.selectedTimeForAfternoon_PlainData != undefined && totalAfterNoonDuration > 0 && (this.selectedTimeForEvening_PlainData == undefined && this.selectedTimeForEvening_PlainData != "" || $('#pnlSelectedTimeForEvening').html() == '') &&
                        Number(sumDurHrsAndTotalAfterNoonHrs) > 0 && Number(totalEveningDuration) > 0 &&
                        Number(sumDurHrsAndTotalAfterNoonHrs) > Number(totalEveningDuration)) {
                        //alert('evening time');
                        this.showErrors = true;
                        this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                        $(window).scrollTop(5);

                    }
                }


                


            }
            else if (dosageWindow == 'Bedtime') {
                let totalEveningDuration = 0;
                let bedtimeHours = (Number(selectedValue * 60)); //(Number(this.form.value.adherenceHours_BedTime * 60));
                let bedtimeMinutes = Number(this.form.value.adherenceMinutes_BedTime);
                let totalBedTimeDuration =  (this.defaultBedTimeFromTime != selectedValue)?bedtimeHours + bedtimeMinutes:0;
                if (this.selectedTimeForEvening_PlainData != undefined && this.selectedTimeForEvening_PlainData != '') {
                    //let arrAlreadySelectedMorning: string[] = Array();
                    var arrAlreadySelectedEvening = this.selectedTimeForEvening_PlainData.split(',');
                    //alert(arrAlreadySelectedMorning.length);
                    let lastSelectedEveningTime = arrAlreadySelectedEvening[arrAlreadySelectedEvening.length - 1];
                    //alert(lastSelectedMorningTime);
                    this.alreadySelectedEveningHours = Number(lastSelectedEveningTime.split(':')[0]);
                    let tempAlreadySelectedEveningMinutes = lastSelectedEveningTime.split(':')[1];
                    this.alreadySelectedEveningMinutes = Number(tempAlreadySelectedEveningMinutes.split(' ')[0]);
                    this.alreadySelectedEveningHours = (Number(Number(this.alreadySelectedEveningHours) * 60));
                    totalEveningDuration = this.alreadySelectedEveningHours + this.alreadySelectedEveningMinutes;

                    //lastSelectedMorningTime = parseInt(lastSelectedMorningTime);

                    let diffBetweenWindows = Number(totalBedTimeDuration) - Number(totalEveningDuration);
                    let sumDurHrsAndTotalEveningHrs = durationBetweenDoses + Number(totalEveningDuration);
                    //totalBedTimeDuration = Number(totalEveningDuration); // ex: 720 is 12*60 we have to add 12 hrs after 12 PM
                    //if (durationHours > 0 && durationHours > 0 && durationHours > diffBetweenWindows) {
                    //alert('onchange bedtime');
                    //alert(sumDurHrsAndTotalEveningHrs);
                    //alert(totalBedTimeDuration);
                    if (this.selectedTimeForEvening_PlainData != undefined && totalEveningDuration > 0 && this.selectedTimeForBedTime_PlainData == undefined && Number(sumDurHrsAndTotalEveningHrs) > 0 && Number(totalBedTimeDuration) > 0 &&
                        Number(sumDurHrsAndTotalEveningHrs) > Number(totalBedTimeDuration)) {
                        //alert('bedtime');
                        this.showErrors = true;
                        this.errorMessage = "Dose schedule hours should be more than or equal to Duration between dosages hours";
                        $(window).scrollTop(5);

                    }
                }


                


            }

        //}

        this.isRegimenEditPageLoad = false;

    }


    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }




    public daySelectionEvent(selectedDay, selectedCellId): void {
        this.isUserModifiedDate = true;
        this.isFirstDateSelectedAndThenDeselectedDate = false;
        //this.removedDates = '';
        var arrRemovedDates;
        let removedDates = '';
        if ($('#' + selectedCellId).hasClass("selected")) {

            $('#' + selectedCellId).removeClass("selected");
            if (removedDates == '') {

                removedDates = selectedDay;
            }
            else {

                removedDates = removedDates + "," + selectedDay;
            }
        }
        else {
            $('#' + selectedCellId).addClass("selected");
        }
        // alert(selectedDay);



        if (this.selectedScheduleType == 'Monthly') {
            //Logic to implement deselected dates
            let monthName = '';
            var date = new Date();
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

            

            //End Dates

            if (this.selectedDatesForMonthly == undefined) {
                this.selectedDatesForMonthly = this.regimen.monthlyYearly+"," +selectedDay;

            }
            else {
                this.selectedDatesForMonthly = this.selectedDatesForMonthly + "," + selectedDay;

            }

            if (removedDates != undefined && removedDates != '') {

                this.selectedDatesForMonthly = this.selectedDatesForMonthly.replace(new RegExp(removedDates, 'g'), "");
                this.selectedDatesForMonthly = String(this.selectedDatesForMonthly).split(/[ ,]+/).filter(function (v) { return v !== '' }).join(',');
            }

            var uniqueList = String(this.selectedDatesForMonthly).split(',').filter(function (item, i, allItems) {
                return i == allItems.indexOf(item);
            }).join(',');

            
            this.selectedDatesForMonthly = uniqueList;

            //$("#spnSelectedDates").text(this.selectedDatesForMonthly);

        }

        if (this.selectedScheduleType == 'Yearly') {

            let monthName = '';
            var date = new Date();
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

            if (removedDates != undefined && removedDates != '') {
                //alert('this.selectedDatesForYearly' + this.selectedDatesForYearly);
                
                if ((this.selectedDatesForYearly == undefined || this.selectedDatesForYearly == '') && localStorage.getItem(this.selectedMonthForYear) != undefined && localStorage.getItem(this.selectedMonthForYear) != '' && months[date.getMonth()] == this.selectedMonthForYear) //current calendar month
                {
                    this.selectedDatesForYearly = localStorage.getItem(this.selectedMonthForYear);
                    
                }
                this.selectedDatesForYearly = this.selectedDatesForYearly.replace(new RegExp(removedDates, 'g'), "");
                this.selectedDatesForYearly = this.selectedDatesForYearly.split(/[ ,]+/).filter(function (v) { return v !== '' }).join(',');
                if (this.removeDatesState == undefined && this.removeDatesState == '') {
                    this.removeDatesState = removedDates;
                }
                else
                {
                    this.removeDatesState = this.removeDatesState + ',' + removedDates;
                }
                
                removedDates = '';
                
                //alert(this.selectedMonthForYear);
               //alert(this.selectedDatesForYearly);
                if (this.selectedMonthForYear != undefined && this.selectedMonthForYear != '')
                {
                    localStorage.setItem(this.selectedMonthForYear, this.selectedDatesForYearly);

                    //store removed dates
                    localStorage.setItem(this.selectedMonthForYear+"_removedDates", this.removeDatesState);
                }
                 else {
                   
                    localStorage.setItem(months[date.getMonth()], this.selectedDatesForYearly);

                    //store removed dates
                    localStorage.setItem(months[date.getMonth()] + "_removedDates", this.removeDatesState);
                 }
                
                this.isFirstDateSelectedAndThenDeselectedDate = true;
            }
            if ($('#' + selectedCellId).hasClass("selected")) //if date is selected only, then append this date to string, if the date is deselected, no need to append
            {
                this.isFirstDateSelectedAndThenDeselectedDate = false;
                if (this.selectedDatesForYearly == undefined || this.selectedDatesForYearly == '') {
                    //alert('month' + this.selectedMonthForYear);
                    if (localStorage.getItem(this.selectedMonthForYear) != undefined) {
                        // alert(localStorage.getItem(this.selectedMonthForYear));
                        this.selectedDatesForYearly = localStorage.getItem(this.selectedMonthForYear) + "," + selectedDay;

                    }
                    else {
                        this.selectedDatesForYearly = selectedDay;
                    }
                }
                else {
                    //alert(this.selectedDatesForYearly);
                    //if (this.selectedDatesForYearly.indexOf(selectedDay)==-1)
                    this.selectedDatesForYearly = this.selectedDatesForYearly + "," + selectedDay;

                }
                //alert('localStorage.getItem(monthName)' + localStorage.getItem(monthName));


                if (monthName != '') //current month(March)
                {
                    //alert('entered');
                    this.selectedDatesForYear = monthName + '^' + this.selectedDatesForYearly;

                    //if (localStorage.getItem(monthName) == undefined)
                    localStorage.setItem(monthName, this.selectedDatesForYearly); //store selected dates into local storage 
                    //else if (localStorage.getItem(monthName) != undefined) {
                    //    localStorage.setItem(monthName, this.selectedDatesForYearly); //store selected dates into local storage 
                    //}

                }
                //alert(this.selectedMonthForYear);
                //alert(monthName);
                //alert(this.selectedDatesForYearly);
                if (this.selectedMonthForYear != undefined && monthName != this.selectedMonthForYear) //not the current month
                {
                    //alert('not the current month');
                    if (this.selectedDatesForYear != undefined) {
                        if (this.selectedDatesForYear.indexOf(this.selectedMonthForYear) == -1) //selected month name is not part of string
                            this.selectedDatesForYear = this.selectedDatesForYear + '|' + this.selectedMonthForYear + '^' + this.selectedDatesForYearly;
                        else
                            this.selectedDatesForYear = this.selectedDatesForYear + ',' + selectedDay;
                    }
                    else {
                        this.selectedDatesForYear = this.selectedMonthForYear + '^' + this.selectedDatesForYearly;
                    }
                    //alert('before storing into local storage' + this.selectedDatesForYearly);
                    //alert('selectedDatesForYear' + this.selectedDatesForYear);

                    //if (localStorage.getItem(this.selectedMonthForYear) == undefined)

                    if (localStorage.getItem(this.selectedMonthForYear) == undefined)
                        localStorage.setItem(this.selectedMonthForYear, this.selectedDatesForYearly); //store selected dates into local storage
                    else if (localStorage.getItem(this.selectedMonthForYear) != undefined) {
                        let alreadySelectedDates = localStorage.getItem(this.selectedMonthForYear);
                        localStorage.setItem(this.selectedMonthForYear, alreadySelectedDates + "," + selectedDay);
                    }

                }




                //selected prev month and checking for future month has any selected dates
                //if (localStorage.getItem(months[months.indexOf(monthName) + 1]) != undefined && monthName != months[months.indexOf(monthName) + 1])
                //{
                //    this.selectedDatesForYear = this.selectedDatesForYear + '|' + months[months.indexOf(monthName) + 1] +'^'+ localStorage.getItem(months[months.indexOf(monthName) + 1]);

                //}

                ////selected next month and checking for prev month has any selected dates
                //if (localStorage.getItem(months[months.indexOf(monthName) - 1]) != undefined && monthName != months[months.indexOf(monthName) - 1]) {
                //    this.selectedDatesForYear = months[months.indexOf(monthName) - 1] + '^' + localStorage.getItem(months[months.indexOf(monthName) - 1]) + '|' + this.selectedDatesForYear;

                //}
                //$("#spnSelectedDates").text(this.selectedDatesForYearly);

            }

            
        }


    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);
        var dt = event.value;
        var mlist: any;
        var month_name = function (dt) {
            mlist = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            return mlist[dt.getMonth()];
        };

        let monthName = month_name(new Date(event.value));
        if (this.selectedScheduleType == 'Monthly') {
            if (this.selectedDatesForMonthly == undefined) {
                this.selectedDatesForMonthly = d.toString().split('-')[2];

            }
            else {
                this.selectedDatesForMonthly = this.selectedDatesForMonthly + "," + d.toString().split('-')[2];

            }

            $("#spnSelectedDates").text(this.selectedDatesForMonthly);

        }

        if (this.selectedScheduleType == 'Yearly') {
            //alert(this.selectedMonthForYearly);
            //alert(d.toString().split('-')[1]);

            if (this.selectedDatesForYearly == undefined) {

                this.selectedDatesForYearly = monthName + '^' + d.toString().split('-')[2];

            }
            else {
                this.selectedDatesForYearly = this.selectedDatesForYearly + "," + d.toString().split('-')[2];

            }
            //if (this.selectedDatesForYearly != undefined) {
            //    if (this.selectedMonthForYearly == undefined) {
            //        var selectedMonthNumber = d.toString().split('-')[1]; // moment('09', 'MM').format('MMMM');
            //        selectedMonthNumber = selectedMonthNumber.toString().split('-')[1];

            //        this.selectedMonthForYearly = d.toString().split('-')[1] + '^' + this.selectedDatesForYearly;

            //    }
            //    else {
            //        alert('else part of selectedMonthForYearly');
            //        this.selectedMonthForYearly = this.selectedMonthForYearly + '|' + this.selectedDatesForYearly;
            //    }
            //}


            //alert(this.selectedMonthForYearly);
            $("#spnSelectedDates").text(this.selectedDatesForYearly);

        }

        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            } else if (field === 'end') {
                this.setStartDateDisableSince(date.date);
            }
        }
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }


    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    private dateForView(date: string): any {
        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: d[1].replace('0', ''), day: d[2].replace('0', '') } };
        } else {
            return '';
        }
    }

    //Dispaly popup
    public viewRegimenYrlyAllMonthsCalendar() {
        this.displayAllMonthsWithSelectedDates();
        this.pnlRegimenYearlyCalendar_AllMonthsModal.show();

    }

    public hideRegimenYrlyAllMonthsCalendar() {
        this.pnlRegimenYearlyCalendar_AllMonthsModal.hide();

    }

    public displayAllMonthsWithSelectedDates() {

        if (this.isUserModifiedDate != true) {
            if (this.selectedScheduleType == 'Yearly') {

                var arrSelectedDates;
                //alert(this.selectedDatesForYearly);
                //this.clearAllDateSelections();

                this.selectedDatesForYearly = '';
                var arrSelectedMonths;
                var arrSelectedDates;
                var arrSelectedDates1;
                let strSelectedMonths;
                let strSelectedDates;
                if (this.regimen.monthlyYearly != undefined) { //This is for page load
                    arrSelectedMonths = this.regimen.monthlyYearly.split('|');
                    arrSelectedMonths.forEach((item, index) => {
                        strSelectedMonths = item;
                        //alert(strSelectedMonths);
                        arrSelectedDates = strSelectedMonths.split('^'); //Ex: March^1,2,3,4

                        arrSelectedDates.forEach((item, index) => {
                            localStorage.setItem(item, arrSelectedDates[1]); //store dates for selected month
                            //$("#monthList option:'"+arrSelectedDates[0]+"'").css("background-color", "green");
                            //if (arrSelectedDates[0] == selectedMonth) {
                            //localStorage.setItem(selectedMonth, arrSelectedDates[1]); //store dates for selected month
                            //console.log(item); // 9, 2, 5
                            //console.log(index); // 0, 1, 2
                            if (index != 0) {
                                strSelectedDates = item;
                                arrSelectedDates1 = strSelectedDates.split(',');
                                arrSelectedDates1.forEach((item, index) => {
                                    $('#day' + item + 'Cell_' + arrSelectedDates[0]).addClass("selected");
                                });



                            }

                            //}

                        });

                    });


                }


               



            }

        }
        else {

             var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

             var arrRemovedDates;
                months.forEach((month, index) => {
                    //for (let i = 0; i < 31; i++) {
                    //    $('#day' + i + 'Cell_'+month).removeClass("selected");
                    //}
                    
                    if (localStorage.getItem(month+"_removedDates") != undefined) {
                        let removedDates = localStorage.getItem(month + "_removedDates");

                        var arrRemovedDates = removedDates.split(',');
                        arrRemovedDates.forEach((item, index) => {

                            $('#day' + item + 'Cell_' + month).removeClass("selected");

                        });

                    }
                    if (localStorage.getItem(month) != undefined) {
                        let selectedDates = localStorage.getItem(month);

                        var arrSelectedDates1 = selectedDates.split(',');
                        arrSelectedDates1.forEach((item, index) => {

                            $('#day' + item + 'Cell_' + month).addClass("selected");

                        });

                    }

                });
        }


    }


    //Clear fields
    clearFields() {


        $('#pnlSelectedTimeForMorning').text('');
        $('#pnlSelectedTimeForAfterNoon').text('');
        $('#pnlSelectedTimeForEvening').text('');
        $('#pnlSelectedTimeForBedTime').text('');
        this.form.controls['name'].reset();
        this.form.controls['medicationUnitsPerDose'].reset();
        this.form.controls['totalDoses'].reset();
        this.form.controls['extraDoses'].reset();
        this.form.controls['durationHours'].reset();
        this.form.controls['durationMinutes'].reset();
        this.form.controls['adherenceDays'].reset();
        this.form.controls['adherenceHours'].reset();
        this.form.controls['adherenceMinutes'].reset();
        this.form.controls['weekly'].reset();
        this.form.controls['daily'].reset();
        this.form.controls['monthly'].reset();
        this.form.controls['yearly'].reset();
        this.form.controls['interval'].reset();
        this.form.controls['event'].reset();
        this.clearLocalStorage();
        this.selectedTimeForMorning_PlainData = '';
        this.selectedTimeForAfternoon_PlainData = '';
        this.selectedTimeForEvening_PlainData = '';
        this.selectedTimeForBedTime_PlainData = '';
        this.selectedTimeForMorning = '';
        this.selectedTimeForAfternoon = '';
        this.selectedTimeForEvening = '';
        this.selectedTimeForBedTime = '';
        //this.setDefaultTimeForDosageWindow();
        //$('#adherenceHours_Morning').val(this.defaultMorningFromTime);
        //$('#adherenceMinutes_Morning').val(this.defaultMorningFromMins);
        //$('#adherenceHours_Afternoon').val(this.defaultAfternoonFromTime);
        //$('#adherenceMinutes_Afternoon').val(this.defaultAfternoonFromMins);
        //$('#adherenceHours_Evening').val(this.defaultEveningFromTime);
        //$('#adherenceMinutes_Evening').val(this.defaultEveningFromMins);
        //$('#adherenceHours_BedTime').val(this.defaultBedTimeFromTime);
        //$('#adherenceMinutes_BedTime').val(this.defaultBedTimeFromMins);
        //$('#adherenceAMPM_Morning').val('AM');
        //$('#adherenceAMPM_Afternoon').val('PM');
        //$('#adherenceAMPM_Evening').val('PM');
        //$('#adherenceAMPM_BedTime').val('PM');
        //$('timeSlotPnl_1_MORNING').remove();
    }
}
