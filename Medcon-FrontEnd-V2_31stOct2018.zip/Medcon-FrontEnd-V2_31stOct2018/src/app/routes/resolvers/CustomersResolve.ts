import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Customer } from '../../models/customer';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerService } from '../../services/customer.service';
import { Pagination } from '../../models/pagination';

@Injectable()
export class CustomersResolve implements Resolve<(Pagination<Customer>)> {
	constructor(private customerService: CustomerService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(Pagination<Customer>)>
		| Promise<(Pagination<Customer>)>
		| (Pagination<Customer>) {
		return this.customerService.getCustomers();
	}
}
