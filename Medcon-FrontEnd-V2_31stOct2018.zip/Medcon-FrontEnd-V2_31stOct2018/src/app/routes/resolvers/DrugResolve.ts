import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DrugService } from '../../services/drug.service';
import { Drug } from '../../models/drug';

@Injectable()
export class DrugResolve implements Resolve<Drug> {
	constructor(private drugService: DrugService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Drug> | Promise<Drug> | Drug {
		return this.drugService.getDrug(route.params['id']);
	}
}
