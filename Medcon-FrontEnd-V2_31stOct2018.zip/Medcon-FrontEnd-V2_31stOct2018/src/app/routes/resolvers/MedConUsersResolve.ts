import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserService } from '../../services/user.service';
import { MedConUser } from '../../models/medconuser';
import { Pagination } from '../../models/pagination';

@Injectable()
export class MedConUsersResolve implements Resolve<(Pagination<MedConUser>)> {
	constructor(private userService: UserService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(Pagination<MedConUser>)>
		| Promise<(Pagination<MedConUser>)>
		| (Pagination<MedConUser>) {
		return this.userService.getMedConUsers();
	}
}
