import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ReportService } from '../../services/report.service';
import { CurrentUserService } from '../../services/currentuser.service';
import { UserRole } from '../../models/userrole';
import { ReportSchedule } from '../../models/reportschedule';

@Injectable()
export class ReportSchedulesResolve implements Resolve<ReportSchedule[]> {
	constructor(private reportService: ReportService, private currentUserService: CurrentUserService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<ReportSchedule[]> | Promise<ReportSchedule[]> | ReportSchedule[] {

		return this.currentUserService.getRole().flatMap((result) => {
			if (result === UserRole.CustomerAdmin || result === UserRole.CustomerUser) {
				return this.reportService.getSchedules();
			}
			return Observable.of(null);
		});
	}
}
