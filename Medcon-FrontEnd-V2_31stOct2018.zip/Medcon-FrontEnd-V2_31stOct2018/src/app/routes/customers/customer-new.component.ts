import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerType } from '../../models/customertype';
import { CustomerService } from '../../services/customer.service';
import { CustomerRequest } from '../../requests/customerrequest';
import { Observable } from 'rxjs/Observable';

@Component({
	templateUrl: './customer-new.component.html'
})

export class CustomerNewComponent {
	public errorMessage: string;
	public form: FormGroup;
	public showErrors: boolean;
	public years = [];
	public types: CustomerType[];

	constructor(public templateService: TemplateService,
		private router: Router, private fb: FormBuilder, private customerService: CustomerService) {
		// Years
		for (let i = new Date().getFullYear(); i <= new Date().getFullYear() + 1; i++) {
			this.years.push(i);
		}

		this.form = fb.group({
			name: ['', [Validators.required, Validators.pattern('[A-Za-z ]{3,45}')]],
			type: ['', Validators.required],
		});

		customerService.getCustomerTypesAll().subscribe((types) => this.types = types);
	}

	public onSubmit(): void {
		if (this.form.invalid) {
			this.showErrors = true;
		} else {
			let request = new CustomerRequest(
				this.form.value.name,
				this.form.value.type
			);

			this.customerService.createCustomer(request).subscribe(
				(response) => {
					this.form.markAsPristine();
					this.router.navigate(['/customers', response.id, 'edit']);
				},
				(err) => {
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

	public goBack(): void {
		this.form.markAsPristine();
		this.router.navigate(['/customers']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}
}
