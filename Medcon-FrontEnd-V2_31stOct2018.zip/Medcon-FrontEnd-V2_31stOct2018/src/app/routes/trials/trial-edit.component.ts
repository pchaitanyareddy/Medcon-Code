import { Component, HostListener, OnInit, ViewChild, ChangeDetectorRef, Compiler } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import 'rxjs/add/operator/switchMap';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialService } from '../../services/trial.service';
import { PatientService } from '../../services/patient.service';
import { LabelService } from '../../services/label.service';
import { Trial } from '../../models/trial';
import { Drug } from '../../models/drug';
import { Regimen } from '../../models/regimen';
import { Customer } from '../../models/customer';
import { UserRole } from '../../models/userrole';
import { Site } from '../../models/site';
import { PairDrugRegimenRequest } from '../../requests/pair-drug-regimen-request';
import { TrialRequest } from '../../requests/trial-request';
import { TrialLabelsRequest } from '../../requests/trial-labels-request';
import { TrialContainersRequest } from '../../requests/trial-containers-request';
import { TrialOptionsRequest } from '../../requests/trial-options-request';
import { TrialGroupRequest } from '../../requests/trialgroup-request';
import { SiteRequest } from '../../requests/site-request';
import { TrialPatientAlertsRequest } from '../../requests/trial-patient-alerts-request';
import { Observable } from 'rxjs/Observable';
import { Patient } from '../../models/patient';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { TrialGroup } from '../../models/trialgroup';
import { SubscriptionRequest } from '../../requests/Subscription-request';
import {TrailGroupAssociateRequest} from '../../requests/trailgroupAssociate-request';
import {TrialgroupAddAssociateRequest} from '../../requests/trialgroupAddAssociate-request';
import {TrialgroupAssociateSiteRequest} from '../../requests/trialgroupAssociateSite-request';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { DisassociateSiteRequest } from '../../requests/disassociateSite-request';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
//import { TrialOverview } from '../../models/trialoverview';
import _ from 'lodash';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    selector: 'tooltip-overview-example', //for tooltip
    templateUrl: './trial-edit.component.html?v=${new Date().getTime()}',
    styleUrls: ['./trial-edit.component.scss?v=${new Date().getTime()}']
})

export class TrialEditComponent implements OnInit {
    @ViewChild('deletePatientModal') public deletePatientModal: ModalDirective;
    @ViewChild('deleteModalDRPair') public deleteModalDRPair: ModalDirective;
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('dataMatrixModal') public dataMatrixModal: ModalDirective;
    @ViewChild('trialMenu') public trialMenu: TabsetComponent;
    @ViewChild('viewTitrateModal') public viewTitrateModal: ModalDirective;
    @ViewChild('changeStatusModal') public changeStatusModal: ModalDirective;
    @ViewChild('disassociateModal') public disassociateModal: ModalDirective;
    @ViewChild('disassociateModal_Site') public disassociateModal_Site: ModalDirective;
    @ViewChild('titrateModal') public titrateModal: ModalDirective;
    @ViewChild('viewContainerDetailsModal') public viewContainerDetailsModal: ModalDirective;
    @ViewChild('patientAlertsHelpModal') public patientAlertsHelpModal: ModalDirective;
    //public trialOverview: TrialOverview;
    public deleteType: string;
    public disassociateType: string;
    public deleteObject: any;
    public trial: Trial;
    public drugs: Drug[];
    public regimens: Regimen[];
    public trialGroups: TrialGroup[];
    public sites: Site[];
    public containerLimit = 5;
    public activeContainer: Object;
    public form: FormGroup;
    public formPair: FormGroup;
    public subscribe_for_notificationForm: FormGroup;
    public formLabels: FormGroup;
    public formAssignContainers: FormGroup;
    public formAssociateTrialGroupform: FormGroup;
    public addTrialGroupform: FormGroup;
    public formAssociateSiteform: FormGroup;
    public addSiteform: FormGroup;
    public formTrialOptions: FormGroup;
    public patientAlertsForm: FormGroup;
    public dataMatrixCodes = [];
    public showErrors: boolean;
    public showErrors_formPair: boolean;
    public showErrors_FormAssociateTrialGroupform: boolean;
    public showErrors_addTrialGroupform: boolean;
    public showErrors_formAssociateSiteform: boolean;
    public showErrors_formTrialOptions: boolean;
    public showErrors_PatientAlertsForm: boolean;
    public error: any;
    public assignDrug: Drug;
    public assignTrialGroup: TrialGroup;
    public assignSite: Site;
    public assignRegimen: Regimen;
    public assignDrugRegimenError: String;
    public assignDrugRegimenSuccess: boolean;
    public drugRegimenPairs = [];
    public patientList = [];
    public customer: Customer;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    //public sites: Site[];
    public successMessage: string;
    public errorMessage: string;
    public durationError: boolean;
    public userId: number;
    public earlyDosingThreshholdError: boolean;
    public days = [];
    public hours = [];
    public minutes = [];
    public defaultDays: number;
    public defaultHours: number;
    public defaultMinutes: number;
    public selectedTrialGroupId: number;
    public SelectedsiteId: number;
    public selectedDrugRegimenPairId: number;
    public isTitrated: boolean;
    public patientAlert: any;
    public DRList: any;
    public DRFilteredList: any;
    public selectedDrug: string;
    public selectedRegimen: string;
    public selectedStartDate: string;
    public selectedEndDate: string;
    public drugRegimenPairId: number;
    public isEmailSelected_Final: boolean;
    public isSMSSelected_Final: boolean;
    public isEditDrugRegimenPair: boolean;
    public drugsFiltered: any;
    public regimensFiltered: any;
    public regimenIdOnrowclick: number;
    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public expiryDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public startDateDrugRegimenPairOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    public endDateDrugRegimenPairOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    usedContainersList: any;
    patientContainerList: any;
    patientTitrateList: any;
    patientToChangeStatus: Patient;
    associatedTrialGroupList: any;
    toggoleShowHide: string = "hidden"; 
    associatedSiteList: any;
    trialNotifications: any;
    customerId: number;
    companyId: number;
    patientAlertJsonString: string;
    containerDetailsList: any;
    errorMessage_PatientAlerts: string;
    notificationList: any;
    containerIds: string;
    isLoading: boolean;
    drugName: any;
    selectedPatientNumber: string;
    addPatientButtonMessage: string;
    constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
        private fb: FormBuilder,
        private trialService: TrialService,
        private patientService: PatientService,
        private labelService: LabelService,
        private cognitoUtil: CognitoUtil,
        private reportService: ReportService,
        private changeDetectorRef: ChangeDetectorRef,
        private _compiler: Compiler) {

        // Days
        for (let i = 0; i < 31; i++) {
            this.days.push(i);
        }
        // Hours
        for (let i = 0; i < 24; i++) {
            this.hours.push(i);
        }
        // Minutes
        for (let i = 0; i < 60; i++) {
            this.minutes.push(i);
        }

        //this.defaultDays = 0;
        //this.defaultHours = 0;
        //this.defaultMinutes = 0;
    }

    public enableViewTrialMode()
    {
        $("#btnSubmit,#btnAddDrugRegimen,#drugRegimenButton,#ancAddPatient,#pnlAddTrialGroupBtn,#btnAssociateTrialGroup,#btnAssociateSite,#btnSubmitTrialOptions,#btnSubmitNotification").css("display", "none");

    }
    public addNewEditCheckOptions(): void {

                    if(this.trial.trialNotifications.missedDose == true) {
                // $('#txtMissedDose').removeAttr('disabled');
                $('#missedDoseOccurrence').removeAttr('disabled');
            }
                    else {
                //$('#txtMissedDose').attr('disabled', 'disabled');
                $('#missedDoseOccurrence').attr('disabled', 'disabled');
            }

            if (this.trial.trialNotifications.overDose == true) {

                //$('#txtOverDose').prop('disabled', false);
                //$('#overDoseOccurrence').prop('disabled', false);
                //$('#txtOverDose').removeAttr('disabled');
                $('#overDoseOccurrence').removeAttr('disabled');
            }
            else {
                //$('#txtOverDose').prop('disabled', true);
                //$('#overDoseOccurrence').prop('disabled', true);
                // $('#txtOverDose').attr('disabled', 'disabled');
                $('#overDoseOccurrence').attr('disabled', 'disabled');
            }


            if (this.trial.trialNotifications.lateDose == true) {

                //$('#txtLateDose').prop('disabled', false);

                //$('#lateDoseOccurrence').prop('disabled', false);
                //$('#txtLateDose').removeAttr('disabled');
                $('#lateDoseOccurrence').removeAttr('disabled');
            }
            else {
                // $('#txtLateDose').prop('disabled', true);
                //$('#txtLateDose').attr('disabled', 'disabled');
                $('#lateDoseOccurrence').attr('disabled', 'disabled');
            }

            if (this.trial.trialNotifications.underDose == true) {

                //$('#txtUnderDose').removeAttr('disabled', false);
                //$('#underDoseOccurrence').prop('disabled', false);
                //$('#txtUnderDose').removeAttr('disabled');
                $('#underDoseOccurrence').removeAttr('disabled');
            }
            else {
                //$('#txtUnderDose').attr('disabled', 'disabled');
                //$('#underDoseOccurrence').prop('disabled', true);
                //$('#txtUnderDose').attr('disabled', 'disabled');
                $('#underDoseOccurrence').attr('disabled', 'disabled');
            }

            if (this.trial.trialNotifications.excessiveManualDose == true) {

                //$('#txtExcesManualDose').prop('disabled', false);
                //$('#excessiveManualDoseOccurrence').prop('disabled', false);
                //$('#txtExcesManualDose').removeAttr('disabled');
                $('#excessiveManualDoseOccurrence').removeAttr('disabled');
            }
            else {
                //$('#txtUnderDose').prop('disabled', true);
                //$('#underDoseOccurrence').prop('disabled', true);
                //$('#txtExcesManualDose').attr('disabled', 'disabled');
                $('#excessiveManualDoseOccurrence').attr('disabled', 'disabled');
            }

    }
    public ngAfterViewInit(): void {

        if (this.trial.turnoffManualDosing == "1") {
            $('#pnlTurnOffPanel').removeClass('btn-group').addClass('btn-group selected');
            $("#turnOffManualDosing").prop('checked', true);
        }
        else {

            $('#pnlTurnOffPanel').removeClass('btn-group selected').addClass('btn-group');
            $("#turnOffManualDosing").prop('checked', false);
        }
        
        if (localStorage.getItem(String(this.trial.id)) =='trial patient alerts exists' ) {
           
            $("#preDoseAlert,#onTimeDoseAlert,#thresholdDueAlert,#thresholdWindow,#preDoseAlertDays,#preDoseAlertHours,#preDoseAlertMinutes,#thresholdDueAlertDays,#thresholdDueAlertHours,#thresholdDueAlertMinutes,#thresholdWindowAlertDays,#thresholdWindowAlertHours,#thresholdWindowAlertMinutes").attr("disabled", "disabled");
        }




        //$('#datatable_drugRegimenPair').DataTable();
        //$('#datatable_TrialPatientsList').DataTable();
        //$('#datatable_TitrateDetails').DataTable();
        //$('#datatable_associatedTrialGroupList').DataTable();


        //$('#datatable_drugRegimenPair').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        //$('#datatable_TrialPatientsList').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        //$('#datatable_TitrateDetails').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});

        //$('#datatable_associatedTrialGroupList').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});


        //$('#datatable_UsedContainers').DataTable({
        //    dom: 'lBfrtip',
        //    buttons: [
        //        'csv', 'print'
        //    ]
        //});


        this.loadDrugRegimenPairList();

        this.loadAssociateTrialGroupList();

        this.loadTrialContainers();

        this.loadSiteList();

        this.loadTrialPatientList();
        this.addNewEditCheckOptions();

        //17th sept 2018 to enable Trial View Model
        //alert(localStorage.getItem(String(this.trial.id)+"_ViewTrial"));
        if (localStorage.getItem(String(this.trial.id) + "_ViewTrial") != undefined && localStorage.getItem(String(this.trial.id) + "_ViewTrial") == "ViewTrial") {
            this.enableViewTrialMode();
            $('#title').text('View Trial - '+this.trial.name);
        }

        this.addPatientButtonMessage = (this.trial.trialAdherenceTarget == null || this.trial.trialAdherenceTarget == undefined || this.trial.trialAdherenceTarget == 0) ? "Please setup trial options first to Add Patient" : '';
        $("#btnAddPatient").attr("title", this.addPatientButtonMessage);
        
    }

    public getTrialGroupList()
    {

        this.trialService.getAllTrialGroups(this.trial.id, this.companyId).subscribe(
            (response) => {
                this.trialGroups = response;

            },
            (err) => {
                this.errorMessage = err;

            });

    }

    public ngOnInit(): void {
        this._compiler.clearCache();
        this.isLoading = false;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.trial = this.route.snapshot.data['trial'];
        this.customer = this.route.snapshot.data['customer'];
        this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
        this.customerId = this.userId;
        //this.userId = this.route.snapshot.params['customer_id'];
        this.companyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        //alert(this.trial.id);
        //alert(this.customer.id);
        //this.drugs = this.route.snapshot.data['drugs'];
        //this.regimens = this.route.snapshot.data['regimens'];
        //this.sites = this.route.snapshot.data['sites'];
        //this.trial.labels = this.route.snapshot.data['labels'];
        //this.trial.containers = this.route.snapshot.data['containers'];
        this.trial.associatedTrialGroups = this.route.snapshot.data['associatedTrialGroups']; 
        this.trial.associatedSites = this.route.snapshot.data['associatedSites'];
        this.trial.trialNotifications = this.route.snapshot.data['trialNotifications'];  
        this.patientAlert = this.route.snapshot.data['patientAlert'];
        this.notificationList = this.route.snapshot.data['notifications'];
        //this.trialOverview = this.route.snapshot.data['trialOverview'];
        //this.trial.trialNotifications = [
        //    //{ id: 1, missedDose: false, missedDoseContent: 'Test missedDoseContent', missedDoseOccurances: '1', isOverDoseSelected: false, overDoseContent: 'Test content', overDoseOccurances: '1', isLateDoseSelected: false, lateDoseContent: 'Test content', lateDoseOccurances: '1', isUnderDoseSelected: false, underDoseContent: 'Test content', underDoseOccurances: '1', isExcessiveManualDoseSelected: false, excessiveManualDoseContent: 'Test content', excessiveManualDoseOccurances: '1' },

        //]
        //alert(this.patientAlert);
        localStorage.setItem('TRIAL_LEVEL_COMPANY_ID', this.trial.companyId); //TO GET trial company id while adding patient
      

        this.addNewEditCheckOptions();
            
        this.getTrialGroupList();
        
      
        this.trialService.getAllSites(this.trial.id, this.companyId).subscribe(
            (response) => {
                this.sites = response;

            },
            (err) => {
                this.errorMessage = err;

            });
           
        this.usedContainersList = [
           
        ]

        this.patientContainerList = [
            
        ]
        
        this.patientTitrateList = [
            
        ]
        
        this.trial.associatedSites = [
            
        ]

        //12th Feb 2018
        //To get the list of drugs
        this.trialService.getAllDrugs(this.companyId).subscribe(
            (response) => {
                this.drugs = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        //To get the list of regimens
        this.trialService.getAllRegimens(this.companyId).subscribe(
            (response) => {
                this.regimens = response;

            },
            (err) => {
                this.errorMessage = err;

            });


        //20th Dec 2017
        this.trial.patients = this.route.snapshot.data['patients'];

        //this.setDrugRegimenPairs();
        //To convert dateformat from mm/dd/yyyy to yyyy-dd-mm
        //var startDate = this.trial.startDate.split("/"); //ex: 03/31/2018
        //var endDate = this.trial.end_date.split("/");
        var trialStartDate = (this.trial.startDate!=null)?this.trialService.convertDateToCalendarFormat(this.trial.startDate):''; //startDate[2] + '-' + startDate[0] + '-' + startDate[1]; //2018-01-03
        var trialEndDate = (this.trial.end_date!=null)?this.trialService.convertDateToCalendarFormat(this.trial.end_date):''; //endDate[2] + '-' + endDate[0] + '-' + endDate[1]; //2018-31-03

      
        var startDate1 = new Date(this.trial.startDate);
        var endDate1 = new Date(this.trial.end_date);
        var todayDate = new Date();
        //alert(startDate1);
        //alert(todayDate);
        //if (startDate1.getDate() < todayDate.getDate()) {
        if (startDate1 < todayDate) {
            let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
            copy.componentDisabled = true;
            this.startDateOptions = copy;
           

        }

       
        
        this.form = this.fb.group({
            //site: [this.trial.site.id, Validators.required],
            name: [this.trial.name, Validators.required],
            startDate: [this.dateForView(trialStartDate), Validators.required],
            endDate: [this.dateForView(trialEndDate), Validators.required],
            //adherenceTarget: [this.trial.adherenceTarget,
            //Validators.pattern(/^(\d{0,2}(\.\d{1,2})?|100(\.00?)?)$/)],
            //enrolmentTarget: [this.trial.enrolmentTarget],
            //earlyDosingThresholdTime: [this.trial.earlyDosingThresholdTime, Validators.required],
            status: [this.trial.status, Validators.required]
        });
        //Added by ramesh on 20th Oct 2017
        let expiryDateTime1 = new Date();
        let day = expiryDateTime1.getDate();
        let month = expiryDateTime1.getMonth() + 1;
        //let year = expiryDateTime1.getFullYear();
        //let today = year + '-' + month + '-' + day;
        //End
       
       
        this.trialService
            .getNotification(this.trial.id)
            .subscribe(
            (response) => {

                $('#missedDose').val(response.missedDose)
                $('#missedDoseOccurrence').val(response.missed_Dose_Occurrence);
                $('#overDose').val(response.overDose)
                $('#overDoseOccurrence').val(response.overDoseOccurrence);
                $('#lateDose').val(response.lateDose)
                $('#lateDoseOccurrence').val(response.lateDoseOccurrence);
                $('#underDose').val(response.underDose)
                $('#underDoseOccurrence').val(response.underDoseOccurrence);
                $('#excessiveManualDose').val(response.excessiveManualDose)
                $('#excessiveManualDoseOccurrence').val(response.excessiveManualDoseOccurrence);
              
                let isEmailSelected;
                let isSMSSelected;
                if (response.notificationType == '1') {
                    isEmailSelected = true;
                    
                    $("#pnlNotificationTypeEmail").removeClass("btn-group").addClass("btn-group selected");
                    $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");

                }

                else if (response.notificationType == '2') {

                    isSMSSelected = true;
                    $("#pnlNotificationTypeSMS").removeClass("btn-group").addClass("btn-group selected");
                    $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
                }
                else if (response.notificationType == '3') {

                    isEmailSelected = true;
                    $("#pnlNotificationTypeEmail").removeClass("btn-group").addClass("btn-group selected");
                    isSMSSelected = true;
                    $("#pnlNotificationTypeSMS").removeClass("btn-group").addClass("btn-group selected");
                }
                else {
                    isEmailSelected = false;
                    isSMSSelected = false;
                }
                if (response.missedDose == true) {

                    $("#pnlMissedDose").removeClass("btn-group").addClass("btn-group selected");
                }
                else {
                    $("#pnlMissedDose").addClass("btn-group")
                }
                if (response.overDose == true) {
                    $("#pnlOverDose").removeClass("btn-group").addClass("btn-group selected")
                }
                else {
                    $("#pnlOverDose").addClass("btn-group")
                }
                if (response.lateDose == true) {
                    $("#pnlLateDose").removeClass("btn-group").addClass("btn-group selected")
                }
                else {
                    $("#pnlLateDose").addClass("btn-group")
                }
                if (response.underDose == true) {
                    $("#pnlUnderDose").removeClass("btn-group").addClass("btn-group selected")
                }
                else {
                    $("#pnlUnderDose").addClass("btn-group")
                }
                if (response.excessiveManualDose == true) {
                    $("#pnlExcessiveManualDose").removeClass("btn-group").addClass("btn-group selected");
                }
                else {
                    $("#pnlExcessiveManualDose").addClass("btn-group")
                }
                
                if (response.missedDose == true)
                    $('#missedDoseOccurrence').removeAttr('disabled');
                if (response.overDose == true)
                    $('#overDoseOccurrence').removeAttr('disabled');
                if (response.underDose == true)
                    $('#underDoseOccurrence').removeAttr('disabled');
                if (response.lateDose == true)
                    $('#lateDoseOccurrence').removeAttr('disabled');
                if (response.excessiveManualDose == true)
                    $('#excessiveManualDoseOccurrence').removeAttr('disabled');

                this.addNewEditCheckOptions();
               

            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
        );
        let isEmailSelected ;
        let isSMSSelected ;
        if (this.trial.trialNotifications.notificationType == '1') {
            
            isEmailSelected = true;
            
            $("#pnlNotificationTypeEmail").removeClass("btn-group").addClass("btn-group selected");
            $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
        }
        else if (this.trial.trialNotifications.notificationType == '2') {
            
            isSMSSelected = true;
            $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
            $("#pnlNotificationTypeSMS").removeClass("btn-group").addClass("btn-group selected");
        }
        else if (this.trial.trialNotifications.notificationType == '3') {
            
            isEmailSelected = true;
            isSMSSelected = true;
            $("#pnlNotificationTypeEmail").removeClass("btn-group").addClass("btn-group selected");
            $("#pnlNotificationTypeSMS").removeClass("btn-group").addClass("btn-group selected");
        }
        else {
            
            //alert("Else");
            isEmailSelected = false;
            isSMSSelected = false;
            $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
            $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
        }
        //if (localStorage.getItem(String(this.trial.id) + "_notifications") == 'No trial notifications') {
        //    alert("No trial notifications");
        //    isEmailSelected = false;
        //    isSMSSelected = false;
        //    $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
        //    $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
        //}

        this.subscribe_for_notificationForm = this.fb.group({
            
            missedDose: [this.trial.trialNotifications.missedDose],
            txtMissedDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[0].message : this.notificationList[0].message],
            missedDoseOccurrence: [this.trial.trialNotifications.missedDoseOccurances],
            overDose: [this.trial.trialNotifications.overDose],
            txtOverDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[1].message : this.notificationList[1].message],
            overDoseOccurrence: [this.trial.trialNotifications.overDoseOccurances],
            lateDose: [this.trial.trialNotifications.lateDose],
            txtLateDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[2].message : this.notificationList[2].message],
            lateDoseOccurrence: [this.trial.trialNotifications.lateDoseOccurances],
            underDose: [this.trial.trialNotifications.underDose],
            txtUnderDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[3].message : this.notificationList[3].message],
            underDoseOccurrence: [this.trial.trialNotifications.underDoseOccurances],
            excessiveManualDose: [this.trial.trialNotifications.excessiveManualDose],
            txtExcesManualDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[4].message : this.notificationList[4].message],
            excessiveManualDoseOccurrence: [this.trial.trialNotifications.excessiveManualDoseOccurances],
            chkNotificationTypeEmail: [isEmailSelected],
            chkNotificationTypeSMS: [isSMSSelected],


        });
      
        //$("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
        //$("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
        let preDoseAlertDuration = this.convertMinutes(this.patientAlert.preDoseAlertTime);
        let thresholdDueAlertTimeDuration = this.convertMinutes(this.patientAlert.thresholdDueAlertTime);
        let thresholdWindowAlertTimeDuration = this.convertMinutes(this.patientAlert.thresholdWindowAlertTime);

        let preDoseDays = preDoseAlertDuration.days;
        let preDoseHours = preDoseAlertDuration.hours;
        let preDoseMinutes = preDoseAlertDuration.minutes;


        let onTimeDoseDays = preDoseAlertDuration.days;
        let onTimeDoseHours = preDoseAlertDuration.hours;
        let onTimeDoseMinutes = preDoseAlertDuration.minutes;



        let thresholdDueAlertDays = thresholdDueAlertTimeDuration.days;
        let thresholdDueAlertHours = thresholdDueAlertTimeDuration.hours;
        let thresholdDueAlertMinutes = thresholdDueAlertTimeDuration.minutes;


        let thresholdWindowAlertDays = thresholdWindowAlertTimeDuration.days;
        let thresholdWindowAlertHours = thresholdWindowAlertTimeDuration.hours;
        let thresholdWindowAlertMinutes = thresholdWindowAlertTimeDuration.minutes;

        this.formPair = this.fb.group({
            drug: ['', Validators.required],
            regimen: ['', Validators.required],
            //expiryDate: [this.dateForView(today), Validators.required],
            startDateDrugRegimenPair: ['', Validators.required],
            endDateDrugRegimenPair: [this.dateForView(trialEndDate), Validators.required],
            preDoseAlert: [(this.patientAlert.preDoseAlertText == undefined) ? this.patientAlert[1].message : this.patientAlert.preDoseAlertText, Validators.required],
            onTimeDoseAlert: [(this.patientAlert.ontimeDoseAlertText == undefined) ? this.patientAlert[0].message : this.patientAlert.ontimeDoseAlertText, Validators.required],
            thresholdDueAlert: [(this.patientAlert.thresholdDueAlertText == undefined) ? this.patientAlert[2].message  : this.patientAlert.thresholdDueAlertText],
            thresholdWindow: [(this.patientAlert.thresholdWindowAlertText == 'null') ? '': this.patientAlert.thresholdWindowAlertText],
            preDoseAlertDays: [(this.patientAlert.preDoseAlertText == undefined) ? 0 : preDoseDays],
            preDoseAlertHours: [(this.patientAlert.preDoseAlertText == undefined) ? 0 : preDoseHours],
            preDoseAlertMinutes: [(this.patientAlert.preDoseAlertText == undefined) ? this.patientAlert[1].time : preDoseMinutes],
            thresholdDueAlertDays: [(this.patientAlert.thresholdDueAlertText == undefined) ? 0 : thresholdDueAlertDays],
            thresholdDueAlertHours: [(this.patientAlert.thresholdDueAlertText == undefined) ? 0 : thresholdDueAlertHours],
            thresholdDueAlertMinutes: [(this.patientAlert.thresholdDueAlertText == undefined) ? this.patientAlert[2].time : thresholdDueAlertMinutes],
            thresholdWindowAlertDays: [(this.patientAlert.thresholdWindowAlertText == undefined) ? 0 : thresholdWindowAlertDays],
            thresholdWindowAlertHours: [(this.patientAlert.thresholdWindowAlertText == undefined) ? 0 : thresholdWindowAlertHours],
            thresholdWindowAlertMinutes: [(this.patientAlert.thresholdWindowAlertText == undefined) ? 0 : thresholdWindowAlertMinutes],

        });

      

        //this.isEmailSelected_Final = isEmailSelected;
        //this.isSMSSelected_Final = isSMSSelected;
        this.formLabels = this.fb.group({
            additionalLabels: ['', Validators.pattern('[0-9]+')]
        });

        this.formAssignContainers = this.fb.group({
           // pair: [this.drugRegimenPairs[0].id, Validators.required],
            containerNumbers: [''],
            containerNumbersFile: ['']
        });

        this.formAssociateTrialGroupform = this.fb.group({
            trialGroupName: ['', Validators.required]

        });

        this.addTrialGroupform = this.fb.group({
            trialGroupName: ['', Validators.required]

        });

        this.formAssociateSiteform = this.fb.group({
            siteName: ['', Validators.required]

        });

        this.addSiteform = this.fb.group({
            siteName: ['', Validators.required]

        });
        
        
        //Added by ramesh on 29th Dec 2017
        this.formTrialOptions = this.fb.group({
            trialAdherenceTarget: [this.trial.trialAdherenceTarget, [Validators.required]],
            minPatientAdherenceTarget: [this.trial.minimumPatientAdherenceTarget, [Validators.required]],
            patientEnrollmentTarget: [this.trial.patientEnrollementTarget, [Validators.required]],
            turnOffManualDosing: [this.trial.turnoffManualDosing],

        });
        
        

       


        
        setTimeout(() => {
            
            if (this.route.snapshot.queryParams['tab'] === 'patients') {
                let index = (this.currentUserRole === this.UserRole.MedConAdmin) ? 0 : 2;
                this.trialMenu.tabs[2].active = true;
            }
        });

       

        // Make sure start date can't come after end date
        if (this.form.value.endDate.date!=undefined)
        this.setStartDateDisableSince(this.form.value.endDate.date);

        // Make sure end date can't be set earlier than start date
        if(this.form.value.startDate.date != undefined)
            this.setEndDateDisableUntil(this.form.value.startDate.date);
        var todayDate = new Date();
        var month1 = todayDate.getMonth();
        month1 = Number(month1) + 1;
        var day1 = todayDate.getDate();
        day1 = Number(day1) - 1;
        let date = this.dateForView(todayDate.getFullYear() + '-' + month1 + '-' + day1);
        this.setStartDateDisableUntil(date.date);

        //Disable the drug regimen pair tab start and end date based on trial start and end date
        // Make sure start date can't come after end date
        //this.setStartDateDrugRegimenPairDisableSince(this.form.value.endDate.date);

        //this.setEndDateDrugRegimenPairDisableSince(this.form.value.endDate.date);
        // Make sure end date can't be set earlier than start date
        //this.setEndDateDrugRegimenPairDisableUntil(this.form.value.startDate.date);

        // Make sure drug regimen start date can't be set earlier than trial start date
        //alert('hh'+this.form.value.startDate.date);
        if (this.form.value.startDate.date != undefined) {
            let d = this.convertDate(this.form.value.startDate.date).split('-');
            day = Number(d[2]) - 1; //day
            let date = this.dateForView(d[0] + '-' + d[1] + '-' + day);//2018-4-12
            var startDate1 = new Date(this.trial.startDate);
            var todayDate = new Date();
           
            if (startDate1 < todayDate) {   //If the trial start date is less than current system date, then allow user to select drug regimen start date as current system date
                
                var currentSystemDateMonth = todayDate.getMonth();
                currentSystemDateMonth = Number(currentSystemDateMonth) + 1;
                var currentSystemDateDay = todayDate.getDate();
                currentSystemDateDay = Number(currentSystemDateDay) - 1;
                date = this.dateForView(todayDate.getFullYear() + '-' + currentSystemDateMonth + '-' + currentSystemDateDay);
            }
            
            this.setDRStartDateDisableUntilTrailStartDate(date.date);

            let d1 = this.convertDate(this.form.value.endDate.date).split('-');
            let day1 = Number(d1[2]) + 1;
            let date1 = this.dateForView(d1[0] + '-' + d1[1] + '-' + day1);
            this.setDREndDateDisableSinceTrialEndDate(date1.date);

            //this.setDRStartDateDisableSinceTrialEndDate(this.form.value.endDate.date);
            this.setDRStartDateDisableSinceTrialEndDate(date1.date);
            this.setDREndDateDisableUntil(date.date);
        }

        //if (this.form.value.endDate.date != undefined) {
        //    let d1 = this.convertDate(this.form.value.endDate.date).split('-');
        //    day1 = Number(d1[2]) ; //day
        //    let date1 = this.dateForView(d1[0] + '-' + d1[1] + '-' + day1);//2018-4-12
        //    this.setDREndDateDisableSinceTrialEndDate(date1.date);
        //}

        //End

        
    }

    
    public moreContainers(): void {
        this.containerLimit = 6;
    }
    public goBack(): void {
        this.isLoading = true;
        this.form.markAsPristine();
        this.router.navigate(['/' + this.companyId, 'trials']);
    }
    public cancelForm(): void {
        this.form.markAsPristine();
        this.router.navigate([this.customer.id, 'trials']);
    }

    public populateContainerPopover(patient): void {
        //this.activeContainer = container;
        this.patientContainerList = [
            //{ id: 1, containerNumber: 'Container1' },
            //{ id: 2, containerNumber: 'Container2' },
            //{ id: 3, containerNumber: 'Container5' },
        ]
    }

    public enableErrorMsg()
    {
        $('.alert').css("display", "block");
    }
    public onSubmit() {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg(); 
        if (this.form.invalid) {
            this.showErrors = true;
           
        }
        else if (this.trialService.IsStartDateGreaterThanEndDate(this.convertDate(this.form.value.startDate.date), this.convertDate(this.form.value.endDate.date))) {

            this.showErrors = true;
            this.errorMessage = "Start Date should be Less than End Date"
        }
        else {
            this.isLoading = true;
            let request = new TrialRequest(
                this.form.value.name,
                this.convertDate(this.form.value.startDate.date),
                this.convertDate(this.form.value.endDate.date),
                Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'))
            );

            this.trialService
                .updateTrial(this.trial.id, request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.form.markAsPristine();
                    this.successMessage = 'Trial has been successfully updated';
                    $(window).scrollTop(5);
                    //$("#success-alert").css("display", "block");
                    //$("#success-alert").fadeTo(2000, 500).slideUp(500, function () {
                    //    $("#success-alert").slideUp(500);
                    //});
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage_PatientAlerts = err;
                    this.errorMessage = err;
                }
                );
        }
    }

    

    public submitAddLabels() {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.formLabels.invalid) {
            this.showErrors = true;
        } else {
            this.isLoading = true;
            let request = new TrialLabelsRequest(
                this.formLabels.value.additionalLabels
            );

            this.trialService.addLabels(this.trial.id, this.route.snapshot.params['customer_id'], request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.successMessage = 'Additional labels have been successfully added';
                    this.labelService
                        .getOverview(this.trial.id, this.customer.id)
                        .subscribe((labels) => this.trial.labels = labels);
                },
                (err) => {
                    this.errorMessage = err;
                }
                );
        }
    }
    


    public assignDrugRegimen(): void {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.formPair.invalid) {
            this.showErrors_formPair = true;
            if (this.formPair.value.drug == '') {
                this.assignDrugRegimenError = 'Please choose drug to pair';
            }
            else if (this.formPair.value.regimen == '')
            {
                this.assignDrugRegimenError = 'Please choose regimen to pair';

            }
            else if (this.trialService.IsStartDateGreaterThanEndDate(this.convertDate(this.formPair.value.startDateDrugRegimenPair.date), this.convertDate(this.formPair.value.endDateDrugRegimenPair.date))) {

                this.showErrors = true;
                this.errorMessage = "Start Date should be Less than End Date"
            }

            //else if (this.convertDate(this.formPair.value.startDateDrugRegimenPair.date) > this.convertDate(this.formPair.value.endDateDrugRegimenPair.date)) {
            //    this.assignDrugRegimenError = 'End Date should be higher than Start Date';

            //}

            if (this.assignDrug == undefined || this.assignRegimen == undefined) {

                this.showErrors_formPair = true;
                this.assignDrugRegimenError = 'Please choose correct drug/regimen to pair';
            }

        }
        else if (this.trialService.IsStartDateGreaterThanEndDate(this.convertDate(this.formPair.value.startDateDrugRegimenPair.date), this.convertDate(this.formPair.value.endDateDrugRegimenPair.date))) {

            this.showErrors = true;
            this.errorMessage = "Start Date should be Less than End Date"
        }
        //else if (this.convertDate(this.formPair.value.startDateDrugRegimenPair.date) > this.convertDate(this.formPair.value.endDateDrugRegimenPair.date)) {
        //    this.assignDrugRegimenError = 'End Date should be higher than Start Date';

        //}
        else {

            if (this.isEditDrugRegimenPair) //Added by ramesh on 28th Mar 2018 to update drug regimen start and end dates
            {
                this.isLoading = true;

                let jsonString = '{\r\n    \"startDateDrugRegimenPair\": \"' + this.convertDate(this.formPair.value.startDateDrugRegimenPair.date) + '\",\r\n    \"endDateDrugRegimenPair\":\"' + this.convertDate(this.formPair.value.endDateDrugRegimenPair.date) + '\"\r\n}';
                this.trialService.updateDrugRegimenPair(Number(this.drugRegimenPairId), jsonString).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.successMessage = "successfully Updated Drug Regimen Pair";
                        $(window).scrollTop(5);
                        $("#datatable_drugRegimenPair").dataTable().fnDestroy();
                        this.loadDrugRegimenPairList();
                    },
                    (err) => {
		        this.isLoading = false;
                        this.errorMessage = err;
                    });


            }
            else if (this.isTitrated) {
                //alert('titrate action');
                // alert(this.selectedDrugRegimenPairId);
                let notificationType = (this.formPair.value.chkNotificationTypeEmail) ? 1 : 2;

                if (this.formPair.value.chkNotificationTypeEmail && this.formPair.value.chkNotificationTypeSMS) {
                    notificationType = 3;
                }
                this.isLoading = true;
                //alert(this.convertDate(this.formPair.value.startDateDrugRegimenPair.date));
                //alert(this.convertDate(this.formPair.value.endDateDrugRegimenPair.date));
                let request = new PairDrugRegimenRequest(
                    this.assignDrug.id,
                    this.assignRegimen.id,
                    this.convertDate(this.formPair.value.startDateDrugRegimenPair.date),
                    this.convertDate(this.formPair.value.endDateDrugRegimenPair.date),
                    Number(this.userId),
                    Number(this.companyId),
                    Number(this.selectedDrugRegimenPairId)
                );
                this.trialService.titrateDrugRegimenPair(Number(this.selectedDrugRegimenPairId), request).subscribe(
                    (response) => {
                        //this.assignDrugRegimenSuccess = true;
                        //this.formPair.controls['drug'].setValue('');
                        //this.formPair.controls['regimen'].setValue('');
                        //this.assignDrugRegimenError = null;
                        //this.assignDrug = null;
                        //this.assignRegimen = null;
                        this.isLoading = false;
                        this.successMessage = "successfully Updated Drug Regimen Pair";
                        $(window).scrollTop(5);
                        $("#datatable_drugRegimenPair").dataTable().fnDestroy();
                        this.loadDrugRegimenPairList();

                    },
                    (err) => {
     		        this.isLoading = false;
                        this.errorMessage = err;
                    });
            }
            else {
                if (this.assignDrug == undefined || this.assignRegimen == undefined) {

                    this.showErrors_formPair = true;
                    this.assignDrugRegimenError = 'Please choose correct drug/regimen to pair';
                }
                else {
                    this.isLoading = true;
                    let request = new PairDrugRegimenRequest(
                        this.assignDrug.id,
                        this.assignRegimen.id,
                        this.convertDate(this.formPair.value.startDateDrugRegimenPair.date),
                        this.convertDate(this.formPair.value.endDateDrugRegimenPair.date),
                        Number(this.userId),
                        Number(this.companyId)
                    );

                    //assign new regimen
                    this.trialService.pairDrugRegimen(this.trial.id, request).subscribe(
                        (response) => {
                            this.isLoading = false;
                            this.assignDrugRegimenSuccess = true;
                            this.formPair.controls['drug'].setValue('');
                            this.formPair.controls['regimen'].setValue('');
                            this.assignDrugRegimenError = null;
                            this.assignDrug = null;
                            this.assignRegimen = null;

                            // Update assigned drug/regimens list
                            //this.trialService.getTrial(this.trial.id).subscribe((trial) => {
                            //    this.drugRegimenPairs = [];
                            //    this.trial.drPairs = trial.drPairs;
                            //    this.setDrugRegimenPairs();
                            //});

                            $(window).scrollTop(5);
                            $("#datatable_drugRegimenPair").dataTable().fnDestroy();
                            //this.successMessage = "successfully created Drug Regimen Pair";
                            this.loadDrugRegimenPairList();
                        },
                        (err) => {
                            this.isLoading = false;
                            this.errorMessage = err;
                        });

                    //code for Patient alert
                    let preDoseAlertDurationDays = ((Number(this.formPair.value.preDoseAlertDays * 24)) * 60);
                    let preDoseAlertdurationHours = (Number(this.formPair.value.preDoseAlertHours * 60));
                    let preDoseAlertdurationMinutes = Number(this.formPair.value.preDoseAlertMinutes);
                    let preDoseAlertTime = preDoseAlertDurationDays + preDoseAlertdurationHours + preDoseAlertdurationMinutes;
                    let thresholdDueAlertDurationDays = ((Number(this.formPair.value.thresholdDueAlertDays * 24)) * 60);
                    let thresholdDueAlertdurationHours = (Number(this.formPair.value.thresholdDueAlertHours * 60));
                    let thresholdDueAlertdurationMinutes = Number(this.formPair.value.thresholdDueAlertMinutes);
                    let thresholdDueAlertTime = thresholdDueAlertDurationDays + thresholdDueAlertdurationHours + thresholdDueAlertdurationMinutes;
                    let thresholdWindowAlertDurationDays = ((Number(this.formPair.value.thresholdWindowAlertDays * 24)) * 60);
                    let thresholdWindowAlertdurationHours = (Number(this.formPair.value.thresholdWindowAlertHours * 60));
                    let thresholdWindowAlertdurationMinutes = (Number(this.formPair.value.thresholdWindowAlertMinutes));
                    let thresholdWindowAlertTime = thresholdWindowAlertDurationDays + thresholdWindowAlertdurationHours + thresholdWindowAlertdurationMinutes;
                    //alert("Patient alert");
                    if (localStorage.getItem(String(this.trial.id)) != undefined && localStorage.getItem(String(this.trial.id)) == 'No trial patient alerts') {
                        this.isLoading = true;
                        let request1 = new TrialPatientAlertsRequest(
                            this.formPair.value.preDoseAlert,
                            preDoseAlertTime,
                            this.formPair.value.onTimeDoseAlert,
                            this.formPair.value.thresholdDueAlert,
                            thresholdDueAlertTime,
                            this.formPair.value.thresholdWindow,
                            thresholdWindowAlertTime,
                            Number(this.userId)

                        );
                        this.preparePatientAlertsJsonString(
                            this.formPair.value.preDoseAlert,
                            preDoseAlertTime,
                            this.formPair.value.onTimeDoseAlert,
                            this.formPair.value.thresholdDueAlert,
                            thresholdDueAlertTime,
                            this.formPair.value.thresholdWindow,
                            thresholdWindowAlertTime,
                            Number(this.userId));
                        //Uncomment this when API is available
                        this.trialService
                            .saveTrialPatientAlerts(this.trial.id, this.patientAlertJsonString)
                            .subscribe(
                            (response) => {
                                this.isLoading = false;
                                //alert("Patient alert");
                                this.form.markAsPristine();
                                this.successMessage = 'Trial patient alerts have been successfully Saved';
                            },
                            (err) => {
                                this.isLoading = false;
                                this.errorMessage = err;
                            }
                            );

                        localStorage.setItem(String(this.trial.id), "");

                        $("#preDoseAlert,#onTimeDoseAlert,#thresholdDueAlert,#thresholdWindow,#preDoseAlertDays,#preDoseAlertHours,#preDoseAlertMinutes,#thresholdDueAlertDays,#thresholdDueAlertHours,#thresholdDueAlertMinutes,#thresholdWindowAlertDays,#thresholdWindowAlertHours,#thresholdWindowAlertMinutes").attr("disabled", "disabled");


                    }

                    // code for Notification subscription

                }


            }

        }

    }

    public submitAssignContainers() {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.formAssignContainers.invalid) {
            this.showErrors = true;
        } else {
            let containerNumbers = this.formAssignContainers.value.containerNumbers
                .replace(/[,;]+/g, '').split('\n').filter((e) => /\S/.test(e));
            if (containerNumbers.length <= 0) {
                this.errorMessage = 'Please enter at least 1 container number';
                return;
            }
            this.isLoading = true;
            let request = new TrialContainersRequest(
                containerNumbers,
                this.formAssignContainers.value.pair,
                !!(this.error && this.error.error === 'duplicates'),
            );

            this.alertClosed();

            this.trialService.createContainers(this.trial.id, request, this.customer.id)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.successMessage = 'Containers successfully uploaded';
                    // Update containers list
                    this.trialService.getContainers(this.trial.id, this.customer.id)
                        .subscribe((containers) => {
                            let diff = _.difference(_.map(containers.unused, 'id'), _.map(this.trial.containers.unused, 'id'));
                            let newContainers = _.filter(containers.unused, (obj) => {
                                return diff.indexOf(obj['id']) >= 0;
                            });
                            this.trial.containers = containers;
                            // Reset containers input field
                            this.formAssignContainers.controls['containerNumbers'].setValue('');
                            this.formAssignContainers.controls['containerNumbersFile'].setValue('');
                            // Populate data matrix modal
                            this.dataMatrixCodes = [];
                            for (let code of newContainers) {
                                code['code'] = response.prefix + '/' + code['id'];
                                this.dataMatrixCodes.push(code);
                            }
                            this.dataMatrixModal.show();
                        });
                },
                (err) => {
                    // Duplicates error
                    if (err.error === 'duplicates') {
                        this.errorMessage = err.message;
                        this.error = err;
                    } else {
                        // Generic error
                        this.errorMessage = err;
                    }
                }
                );
        }
    }
    //Code added by ramesh on 21st Oct 2017
    public submitTrialOptions() {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.formTrialOptions.invalid) {
            this.showErrors_formTrialOptions = true;

        }
        else if (!this.isValidNumber(Number(this.formTrialOptions.value.trialAdherenceTarget)))
        {
            this.showErrors = true;
            this.errorMessage = 'Please enter Valid Range values(0 - 100) for Trial Adherence Target';
        }
        else if (!this.isValidNumber(Number(this.formTrialOptions.value.minPatientAdherenceTarget))) {
            this.showErrors = true;
            this.errorMessage = 'Please enter Valid Range values(0 - 100) for Minimum Patient Adherence Target';
        }
        else if (Number(this.formTrialOptions.value.patientEnrollmentTarget) < 0)
        {
            this.showErrors = true;
            this.errorMessage = 'Patient Enrollment Target shouble be greater than or equal to zero';
        }
        else {
            this.isLoading = true;
            let request = new TrialOptionsRequest(
                Number(this.formTrialOptions.value.patientEnrollmentTarget),
                Number(this.formTrialOptions.value.trialAdherenceTarget),
                Number(this.formTrialOptions.value.minPatientAdherenceTarget),
                Number(this.formTrialOptions.value.turnOffManualDosing),
                Number(this.userId)
            );
            this.trialService
                .updateTrialOptions(this.trial.id, request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.formTrialOptions.markAsPristine();
                    this.successMessage = 'Trial options  has been successfully updated';
                    $(window).scrollTop(5);
                    $('#btnAddPatient').removeAttr('disabled');
                    $('#btnAddPatient').removeAttr('title');
                },
                (err) => {
		    this.isLoading = false;
                    this.errorMessage = err;
                }
                );
        }
    }

    public drugSelected(drug): void {
        this.assignDrug = drug.item;
    }

    public trialGroupSelected(trialGroup): void {
        //this.assignTrialGroup = trialGroup.item;
        this.selectedTrialGroupId = trialGroup.item.id;

    }

    public siteSelected(sites): void {
        //this.assignSite = site.item;
        this.SelectedsiteId = sites.item.id;

    }

    public regimenSelected(regimen): void {
        this.assignRegimen = regimen.item;
        this.formPair.controls['startDateDrugRegimenPair'].setValue("");
    }

    public deleteItem(deleteType, deleteObject, index?): void {
        deleteObject.index = index;
        this.deleteType = deleteType;
        this.deleteObject = deleteObject;
        this.deleteModal.show();
    }

    public hideDeleteModal(): void {
        this.deleteType = null;
        this.deleteObject = null;
        this.deleteModal.hide();
        this.viewContainerDetailsModal.hide();
    }

    public hidedeleteModalDRPair(): void {

        this.deleteModalDRPair.hide();
    }

    public hidedeletePatientModal(): void {

        this.deletePatientModal.hide();
    }

    public hideTitrateModal(): void {
        this.deleteType = null;
        this.deleteObject = null;
        this.titrateModal.hide();
    }

    public hideDataMatrixModal(): void {
        this.dataMatrixModal.hide();
    }

 

    public titrateConfirmed(): void {

        this.successMessage = 'Please assign the drug regimen pair once again';
        this.hideTitrateModal();
        $(window).scrollTop(5);
        //this.trialService.titrateDrugRegimenPair(Number(this.selectedDrugRegimenPairId)).subscribe(
        //    (response) => {
        //        //this.drugRegimenPairs.splice(deleteObject.index, 1);
        //        this.successMessage = 'Drug/Regimen pair successfully removed';
        //        this.hideTitrateModal();
        //        this.loadDrugRegimenPairList();
        //    },
        //    (err) => {
        //        this.errorMessage = err;
        //    }
        //);


    }

    public deleteConfirmedForDrugRegimenPair(): void {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        this.isLoading = true;
        let jsonString = "{\n\"userId\" :" + this.userId + "\n}";
        this.trialService.deleteDrugRegimenPair(Number(this.selectedDrugRegimenPairId), jsonString).subscribe(
            (response) => {
                this.isLoading = false;
                this.successMessage = 'Drug/Regimen pair successfully deleted';
                $(window).scrollTop(5);
                $("#datatable_drugRegimenPair").dataTable().fnDestroy();
                this.loadDrugRegimenPairList();
                //this.hideTitrateModal();
                this.hidedeleteModalDRPair();


            },
            (err) => {
                this.errorMessage = err;
            }
        );

    }

   
    public getAge(date) {
        return this.patientService.getAge(date);
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
        this.assignDrugRegimenSuccess = false;
        this.assignDrugRegimenError = null;
        this.error = null;
    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        
        //alert('onDateChange');
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);
        //alert(d[2] + '-' + d[0] + '-' + d[1]); //2018-04-13
        let day;
        if (field === 'startDR' || field === 'endDR')
        {

            //alert(this.convertDate(this.form.value.startDate.date));
            d = this.convertDate(this.form.value.startDate.date).split('-');
            day = Number(d[2]) - 1; //day
            date = this.dateForView(d[0] + '-' + d[1] + '-' + day);//2018-4-12
                //alert(d[0] + '-' + d[1] + '-' + d[2]);
        }

        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            } else if (field === 'end') {
                this.setStartDateDisableSince(date.date);
            }
            else if (field === 'startDR')
            {
               
                //this.setDRStartDateDisableUntilTrailStartDate(date.date);
                d = event.value.split('/');
                date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);
                this.setDREndDateDisableUntil(date.date);

                //To set the drug regimen pair end date
                let days = 0; 
                if (this.assignRegimen != null) {
                    days = this.assignRegimen.days;
                    //else
                    //    days = this.getNumberOfDaysByRegimen(this.regimenIdOnrowclick);
                    if (days != 0) {
                        let drPairEndDate = this.trialService.GetDrugRegimenPairEndDate(this.formPair.value.startDateDrugRegimenPair.date, days);
                        this.formPair.controls['endDateDrugRegimenPair'].setValue(drPairEndDate);
                        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateDrugRegimenPairOptions);
                        copy.componentDisabled = true;
                        this.endDateDrugRegimenPairOptions = copy;
                    }
                }
                //End here
            }
            else if (field === 'endDR') {

                //this.setDRStartDateDisableUntilTrailStartDate(date.date);
            }
        }
    }

    public fileChange(input) {
        this.processContainersFile(input.target.files);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.form.dirty;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private setStartDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableUntil = date;
        this.startDateOptions = copy;
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }


    private setDRStartDateDisableSinceTrialEndDate(date) {
        //let d1 = this.convertDate(date).split('-');
        //let day1 = Number(d1[2]) - 1; //day
        //let date1 = this.dateForView(d1[0] + '-' + d1[1] + '-' + day1);//2018-4-12
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateDrugRegimenPairOptions);
        copy.disableSince = date;
        this.startDateDrugRegimenPairOptions = copy;
    }

    private setDREndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateDrugRegimenPairOptions);
        copy.disableUntil = date;
        this.endDateDrugRegimenPairOptions = copy;
    }

    private setDRStartDateDisableUntilTrailStartDate(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateDrugRegimenPairOptions);
        copy.disableUntil = date;
        this.startDateDrugRegimenPairOptions = copy;
    }

    private setDREndDateDisableSinceTrialEndDate(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateDrugRegimenPairOptions);
        copy.disableSince = date;
        this.endDateDrugRegimenPairOptions = copy;
    }

    //private setStartDateDrugRegimenPairDisableSince(date) {
    //    let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
    //    copy.disableSince = date;
    //    this.startDateDrugRegimenPairOptions = copy;
    //}

    //private setEndDateDrugRegimenPairDisableSince(date) {
    //    let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateDrugRegimenPairOptions);
    //    copy.disableSince = date;
    //    this.endDateDrugRegimenPairOptions = copy;
    //}

    private setEndDateDrugRegimenPairDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateDrugRegimenPairOptions = copy;
    }

    private setDrugRegimenPairs(): void {
        this.trial.drPairs.forEach((pair) => {
            this.drugRegimenPairs.push({
                id: pair.id,
                drug: pair.drug,
                regimen: { id: pair.regimen.id, name: pair.regimen.name },
                inUse: pair.inUse
            });
        });
    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {
           
            return (value <= 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    private processContainersFile(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                this.formAssignContainers.controls['containerNumbers'].setValue(result);
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

    private readFile(file, reader, callback) {
        let invalidFileMessage = 'Container numbers file must be a CSV';

        if (
            file.type &&
            file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel' && file.type !== 'application/csv'
        ) {
            return this.errorMessage = invalidFileMessage;
        }

        if (file.name.split('.').pop().toLowerCase() !== 'csv') {
            return this.errorMessage = invalidFileMessage;
        }

        reader.onload = () => {
            callback(reader.result.replace(/\r\n|\n/, '\n').replace(/[,;]+/g, ''));
        };

        reader.readAsText(file);
    }

    public viewTitrateDetails(patient): void {
        this.trialService
            .getPatientTitrateList(this.trial.id, this.customer.id, patient.id)
            .subscribe((patientContainerList) => this.trial.titrateList = this.patientTitrateList);

        

        this.viewTitrateModal.show();
    }

    public hideTitrateDetailsModal(): void {
        this.viewTitrateModal.hide();
    }

    public changePatientStatus(patient): void {
        this.patientToChangeStatus = patient;
        this.changeStatusModal.show();
    }

    public hideChangePatientStatusModal(): void {
        this.changeStatusModal.hide();
    }

    public viewHelpSection(): void {

        this.patientAlertsHelpModal.show();
    }

    public hideHelpSection(): void {

        this.patientAlertsHelpModal.hide();
    }

    //Code added by ramesh on 19th Dec 2017
    public confirmChangeStatusConfirmation(): void {
        this.isLoading = true;
        let patient = this.patientToChangeStatus;
        this.trialService
            .updatePatientStatus(this.trial.id, this.customer.id, patient.id)
            .subscribe(
            (response) => {
                this.isLoading = false;
                this.trialService.getPatients(this.trial.id, this.customer.id)
                    .subscribe((patients) => {
                        this.isLoading = false;
                        this.trial.patients = patients;
                        this.successMessage = patient.id + ' has been changed status successfully';
                        this.hideChangePatientStatusModal();
                    }
                    );
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    

    //Code added by ramesh on 4th Jan 2017
    public disassociateSite(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.SelectedsiteId = id;
        this.disassociateModal_Site.show();

    }

    public confirmDisassociateTrialGroup(trialGroup)
    {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        this.isLoading = true;
        let trialId = this.trial.id;
        let userId=Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'))
        let jsonString = "{\r\n     \"trailGroupTrailId\":" + this.selectedTrialGroupId + ",\r\n     \"userId\":" + userId +"\r\n}"
        //Uncomment when API is available
            this.trialService
                .disassociateTrialGroup(trialId, jsonString)
            .subscribe(
                (response) => {
                    this.isLoading = false;
                        //this.trialService.getAssociatedTrialGroupList(this.trial.id)
                        //.subscribe((associatedTrialGroups) => {
                        //    this.trial.associatedTrialGroups = associatedTrialGroups;
                          this.successMessage = 'TrialGroup has been disassociated to trial successfully';
                        //    this.hideChangePatientStatusModal();
                        //}
                        //);

                $("#datatable_associatedTrialGroupList").dataTable().fnDestroy();
                this.loadAssociateTrialGroupList();
                       
                
            },
            (err) => {
	    	this.isLoading = false;
                this.errorMessage = err;
                this.hideDeleteModal();
            }
        );

        this.successMessage = 'TrialGroup has been disassociated to trial successfully';
        this.hideDisassociateModal();
    }


    public confirmDisassociate_Site(site) {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        this.isLoading = true;
        let request = new DisassociateSiteRequest(

            Number(this.SelectedsiteId),
            Number(this.userId)
        );

        this.trialService
            .disassociateSite(this.SelectedsiteId, request)
            .subscribe(
            (response) => {
                this.isLoading = false;
                //this.trialService.getAssociatedSiteList(this.trial.id)
                //        .subscribe((associatedSites) => {
                //            this.trial.associatedSites = associatedSites;
                //         this.successMessage = 'Site has been disassociated from Associated List successfully';
                //            this.hideChangePatientStatusModal();
                //        }
                //        );

                $("#datatable_associatedSiteList").dataTable().fnDestroy();
                this.loadSiteList();


            },
            (err) => {
	    	this.isLoading = false;
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );

        this.successMessage = 'Site has been disassociated  successfully';
        this.hideDisassociateModal_Site();
    }


    
    public hideDisassociateModal(): void {
        //this.deleteType = null;
        //this.deleteObject = null;
        this.disassociateModal.hide();
    }

    public hideDisassociateModal_Site(): void {
        //this.deleteType = null;
        //this.deleteObject = null;
        this.disassociateModal_Site.hide();
    }

    public enableAddTrialGroupSection(): void {
        
        this.toggoleShowHide="visible"; 
    }

    public disableAddTrailSection(): void {

        this.toggoleShowHide = "hidden";
    }

    public enableAddSiteSection(): void {

        this.toggoleShowHide = "visible";
    }
    

    //28th Dec 2017
    public associateTrialGroup()
    {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.formAssociateTrialGroupform.invalid) {
            this.showErrors_FormAssociateTrialGroupform = true;
        } else {
            this.isLoading = true;
            let request = new TrailGroupAssociateRequest(
                Number(this.selectedTrialGroupId),
                Number(this.userId)
            );
            //un comment these lines when API is available
            this.trialService
                .associateTrialGroup(this.trial.id,  request)
                .subscribe(
                (response) => {
                    //this.trialService.getAssociatedTrialGroupList(this.trial.id)
                    //    .subscribe((associatedTrialGroups) => {
                    //        this.trial.associatedTrialGroups = associatedTrialGroups;
                    //        this.successMessage = 'TrialGroup has been successfully associated to trial';
                    //        this.hideChangePatientStatusModal();
                    //    }
                    //    );
                    this.isLoading = false;
                    this.successMessage = 'TrialGroup has been successfully associated to trial';

                    $("#datatable_associatedTrialGroupList").dataTable().fnDestroy();
                    this.loadAssociateTrialGroupList();

                    
                },
                (err) => {
		    this.isLoading = false;
                    this.errorMessage = err;
                }
                );
            //this.successMessage = 'Trial Group  has been successfully associated to trial';
        }

    }

    public addTrialGroupAndAssociateTrialGroup() {
        
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.addTrialGroupform.invalid) {
            this.showErrors_addTrialGroupform = true;
        } else {
            this.isLoading = true;
            let request = new TrialgroupAddAssociateRequest(
                this.addTrialGroupform.value.trialGroupName,
                Number(this.companyId),
                Number(this.userId)
                
               
            );

            //Uncomment this code when API is avialable
            this.trialService
                .addTrialGroupAndAssociateTrialGroup(this.trial.id, request)
                .subscribe(
                (response) => {
                    //this.form.markAsPristine();
                    this.isLoading = false;
                    //this.trialService.getAssociatedTrialGroupList(this.trial.id, this.customer.id)
                    //    .subscribe((associatedTrialGroups) => {

                    //        this.trial.associatedTrialGroups = associatedTrialGroups;
                            
                    //        this.successMessage = 'Trial Group has been successfully added and associated to a trial';
                    //        this.hideChangePatientStatusModal();
                    //        $("#datatable_associatedTrialGroupList").dataTable().fnDestroy();

                    //    }
                    //); 
                    this.successMessage = 'Trial Group has been successfully added and associated to a trial';
                    $("#datatable_associatedTrialGroupList").dataTable().fnDestroy();
                    this.loadAssociateTrialGroupList();
                    this.getTrialGroupList();
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                }
                );

            //this.successMessage = 'Trial Group has been successfully added and associated to a trial';
        }

    }


    public onSubmit_ForAssociateSite()
    {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        if (this.formAssociateSiteform.invalid) {
            this.showErrors_formAssociateSiteform = true;
        } else {
            this.isLoading = true;
            let request = new TrialgroupAssociateSiteRequest(

                //this.addTrialGroupform.value.trialGroupName,

                Number(this.SelectedsiteId),
                Number(this.userId)


            );

            //Uncomment this code when API is avialable
            this.trialService
                .associateSite(this.trial.id, request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.form.markAsPristine();
                    this.successMessage = 'Site has been successfully associated to a trial';
                    this.formAssociateSiteform.reset();
                    $("#datatable_associatedSiteList").dataTable().fnDestroy();
                    this.loadSiteList();

                },
                (err) => {
		    this.isLoading = false;
                    this.errorMessage = err;
                }
                );

            //this.successMessage = 'Site has been successfully associated to a trial';
        }

    }

    public onSubmit_PatientAlertsForm() {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        let preDoseAlertDurationDays = ((Number(this.patientAlertsForm.value.preDoseAlertDays * 24)) * 60);
        let preDoseAlertdurationHours = (Number(this.patientAlertsForm.value.preDoseAlertHours * 60));
        let preDoseAlertdurationMinutes = Number(this.patientAlertsForm.value.preDoseAlertMinutes);
        let preDoseAlertTime = preDoseAlertDurationDays + preDoseAlertdurationHours + preDoseAlertdurationMinutes;
        let thresholdDueAlertDurationDays = ((Number(this.patientAlertsForm.value.thresholdDueAlertDays * 24)) * 60);
        let thresholdDueAlertdurationHours = (Number(this.patientAlertsForm.value.thresholdDueAlertHours * 60));
        let thresholdDueAlertdurationMinutes = Number(this.patientAlertsForm.value.thresholdDueAlertMinutes);
        let thresholdDueAlertTime = thresholdDueAlertDurationDays + thresholdDueAlertdurationHours + thresholdDueAlertdurationMinutes;
        let thresholdWindowAlertDurationDays = ((Number(this.patientAlertsForm.value.thresholdWindowAlertDays * 24)) * 60);
        let thresholdWindowAlertdurationHours = (Number(this.patientAlertsForm.value.thresholdWindowAlertHours * 60));
        let thresholdWindowAlertdurationMinutes = (Number(this.patientAlertsForm.value.thresholdWindowAlertMinutes));
        let thresholdWindowAlertTime = thresholdWindowAlertDurationDays + thresholdWindowAlertdurationHours + thresholdWindowAlertdurationMinutes;



        if (this.patientAlertsForm.invalid) {
            this.showErrors_PatientAlertsForm = true;
        } else {
            this.isLoading = true;
            let request = new TrialPatientAlertsRequest(
                this.patientAlertsForm.value.preDoseAlert,
                preDoseAlertTime,
                this.patientAlertsForm.value.onTimeDoseAlert,
                this.patientAlertsForm.value.thresholdDueAlert,
                thresholdDueAlertTime,
                this.patientAlertsForm.value.thresholdWindow,
                thresholdWindowAlertTime,
                Number(this.userId)

            );
            this.preparePatientAlertsJsonString(
                this.patientAlertsForm.value.preDoseAlert,
                preDoseAlertTime,
                this.patientAlertsForm.value.onTimeDoseAlert,
                this.patientAlertsForm.value.thresholdDueAlert,
                thresholdDueAlertTime,
                this.patientAlertsForm.value.thresholdWindow,
                thresholdWindowAlertTime,
                Number(this.userId));
            //Uncomment this when API is available
            this.trialService
                .saveTrialPatientAlerts(this.trial.id, this.patientAlertJsonString)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.form.markAsPristine();
                    this.successMessage = 'Trial patient alerts have been successfully Saved';
                },
                (err) => {
		    this.isLoading = false;
                    this.errorMessage = err;
                }
                );

            //this.successMessage = 'Trial patient alerts have been successfully Saa';
        }
    }

    public enablePanel(chkType,textBox1Id, textBox2Id)
    {
        
        let flag = (<HTMLInputElement>document.getElementById(chkType)).checked;
        let checkBoxId = chkType
        
        if (flag==true) {
            
            //$('#' + textBox1Id).prop('disabled', false);
           
            $('#' + textBox1Id).removeAttr('disabled');
            $('#' + textBox2Id).prop('disabled', false);
            //(<HTMLInputElement>document.getElementById(textBox1Id)).disabled = false;
            //(<HTMLInputElement>document.getElementById(textBox2Id)).disabled = false;

            if (chkType == 'missedDose') {
                $('#pnlMissedDose').addClass('selected btn-group');

            }
            else if (chkType == 'overDose') {
                $('#pnlOverDose').addClass('selected btn-group');

            }
            else if (chkType == 'lateDose') {
                $('#pnlLateDose').addClass('selected btn-group');

            }
            else if (chkType == 'underDose') {
                $('#pnlUnderDose').addClass('selected btn-group');

            } 
            else if (chkType == 'excessiveManualDose') {
                $('#pnlExcessiveManualDose').addClass('selected btn-group');

            } 

        }
        else {
            //$('#' + textBox1Id).prop('disabled', true);
            $('#' + textBox1Id).attr('disabled', 'disabled');
            $('#' + textBox2Id).prop('disabled', true);
            //(<HTMLInputElement>document.getElementById(textBox1Id)).disabled = true;
            //(<HTMLInputElement>document.getElementById(textBox2Id)).disabled = false;
            if (chkType == 'missedDose') {
                $('#pnlMissedDose').removeClass('selected btn-group').addClass('btn-group');

            }
            else if (chkType == 'overDose') {
                $('#pnlOverDose').removeClass('selected btn-group').addClass('btn-group');

            }
            else if (chkType == 'lateDose') {
                $('#pnlLateDose').removeClass('selected btn-group').addClass('btn-group');

            }
            else if (chkType == 'underDose') {
                $('#pnlUnderDose').removeClass('selected btn-group').addClass('btn-group');

            } 
            else if (chkType == 'excessiveManualDose') {
                $('#pnlExcessiveManualDose').removeClass('selected btn-group').addClass('btn-group');

            } 

        }
        
    }


    //code for notification 5April2018

    public subscriptionNotification() {
        this.showErrors = false;
        this.errorMessage = "";
        this.errorMessage_PatientAlerts = "";
        this.enableErrorMsg();
        $('#errPnl_Notification').css('display', 'block');
       let notificationType ;
     
        if (this.subscribe_for_notificationForm.value.chkNotificationTypeEmail && this.subscribe_for_notificationForm.value.chkNotificationTypeSMS) {
            notificationType = 3;
        }
        else if (this.subscribe_for_notificationForm.value.chkNotificationTypeSMS) {
            notificationType = 2;
        }
        else if (this.subscribe_for_notificationForm.value.chkNotificationTypeEmail) {
            notificationType = 1;
        }
        //alert(this.subscribe_for_notificationForm.value.missedDoseOccurrence);
        //alert($('#missedDoseOccurrence').val());
        let missedDoseOccurrence = (this.subscribe_for_notificationForm.value.missedDoseOccurrence == null) ? $('#missedDoseOccurrence').val() : this.subscribe_for_notificationForm.value.missedDoseOccurrence;
        let overDoseOccurrence = (this.subscribe_for_notificationForm.value.overDoseOccurrence == null) ? $('#overDoseOccurrence').val() : this.subscribe_for_notificationForm.value.overDoseOccurrence;
        let lateDoseOccurrence = (this.subscribe_for_notificationForm.value.lateDoseOccurrence == null) ? $('#lateDoseOccurrence').val() : this.subscribe_for_notificationForm.value.lateDoseOccurrence;
        let underDoseOccurrence = (this.subscribe_for_notificationForm.value.underDoseOccurrence == null) ? $('#underDoseOccurrence').val() : this.subscribe_for_notificationForm.value.underDoseOccurrence;
        let excessiveManualDoseOccurrence = (this.subscribe_for_notificationForm.value.excessiveManualDoseOccurrence == null) ? $('#excessiveManualDoseOccurrence').val() : this.subscribe_for_notificationForm.value.excessiveManualDoseOccurrence;
        this.isLoading = true;
        //Code added on 1st June 2018
        let missedDoseChkValue = (this.subscribe_for_notificationForm.value.missedDose==true)?1:0;
        let overDoseChkValue = (this.subscribe_for_notificationForm.value.overDose == true) ? 1 : 0;
        let lateDoseChkValue = (this.subscribe_for_notificationForm.value.lateDose == true) ? 1 : 0;
        let underDoseChkValue = (this.subscribe_for_notificationForm.value.underDose == true) ? 1 : 0;
        let excessiveManualDoseChkValue = (this.subscribe_for_notificationForm.value.excessiveManualDose == true) ? 1 : 0;
        //End

        //Code added on 24th July 2018 to validate occurances value, if it is zero, then display validation error
        let isValid;
        isValid = true;
        if ((missedDoseChkValue == 1 && missedDoseOccurrence == 0) || (overDoseChkValue == 1 && overDoseOccurrence == 0)
            || (lateDoseChkValue == 1 && lateDoseOccurrence == 0) || (underDoseChkValue == 1 && underDoseOccurrence == 0)
            || (excessiveManualDoseChkValue == 1 && excessiveManualDoseOccurrence==0) )
        
        {

            isValid = false;
            this.errorMessage = "Please enter Occurrences value higher than zero";
            this.isLoading = false;
            $(window).scrollTop(5);
            $('#errPnl_Notification').css('display', 'block');
        }
        
        if (missedDoseChkValue == 0 && overDoseChkValue == 0
            && lateDoseChkValue == 0 && underDoseChkValue == 0
            && excessiveManualDoseChkValue == 0) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please select atleast one subscription";
            this.isLoading = false;
            $(window).scrollTop(5);
        }

        //End 24th July 2018

        if (isValid) {
            let request = new SubscriptionRequest(

                missedDoseChkValue,
                missedDoseOccurrence, //this.subscribe_for_notificationForm.value.missedDoseOccurrence,
                overDoseChkValue,
                overDoseOccurrence, //this.subscribe_for_notificationForm.value.overDoseOccurrence,
                lateDoseChkValue,
                lateDoseOccurrence, //this.subscribe_for_notificationForm.value.lateDoseOccurrence,
                underDoseChkValue,
                underDoseOccurrence, //this.subscribe_for_notificationForm.value.underDoseOccurrence,
                excessiveManualDoseChkValue,
                excessiveManualDoseOccurrence, //this.subscribe_for_notificationForm.value.excessiveManualDoseOccurrence,
                notificationType,

                this.userId
            );
            if (localStorage.getItem(String(this.trial.id) + "_notifications") == 'No trial notifications') {
                this.showErrors = false;
                this.errorMessage = "";
                this.enableErrorMsg();
                this.trialService.createNotifications(this.trial.id, request).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.formPair.markAsPristine();

                        this.successMessage = "successfully created Notifications ";
                        $(window).scrollTop(5);
                        //this.notification.reset();
                        localStorage.setItem(String(this.trial.id) + "_notifications", "Trial notifications exists");
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                        this.enableErrorMsg();
                        $('#errPnl_Notification').css('display', 'block');
                        $('.alert').css("display", "block");
                    });

            }
            else {
                this.showErrors = false;
                this.errorMessage = "";
                this.enableErrorMsg();
                this.trialService.updateNotifications(this.trial.id, request).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.formPair.markAsPristine();
                        this.showErrors = false;
                        this.errorMessage = "";
                        this.successMessage = "successfully Updated Notification";
                        $(window).scrollTop(5);
                        //this.notification.reset();

                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                        this.enableErrorMsg();
                        
                        $('#errPnl_Notification').css('display', 'block');
                        $('.alert').css("display", "block");

                    });

            }

        }

    }

    public preparePatientAlertsJsonString(preDoseAlertText, preDoseAlertTime, onTimeDoseAlert, thresholdDueAlert, thresholdDueAlertTime, thresholdWindow, thresholdWindowAlertTime, userId) {

        this.patientAlertJsonString = "{\r\n  \"preDoseAlertText\":\"" + preDoseAlertText + "\",\r\n    \"preDoseAlertTime\":" + preDoseAlertTime + ",\r\n    \"ontimeDoseAlertText\":\"" + onTimeDoseAlert + "\",\r\n    \"thresholdDueAlertText\":\"" + thresholdDueAlert + "\",\r\n    \"thresholdDueAlertTime\":" + thresholdDueAlertTime + ",\r\n    \"thresholdWindowAlertText\":\"" + thresholdWindow + "\",\r\n    \"thresholdWindowAlertTime\":\"" + thresholdWindowAlertTime + "\",\r\n    \"userId\":" + userId + "\r\n}";
    }


    public loadDrugRegimenPairList(): void {
        var self = this;
        let trialId = this.trial.id;
        //alert(trialId);
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_drugRegimenPair').DataTable({
                    "processing": false,
                    "serverSide": true,
                    "rowId": "drugregimenId",
                    'ajax': {
                        
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/pair/' + trialId,
                        'url': CommonService.API_PATH_V2_TRIAL_EDIT_DRUG_REGIMEN_PAIR_LIST+'trial/list/pair/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 7]
                            }
                            ,
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_EDIT_DRUG_REGIMEN_PAIR_LIST + 'trial/list/pair/' + trialId + '?draw=4&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=trialName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=TrialGroups&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Company&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=startDate&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=endDate&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $("input[type=search").val() +'&search%5Bregex%5D=false&_=15'
                                self.reportService.ExportAll(apiUrl, 'Drug Regimen Pair List');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5,6, 7]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "drugName" },
                        { "data": "RegimenName" },
                        { "data": "medicationType"},
                        { "data": "doseAmount" },
                        { "data": "measureDose" },
                        { "data": "doseStrength" },
                        { "data": "startDate" },
                        { "data": "endDate" },
                        { "data": "status" },
                        { "data": "drugregimenId" },
                        { "data": "isTitrated" },
                        { "data":"measureUnit"}
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                var endDate = new Date(full.endDate);
                                var todayDate = new Date();
                                var drugRegimenPairStatus = todayDate > endDate;
                                if (localStorage.getItem(trialId+"_ViewTrial") == undefined ) {


                                    if (full.isTitrated == 1)
                                        return "<div class=\"btn-action\"><button  id=\"" + full.drugregimenId + "_delete" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button><button  disabled title=\"Cannot Titrate as it is already titrated\" id=\"" + full.drugregimenId + "_titrate" + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Titrate</button>  </div>";
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button  disabled title=\"Cannot Delete this Drug Regimen Pair as it is deleted\"  id=\"" + full.drugregimenId + "_delete" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button><button  disabled title=\"Cannot Titrate this Drug Regimen Pair as it is deleted\"   id=\"" + full.drugregimenId + "_titrate" + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Titrate</button>  </div>";
                                    }
                                    else if (drugRegimenPairStatus == true) {
                                        return "<div class=\"btn-action\"><button  disabled title=\"Drug Regimen pair end date has been completed\"  id=\"" + full.drugregimenId + "_delete" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button><button  disabled title=\"Drug Regimen pair end date has been completed\"   id=\"" + full.drugregimenId + "_titrate" + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Titrate</button>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.drugregimenId + "_delete" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button><button   id=\"" + full.drugregimenId + "_titrate" + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-eye\" > </i> Titrate</button>  </div>";
                                    }
                                }
                                else if (localStorage.getItem(trialId + "_ViewTrial") != undefined && localStorage.getItem(trialId+"_ViewTrial") == 'ViewTrial') 
                                {
                                        return "";
                                }
                            }
                        }

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [9],
                            "visible": false
                        },
                        {
                            "targets": [10],
                            "visible": false
                        },
                        //{
                        //    "targets": [8],
                        //    render: function (data, type, row) {
                        //        return data == '1' ? 'Active' : 'Inactive'
                        //    }
                        //}
                       
                        {
                            "targets": [8],
                            render: function (data, type, full, meta) {
                                var endDate = new Date(full.endDate);
                                var todayDate = new Date();
                                var drugRegimenPairStatus = todayDate > endDate;
                                if (full.isTitrated == 1 || full.status == 0 || drugRegimenPairStatus==true)
                                    return 'Inactive'
                                else
                                    return 'Active'
                            }
                        },
                        {
                            "targets": [11],
                            "visible": false
                        },
                        {
                            "targets": [5],
                            render: function (data, type, full, meta) {
                                return full.doseStrength + full.measureUnit
                              
                            }
                        }
                    ]
                    , "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                    "initComplete": function (settings, json) {
                        //alert('DataTables has finished its initialisation.');
                        //alert(json.data[0].RegimenName);
                        // alert(JSON.parse(json.data[0]));
                        var myJSON = JSON.stringify(json.data);
                        this.DRList = myJSON;
                        //alert(this.DRList);
                        localStorage.setItem("DRList", json.data);
                        //alert(json.data[0].startDate);
                        //var JSONObject = JSON.parse("json.data");
                        //alert(JSONObject);

                        //alert(JSON.parse(myJSON));
                        //if (json.data[0] != undefined)
                        //    self.LoadDosageData(json.data[0].PatientID);
                    }
                });
            }
        });


        $('#datatable_drugRegimenPair tbody').on('click', 'td button', function () {
            //alert('hello');
            //alert($(this).attr('id'));
            //alert($('button').text());
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            //alert(buttonName);
            if (buttonName == "delete")
                self.deleteDrugRegimenPair(buttonId);
            if (buttonName == "titrate") {

                self.titrateDrugRegimenPair(buttonId);

            }


        });

        $('#datatable_drugRegimenPair tbody').on('click', 'tr', function (evt) {

            //if (!$(evt.target).is("button")) {
            //    var attId = $(this).attr('id');
            //    self.editDrugRegimen(attId);
            //}
            
            //var pairList;
            //if (localStorage.getItem("DRList") != undefined) {
            //    //alert(localStorage.getItem("DRList"));
            //    pairList = localStorage.getItem("DRList")
            //}
            ////alert(this.DRList);
            //alert(attId);
            //alert(this.DRList);
            //if (pairList != null && pairList != undefined) {
            //    //this.DRFilteredList = this.DRList.filter(DRList => DRList.drugregimenId === Number(attId));
            //    //this.DRFilteredList = this.DRList.filter(
            //    //    pair => pair.drugregimenId === Number(attId));
            //    //alert(this.DRList[0].drugregimenId);
            //    //alert(this.DRFilteredList[0].drugregimenId);
            //    pairList.forEach(function (x) {
            //        if (x.drugregimenId == attId)
            //        {
            //            //this.selectedDrug = x.drugName;
            //            //this.selectedRegimen = x.RegimenName;
            //            //this.selectedStartDate = x.startDate;
            //            //this.selectedEndDate = x.endDate;
            //            alert(x.drugName);
            //            $('#drug-selector').text(x.selectedDrug);
            //            $('#regimen-selector').text(x.selectedRegimen);
            //            $('#startDateDrugRegimenPair').val(x.startDate);
            //            $('#endDateDrugRegimenPair').val(x.endDate);
            //            $('#drugRegimenButton').text('Update');
            //            return;
            //        }
            //    });
            //}
            
        });


    }

    public editDrugRegimen(id): void {
        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        //alert(id);
        $(window).scrollTop(5);
        //let $datepicker = $('#startDateDrugRegimenPair');
        //$datepicker.datepicker();
        //alert(this.isEmailSelected_Final);
        //alert(this.isEmailSelected_Final);
        this.isEditDrugRegimenPair = true;
        //let isEmailSelected;
        //let isSMSSelected;
        //if (this.trial.trialNotifications.notificationType == '1') {
        //    isEmailSelected = true;

        //}

        //else if (this.trial.trialNotifications.notificationType == '2') {

        //    isSMSSelected = true;
        //}
        //else {

        //    isEmailSelected = true;
        //    isSMSSelected = true;
        //}
        this.drugRegimenPairId = id;
        this.isLoading = true;
        this.trialService.getSelectedDrugRegimenPair(this.drugRegimenPairId).subscribe(
            (response) => {
                this.isLoading = false;
                //alert(response.startDate);
                //alert(this.dateForView(response.startDate));
                //let createdDate = new Date();
                //let day = createdDate.getDate();
                //let month = createdDate.getMonth() + 1;
                //let year = createdDate.getFullYear();
                //let today = year + '-' + month + '-' + day;
                //$('#startDateDrugRegimenPair').text((response.startDate));
                //$datepicker.datepicker('setDate', new response.startDate);
                //$('#endDateDrugRegimenPair').val(this.dateForView(response.endDate));
                //$('#drug-selector').val(response.drugName);
                //this.formPair = this.fb.group({
                //    startDateDrugRegimenPair: [this.dateForView(response.startDate)]

                //});
               // alert(this.dateForView(today));
                //To convert dateformat from mm/dd/yyyy to yyyy-dd-mm
                //var startDate = this.trialService.convertDateToCalendarFormat(response.startDate); // response.startDate.split("/"); //ex: 03/31/2018
                //var endDate = response.endDate.split("/");
                $("#drug-selector").attr("disabled", "disabled"); 
                $("#regimen-selector").attr("disabled", "disabled"); 
                //$("#startDateDrugRegimenPair").attr("disabled", "disabled"); 
                let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateDrugRegimenPairOptions);
                copy.componentDisabled = true;
                this.startDateDrugRegimenPairOptions = copy;
                
                var drStartDate = this.trialService.convertDateToCalendarFormat(response.startDate); //startDate[2] + '-' + startDate[0] + '-' + startDate[1]; //2018-01-03
                var drEndDate = this.trialService.convertDateToCalendarFormat(response.endDate); //endDate[2] + '-' + endDate[0] + '-' + endDate[1]; //2018-31-03
                this.formPair = this.fb.group({
                    drug: [response.drugName, Validators.required],
                    regimen: [response.regimenName, Validators.required],
                    //expiryDate: [this.dateForView(today), Validators.required],
                    startDateDrugRegimenPair: [this.dateForView(drStartDate), Validators.required],
                    endDateDrugRegimenPair: [this.dateForView(drEndDate), Validators.required],
                    thresholdWindow: [this.patientAlert.thresholdWindowAlertText],
                    //missedDose: [this.trial.trialNotifications.missedDose],
                    //txtMissedDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[0].message : this.notificationList[0].message],
                    //missedDoseOccurrence: [this.trial.trialNotifications.missedDoseOccurances],
                    //overDose: [this.trial.trialNotifications.overDose],
                    //txtOverDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[1].message : this.notificationList[1].message],
                    //overDoseOccurrence: [this.trial.trialNotifications.overDoseOccurances],
                    //lateDose: [this.trial.trialNotifications.lateDose],
                    //txtLateDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[2].message : this.notificationList[2].message],
                    //lateDoseOccurrence: [this.trial.trialNotifications.lateDoseOccurances],
                    //underDose: [this.trial.trialNotifications.underDose],
                    //txtUnderDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[3].message : this.notificationList[3].message],
                    //underDoseOccurrence: [this.trial.trialNotifications.underDoseOccurances],
                    //excessiveManualDose: [this.trial.trialNotifications.excessiveManualDose],
                    //txtExcesManualDose: [(this.trial.trialNotifications.missedDose == undefined) ? this.trial.trialNotifications[4].message : this.notificationList[4].message],
                    //excessiveManualDoseOccurrence: [this.trial.trialNotifications.excessiveManualDoseOccurances],
                    //NotificationTypeEmail: [this.trialNotifications[0].notificationType],
                   
                });

                //10th Aug 2018, to set end date based on number of days, disable end date on row click

                this.regimenIdOnrowclick = this.getNumberOfDaysByRegimen(response.regimenid);
                //let drPairEndDate = this.trialService.GetDrugRegimenPairEndDate(this.formPair.value.startDateDrugRegimenPair.date, days);
                //this.formPair.controls['endDateDrugRegimenPair'].setValue(drPairEndDate);
                //let copyDrpairEndDate: IMyOptions = this.getCopyOfDateOptions(this.endDateDrugRegimenPairOptions);
                //copyDrpairEndDate.componentDisabled = true;
                //this.endDateDrugRegimenPairOptions = copyDrpairEndDate;
                //End
            },
            (err) => {
	    	this.isLoading = false;
                this.errorMessage = err;

            });
        $('#drugRegimenButton').text('Update');

      

    }

    public deleteDrugRegimenPair(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        //this.deleteType === 'drug/regimen pair';
        this.selectedDrugRegimenPairId = id;
        //this.deleteModal.show();
        this.deleteModalDRPair.show();
    }

    public deletePatient(id): void {
       // alert(id);
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        //this.deleteType === 'drug/regimen pair';
        //this.selectedDrugRegimenPairId = id;
        //this.deleteModal.show();
        this.selectedPatientNumber = id;
        this.deletePatientModal.show();
    }

    public titrateDrugRegimenPair(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.deleteType == 'titrate';
        //this.deleteModal.show();
        this.titrateModal.show();
        this.selectedDrugRegimenPairId = id;
        this.isTitrated=true;
    }


    public loadTrialPatientList(): void {


        var self = this;
        let trialId = this.trial.id;
        //alert(trialId);
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert("Testing Load patient");
                $('#datatable_TrialPatientsList').DataTable({
                    "processing": false,
                    "serverSide": true,
                    "rowId": "PatientID",
                    'ajax': {
                        
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trailpatients/' + trialId,
                        'url': CommonService.API_PATH_V2_TRIAL_EDIT_TRIAL_PATIENT_LIST+'trial/list/trailpatients/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export',exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6,7]
                            },

                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_EDIT_TRIAL_PATIENT_LIST + 'trial/list/trailpatients/' + trialId + '?draw=2&columns%5B0%5D%5Bdata%5D=trailGroupName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=createdBy&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=createdDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=id&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=trailCount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('#datatable_TrialPatientsList_filter input[type="search"]').val() +'&search%5Bregex%5D=false&_=1525343677314'
                                //let apiUrl = CommonService.API_PATH_V2_TRIAL_EDIT_TRIAL_PATIENT_LIST + 'trial/list/trailpatients/' + trialId + '?draw=7&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=age&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=false&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=Sex&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=false&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Race&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=false&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=FirstScan&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=false&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=LastScan&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=false&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=Containers&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=titrate&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=false&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() + '&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=status&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=false&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=' + $('input[type = "search"]').val() +'&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1534394284115'
                                self.reportService.ExportAll(apiUrl, 'Trial Patient List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7]
                            } }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "PatientID" },
                        { "data": "age" },
                        { "data": "Sex" },
                        { "data": "Race" },
                        { "data": "FirstScan" },
                        { "data": "LastScan" },
                        {
                            "data": "Containers"
                            ,
                            "render": function (data, type, full, meta) {
                                
                                if (full.Containers == null) {
                                    return '0';
                                }
                                else {
                                    return '<div class="tooltip1" ><u>' + full.Containers + '</u><span id="spnSpanTooltip_' + full.PatientID.replace(" ", "_") + '" class="tooltiptext"  >' + self.loadTrailPatientContainer(full.PatientID, '') + '</span></div>';
                                }
                            }
                        },
                        //{ "data": "titrate" },
                        {
                            "data": "titrate"
                            ,
                            "render": function (data, type, full, meta) {
                                //return '<u>' + full.titrate + '</u>';

                                let topValue = full.titrate.split('/')[0];
                                let bottomValue = full.titrate.split('/')[1];
                                if (topValue == 'None' && bottomValue == 'None') {
                                    let nulltopValue = 0;
                                    let nullbottomValue = 0;
                                    return '<u style=\"cursor:pointer;\"><span class=\"red\">' + nulltopValue + '</span> /' + nullbottomValue + '</u>';
                                }
                                else if (topValue == bottomValue) {
                                   // $('td', row).eq(7).css('color', 'green');
                                    return '<u style=\"cursor:pointer;\"><span class=\"green\">' + topValue + '</span> /' + bottomValue +'</u>';
                                    
                                }
                                else {
                                    return '<u style=\"cursor:pointer;\"><span class=\"red\">' + topValue + '</span> /' + bottomValue + '</u>';
                                    //$('td', row).eq(7).css('color', 'red');
                                    //$('td', row).eq(7).text().split('/')[0].css('color', 'red')
                                    //$('td', row).eq(9).text($('td', row).eq(7).text().split('/')[0].css('color', 'red'))
                                    //$('td', row).eq(7).text(document.body.innerHTML += "<span style=\"color:red\">" +
                                    //    topValue + "</span>/" + bottomValue);
                                }
                            }

                        },
                        { "data": "status" },
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                if (localStorage.getItem(trialId + "_ViewTrial") == undefined) {
                                    if (full.status == 1 || full.status == null) {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.PatientID + "_deletePatient" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button>  </div></div>";

                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this Patient  as it is already deleted \"  disabled id=\"" + full.PatientID + "_deletePatient" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button>  </div></div>";

                                    }
                                    //else if (full.status == null)
                                    //{
                                    //    return "<div class=\"btn-action\"><button title=\"Cannot Delete this Patient  as it is already Pending \"  disabled id=\"" + full.PatientID + "_deletePatient" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button>  </div></div>";
                                    //}
                                }
                                else if (localStorage.getItem(trialId + "_ViewTrial") != undefined && localStorage.getItem(trialId + "_ViewTrial") == 'ViewTrial') {
                                    return "";
                                }
                            }
                        }


                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [8],
                            "orderable": true,
                            render: function (data, type, row) {
                                if (data == '1') {
                                    return 'Active'
                                }
                                else if (data == null) {
                                    return 'Pending'
                                }
                                else {
                                    return 'Inactive'
                                }
                            }
                        },
                        {
                            "targets": [6],
                            "orderable": true,
                        },
                        {
                            "targets": [3],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        },
                        {
                            "targets": [2],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [1],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == 0 ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [4],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                        ,
                        {
                            "targets": [5],
                            "orderable": true,
                            render: function (data, type, row) {
                                return data == null ? '-' : data
                            }
                        }
                        ,

                        {
                            "targets": [7],
                            "orderable": true,
                        }
                        
                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    "createdRow": function (row, data, index) {
                        //let topValue = $('td', row).eq(7).text().split('/')[0];
                        //let bottomValue = $('td', row).eq(7).text().split('/')[1];
                        //if (topValue == bottomValue)
                        //{
                        //    $('td', row).eq(7).css('color', 'green');


                        //}
                        //else
                        //{
                        //    $('td', row).eq(7).css('color', 'red');
                        //    //$('td', row).eq(7).text().split('/')[0].css('color', 'red')
                        //    //$('td', row).eq(9).text($('td', row).eq(7).text().split('/')[0].css('color', 'red'))
                        //    //$('td', row).eq(7).text(document.body.innerHTML += "<span style=\"color:red\">" +
                        //    //    topValue + "</span>/" + bottomValue);
                        //}
                        
                    }

                });
            }
        });

        //$('#datatable_TrialPatientsList tbody').on("click", 'tr td:eq(7)', function () {
        $('#datatable_TrialPatientsList tbody').on("click", 'td:nth-child(8)', function () {
            //var data = $('#datatable_TrialPatientsList').row(this).data();
            //alert(data.PatientID);
            //var attId = $(this).attr('id');
            var attId =this.parentNode.id;
            //alert($(this).attr('id'));
            //self.loadTrialTitrateDetails($(this).attr('id'));
            self.isLoading = true;
            self.loadTrialTitrateDetails(attId);
            var table = $('#datatable_TrialPatientsList').DataTable();
            //alert('Clicked on cell column: ' + table.cell(this).index().column + ' and row: ' + table.cell(this).index().row);
        });

        $('#datatable_TrialPatientsList tbody').on("click", 'td:nth-child(7) ', function () {
            //var data = $('#datatable').row(this).data();
            //alert(data.firstName);
            var attId = this.parentNode.id;
            //alert(attId);
           // return self.loadTrailPatientContainer(attId,'');
        });

        

        //$('#datatable_TrialPatientsList').
        //    on('mouseover', 'td:nth-child(7) ', function (evt) {
        //        alert($(evt.target).is("span"));
        //        alert($(evt.target).is("button"));
        //        alert($(evt.target).is("link"));
        //        alert($(evt.target).is("pointer"));
        //        alert($(evt.target).id);
        //       // jQuery(this).find('span:first').show();
        //        var attId = this.parentNode.id;
        //        //this.viewContainerDetailsModal.show();
        //        //<div class="tooltiptext" > Tooltip text< /div>
        //        self.loadTrailPatientContainer(attId, '');
        //        self.isLoading = false;
               
        //    }).
        //    on('mouseout','td:nth-child(7) ', function () {
        //        $('#pnlContainers').css('display', 'none');
        //    });

        //Code added on 2nd july 2018 to delete a patient from edit trial patient list
        $('#datatable_TrialPatientsList tbody').on('click', 'td button', function () {
            //alert('hello');
            //alert($(this).attr('id'));
            //alert($('button').text());
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            //alert(buttonName);
            if (buttonName == "deletePatient")
                self.deletePatient(buttonId);
           


        });
    }

    public confirmPatientDelete()
    {


        this.showErrors = false;
        this.errorMessage = "";
        this.enableErrorMsg();
        this.isLoading = true;
        //let request = new DisassociateSiteRequest(

        //    Number(this.SelectedsiteId),
        //    Number(this.userId)
        //);
       // alert('confirm');
        this.trialService
            .deletePatient(this.selectedPatientNumber, Number(this.trial.companyId),Number(this.trial.id))
            .subscribe(
            (response) => {
                this.isLoading = false;
                //this.trialService.getAssociatedSiteList(this.trial.id)
                //        .subscribe((associatedSites) => {
                //            this.trial.associatedSites = associatedSites;
                //         this.successMessage = 'Site has been disassociated from Associated List successfully';
                //            this.hideChangePatientStatusModal();
                //        }
                //        );
                this.successMessage = 'Patient has been deleted  successfully';
                $("#datatable_TrialPatientsList").dataTable().fnDestroy();
                this.loadTrialPatientList();
                

            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;
                this.hidedeletePatientModal();
            }
            );

        
        this.hidedeletePatientModal();
    }

    public loadTrailPatientContainer(id,data): void {
        let finalContainerString = '';
        let containerIds = '';
        let trialId = this.trial.id;
        let patientId = id;
        //alert(patientId);
        this.isLoading = true;
        this.trialService.getTrailPatientContainerDetails(trialId, patientId).subscribe(
            (response) => {
                this.isLoading = false;
                //this.patientTitrateList = response;
                this.containerDetailsList = response;
                //this.viewContainerDetailsModal.show();
                //$('#pnlContainers').css('display', 'block');
                // this.viewTitrateModal.show();
                if (this.containerDetailsList != undefined) {
                    //alert('ented');
                    this.containerDetailsList.forEach((item, index) => {
                        //alert(this.containerDetailsList[index].ContainerId);
                        if (containerIds == undefined) {
                            containerIds  = this.containerDetailsList[index].ContainerId.split('_')[3];
                        }
                        else {
                            containerIds = containerIds + '\n' + this.containerDetailsList[index].ContainerId.split('_')[3];

                        }
                    });
                    
                    if (containerIds != "undefined")
                    {
                        
                        $("#spnSpanTooltip_" + id.replace(" ","_")).html(containerIds);
                    }
                    else
                    {
                        $("#spnSpanTooltip_" + id).html("");
                    }

                    //$("#spnSpanTooltip_" + id).attr('title', containerIds);
                    //$("#spnSpanTooltip_" + id).attr('matTooltip', containerIds);
                }
                else {
                    $("#spnSpanTooltip_" + id.replace(" ", "_")).html("");
                }

            

            });
        //alert(this.containerIds);
        //finalContainerString = '<span data-toggle="tooltip" title="vvvvv' + this.containerIds  + '">' + data + '</span>';
        //return finalContainerString;

    }


    public loadTrialTitrateDetails(id): void {

        this.isLoading = true;
        //alert(iD);
        //alert("LoadLabelData Entered");
        let trialId = this.trial.id;
        //let patientId = 'Pat456688';
        let patientId = id;

        this.trialService.getTitrateDetails(trialId, patientId).subscribe(
            (response) => {
                this.isLoading = false;

                this.patientTitrateList = response;
                //To set the image
                
                        if (this.patientTitrateList != null) {
                            for (var i = 0; i < this.patientTitrateList.length; i++) {
                                //alert(this.patientTitrateList[i].bucket);
                                if (this.patientTitrateList[i].bucket != null) {

                                    //this.SetAndValidateImageUrl("https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/" + this.patientTitrateList[i].bucket, "imgDiv_" + i);
                                    this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.patientTitrateList[i].bucket, "imgDiv_" + i);

                                }
                                else {
                                    
                                    $("#imgDiv_" + i).attr("src", "../../../assets/images/medication-type-default.png");

                                }
                            }

                        }

                 //End to set the image
                this.viewTitrateModal.show();
            },
            (err) => {
                this.errorMessage = err;

            });


    }

    public loadTrialContainers(): void {

        //NoAPI
        let trialId = this.trial.id;
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_UsedContainers').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/containers/' + trialId,
                        'url': CommonService.API_PATH_V2_TRIAL_EDIT_TRIAL_CONTAINERS_LIST+'trial/list/containers/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 4]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_EDIT_TRIAL_CONTAINERS_LIST + 'trial/list/containers/' + trialId + '?draw=2&columns%5B0%5D%5Bdata%5D=userId&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=firstName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=lastName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=email&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=phoneNumber&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=role&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=logintime&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=sub&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('#datatable_UsedContainers_filter input[type="search"]').val() + '&search%5Bregex%5D=false&_=1535032103296'
                                self.reportService.ExportAll(apiUrl, 'Trial Containers');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0,1, 2, 3, 4, 5, 6]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "containerId" },
                        {"data":"patientId"},
                        { "data": "doseType" },
                        { "data": "remainingDoses" },
                        { "data": "remainingDoseUnits" },
                        { "data": "start" },
                        { "data": "end" },
                        { "data": "status" }
                      
                    ]
                    ,
                    "columnDefs": [

                       
                        {
                            "targets": [7],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }
                    ,
                         {
                            "targets": [0],
                            render: function (data, type, row) {
                                return data.split('_')[3];
                            }
                        }


                    ]
                    ,"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                });
            }
        });

       

    }

    public loadAssociateTrialGroupList(): void{

        //API 
        let trialId = this.trial.id;
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup/{id}

        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_associatedTrialGroupList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/trialgroup/' + trialId,
                        'url': CommonService.API_PATH_V2_TRIAL_EDIT_ASSOCIATE_TRIALGROUP_LIST+'trial/list/trialgroup/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_EDIT_ASSOCIATE_TRIALGROUP_LIST + 'trial/list/trialgroup/' + trialId + '?draw=1&columns%5B0%5D%5Bdata%5D=siteName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=siteAdress&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=countryName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=phoneNumber&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=id&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('#datatable_associatedTrialGroupList_filter input[type="search"]').val() + '&search%5Bregex%5D=false&_=1536064422278'
                                self.reportService.ExportAll(apiUrl, 'Associate Group List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "trialGroupName" },
                        { "data": "createdBy" },
                        { "data": "createdDate" },
                        { "data": "id" },
                        {"data":"status"}

                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                if (localStorage.getItem(trialId + "_ViewTrial") == undefined) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button disabled title=\"Cannot Disassociate this Trialgroup as it is already disassociated\" id=\"" + full.id + "_disassociate" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Disassociate</button> </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.id + "_disassociate" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Disassociate</button> </div>";
                                    }
                                }
                                else if (localStorage.getItem(trialId + "_ViewTrial") != undefined && localStorage.getItem(trialId + "_ViewTrial") == 'ViewTrial') {
                                    return "";
                                }
                            }
                        }
                        

                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    "columnDefs": [

                        {
                            "targets": [3],
                            "visible": false
                        },
                        {
                            "targets": [4],
                            "visible": false
                        }

                    ]
                });
            }
        });

        $('#datatable_associatedTrialGroupList tbody').on('click', 'td button', function () {
           
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];

            if (buttonName == "disassociate")
                self.disassociateTrialGroup(buttonId);
            


        });
    }

    //Code added by ramesh on 27th Dec 2017
    public disassociateTrialGroup(id): void {
        //deleteObject.index = index;
        //this.deleteType = deleteType;
        //this.deleteObject = deleteObject;
        this.selectedTrialGroupId = id;
        this.disassociateModal.show();
    }

    public loadSiteList(): void {
        let trialId = this.trial.id;
        var self = this;
        //https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/site/{id} localStorage.getItem('GLOBAL_COMPANY_ID')

        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                //alert(this.authorizationToken);
                $('#datatable_associatedSiteList').DataTable({
                    "processing": true,
                    "serverSide": true,
                    'ajax': {
                        
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/site/' + trialId,
                        'url': CommonService.API_PATH_V2_TRIAL_EDIT_ASSOCIATE_SITE_LIST+'trial/list/site/' + trialId,
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_EDIT_ASSOCIATE_SITE_LIST + 'trial/list/site/' + trialId + '?draw=1&columns%5B0%5D%5Bdata%5D=siteName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=siteAdress&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=countryName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=phoneNumber&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=id&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('#datatable_associatedSiteList_filter input[type="search"]').val() + '&search%5Bregex%5D=false&_=1536064422278'
                                self.reportService.ExportAll(apiUrl, 'Associate Site');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3]
                            }}

                    ],
                    "order": [[0, "desc"]],
                    "columns": [

                        { "data": "siteName" },
                        { "data": "siteAdress" },
                        { "data": "countryName" },
                        { "data": "phoneNumber" },
                        { "data": "id" },
                        //{ "data": "female" },
                        //{ "data": "containers" },
                        { "data": "status" }
                        //{ "data": "Id" }
                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                if (localStorage.getItem(trialId + "_ViewTrial") == undefined) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button  disabled title=\"Cannot Disassociate this Site as it is already disassociated\"  id=\"" + full.id + "_disassociate" + "\" class=\"btn btn-danger btn-xs\" ><i class=\"fa fa-trash-o\" > </i> Disasscociate</button> </div>";
                                    }
                                    return "<div class=\"btn-action\"><button  id=\"" + full.id + "_disassociate" + "\" class=\"btn btn-danger btn-xs\" ><i class=\"fa fa-trash-o\" > </i> Disasscociate</button> </div>";
                                }
                                else if (localStorage.getItem(trialId + "_ViewTrial") != undefined && localStorage.getItem(trialId + "_ViewTrial") == 'ViewTrial')
                                {
                                    return "";
                                }
                            }
                        }

                    ],
                    "columnDefs": [

                        {
                            "targets": [4],
                            "visible": false
                        },
                        {
                            "targets": [5],
                            "visible": false
                        },
                        //{
                        //    "targets": [7],
                        //    render: function (data, type, row) {
                        //        return data == '1' ? 'Active' : 'Inactive'
                        //    }
                        //}
                    ]
                    ,"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                });
            }
        });
        $('#datatable_associatedSiteList tbody').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            if (buttonName == "disassociate")
                self.disassociateSite(buttonId);



        });

    }

    private convertMinutes(totalMinutes: number): any {
        let minsPerDay = 24 * 60;
        let minsPerHour = 60;
        let minutes = totalMinutes;
        let converted = { days: null, hours: null, minutes: null };

        let days = Math.floor(minutes / minsPerDay);
        converted.days = days;
        minutes = minutes - days * minsPerDay;
        let hours = Math.floor(minutes / minsPerHour);
        converted.hours = hours;
        minutes = minutes - hours * minsPerHour;
        converted.minutes = minutes;

        return converted;
    }


    enableAndDisableCSS(controlId,selectedValue)
    {
        //alert(selectedValue);
        if (selectedValue==false)
            $("#" + controlId).removeClass("btn-group selected").addClass("btn-group");
        else
            $("#" + controlId).removeClass("btn-group").addClass("btn-group selected");
    }


    isValidDrug(drugName): boolean
    {
        let flag= true;
        
        this.drugsFiltered = this.drugs.filter(
            drugs => drugs.name === drugName)
        if (this.drugsFiltered.length == 0)
            flag = false;
        return flag;
    }


    isValidRegimen(regimenName): boolean {
        let flag = true;

        this.regimensFiltered = this.regimens.filter(
            regimens => regimens.name === regimenName)
        if (this.regimensFiltered.length == 0)
            flag = false;
        return flag;
    }

    changeCSS(chkType)
    {
        let flag = (<HTMLInputElement>document.getElementById(chkType)).checked;
        let checkBoxId = chkType

        if (flag == true) {
            $('#pnlTurnOffPanel').removeClass('btn-group').addClass('btn-group selected');
        }
        else {
            $('#pnlTurnOffPanel').removeClass('btn-group selected').addClass('btn-group');
        }

    }


    SetAndValidateImageUrl(url, imageId): void {
        //alert(imageId);
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            //alert(" Image Exists...!");
            //flag = true;
        }).on("error ", function () {
            //alert("ERROR");
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            //flag = false;

        });
        //return flag;

    }

    getNumberOfDaysByRegimen(regimenId):number
    {

        let numberOfDays = 0;
        if (this.regimens!= null) {
            for (var i = 0; i < this.regimens.length; i++) {
                if (this.regimens[i].id == regimenId) {
                    numberOfDays = this.regimens[i].days;
                }
            }

        }

        return numberOfDays;
    }

    clearPairData()
    {


        $("#drug-selector,#regimen-selector,#startDateDrugRegimenPair").val("");
        this.formPair.controls['startDateDrugRegimenPair'].setValue("");
        var trialEndDate = (this.trial.end_date != null) ? this.trialService.convertDateToCalendarFormat(this.trial.end_date) : '';
        this.formPair.controls['endDateDrugRegimenPair'].setValue(this.dateForView(trialEndDate));
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateDrugRegimenPairOptions);
        copy.componentDisabled = false;
        this.endDateDrugRegimenPairOptions = copy;
    }

    clearErrorMessage()
    {
       
        this.showErrors = false;
        this.errorMessage = "";
        $('.alert').css("display", "none");
        
    }

    isValidNumber(val): boolean
    {

        if (val < 0)
            return false;
        else if (val > 100)
            return false;
        else
            return true;

    }
    
}
